import React, { useState, useMemo } from 'react';
import {
  X,
  Plus,
  Minus,
  Trash2,
  ShoppingBag,
  User,
  Search,
  AlertCircle,
  Coffee,
  Gamepad2,
  CheckCircle2,
  CreditCard,
  Banknote,
  Percent,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import {
  CafeteriaItem,
  CafeteriaCategory,
  PaymentTransaction,
  PaymentMethod,
  PaymentStatus,
} from '../../types';
import { CafeteriaPaymentSection, CafeteriaPaymentData } from './CafeteriaPaymentSection';

interface CreateCafeteriaOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenReceiptModal?: (transaction: PaymentTransaction) => void;
}

interface OrderItemEntry {
  item: CafeteriaItem;
  quantity: number;
}

const CATEGORIES: ('All' | CafeteriaCategory)[] = [
  'All',
  'Snacks',
  'Beverages',
  'Fast Food',
  'Energy Drinks',
  'Desserts',
  'Combos',
  'Other',
];

export const CreateCafeteriaOrderModal: React.FC<CreateCafeteriaOrderModalProps> = ({
  isOpen,
  onClose,
  onOpenReceiptModal,
}) => {
  const {
    cafeteriaItems,
    customers,
    sessions,
    settings,
    currentUser,
    createCafeteriaOrder,
  } = useCafe();

  // 1. Customer Selection State
  const [customerMode, setCustomerMode] = useState<'registered' | 'walk_in'>('registered');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [walkInName, setWalkInName] = useState<string>('');
  const [walkInPhone, setWalkInPhone] = useState<string>('');
  const [customerError, setCustomerError] = useState<string | null>(null);

  // 2. Item Catalog & Filter State
  const [itemSearchQuery, setItemSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | CafeteriaCategory>('All');

  // 3 & 4. Selected Items (Cart / Quantity)
  const [orderItems, setOrderItems] = useState<OrderItemEntry[]>([]);
  const [itemsError, setItemsError] = useState<string | null>(null);

  // 5. Total & Discount
  const [discountInput, setDiscountInput] = useState<string>('0');

  // 6 & 7. Payment Selection & Split Payment Data
  const [paymentData, setPaymentData] = useState<CafeteriaPaymentData>({
    paymentMode: 'single',
    paymentMethod: 'cash',
    paidAmount: 0,
    remaining: 0,
    paymentStatus: 'paid',
    isValid: true,
  });

  // Notes & Submission
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Available Items Filter
  const availableItems = useMemo(() => {
    return cafeteriaItems.filter((item) => {
      const matchesCat = selectedCategory === 'All' || item.category === selectedCategory;
      const matchesSearch =
        item.name.toLowerCase().includes(itemSearchQuery.toLowerCase()) ||
        (item.description && item.description.toLowerCase().includes(itemSearchQuery.toLowerCase()));
      return matchesCat && matchesSearch;
    });
  }, [cafeteriaItems, selectedCategory, itemSearchQuery]);

  // Calculations
  const subtotal = useMemo(() => {
    return orderItems.reduce((acc, entry) => acc + entry.item.price * entry.quantity, 0);
  }, [orderItems]);

  const discountAmount = Math.max(0, parseFloat(discountInput) || 0);
  const netTotal = Math.max(0, subtotal - discountAmount);

  if (!isOpen) return null;

  // Handlers for Add/Remove & Quantity
  const handleAddItem = (item: CafeteriaItem) => {
    setItemsError(null);
    setGeneralError(null);

    if (!item.isAvailable || item.stockQuantity <= 0) {
      setItemsError(`"${item.name}" is currently out of stock or unavailable.`);
      return;
    }

    setOrderItems((prev) => {
      const existing = prev.find((entry) => entry.item.id === item.id);
      if (existing) {
        if (existing.quantity >= item.stockQuantity) {
          setItemsError(`Cannot add more "${item.name}". Only ${item.stockQuantity} available in inventory.`);
          return prev;
        }
        return prev.map((entry) =>
          entry.item.id === item.id ? { ...entry, quantity: entry.quantity + 1 } : entry
        );
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (itemId: string, newQuantity: number) => {
    setItemsError(null);
    setGeneralError(null);

    if (newQuantity <= 0) {
      handleRemoveItem(itemId);
      return;
    }

    const currentItem = cafeteriaItems.find((i) => i.id === itemId);
    if (currentItem && newQuantity > currentItem.stockQuantity) {
      setItemsError(`Only ${currentItem.stockQuantity} in stock for "${currentItem.name}".`);
      return;
    }

    setOrderItems((prev) =>
      prev.map((entry) =>
        entry.item.id === itemId ? { ...entry, quantity: newQuantity } : entry
      )
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setOrderItems((prev) => prev.filter((entry) => entry.item.id !== itemId));
  };

  // Quick preset: Select Active Gaming Console Player
  const handleSelectActivePlayer = (session: { customerId: string; customerName: string; consoleCode: string }) => {
    setCustomerMode('registered');
    setSelectedCustomerId(session.customerId);
    setCustomerError(null);
    setOrderNotes(`Deliver to console ${session.consoleCode}`);
  };

  // Order Submission
  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setCustomerError(null);
    setItemsError(null);
    setGeneralError(null);

    // 1. Validate Customer
    let finalCustomerId = '';
    let finalCustomerName = '';
    let finalCustomerPhone: string | undefined = undefined;

    if (customerMode === 'registered') {
      if (!selectedCustomerId) {
        setCustomerError('Please select a customer from the list.');
        return;
      }
      const found = customers.find((c) => c.id === selectedCustomerId);
      if (!found) {
        setCustomerError('Selected customer not found. Please re-select.');
        return;
      }
      finalCustomerId = found.id;
      finalCustomerName = found.name;
      finalCustomerPhone = found.phone;
    } else {
      // Walk-in
      if (!walkInName.trim()) {
        setCustomerError('Customer name is required for walk-in orders.');
        return;
      }
      finalCustomerId = 'walk_in';
      finalCustomerName = walkInName.trim();
      finalCustomerPhone = walkInPhone.trim() || undefined;
    }

    // 2. Validate Items
    if (orderItems.length === 0) {
      setItemsError('Please select at least one cafeteria item.');
      return;
    }

    // Validate Stock Limit for each
    for (const entry of orderItems) {
      const freshItem = cafeteriaItems.find((i) => i.id === entry.item.id);
      if (!freshItem || freshItem.stockQuantity < entry.quantity) {
        setItemsError(
          `Insufficient stock for "${entry.item.name}". Only ${
            freshItem ? freshItem.stockQuantity : 0
          } units available.`
        );
        return;
      }
    }

      // 3. Payment Method & Split Validation
    const paymentMethod: PaymentMethod = paymentData.paymentMethod;
    const paidAmount = paymentData.paidAmount;
    const splitPayments = paymentData.splitPayments;
    const paymentStatus: PaymentStatus =
      paidAmount >= netTotal ? 'paid' : 'pending';

    // Verify consistency
    console.log(`[Cafeteria] Preparing order for ${finalCustomerName}. Total: ${netTotal}, Paid: ${paidAmount}, Status determined as: ${paymentStatus}`);

    // Payment cannot exceed total bill
    if (paidAmount > netTotal) {
      setGeneralError(
        `Payment amount (${settings.currencySymbol} ${paidAmount}) cannot exceed total bill (${settings.currencySymbol} ${netTotal}).`
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        customerId: finalCustomerId,
        customerName: finalCustomerName,
        customerPhone: finalCustomerPhone,
        items: orderItems.map((entry) => ({
          itemId: entry.item.id,
          quantity: entry.quantity,
        })),
        discountAmount,
        paymentMethod,
        paidAmount,
        paymentStatus,
        splitPayments,
        notes: orderNotes.trim() || undefined,
      };

      const result = await createCafeteriaOrder(payload);

      if (!result.success || !result.order) {
        setGeneralError(result.error || 'Failed to create cafeteria order');
        setIsSubmitting(false);
        return;
      }

      const createdOrder = result.order;

      // Print receipt modal callback if provided
      if (onOpenReceiptModal && createdOrder.paidAmount > 0) {
        const syntheticPayment: PaymentTransaction = {
          id: `pay_${createdOrder.id}`,
          type: 'cafeteria_order',
          referenceId: createdOrder.id,
          referenceTitle: `Cafeteria Bill: ${createdOrder.items
            .map((i) => `${i.quantity}x ${i.name}`)
            .join(', ')}`,
          customerId: createdOrder.customerId,
          customerName: createdOrder.customerName,
          amount: createdOrder.paidAmount,
          method: createdOrder.paymentMethod,
          status: createdOrder.paymentStatus,
          splitDetails: createdOrder.splitPayments,
          notes: createdOrder.notes,
          timestamp: createdOrder.createdAt,
          recordedBy: currentUser?.name || 'Staff Member',
        };
        onOpenReceiptModal(syntheticPayment);
      }

      onClose();
    } catch (err: any) {
      setGeneralError(err?.message || 'Error processing cafeteria order');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="create-order-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="create-order-modal"
        className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh]"
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-slate-950 font-black shadow-md shadow-amber-500/20">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-white">
                  Create Cafeteria Order
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                  Point of Sale
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Select customer, choose items, specify quantities and process payment
              </p>
            </div>
          </div>
          <button
            id="close-create-order-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Error Notice */}
        {generalError && (
          <div className="p-3 mx-4 sm:mx-6 mt-4 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{generalError}</span>
          </div>
        )}

        {/* Modal Body: Two-Column Responsive Layout */}
        <form onSubmit={handleSubmitOrder} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* LEFT COLUMN: Customer Selection & Items Catalog (Col 7) */}
            <div className="lg:col-span-7 space-y-5">
              
              {/* STEP 1: Select Customer */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 text-xs font-black flex items-center justify-center">
                      1
                    </span>
                    <label className="text-xs font-bold text-white uppercase tracking-wider">
                      Select Customer
                    </label>
                  </div>
                  {/* Mode switch pills */}
                  <div className="flex rounded-lg bg-slate-900 border border-slate-800 p-0.5 text-xs">
                    <button
                      type="button"
                      onClick={() => {
                        setCustomerMode('registered');
                        setCustomerError(null);
                      }}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                        customerMode === 'registered'
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Registered Member
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCustomerMode('walk_in');
                        setCustomerError(null);
                      }}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                        customerMode === 'walk_in'
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Walk-in / Counter
                    </button>
                  </div>
                </div>

                {/* Validation Message */}
                {customerError && (
                  <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{customerError}</span>
                  </div>
                )}

                {customerMode === 'registered' ? (
                  <div>
                    <select
                      id="create-order-customer-select"
                      value={selectedCustomerId}
                      onChange={(e) => {
                        setSelectedCustomerId(e.target.value);
                        setCustomerError(null);
                      }}
                      className={`w-full bg-slate-900 border rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none ${
                        customerError
                          ? 'border-rose-500 ring-1 ring-rose-500'
                          : 'border-slate-700 focus:border-amber-500'
                      }`}
                    >
                      <option value="">-- Choose Registered Customer --</option>
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} {c.phone ? `(${c.phone})` : ''}
                        </option>
                      ))}
                    </select>

                    {/* Active Gaming Players Quick Suggestion */}
                    {sessions.filter((s) => s.status === 'active' || s.status === 'paused').length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80">
                        <span className="text-[10px] text-slate-400 font-semibold block mb-1.5 flex items-center gap-1">
                          <Gamepad2 className="w-3 h-3 text-cyan-400" />
                          <span>Quick Select Active Gaming Station:</span>
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {sessions
                            .filter((s) => s.status === 'active' || s.status === 'paused')
                            .map((s) => (
                              <button
                                key={s.id}
                                type="button"
                                onClick={() =>
                                  handleSelectActivePlayer({
                                    customerId: s.customerId,
                                    customerName: s.customerName,
                                    consoleCode: s.consoleCode,
                                  })
                                }
                                className={`px-2 py-1 rounded text-[10px] border transition-colors ${
                                  selectedCustomerId === s.customerId
                                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold'
                                    : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-300'
                                }`}
                              >
                                {s.consoleCode} &middot; {s.customerName.split(' ')[0]}
                              </button>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <input
                        id="walkin-customer-name"
                        type="text"
                        placeholder="Customer Name or Table/Booth *"
                        value={walkInName}
                        onChange={(e) => {
                          setWalkInName(e.target.value);
                          setCustomerError(null);
                        }}
                        className={`w-full bg-slate-900 border rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none ${
                          customerError && !walkInName.trim()
                            ? 'border-rose-500 ring-1 ring-rose-500'
                            : 'border-slate-700 focus:border-amber-500'
                        }`}
                      />
                    </div>
                    <div>
                      <input
                        id="walkin-customer-phone"
                        type="text"
                        placeholder="Phone Number (Optional)"
                        value={walkInPhone}
                        onChange={(e) => setWalkInPhone(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* STEP 2: Select Cafeteria Items */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 text-xs font-black flex items-center justify-center">
                      2
                    </span>
                    <label className="text-xs font-bold text-white uppercase tracking-wider">
                      Select Menu Items
                    </label>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Click an item to add to order
                  </span>
                </div>

                {/* Search & Category Pills */}
                <div className="space-y-2.5">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      id="modal-search-items"
                      type="text"
                      placeholder="Search drinks, snacks, meals..."
                      value={itemSearchQuery}
                      onChange={(e) => setItemSearchQuery(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                          selectedCategory === cat
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                            : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Items Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-64 overflow-y-auto pr-1 custom-scrollbar">
                  {availableItems.length === 0 ? (
                    <div className="col-span-2 py-6 text-center text-slate-500 text-xs">
                      No menu items match your search.
                    </div>
                  ) : (
                    availableItems.map((item) => {
                      const inCart = orderItems.find((e) => e.item.id === item.id);
                      const isOutOfStock = item.stockQuantity <= 0;
                      const isLowStock = item.stockQuantity <= 5 && item.stockQuantity > 0;

                      return (
                        <div
                          key={item.id}
                          className={`p-3 rounded-xl border flex flex-col justify-between transition-all ${
                            !item.isAvailable || isOutOfStock
                              ? 'bg-slate-950/40 border-slate-800/40 opacity-50'
                              : inCart
                              ? 'bg-amber-500/5 border-amber-500/40 shadow-sm'
                              : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <span className="text-[9px] font-bold uppercase text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded">
                                {item.category}
                              </span>
                              <span
                                className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                                  isOutOfStock
                                    ? 'bg-rose-500/20 text-rose-400'
                                    : isLowStock
                                    ? 'bg-amber-500/20 text-amber-300'
                                    : 'text-slate-400'
                                }`}
                              >
                                {isOutOfStock ? 'Out of stock' : `Stock: ${item.stockQuantity}`}
                              </span>
                            </div>
                            <p className="text-xs font-bold text-white leading-tight">{item.name}</p>
                            {item.description && (
                              <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                                {item.description}
                              </p>
                            )}
                          </div>

                          <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between">
                            <span className="text-xs font-black text-white">
                              {settings.currencySymbol} {item.price}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleAddItem(item)}
                              disabled={!item.isAvailable || isOutOfStock}
                              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                                inCart
                                  ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                                  : 'bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-amber-400 border border-slate-700'
                              } disabled:opacity-40 disabled:pointer-events-none`}
                            >
                              <Plus className="w-3 h-3" />
                              <span>{inCart ? `Add (${inCart.quantity})` : 'Add'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN: Steps 3-8 (Order Review, Quantities, Calculation, Payment & Submit) (Col 5) */}
            <div className="lg:col-span-5 space-y-4">
              
              {/* STEPS 3 & 4: Set Quantity & Add/Remove Items */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 text-xs font-black flex items-center justify-center">
                      3
                    </span>
                    <label className="text-xs font-bold text-white uppercase tracking-wider">
                      Selected Items ({orderItems.reduce((a, c) => a + c.quantity, 0)})
                    </label>
                  </div>
                  {orderItems.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setOrderItems([])}
                      className="text-[11px] text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Clear All</span>
                    </button>
                  )}
                </div>

                {itemsError && (
                  <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{itemsError}</span>
                  </div>
                )}

                {orderItems.length === 0 ? (
                  <div className="p-6 bg-slate-900/60 border border-dashed border-slate-800 rounded-xl text-center">
                    <Coffee className="w-6 h-6 text-slate-600 mx-auto mb-1.5" />
                    <p className="text-xs text-slate-400 font-medium">No cafeteria items added yet</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      Click "+ Add" on items in the menu to build the order
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
                    {orderItems.map(({ item, quantity }) => (
                      <div
                        key={item.id}
                        className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-white truncate">{item.name}</p>
                          <p className="text-[10px] text-slate-400">
                            {settings.currencySymbol} {item.price} each
                          </p>
                        </div>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-1 shrink-0 bg-slate-950 border border-slate-800 rounded-lg p-0.5">
                          <button
                            type="button"
                            onClick={() => handleUpdateQuantity(item.id, quantity - 1)}
                            className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center text-xs"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-5 text-center text-xs font-bold text-amber-400">
                            {quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleUpdateQuantity(item.id, quantity + 1)}
                            disabled={quantity >= item.stockQuantity}
                            className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center text-xs disabled:opacity-30"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="text-right shrink-0">
                          <p className="text-xs font-bold text-white">
                            {settings.currencySymbol} {item.price * quantity}
                          </p>
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-[10px] text-rose-400 hover:text-rose-300 font-medium"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* STEP 5: Automatically Calculate Total & Discount */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2.5 text-xs">
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 text-xs font-black flex items-center justify-center">
                    4
                  </span>
                  <label className="text-xs font-bold text-white uppercase tracking-wider">
                    Total & Pricing
                  </label>
                </div>

                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-slate-200">
                    {settings.currencySymbol} {subtotal}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                  <span className="text-slate-400">Special Discount:</span>
                  <div className="flex items-center gap-1">
                    <span className="text-slate-400">{settings.currencySymbol}</span>
                    <input
                      id="order-discount-input"
                      type="number"
                      min="0"
                      max={subtotal}
                      value={discountInput}
                      onChange={(e) => setDiscountInput(e.target.value)}
                      className="w-20 bg-slate-900 border border-slate-700 rounded-lg px-2 py-0.5 text-xs text-right font-bold text-emerald-400 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-sm font-black">
                  <span className="text-white">Net Bill Payable:</span>
                  <span className="text-base text-amber-400">
                    {settings.currencySymbol} {netTotal}
                  </span>
                </div>
              </div>

              {/* STEPS 6 & 7: Payment Method Selection & Split Payment */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 text-xs font-black flex items-center justify-center">
                    5
                  </span>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Payment Details
                  </span>
                </div>

                <CafeteriaPaymentSection
                  totalBill={netTotal}
                  currencySymbol={settings.currencySymbol}
                  onChange={setPaymentData}
                  defaultMode="single"
                  defaultMethod="cash"
                />

                {/* Instructions / Notes */}
                <div className="pt-1">
                  <input
                    id="create-order-notes"
                    type="text"
                    placeholder="Instructions / Notes (e.g. deliver to Booth 2, extra napkins)"
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* STEP 8: Create and Save the Order */}
              <button
                id="submit-create-cafeteria-order-btn"
                type="submit"
                disabled={isSubmitting || orderItems.length === 0}
                className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 via-amber-400 to-orange-400 hover:from-amber-400 hover:to-orange-300 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
              >
                {isSubmitting
                  ? 'Saving Order & Updating Stock...'
                  : paymentData.paidAmount < netTotal
                  ? `Create & Save Order • ${settings.currencySymbol} ${paymentData.paidAmount} Paid (${settings.currencySymbol} ${Math.max(0, netTotal - paymentData.paidAmount)} PENDING)`
                  : `Create & Save Order (${settings.currencySymbol} ${netTotal} FULLY PAID)`}
              </button>

            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
