import React, { useState } from 'react';
import { X, Receipt, ShoppingBag, User, Calendar, CreditCard, Banknote, AlertCircle, Ban } from 'lucide-react';
import { CafeteriaOrder, PaymentTransaction } from '../../types';
import { useCafe } from '../../context/CafeContext';

interface CafeteriaOrderDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: CafeteriaOrder | null;
  onOpenReceiptModal?: (transaction: PaymentTransaction) => void;
}

export const CafeteriaOrderDetailsModal: React.FC<CafeteriaOrderDetailsModalProps> = ({
  isOpen,
  onClose,
  order,
  onOpenReceiptModal,
}) => {
  const { settings, payments, cancelCafeteriaOrder } = useCafe();
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [isCancelling, setIsCancelling] = useState(false);
  const [cancelError, setCancelError] = useState<string | null>(null);

  if (!isOpen || !order) return null;

  // Find associated payment transaction if exists
  const associatedPayment = payments.find(
    (p) => p.referenceId === order.id || (p.type === 'cafeteria_order' && p.notes?.includes(order.id))
  );

  const handlePrintReceipt = () => {
    if (onOpenReceiptModal) {
      if (associatedPayment) {
        onOpenReceiptModal(associatedPayment);
      } else {
        // Construct transaction object for receipt display
        const syntheticPayment: PaymentTransaction = {
          id: `pay_${order.id}`,
          type: 'cafeteria_order',
          referenceId: order.id,
          referenceTitle: `Cafeteria Order: ${order.items.map((i) => `${i.quantity}x ${i.name}`).join(', ')}`,
          customerId: order.customerId,
          customerName: order.customerName,
          amount: order.paidAmount,
          method: order.paymentMethod,
          status: order.paymentStatus,
          splitDetails: order.splitPayments,
          notes: order.notes,
          timestamp: order.createdAt,
          recordedBy: order.workerName,
        };
        onOpenReceiptModal(syntheticPayment);
      }
    }
  };

  const handleCancelOrder = async () => {
    setIsCancelling(true);
    setCancelError(null);
    try {
      const res = await cancelCafeteriaOrder(order.id, cancelReason || 'Customer cancelled order');
      if (!res.success) {
        setCancelError(res.error || 'Failed to cancel order');
      } else {
        setShowCancelConfirm(false);
        onClose();
      }
    } catch (err: any) {
      setCancelError(err?.message || 'Failed to cancel order');
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <div
      id="order-details-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="order-details-modal"
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Cafeteria Order Details</h2>
                <span
                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded uppercase ${
                    order.status === 'cancelled'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      : order.paymentStatus === 'paid'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  {order.status === 'cancelled' ? 'Cancelled' : order.paymentStatus}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">#{order.id}</p>
            </div>
          </div>
          <button
            id="close-order-details-btn"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {cancelError && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-2 text-xs text-rose-400">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{cancelError}</span>
            </div>
          )}

          {/* Customer & Timestamp Info */}
          <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-950/60 border border-slate-800/80 rounded-xl text-xs">
            <div>
              <div className="flex items-center gap-1.5 text-slate-400 font-semibold mb-1">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>Customer</span>
              </div>
              <p className="font-bold text-white text-sm">{order.customerName}</p>
              {order.customerPhone && (
                <p className="text-slate-400 font-mono text-[11px]">{order.customerPhone}</p>
              )}
            </div>

            <div>
              <div className="flex items-center gap-1.5 text-slate-400 font-semibold mb-1">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Date & Time</span>
              </div>
              <p className="text-slate-200 font-mono">
                {new Date(order.createdAt).toLocaleString([], {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                })}
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">Billed by: {order.workerName}</p>
            </div>
          </div>

          {/* Items Breakdown Table */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Ordered Items ({order.items.reduce((acc, i) => acc + i.quantity, 0)})
            </h4>
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900 text-slate-400 font-semibold uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">Item</th>
                    <th className="p-2.5 text-center">Qty</th>
                    <th className="p-2.5 text-right">Price</th>
                    <th className="p-2.5 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {order.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/40">
                      <td className="p-2.5">
                        <p className="font-bold text-slate-200">{item.name}</p>
                        <span className="text-[10px] text-cyan-400 font-medium">{item.category}</span>
                      </td>
                      <td className="p-2.5 text-center font-bold text-white">x{item.quantity}</td>
                      <td className="p-2.5 text-right text-slate-400">
                        {settings.currencySymbol} {item.unitPrice}
                      </td>
                      <td className="p-2.5 text-right font-bold text-white">
                        {settings.currencySymbol} {item.totalPrice}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Financial Calculation & Payment Method */}
          <div className="p-3.5 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Items Subtotal:</span>
              <span className="font-semibold text-slate-200">
                {settings.currencySymbol} {order.subtotal}
              </span>
            </div>

            {order.discountAmount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Special Discount:</span>
                <span>
                  - {settings.currencySymbol} {order.discountAmount}
                </span>
              </div>
            )}

            <div className="pt-2 border-t border-slate-800 flex justify-between text-sm font-extrabold text-white">
              <span>Final Bill Total:</span>
              <span className="text-cyan-400 text-base">
                {settings.currencySymbol} {order.totalAmount}
              </span>
            </div>

            <div className="flex justify-between text-xs text-slate-400">
              <span>Amount Paid:</span>
              <span className="font-bold text-emerald-400">
                {settings.currencySymbol} {order.paidAmount}
              </span>
            </div>

            {/* Payment Method Badge or Split Details */}
            <div className="pt-2 border-t border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Payment Channel:
              </span>
              {order.splitPayments && order.splitPayments.length > 0 ? (
                <div className="space-y-1">
                  <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 border border-amber-500/40 text-amber-300 uppercase">
                    Split Payment
                  </span>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {order.splitPayments.map((s, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 text-[11px]"
                      >
                        <strong className="uppercase text-slate-400">{s.method}:</strong> ₹{s.amount}
                      </span>
                    ))}
                  </div>
                </div>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-800 border border-slate-700 text-slate-200 uppercase">
                  {order.paymentMethod === 'cash' && <Banknote className="w-3.5 h-3.5 text-emerald-400" />}
                  {order.paymentMethod === 'card' && <CreditCard className="w-3.5 h-3.5 text-indigo-400" />}
                  {order.paymentMethod === 'upi' && <CreditCard className="w-3.5 h-3.5 text-cyan-400" />}
                  {order.paymentMethod}
                </span>
              )}
            </div>

            {order.notes && (
              <div className="pt-2 text-slate-400 text-[11px] italic">
                Note: {order.notes}
              </div>
            )}
          </div>

          {/* Cancellation section */}
          {order.status !== 'cancelled' && (
            <div className="pt-2">
              {!showCancelConfirm ? (
                <button
                  type="button"
                  id="cancel-order-trigger-btn"
                  onClick={() => setShowCancelConfirm(true)}
                  className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1.5 font-medium transition-colors"
                >
                  <Ban className="w-3.5 h-3.5" />
                  <span>Cancel Order & Restore Inventory Stock</span>
                </button>
              ) : (
                <div className="p-3 bg-rose-950/30 border border-rose-500/30 rounded-xl space-y-2">
                  <p className="text-xs text-rose-200 font-semibold">
                    Confirm Order Cancellation?
                  </p>
                  <p className="text-[11px] text-slate-400">
                    This will mark the order as cancelled and restore the ordered item quantities back into the cafeteria inventory.
                  </p>
                  <input
                    type="text"
                    placeholder="Reason for cancellation (e.g. customer changed mind)"
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={handleCancelOrder}
                      disabled={isCancelling}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs"
                    >
                      {isCancelling ? 'Cancelling...' : 'Yes, Cancel Order'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowCancelConfirm(false)}
                      className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
                    >
                      Keep Order
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between gap-3">
          <button
            type="button"
            id="print-order-receipt-btn"
            onClick={handlePrintReceipt}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 hover:text-cyan-300 text-xs font-bold rounded-xl border border-slate-700 transition-all"
          >
            <Receipt className="w-4 h-4" />
            <span>Print Thermal Receipt</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
