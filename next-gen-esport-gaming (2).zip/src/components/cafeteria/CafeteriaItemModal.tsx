import React, { useState, useEffect } from 'react';
import { X, Coffee, AlertCircle } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { CafeteriaItem, CafeteriaCategory } from '../../types';

interface CafeteriaItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemToEdit?: CafeteriaItem | null;
}

const CATEGORIES: CafeteriaCategory[] = [
  'Snacks',
  'Beverages',
  'Fast Food',
  'Energy Drinks',
  'Desserts',
  'Combos',
  'Other',
];

export const CafeteriaItemModal: React.FC<CafeteriaItemModalProps> = ({
  isOpen,
  onClose,
  itemToEdit,
}) => {
  const { addCafeteriaItem, updateCafeteriaItem, deleteCafeteriaItem, settings } = useCafe();

  const [name, setName] = useState('');
  const [category, setCategory] = useState<CafeteriaCategory>('Snacks');
  const [price, setPrice] = useState<number>(50);
  const [stockQuantity, setStockQuantity] = useState<number>(20);
  const [isAvailable, setIsAvailable] = useState<boolean>(true);
  const [description, setDescription] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (itemToEdit) {
      setName(itemToEdit.name);
      setCategory(itemToEdit.category);
      setPrice(itemToEdit.price);
      setStockQuantity(itemToEdit.stockQuantity);
      setIsAvailable(itemToEdit.isAvailable);
      setDescription(itemToEdit.description || '');
      setExpiryDate(itemToEdit.expiryDate || '');
    } else {
      setName('');
      setCategory('Snacks');
      setPrice(50);
      setStockQuantity(20);
      setIsAvailable(true);
      setDescription('');
      setExpiryDate('');
    }
    setError(null);
    setShowDeleteConfirm(false);
  }, [itemToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide an item name');
      return;
    }
    if (price < 0) {
      setError('Price cannot be negative');
      return;
    }
    if (stockQuantity < 0) {
      setError('Stock quantity cannot be negative');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      if (itemToEdit) {
        await updateCafeteriaItem(itemToEdit.id, {
          name: name.trim(),
          category,
          price: Number(price),
          stockQuantity: Number(stockQuantity),
          isAvailable,
          description: description.trim() || undefined,
          expiryDate: expiryDate || undefined,
        });
      } else {
        await addCafeteriaItem({
          name: name.trim(),
          category,
          price: Number(price),
          stockQuantity: Number(stockQuantity),
          isAvailable,
          description: description.trim() || undefined,
          expiryDate: expiryDate || undefined,
        });
      }
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save cafeteria item');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!itemToEdit) return;
    setIsSubmitting(true);
    try {
      await deleteCafeteriaItem(itemToEdit.id);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to delete cafeteria item');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="cafeteria-item-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="cafeteria-item-modal"
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Coffee className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {itemToEdit ? 'Edit Cafeteria Item' : 'Add Food & Beverage Item'}
              </h2>
              <p className="text-xs text-slate-400">
                {itemToEdit ? 'Modify price, stock & menu availability' : 'Add a new refreshment to the cafe catalog'}
              </p>
            </div>
          </div>
          <button
            id="close-cafeteria-modal-btn"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-2.5 text-xs text-rose-400">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Item Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Item Name *
            </label>
            <input
              id="item-name-input"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Monster Energy Ultra, Loaded Cheese Nachos"
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Category & Price Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Category *
              </label>
              <select
                id="item-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value as CafeteriaCategory)}
                className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Price ({settings.currencySymbol}) *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-slate-400 font-bold text-sm">
                  {settings.currencySymbol}
                </span>
                <input
                  id="item-price-input"
                  type="number"
                  required
                  min="0"
                  step="1"
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-8 pr-3.5 py-2.5 text-sm font-semibold text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          </div>

          {/* Stock Quantity & Availability */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Current Stock Quantity *
              </label>
              <input
                id="item-stock-input"
                type="number"
                required
                min="0"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(Number(e.target.value))}
                className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-white focus:outline-none focus:border-cyan-500"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Items with stock ≤ 5 will show low stock alerts
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Expiry Date (Optional)
              </label>
              <input
                id="item-expiry-input"
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Leave blank if the product has no expiry
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Menu Availability
            </label>
              <div
                onClick={() => setIsAvailable(!isAvailable)}
                className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition-all ${
                  isAvailable
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                }`}
              >
                <div className="text-xs">
                  <span className="font-bold block">{isAvailable ? 'Enabled in Menu' : 'Disabled / Hidden'}</span>
                  <span className="text-[10px] opacity-75">
                    {isAvailable ? 'Staff can order this item' : 'Cannot be added to orders'}
                  </span>
                </div>
                <div
                  className={`w-10 h-6 flex items-center rounded-full p-1 transition-colors ${
                    isAvailable ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-md" />
                </div>
              </div>
            </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Description / Ingredients (Optional)
            </label>
            <textarea
              id="item-description-input"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Served hot with melted cheese, 250ml can, etc."
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none"
            />
          </div>

          {/* Delete section for existing item */}
          {itemToEdit && (
            <div className="pt-3 border-t border-slate-800">
              {!showDeleteConfirm ? (
                <button
                  type="button"
                  id="delete-item-btn"
                  onClick={() => setShowDeleteConfirm(true)}
                  className="text-xs text-rose-400 hover:text-rose-300 underline font-medium"
                >
                  Delete this item from cafeteria catalog
                </button>
              ) : (
                <div className="p-3 bg-rose-950/30 border border-rose-500/30 rounded-xl space-y-2">
                  <p className="text-xs text-rose-200">
                    Are you sure you want to permanently delete <strong>{itemToEdit.name}</strong>?
                  </p>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={handleDelete}
                      disabled={isSubmitting}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs"
                    >
                      Yes, Delete Item
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowDeleteConfirm(false)}
                      className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="pt-3 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="save-cafeteria-item-btn"
              disabled={isSubmitting}
              className="px-5 py-2 bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 text-xs font-extrabold rounded-xl shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : itemToEdit ? 'Update Item' : 'Add to Cafeteria'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
