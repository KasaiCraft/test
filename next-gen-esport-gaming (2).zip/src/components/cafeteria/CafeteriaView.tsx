import React, { useState, useMemo } from 'react';
import {
  Coffee,
  Plus,
  Search,
  ShoppingBag,
  Trash2,
  Edit2,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Receipt,
  User,
  Eye,
  SlidersHorizontal,
  Package,
  X,
  PlusCircle,
  MinusCircle,
  Clock,
  Sparkles,
  Ban,
  Gamepad2,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import {
  CafeteriaItem,
  CafeteriaCategory,
  CafeteriaOrder,
  PaymentTransaction,
  PaymentStatus,
} from '../../types';
import { CafeteriaPaymentSection, CafeteriaPaymentData } from './CafeteriaPaymentSection';
import { CafeteriaItemModal } from './CafeteriaItemModal';
import { CafeteriaOrderDetailsModal } from './CafeteriaOrderDetailsModal';
import { CreateCafeteriaOrderModal } from './CreateCafeteriaOrderModal';
import { EditCafeteriaOrderModal } from './EditCafeteriaOrderModal';

interface CafeteriaViewProps {
  onOpenReceiptModal?: (transaction: PaymentTransaction) => void;
}

interface CartItem {
  item: CafeteriaItem;
  quantity: number;
}

const CATEGORIES: ('All' | CafeteriaCategory)[] = [
  'All',
  'Snacks',
  'Beverages',
  'Fast Food',
  'Energy Drinks',
  'Desserts',
  'Combos',
  'Other',
];

export const CafeteriaView: React.FC<CafeteriaViewProps> = ({ onOpenReceiptModal }) => {
  const {
    cafeteriaItems,
    cafeteriaOrders,
    customers,
    sessions,
    isAdmin,
    settings,
    currentUser,
    toggleCafeteriaItemAvailability,
    updateCafeteriaItemStock,
    createCafeteriaOrder,
    cancelCafeteriaOrder,
    payments,
  } = useCafe();

  // Active Main Tab
  const [activeTab, setActiveTab] = useState<'pos' | 'history' | 'inventory'>('pos');

  // Filters
  const [selectedCategory, setSelectedCategory] = useState<'All' | CafeteriaCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [stockFilter, setStockFilter] = useState<'all' | 'in_stock' | 'low_stock' | 'disabled'>('all');

  // Order History Filters
  const [historySearch, setHistorySearch] = useState('');
  const [historyStatusFilter, setHistoryStatusFilter] = useState<'all' | 'paid' | 'partial' | 'pending' | 'cancelled'>('all');

  // POS Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [walkInName, setWalkInName] = useState('');
  const [walkInPhone, setWalkInPhone] = useState('');
  const [discountAmount, setDiscountAmount] = useState<string>('0');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  const [orderError, setOrderError] = useState<string | null>(null);
  const [orderSuccessMessage, setOrderSuccessMessage] = useState<string | null>(null);

  // Split / Payment state for POS
  const [paymentState, setPaymentState] = useState<CafeteriaPaymentData>({
    paymentMode: 'single',
    paymentMethod: 'cash',
    paidAmount: 0,
    remaining: 0,
    paymentStatus: 'paid',
    isValid: true,
  });

  // Modals state
  const [isCreateOrderModalOpen, setIsCreateOrderModalOpen] = useState(false);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [itemToEdit, setItemToEdit] = useState<CafeteriaItem | null>(null);
  const [selectedOrderForDetails, setSelectedOrderForDetails] = useState<CafeteriaOrder | null>(null);
  const [orderToEdit, setOrderToEdit] = useState<CafeteriaOrder | null>(null);
  const [orderToCancel, setOrderToCancel] = useState<CafeteriaOrder | null>(null);
  const [cancelReasonInput, setCancelReasonInput] = useState('');
  const [isCancellingOrder, setIsCancellingOrder] = useState(false);

  // Quick stats
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const todayOrders = cafeteriaOrders.filter(
    (o) => new Date(o.createdAt).getTime() >= todayStart.getTime()
  );

  const todayCafeteriaRevenue = payments
    .filter(
      (p) =>
        p.type === 'cafeteria_order' &&
        new Date(p.timestamp).getTime() >= todayStart.getTime()
    )
    .reduce((acc, p) => acc + p.amount, 0);

  const lowStockCount = cafeteriaItems.filter(
    (item) => item.stockQuantity <= 5 && item.stockQuantity > 0
  ).length;

  const outOfStockCount = cafeteriaItems.filter(
    (item) => item.stockQuantity <= 0
  ).length;

  // Filtered Items for POS & Catalog
  const filteredItems = useMemo(() => {
    return cafeteriaItems.filter((item) => {
      const matchesCategory =
        selectedCategory === 'All' || item.category === selectedCategory;
      const matchesSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()));

      let matchesStock = true;
      if (stockFilter === 'in_stock') matchesStock = item.stockQuantity > 0 && item.isAvailable;
      else if (stockFilter === 'low_stock') matchesStock = item.stockQuantity <= 5 && item.stockQuantity > 0;
      else if (stockFilter === 'disabled') matchesStock = !item.isAvailable;

      return matchesCategory && matchesSearch && matchesStock;
    });
  }, [cafeteriaItems, selectedCategory, searchQuery, stockFilter]);

  // Helper to get expiry status and formatting
  const getExpiryInfo = (expiryDate?: string) => {
    if (!expiryDate) return { label: 'Not Set', status: 'none', color: 'text-slate-500' };
    
    const expiryDateObj = new Date(expiryDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Exactly 2 calendar months before
    const warningDate = new Date(expiryDateObj);
    warningDate.setMonth(warningDate.getMonth() - 2);
    
    const isExpired = expiryDateObj.getTime() < today.getTime();
    const isExpiringSoon = !isExpired && today.getTime() >= warningDate.getTime();
    
    if (isExpired) return { label: `Expired on ${expiryDateObj.toLocaleDateString()}`, status: 'expired', color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' };
    if (isExpiringSoon) return { label: `Expires on ${expiryDateObj.toLocaleDateString()}`, status: 'soon', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' };
    
    return { label: `Expires ${expiryDateObj.toLocaleDateString()}`, status: 'normal', color: 'text-slate-400 bg-slate-950 border-slate-800' };
  };

  // Filtered History Orders
  const filteredOrders = useMemo(() => {
    return cafeteriaOrders.filter((order) => {
      const matchesSearch =
        order.id.toLowerCase().includes(historySearch.toLowerCase()) ||
        order.customerName.toLowerCase().includes(historySearch.toLowerCase()) ||
        (order.customerPhone && order.customerPhone.includes(historySearch)) ||
        order.items.some((i) => i.name.toLowerCase().includes(historySearch.toLowerCase()));

      const matchesStatus =
        historyStatusFilter === 'all' ||
        (historyStatusFilter === 'cancelled'
          ? order.status === 'cancelled'
          : order.status !== 'cancelled' && order.paymentStatus === historyStatusFilter);

      return matchesSearch && matchesStatus;
    });
  }, [cafeteriaOrders, historySearch, historyStatusFilter]);

  // Cart Calculations
  const cartSubtotal = useMemo(() => {
    return cart.reduce((acc, ci) => acc + ci.item.price * ci.quantity, 0);
  }, [cart]);

  const numericDiscount = Math.max(0, parseFloat(discountAmount) || 0);
  const cartTotal = Math.max(0, cartSubtotal - numericDiscount);

  // Cart Actions
  const addToCart = (item: CafeteriaItem) => {
    if (!item.isAvailable || item.stockQuantity <= 0) return;
    setOrderSuccessMessage(null);
    setOrderError(null);

    setCart((prev) => {
      const existing = prev.find((ci) => ci.item.id === item.id);
      if (existing) {
        if (existing.quantity >= item.stockQuantity) {
          setOrderError(`Cannot add more "${item.name}". Only ${item.stockQuantity} in stock.`);
          return prev;
        }
        return prev.map((ci) =>
          ci.item.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const updateCartQuantity = (itemId: string, newQty: number) => {
    setOrderSuccessMessage(null);
    setOrderError(null);
    if (newQty <= 0) {
      removeFromCart(itemId);
      return;
    }

    const food = cafeteriaItems.find((i) => i.id === itemId);
    if (food && newQty > food.stockQuantity) {
      setOrderError(`Only ${food.stockQuantity} available in stock for "${food.name}".`);
      return;
    }

    setCart((prev) =>
      prev.map((ci) => (ci.item.id === itemId ? { ...ci, quantity: newQty } : ci))
    );
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((ci) => ci.item.id !== itemId));
  };

  const clearCart = () => {
    setCart([]);
    setDiscountAmount('0');
    setOrderNotes('');
    setOrderError(null);
    setOrderSuccessMessage(null);
  };

  // Quick preset: Select Active Gaming Player for Order
  const handleSelectActivePlayer = (sessionPlayer: { customerId: string; customerName: string; consoleCode: string }) => {
    setSelectedCustomerId(sessionPlayer.customerId);
    setOrderNotes(`Deliver to ${sessionPlayer.consoleCode}`);
  };

  // Handle Checkout & Order Creation
  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setOrderError(null);
    setOrderSuccessMessage(null);

    // Validate Customer Selection
    if (!selectedCustomerId) {
      setOrderError('Please select a customer or choose Walk-in mode before creating the order.');
      return;
    }

    if (selectedCustomerId === 'walk_in' && !walkInName.trim()) {
      setOrderError('Customer name is required for walk-in orders. Please enter a name or seat number.');
      return;
    }

    // Validate Items
    if (cart.length === 0) {
      setOrderError('Your cart is empty. Please add items before placing order.');
      return;
    }

    setIsSubmittingOrder(true);

    try {
      let finalCustomerId = selectedCustomerId;
      let finalCustomerName = '';
      let finalCustomerPhone: string | undefined = undefined;

      if (selectedCustomerId === 'walk_in') {
        finalCustomerName = walkInName.trim();
        finalCustomerPhone = walkInPhone.trim() || undefined;
      } else {
        const found = customers.find((c) => c.id === selectedCustomerId);
        if (!found) {
          setOrderError('Selected customer not found. Please select a valid customer.');
          setIsSubmittingOrder(false);
          return;
        }
        finalCustomerName = found.name;
        finalCustomerPhone = found.phone;
      }

      const paidAmount = paymentState.paidAmount;
      const paymentStatus: PaymentStatus =
        paidAmount >= cartTotal ? 'paid' : 'pending';

      const orderPayload = {
        customerId: finalCustomerId,
        customerName: finalCustomerName,
        customerPhone: finalCustomerPhone,
        items: cart.map((ci) => ({
          itemId: ci.item.id,
          quantity: ci.quantity,
        })),
        discountAmount: numericDiscount,
        paymentMethod: paymentState.paymentMethod,
        paidAmount,
        paymentStatus,
        splitPayments: paymentState.splitPayments,
        notes: orderNotes.trim() || undefined,
      };

      const result = await createCafeteriaOrder(orderPayload);

      if (!result.success || !result.order) {
        setOrderError(result.error || 'Failed to place order');
      } else {
        setOrderSuccessMessage(
          `Order #${result.order.id} placed successfully! Total: ${settings.currencySymbol} ${result.order.totalAmount}`
        );
        const placedOrder = result.order;
        clearCart();

        // If receipt modal callback is available, prompt or trigger
        if (onOpenReceiptModal && placedOrder.paidAmount > 0) {
          const syntheticPayment: PaymentTransaction = {
            id: `pay_${placedOrder.id}`,
            type: 'cafeteria_order',
            referenceId: placedOrder.id,
            referenceTitle: `Cafeteria Bill: ${placedOrder.items.map((i) => `${i.quantity}x ${i.name}`).join(', ')}`,
            customerId: placedOrder.customerId,
            customerName: placedOrder.customerName,
            amount: placedOrder.paidAmount,
            method: placedOrder.paymentMethod,
            status: placedOrder.paymentStatus,
            splitDetails: placedOrder.splitPayments,
            notes: placedOrder.notes,
            timestamp: placedOrder.createdAt,
            recordedBy: currentUser?.name || 'Staff Member',
          };
          onOpenReceiptModal(syntheticPayment);
        }
      }
    } catch (err: any) {
      setOrderError(err?.message || 'Error processing cafeteria order');
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  // Handle Order Cancellation
  const handleConfirmCancel = async () => {
    if (!orderToCancel) return;
    setIsCancellingOrder(true);
    setOrderError(null);
    try {
      const res = await cancelCafeteriaOrder(orderToCancel.id, cancelReasonInput.trim() || undefined);
      if (!res.success) {
        setOrderError(res.error || 'Failed to cancel order');
      } else {
        setOrderSuccessMessage(`Order #${orderToCancel.id.slice(-6)} has been cancelled. Item stock restored to inventory.`);
        setOrderToCancel(null);
        setCancelReasonInput('');
      }
    } catch (e: any) {
      setOrderError(e?.message || 'Error cancelling order');
    } finally {
      setIsCancellingOrder(false);
    }
  };

  return (
    <div id="cafeteria-view" className="space-y-6 pb-12">
      {/* Top Header Card & Quick Metrics */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg shadow-black/20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-md shadow-amber-500/10">
              <Coffee className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                  Cafeteria & Snacks
                </h1>
                <span
                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded uppercase tracking-wider ${
                    isAdmin
                      ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                      : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  }`}
                >
                  {isAdmin ? 'Admin Mode' : 'Staff POS'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Food & drinks inventory, live billing counter & customer order history
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Prominent Create Order Button */}
            <button
              id="header-create-order-btn"
              onClick={() => setIsCreateOrderModalOpen(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-500 via-amber-400 to-orange-400 hover:from-amber-400 hover:to-orange-300 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-lg shadow-amber-500/25 transition-all cursor-pointer hover:scale-[1.02]"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Create Order</span>
            </button>

            {isAdmin && (
              <button
                id="add-food-item-btn"
                onClick={() => {
                  setItemToEdit(null);
                  setIsItemModalOpen(true);
                }}
                className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 text-amber-400" />
                <span>Add Food / Drink Item</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick Bento Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800">
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
            <p className="text-[10px] uppercase font-semibold text-slate-400">Today's Cafe Sales</p>
            <p className="text-lg sm:text-xl font-black text-amber-400 mt-0.5">
              {settings.currencySymbol} {todayCafeteriaRevenue.toLocaleString('en-IN')}
            </p>
            <p className="text-[10px] text-slate-500 mt-1">{todayOrders.length} orders billed today</p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
            <p className="text-[10px] uppercase font-semibold text-slate-400">Total Menu Items</p>
            <p className="text-lg sm:text-xl font-black text-white mt-0.5">
              {cafeteriaItems.length}
            </p>
            <p className="text-[10px] text-emerald-400 mt-1">
              {cafeteriaItems.filter((i) => i.isAvailable).length} active on menu
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
            <p className="text-[10px] uppercase font-semibold text-slate-400">Low Stock Alert</p>
            <p className={`text-lg sm:text-xl font-black mt-0.5 ${lowStockCount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
              {lowStockCount} items
            </p>
            <p className="text-[10px] text-slate-500 mt-1">Stock count ≤ 5 units</p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
            <p className="text-[10px] uppercase font-semibold text-slate-400">Out of Stock</p>
            <p className={`text-lg sm:text-xl font-black mt-0.5 ${outOfStockCount > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
              {outOfStockCount} items
            </p>
            <p className="text-[10px] text-slate-500 mt-1">Requires immediate restocking</p>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          id="tab-pos-btn"
          onClick={() => setActiveTab('pos')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'pos'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white bg-slate-900/60 border border-slate-800'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Point of Sale & Menu</span>
          {cart.length > 0 && (
            <span className="ml-1 px-1.5 py-0.2 rounded-full bg-slate-950 text-amber-400 text-[10px] font-black">
              {cart.reduce((a, c) => a + c.quantity, 0)}
            </span>
          )}
        </button>

        <button
          id="tab-history-btn"
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'history'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white bg-slate-900/60 border border-slate-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Order History ({cafeteriaOrders.length})</span>
        </button>

        {isAdmin && (
          <button
            id="tab-inventory-btn"
            onClick={() => setActiveTab('inventory')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'inventory'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white bg-slate-900/60 border border-slate-800'
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>Admin Inventory & Stock</span>
          </button>
        )}
      </div>

      {/* TAB 1: POINT OF SALE & MENU COUNTER */}
      {activeTab === 'pos' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Catalog & Items (Col Span 7 or 8) */}
          <div className="lg:col-span-7 xl:col-span-8 space-y-4">
            {/* Search & Category Navigation */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    id="cafeteria-search-input"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search snacks, coffee, burgers..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-3 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Stock filter */}
                <div className="flex items-center gap-1 self-start sm:self-auto">
                  <span className="text-[11px] text-slate-400 font-semibold mr-1">Filter:</span>
                  <select
                    id="cafeteria-stock-filter"
                    value={stockFilter}
                    onChange={(e) => setStockFilter(e.target.value as any)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-amber-500"
                  >
                    <option value="all">All Items</option>
                    <option value="in_stock">In Stock Only</option>
                    <option value="low_stock">Low Stock (≤5)</option>
                    <option value="disabled">Disabled Items</option>
                  </select>
                </div>
              </div>

              {/* Category Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      selectedCategory === cat
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Items Grid */}
            {filteredItems.length === 0 ? (
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center">
                <Coffee className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <h3 className="text-sm font-bold text-slate-300">No cafeteria items found</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Try adjusting your search query or category filter.
                </p>
                {isAdmin && (
                  <button
                    onClick={() => {
                      setItemToEdit(null);
                      setIsItemModalOpen(true);
                    }}
                    className="mt-4 px-4 py-2 bg-amber-500 text-slate-950 text-xs font-bold rounded-xl"
                  >
                    Add First Item
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3.5">
                {filteredItems.map((item) => {
                  const cartItem = cart.find((ci) => ci.item.id === item.id);
                  const isOutOfStock = item.stockQuantity <= 0;
                  const isLowStock = item.stockQuantity <= 5 && item.stockQuantity > 0;

                  return (
                    <div
                      key={item.id}
                      className={`bg-slate-900/90 border rounded-2xl p-4 flex flex-col justify-between transition-all group ${
                        !item.isAvailable
                          ? 'border-slate-800/60 opacity-60'
                          : isOutOfStock
                          ? 'border-rose-500/20 hover:border-rose-500/40'
                          : 'border-slate-800 hover:border-amber-500/40 hover:shadow-lg hover:shadow-amber-500/5'
                      }`}
                    >
                      <div>
                        {/* Header: Category & Badges */}
                        <div className="flex items-center justify-between gap-1 mb-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                            {item.category}
                          </span>

                          <div className="flex items-center gap-1">
                            {!item.isAvailable ? (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                                Disabled
                              </span>
                            ) : isOutOfStock ? (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
                                Out of Stock
                              </span>
                            ) : isLowStock ? (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                Low ({item.stockQuantity})
                              </span>
                            ) : (
                              <span className="text-[9px] font-medium px-1.5 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                                Stock: {item.stockQuantity}
                              </span>
                            )}

                            {isAdmin && (
                              <button
                                onClick={() => {
                                  setItemToEdit(item);
                                  setIsItemModalOpen(true);
                                }}
                                title="Edit item (Admin)"
                                className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-slate-800 transition-colors ml-1"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Title & Description */}
                        <h4 className="text-sm font-bold text-white leading-snug group-hover:text-amber-200 transition-colors">
                          {item.name}
                        </h4>
                        
                        {/* Expiry Badge */}
                        <div className="mt-1.5 flex items-center gap-1.5">
                          <Clock className={`w-3 h-3 ${item.expiryDate ? 'text-slate-400' : 'text-slate-600'}`} />
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${getExpiryInfo(item.expiryDate).color}`}>
                            {getExpiryInfo(item.expiryDate).label}
                          </span>
                        </div>

                        {item.description && (
                          <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>
                        )}
                      </div>

                      {/* Footer: Price & Add / Quantity Stepper */}
                      <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                        <div>
                          <p className="text-xs text-slate-400">Price</p>
                          <p className="text-base font-black text-white">
                            {settings.currencySymbol} {item.price}
                          </p>
                        </div>

                        {/* Order action */}
                        {cartItem ? (
                          <div className="flex items-center gap-1.5 bg-slate-950 border border-amber-500/40 rounded-xl p-1">
                            <button
                              onClick={() => updateCartQuantity(item.id, cartItem.quantity - 1)}
                              className="w-6 h-6 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center font-bold text-xs"
                            >
                              -
                            </button>
                            <span className="w-6 text-center text-xs font-extrabold text-amber-300">
                              {cartItem.quantity}
                            </span>
                            <button
                              onClick={() => updateCartQuantity(item.id, cartItem.quantity + 1)}
                              disabled={cartItem.quantity >= item.stockQuantity}
                              className="w-6 h-6 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center font-bold text-xs disabled:opacity-40"
                            >
                              +
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => addToCart(item)}
                            disabled={!item.isAvailable || isOutOfStock}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-amber-400 text-xs font-bold rounded-xl border border-slate-700 hover:border-amber-400 transition-all disabled:opacity-30 disabled:pointer-events-none"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Column: Live Order & Billing Terminal (Col Span 5 or 4) */}
          <div className="lg:col-span-5 xl:col-span-4 bg-slate-900/95 border border-slate-800 rounded-2xl p-5 shadow-2xl sticky top-4 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">Current Order Bill</h3>
              </div>
              {cart.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-xs text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear</span>
                </button>
              )}
            </div>

            {orderError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{orderError}</span>
              </div>
            )}

            {orderSuccessMessage && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{orderSuccessMessage}</span>
              </div>
            )}

            <form onSubmit={handleCreateOrder} className="space-y-4">
              {/* Customer Selector & Active Gaming Sessions shortcut */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Customer / Table / Seat
                </label>
                <select
                  id="order-customer-select"
                  value={selectedCustomerId}
                  onChange={(e) => {
                    setSelectedCustomerId(e.target.value);
                    setOrderError(null);
                  }}
                  className={`w-full bg-slate-950 border rounded-xl px-3 py-2 text-xs text-white focus:outline-none ${
                    orderError && !selectedCustomerId
                      ? 'border-rose-500 ring-1 ring-rose-500'
                      : 'border-slate-700 focus:border-amber-500'
                  }`}
                >
                  <option value="">-- Select Customer / Mode * --</option>
                  <option value="walk_in">Walk-in Customer (Manual Name / Counter)</option>
                  <optgroup label="Registered Customers">
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.phone ? `(${c.phone})` : ''}
                      </option>
                    ))}
                  </optgroup>
                </select>

                {/* If walk-in, prompt for quick name and optional phone */}
                {selectedCustomerId === 'walk_in' && (
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <input
                      type="text"
                      placeholder="Customer Name / Seat *"
                      value={walkInName}
                      onChange={(e) => {
                        setWalkInName(e.target.value);
                        setOrderError(null);
                      }}
                      className={`bg-slate-950 border rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none ${
                        orderError && !walkInName.trim()
                          ? 'border-rose-500 ring-1 ring-rose-500'
                          : 'border-slate-800 focus:border-amber-500'
                      }`}
                    />
                    <input
                      type="text"
                      placeholder="Phone (Optional)"
                      value={walkInPhone}
                      onChange={(e) => setWalkInPhone(e.target.value)}
                      className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                )}

                {/* Quick shortcut to select active gaming console players */}
                {sessions.filter((s) => s.status === 'active' || s.status === 'paused').length > 0 && (
                  <div className="mt-2 pt-2 border-t border-slate-800/80">
                    <span className="text-[10px] text-slate-400 font-semibold block mb-1 flex items-center gap-1">
                      <Gamepad2 className="w-3 h-3 text-cyan-400" />
                      <span>Deliver to Active Player:</span>
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {sessions
                        .filter((s) => s.status === 'active' || s.status === 'paused')
                        .map((s) => (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() =>
                              handleSelectActivePlayer({
                                customerId: s.customerId,
                                customerName: s.customerName,
                                consoleCode: s.consoleCode,
                              })
                            }
                            className="px-2 py-0.5 rounded text-[10px] bg-slate-950 hover:bg-cyan-500/20 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-colors"
                          >
                            {s.consoleCode} ({s.customerName.split(' ')[0]})
                          </button>
                        ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Cart Items List */}
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  <span>Selected Items ({cart.reduce((a, c) => a + c.quantity, 0)})</span>
                  <span>Line Total</span>
                </div>

                {cart.length === 0 ? (
                  <div className="p-6 bg-slate-950/60 border border-dashed border-slate-800 rounded-xl text-center">
                    <Coffee className="w-6 h-6 text-slate-600 mx-auto mb-2" />
                    <p className="text-xs text-slate-400">Your cart is currently empty</p>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      Click "+ Add" on items in the catalog to prepare order
                    </p>
                  </div>
                ) : (
                  <div className="max-h-52 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                    {cart.map(({ item, quantity }) => (
                      <div
                        key={item.id}
                        className="p-2.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-white truncate">{item.name}</p>
                          <p className="text-[10px] text-slate-400">
                            {settings.currencySymbol} {item.price} each
                          </p>
                        </div>

                        {/* Quantity controller */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => updateCartQuantity(item.id, quantity - 1)}
                            className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center justify-center font-bold"
                          >
                            -
                          </button>
                          <span className="w-5 text-center text-xs font-bold text-white">
                            {quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateCartQuantity(item.id, quantity + 1)}
                            disabled={quantity >= item.stockQuantity}
                            className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center justify-center font-bold disabled:opacity-30"
                          >
                            +
                          </button>
                        </div>

                        <div className="text-right shrink-0">
                          <p className="text-xs font-black text-white">
                            {settings.currencySymbol} {item.price * quantity}
                          </p>
                          <button
                            type="button"
                            onClick={() => removeFromCart(item.id)}
                            className="text-[10px] text-rose-400 hover:text-rose-300"
                          >
                            remove
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Discount Input */}
              {cart.length > 0 && (
                <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Subtotal:</span>
                    <span className="font-bold text-slate-200">
                      {settings.currencySymbol} {cartSubtotal}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/60">
                    <label className="text-xs text-slate-300 font-medium">
                      Discount ({settings.currencySymbol}):
                    </label>
                    <input
                      type="number"
                      min="0"
                      max={cartSubtotal}
                      value={discountAmount}
                      onChange={(e) => setDiscountAmount(e.target.value)}
                      className="w-24 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs font-bold text-right text-emerald-400 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Net Bill Total */}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-sm font-black">
                    <span className="text-white">Net Bill Payable:</span>
                    <span className="text-amber-400 text-base">
                      {settings.currencySymbol} {cartTotal}
                    </span>
                  </div>
                </div>
              )}

              {/* Split / Payment Method Selection */}
              {cart.length > 0 && (
                <div className="pt-1">
                  <CafeteriaPaymentSection
                    totalBill={cartTotal}
                    currencySymbol={settings.currencySymbol}
                    onChange={setPaymentState}
                    defaultMethod="cash"
                    defaultMode="single"
                  />
                </div>
              )}

              {/* Order Notes */}
              {cart.length > 0 && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Order Instructions / Delivery Notes
                  </label>
                  <input
                    type="text"
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    placeholder="e.g. VIP Booth 2, extra ketchup, served chilled"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              )}

              {/* Submit Button */}
              <button
                id="create-order-btn"
                type="submit"
                disabled={isSubmittingOrder || cart.length === 0}
                className="w-full py-3 bg-gradient-to-r from-amber-500 via-amber-400 to-orange-400 hover:from-amber-400 hover:to-orange-300 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
              >
                {isSubmittingOrder
                  ? 'Processing Order...'
                  : paymentState.paidAmount < cartTotal
                  ? `Create Order • ${settings.currencySymbol} ${paymentState.paidAmount} Paid (${settings.currencySymbol} ${cartTotal - paymentState.paidAmount} Pending)`
                  : `Create Bill & Collect ${settings.currencySymbol} ${cartTotal}`}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 2: ORDER HISTORY */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {/* History Filters */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                id="history-search-input"
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Search orders by ID, customer, item..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center gap-2.5 self-start sm:self-auto flex-wrap">
              <button
                id="history-create-order-btn"
                onClick={() => setIsCreateOrderModalOpen(true)}
                className="flex items-center gap-2 bg-gradient-to-r from-amber-500 via-amber-400 to-orange-400 hover:from-amber-400 hover:to-orange-300 text-slate-950 font-bold px-3.5 py-2 rounded-xl text-xs shadow-md shadow-amber-500/20 transition-all cursor-pointer whitespace-nowrap"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Create Order</span>
              </button>

              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-400 font-semibold">Status:</span>
                <select
                  id="history-status-filter"
                  value={historyStatusFilter}
                  onChange={(e) => setHistoryStatusFilter(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500"
                >
                  <option value="all">All Orders</option>
                  <option value="paid">Paid</option>
                  <option value="partial">Partial</option>
                  <option value="pending">Pending</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
            </div>
          </div>

          {/* Orders Table */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
            {filteredOrders.length === 0 ? (
              <div className="p-12 text-center">
                <ShoppingBag className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <h3 className="text-sm font-bold text-slate-300">No cafeteria orders found</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Orders placed through the Point of Sale will appear here.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800 text-[10px]">
                    <tr>
                      <th className="p-3.5">Order ID</th>
                      <th className="p-3.5">Date & Time</th>
                      <th className="p-3.5">Customer</th>
                      <th className="p-3.5">Items Ordered</th>
                      <th className="p-3.5">Payment</th>
                      <th className="p-3.5 text-right">Total Amount</th>
                      <th className="p-3.5 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredOrders.map((order) => {
                      const totalQty = order.items.reduce((acc, i) => acc + i.quantity, 0);
                      const itemsSummary = order.items
                        .map((i) => `${i.quantity}x ${i.name}`)
                        .slice(0, 2)
                        .join(', ');

                      return (
                        <tr key={order.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="p-3.5 font-mono text-cyan-400 font-bold">
                            #{order.id.slice(-6)}
                          </td>
                          <td className="p-3.5 text-slate-400 font-mono">
                            {new Date(order.createdAt).toLocaleString([], {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </td>
                          <td className="p-3.5">
                            <p className="font-bold text-white">{order.customerName}</p>
                            {order.customerPhone && (
                              <p className="text-[10px] text-slate-400 font-mono">{order.customerPhone}</p>
                            )}
                          </td>
                          <td className="p-3.5">
                            <p className="text-slate-200 font-medium">
                              {itemsSummary}
                              {order.items.length > 2 && (
                                <span className="text-slate-500 ml-1">
                                  +{order.items.length - 2} more
                                </span>
                              )}
                            </p>
                            <span className="text-[10px] text-slate-500">
                              Total items: {totalQty}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <div className="space-y-1">
                              <span
                                className={`inline-block text-[9px] font-black px-2 py-0.5 rounded uppercase ${
                                  order.status === 'cancelled'
                                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                    : order.paymentStatus === 'paid'
                                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                }`}
                              >
                                {order.status === 'cancelled' ? 'Cancelled' : order.paymentStatus}
                              </span>
                              <p className="text-[10px] text-slate-400 uppercase font-mono">
                                {order.splitPayments && order.splitPayments.length > 0
                                  ? 'Split'
                                  : order.paymentMethod}
                              </p>
                            </div>
                          </td>
                          <td className="p-3.5 text-right font-black text-sm text-white">
                            {settings.currencySymbol} {order.totalAmount}
                          </td>
                          <td className="p-3.5 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => setSelectedOrderForDetails(order)}
                                title="View Order Details & Receipt"
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                              >
                                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                                <span>View</span>
                              </button>
                              {order.status !== 'cancelled' && (
                                <>
                                  <button
                                    onClick={() => setOrderToEdit(order)}
                                    title="Edit Order Information"
                                    className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-semibold border border-slate-700 transition-colors"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                    <span>Edit</span>
                                  </button>
                                  <button
                                    onClick={() => setOrderToCancel(order)}
                                    title="Cancel Order & Restore Stock"
                                    className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-rose-950/40 text-rose-400 hover:text-rose-300 text-xs font-semibold border border-slate-700 hover:border-rose-700/50 transition-colors"
                                  >
                                    <Ban className="w-3.5 h-3.5" />
                                    <span>Cancel</span>
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: ADMIN INVENTORY & STOCK MANAGEMENT */}
      {isAdmin && activeTab === 'inventory' && (
        <div className="space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-white">
                  Inventory & Stock Control
                </h3>
                <p className="text-xs text-slate-400">
                  Update quantities, toggle menu availability, and manage catalog items
                </p>
              </div>
              <button
                onClick={() => {
                  setItemToEdit(null);
                  setIsItemModalOpen(true);
                }}
                className="flex items-center gap-2 px-3 py-1.5 bg-amber-500 text-slate-950 text-xs font-bold rounded-xl shadow-md"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Item</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800 text-[10px]">
                  <tr>
                    <th className="p-3">Item Name</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Unit Price</th>
                    <th className="p-3">Stock Quantity</th>
                    <th className="p-3">Expiry Date</th>
                    <th className="p-3">Availability</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {cafeteriaItems.map((item) => {
                    const expiry = getExpiryInfo(item.expiryDate);
                    return (
                      <tr key={item.id} className="hover:bg-slate-800/40">
                        <td className="p-3">
                          <p className="font-bold text-white">{item.name}</p>
                          {item.description && (
                            <p className="text-[10px] text-slate-400 line-clamp-1">{item.description}</p>
                          )}
                        </td>
                        <td className="p-3">
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 uppercase">
                            {item.category}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-white">
                          {settings.currencySymbol} {item.price}
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateCafeteriaItemStock(item.id, Math.max(0, item.stockQuantity - 1))}
                              className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold flex items-center justify-center text-xs"
                            >
                              -
                            </button>
                            <span
                              className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                                item.stockQuantity <= 0
                                  ? 'bg-rose-500/20 text-rose-400'
                                  : item.stockQuantity <= 5
                                  ? 'bg-amber-500/20 text-amber-300'
                                  : 'text-slate-200'
                              }`}
                            >
                              {item.stockQuantity}
                            </span>
                            <button
                              onClick={() => updateCafeteriaItemStock(item.id, item.stockQuantity + 1)}
                              className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold flex items-center justify-center text-xs"
                            >
                              +
                            </button>
                          </div>
                        </td>
                        <td className="p-3">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${expiry.color}`}>
                            {expiry.label}
                          </span>
                        </td>
                        <td className="p-3">
                          <button
                          onClick={() => toggleCafeteriaItemAvailability(item.id)}
                          className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border transition-colors ${
                            item.isAvailable
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                              : 'bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20'
                          }`}
                        >
                          {item.isAvailable ? 'Enabled' : 'Disabled'}
                        </button>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => {
                            setItemToEdit(item);
                            setIsItemModalOpen(true);
                          }}
                          className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-lg text-xs font-semibold transition-colors"
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Admin Add/Edit Item Modal */}
      <CafeteriaItemModal
        isOpen={isItemModalOpen}
        onClose={() => {
          setIsItemModalOpen(false);
          setItemToEdit(null);
        }}
        itemToEdit={itemToEdit}
      />

      {/* Prominent Create Order Modal */}
      <CreateCafeteriaOrderModal
        isOpen={isCreateOrderModalOpen}
        onClose={() => setIsCreateOrderModalOpen(false)}
        onOpenReceiptModal={onOpenReceiptModal}
      />

      {/* Edit Order Modal */}
      <EditCafeteriaOrderModal
        isOpen={!!orderToEdit}
        onClose={() => setOrderToEdit(null)}
        order={orderToEdit}
      />

      {/* Order Details Modal */}
      <CafeteriaOrderDetailsModal
        isOpen={!!selectedOrderForDetails}
        onClose={() => setSelectedOrderForDetails(null)}
        order={selectedOrderForDetails}
        onOpenReceiptModal={onOpenReceiptModal}
      />

      {/* Cancel Order Confirmation Modal */}
      {orderToCancel && (
        <div
          id="cancel-order-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          onClick={(e) => {
            if (e.target === e.currentTarget) setOrderToCancel(null);
          }}
        >
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <Ban className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Cancel Order #{orderToCancel.id.slice(-6)}?</h3>
                <p className="text-xs text-slate-400">
                  Customer: <span className="text-slate-200 font-semibold">{orderToCancel.customerName}</span> &middot; {settings.currencySymbol} {orderToCancel.totalAmount}
                </p>
              </div>
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-amber-300">
              Cancelling this order will automatically restore all {orderToCancel.items.reduce((a, i) => a + i.quantity, 0)} item(s) back to the cafeteria inventory stock.
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Cancellation Reason (Optional)
              </label>
              <input
                type="text"
                value={cancelReasonInput}
                onChange={(e) => setCancelReasonInput(e.target.value)}
                placeholder="e.g. Customer cancelled, duplicate entry, incorrect items"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setOrderToCancel(null)}
                disabled={isCancellingOrder}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-colors"
              >
                Keep Order
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                disabled={isCancellingOrder}
                className="px-4 py-2 bg-rose-500 hover:bg-rose-400 text-white rounded-xl text-xs font-bold transition-colors disabled:opacity-50"
              >
                {isCancellingOrder ? 'Cancelling & Restoring Stock...' : 'Confirm Cancel Order'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
