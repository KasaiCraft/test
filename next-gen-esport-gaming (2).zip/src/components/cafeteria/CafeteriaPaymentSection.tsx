import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Banknote,
  QrCode,
  CreditCard,
  MoreHorizontal,
  Split,
  CheckCircle2,
  Clock,
  Sparkles,
  RotateCcw,
  Check,
} from 'lucide-react';
import { PaymentMethod, PaymentSplitItem, PaymentStatus } from '../../types';

export interface CafeteriaPaymentData {
  paymentMode: 'single' | 'split';
  paymentMethod: PaymentMethod;
  paidAmount: number;
  remaining: number;
  paymentStatus: PaymentStatus;
  splitPayments?: PaymentSplitItem[];
  isValid: boolean;
  errorMessage?: string | null;
}

interface CafeteriaPaymentSectionProps {
  totalBill: number;
  currencySymbol: string;
  onChange: (data: CafeteriaPaymentData) => void;
  defaultMode?: 'single' | 'split';
  defaultMethod?: PaymentMethod;
}

export const CafeteriaPaymentSection: React.FC<CafeteriaPaymentSectionProps> = ({
  totalBill,
  currencySymbol,
  onChange,
  defaultMode = 'single',
  defaultMethod = 'cash',
}) => {
  // Mode: Single vs Split
  const [paymentMode, setPaymentMode] = useState<'single' | 'split'>(defaultMode);

  // Single Payment States
  const [singleMethod, setSingleMethod] = useState<PaymentMethod>(
    defaultMethod === 'split' ? 'cash' : defaultMethod
  );
  // Default amount is the total bill
  const [singleAmountPaidStr, setSingleAmountPaidStr] = useState<string>(String(totalBill));
  const [singleWasEdited, setSingleWasEdited] = useState<boolean>(false);

  // Split Payment States: Cash, UPI, Card, Other
  const [cashInput, setCashInput] = useState<string>('');
  const [upiInput, setUpiInput] = useState<string>('');
  const [cardInput, setCardInput] = useState<string>('');
  const [otherInput, setOtherInput] = useState<string>('');

  // Warning feedback if user tried to exceed
  const [warningMessage, setWarningMessage] = useState<string | null>(null);
  const warningTimerRef = useRef<NodeJS.Timeout | null>(null);

  const showWarning = (msg: string) => {
    setWarningMessage(msg);
    if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
    warningTimerRef.current = setTimeout(() => {
      setWarningMessage(null);
    }, 3500);
  };

  // Sync singleAmountPaidStr if totalBill changes and user hasn't deliberately edited it
  const prevBillRef = useRef<number>(totalBill);
  const singleWasEditedRef = useRef(singleWasEdited);
  singleWasEditedRef.current = singleWasEdited;

  useEffect(() => {
    if (prevBillRef.current !== totalBill) {
      setSingleAmountPaidStr((prev) => {
        if (!singleWasEditedRef.current || parseFloat(prev) === prevBillRef.current) {
          return String(totalBill);
        }
        const currentVal = parseFloat(prev) || 0;
        if (currentVal > totalBill) {
          return String(totalBill);
        }
        return prev;
      });
      prevBillRef.current = totalBill;
    }
  }, [totalBill]);

  // --- Calculations for Single Payment ---
  const numericSinglePaid = useMemo(() => {
    if (singleAmountPaidStr.trim() === '') return 0;
    const val = parseFloat(singleAmountPaidStr);
    if (isNaN(val) || val < 0) return 0;
    return Math.min(val, totalBill);
  }, [singleAmountPaidStr, totalBill]);

  const singleRemaining = Math.max(
    0,
    Math.round((totalBill - numericSinglePaid) * 100) / 100
  );

  const singleStatus: PaymentStatus =
    numericSinglePaid >= totalBill ? 'paid' : 'pending';

  // --- Calculations for Split Payment ---
  const numericCash = parseFloat(cashInput) || 0;
  const numericUpi = parseFloat(upiInput) || 0;
  const numericCard = parseFloat(cardInput) || 0;
  const numericOther = parseFloat(otherInput) || 0;

  // Total Paid = Sum of all payment amounts
  const splitTotalPaid = useMemo(() => {
    const sum = numericCash + numericUpi + numericCard + numericOther;
    return Math.round(sum * 100) / 100;
  }, [numericCash, numericUpi, numericCard, numericOther]);

  const splitRemaining = Math.max(
    0,
    Math.round((totalBill - splitTotalPaid) * 100) / 100
  );

  const splitStatus: PaymentStatus =
    splitTotalPaid >= totalBill ? 'paid' : 'pending';

  // Build split details array for non-zero amounts
  const splitItems = useMemo<PaymentSplitItem[]>(() => {
    const items: PaymentSplitItem[] = [];
    if (numericCash > 0) items.push({ method: 'cash', amount: numericCash });
    if (numericUpi > 0) items.push({ method: 'upi', amount: numericUpi });
    if (numericCard > 0) items.push({ method: 'card', amount: numericCard });
    if (numericOther > 0) items.push({ method: 'other', amount: numericOther });
    return items;
  }, [numericCash, numericUpi, numericCard, numericOther]);

  // Emit current state to parent safely
  const onChangeRef = useRef(onChange);
  useEffect(() => {
    onChangeRef.current = onChange;
  });

  const lastEmittedPayloadRef = useRef<string>('');

  const currentPayload: CafeteriaPaymentData = useMemo(() => {
    if (paymentMode === 'single') {
      return {
        paymentMode: 'single',
        paymentMethod: singleMethod,
        paidAmount: numericSinglePaid,
        remaining: singleRemaining,
        paymentStatus: 'pending', // Default to pending until saved
        splitPayments: undefined,
        isValid: true,
      };
    } else {
      return {
        paymentMode: 'split',
        paymentMethod: 'split',
        paidAmount: splitTotalPaid,
        remaining: splitRemaining,
        paymentStatus: 'pending', // Default to pending until saved
        splitPayments: splitItems.length > 0 ? splitItems : undefined,
        isValid: true,
      };
    }
  }, [
    paymentMode,
    singleMethod,
    numericSinglePaid,
    singleRemaining,
    singleStatus,
    splitTotalPaid,
    splitRemaining,
    splitStatus,
    splitItems,
  ]);

  useEffect(() => {
    const serialized = JSON.stringify(currentPayload);
    if (lastEmittedPayloadRef.current !== serialized) {
      lastEmittedPayloadRef.current = serialized;
      onChangeRef.current(currentPayload);
    }
  }, [currentPayload]);

  // Handle Single Payment Amount Change (Editable, cannot exceed total bill)
  const handleSingleAmountChange = (raw: string) => {
    setSingleWasEdited(true);
    if (raw === '') {
      setSingleAmountPaidStr('');
      return;
    }
    const val = parseFloat(raw);
    if (isNaN(val)) {
      setSingleAmountPaidStr('');
      return;
    }
    if (val < 0) {
      setSingleAmountPaidStr('0');
      return;
    }
    // Payment cannot exceed total bill rule
    if (val > totalBill) {
      setSingleAmountPaidStr(String(totalBill));
      showWarning(`Amount paid cannot exceed total bill (${currencySymbol} ${totalBill})`);
      return;
    }
    setSingleAmountPaidStr(raw);
  };

  // Handle Split Amount Changes (Editable, cannot exceed total bill)
  const handleSplitFieldChange = (
    field: 'cash' | 'upi' | 'card' | 'other',
    raw: string
  ) => {
    if (raw === '') {
      if (field === 'cash') setCashInput('');
      if (field === 'upi') setUpiInput('');
      if (field === 'card') setCardInput('');
      if (field === 'other') setOtherInput('');
      return;
    }

    const val = parseFloat(raw);
    if (isNaN(val) || val < 0) return;

    // Calculate sum of the other 3 fields
    const otherSum =
      (field !== 'cash' ? numericCash : 0) +
      (field !== 'upi' ? numericUpi : 0) +
      (field !== 'card' ? numericCard : 0) +
      (field !== 'other' ? numericOther : 0);

    const maxAllowed = Math.max(0, Math.round((totalBill - otherSum) * 100) / 100);

    // If new value exceeds what's left of the bill, cap it
    if (val > maxAllowed) {
      const capped = maxAllowed > 0 ? String(maxAllowed) : '0';
      if (field === 'cash') setCashInput(capped);
      if (field === 'upi') setUpiInput(capped);
      if (field === 'card') setCardInput(capped);
      if (field === 'other') setOtherInput(capped);
      showWarning(
        `Total paid cannot exceed total bill (${currencySymbol} ${totalBill}). Field capped at ${currencySymbol} ${maxAllowed}.`
      );
      return;
    }

    if (field === 'cash') setCashInput(raw);
    if (field === 'upi') setUpiInput(raw);
    if (field === 'card') setCardInput(raw);
    if (field === 'other') setOtherInput(raw);
  };

  // Fill balance shortcut for split fields
  const handleFillBalance = (field: 'cash' | 'upi' | 'card' | 'other') => {
    const otherSum =
      (field !== 'cash' ? numericCash : 0) +
      (field !== 'upi' ? numericUpi : 0) +
      (field !== 'card' ? numericCard : 0) +
      (field !== 'other' ? numericOther : 0);

    const needed = Math.max(0, Math.round((totalBill - otherSum) * 100) / 100);
    const neededStr = needed > 0 ? String(needed) : '0';

    if (field === 'cash') setCashInput(neededStr);
    if (field === 'upi') setUpiInput(neededStr);
    if (field === 'card') setCardInput(neededStr);
    if (field === 'other') setOtherInput(neededStr);
  };

  // Quick split 50/50
  const handleQuick5050 = (m1: 'cash' | 'upi' | 'card', m2: 'cash' | 'upi' | 'card') => {
    const half = Math.round((totalBill / 2) * 100) / 100;
    const remainder = Math.round((totalBill - half) * 100) / 100;

    setCashInput('');
    setUpiInput('');
    setCardInput('');
    setOtherInput('');

    if (m1 === 'cash') setCashInput(String(half));
    if (m1 === 'upi') setUpiInput(String(half));
    if (m1 === 'card') setCardInput(String(half));

    if (m2 === 'cash') setCashInput(String(remainder));
    if (m2 === 'upi') setUpiInput(String(remainder));
    if (m2 === 'card') setCardInput(String(remainder));
  };

  // Clear all split entries
  const handleClearSplit = () => {
    setCashInput('');
    setUpiInput('');
    setCardInput('');
    setOtherInput('');
  };

  const singleMethods: { id: PaymentMethod; label: string; icon: any; colorClass: string }[] = [
    { id: 'cash', label: 'Cash', icon: Banknote, colorClass: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10' },
    { id: 'upi', label: 'UPI', icon: QrCode, colorClass: 'text-cyan-400 border-cyan-500/40 bg-cyan-500/10' },
    { id: 'card', label: 'Card', icon: CreditCard, colorClass: 'text-indigo-400 border-indigo-500/40 bg-indigo-500/10' },
    { id: 'other', label: 'Other', icon: MoreHorizontal, colorClass: 'text-amber-400 border-amber-500/40 bg-amber-500/10' },
  ];

  return (
    <div id="cafeteria-payment-ui" className="space-y-3.5">
      {/* Header & Mode Switcher */}
      <div className="flex items-center justify-between">
        <label className="text-xs font-bold text-white uppercase tracking-wider">
          Payment Mode
        </label>
        <div className="flex rounded-xl bg-slate-900 border border-slate-800 p-0.5 text-xs">
          <button
            type="button"
            id="cafeteria-single-payment-tab"
            onClick={() => setPaymentMode('single')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              paymentMode === 'single'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Single Payment
          </button>
          <button
            type="button"
            id="cafeteria-split-payment-tab"
            onClick={() => setPaymentMode('split')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              paymentMode === 'split'
                ? 'bg-gradient-to-r from-amber-500 to-orange-400 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Split className="w-3.5 h-3.5" />
            <span>Split Payment</span>
          </button>
        </div>
      </div>

      {/* Warning banner if payment was capped */}
      {warningMessage && (
        <div className="p-2.5 bg-amber-500/15 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-center gap-2 animate-fadeIn">
          <Clock className="w-4 h-4 shrink-0 text-amber-400" />
          <span>{warningMessage}</span>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION: SINGLE PAYMENT                                   */}
      {/* ========================================================= */}
      {paymentMode === 'single' && (
        <div
          id="single-payment-container"
          className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-3.5 sm:p-4 space-y-3.5"
        >
          {/* Total Bill Display */}
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-800/80">
            <span className="text-xs font-semibold text-slate-400">Total Bill:</span>
            <span className="text-sm sm:text-base font-black text-white font-mono">
              {currencySymbol} {totalBill.toLocaleString('en-IN')}
            </span>
          </div>

          {/* Payment Method: Cash / UPI / Card / Other */}
          <div>
            <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-2">
              Payment Method
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {singleMethods.map((m) => {
                const Icon = m.icon;
                const isSelected = singleMethod === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    id={`single-method-${m.id}-btn`}
                    onClick={() => setSingleMethod(m.id)}
                    className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? `${m.colorClass} ring-2 ring-amber-500/50 shadow-md`
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{m.label}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 ml-auto text-amber-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amount Paid: ₹___ (Editable) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="single-amount-paid-input"
                className="text-[11px] font-bold text-slate-300 uppercase tracking-wider"
              >
                Amount Paid
              </label>
              {/* Quick shortcut buttons */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setSingleWasEdited(true);
                    setSingleAmountPaidStr(String(totalBill));
                  }}
                  className="text-[10px] bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-2 py-0.5 rounded-md border border-slate-700 transition-colors font-medium cursor-pointer"
                >
                  Full Bill ({currencySymbol}{totalBill})
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSingleWasEdited(true);
                    setSingleAmountPaidStr('0');
                  }}
                  className="text-[10px] bg-slate-900 hover:bg-rose-950/30 text-slate-400 hover:text-rose-300 px-2 py-0.5 rounded-md border border-slate-700 transition-colors font-medium cursor-pointer"
                >
                  Set ₹0 (Pending)
                </button>
              </div>
            </div>

            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                {currencySymbol}
              </span>
              <input
                id="single-amount-paid-input"
                type="number"
                min="0"
                max={totalBill}
                step="any"
                placeholder={`0.00 (Max ${totalBill})`}
                value={singleAmountPaidStr}
                onChange={(e) => handleSingleAmountChange(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-3.5 py-2.5 text-sm font-mono font-bold text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all"
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              * Payment cannot exceed total bill. Amount field is editable for partial or pending orders.
            </p>
          </div>

          {/* Remaining: ₹___ */}
          <div className="pt-2.5 border-t border-slate-800/80 grid grid-cols-1 gap-2 items-center">
            <div>
              <span className="text-[11px] text-slate-400 font-semibold block">Remaining Balance:</span>
              <span
                id="single-remaining-display"
                className={`text-sm sm:text-base font-bold font-mono ${
                  singleRemaining === 0 ? 'text-slate-400' : 'text-amber-400'
                }`}
              >
                {currencySymbol} {singleRemaining.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION: SPLIT PAYMENT                                    */}
      {/* ========================================================= */}
      {paymentMode === 'split' && (
        <div
          id="split-payment-container"
          className="bg-slate-950/80 border border-amber-500/30 rounded-2xl p-3.5 sm:p-4 space-y-3.5 shadow-inner"
        >
          {/* Total Bill Display & Quick Presets */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-800/80">
            <div>
              <span className="text-xs font-semibold text-slate-400 mr-2">Total Bill:</span>
              <span className="text-sm sm:text-base font-black text-white font-mono">
                {currencySymbol} {totalBill.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Quick Presets */}
            <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
              <span className="text-slate-400 flex items-center gap-1 mr-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                Presets:
              </span>
              <button
                type="button"
                id="split-preset-cash-upi"
                onClick={() => handleQuick5050('cash', 'upi')}
                className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-2 py-1 rounded-lg border border-slate-700 transition-colors font-medium cursor-pointer"
              >
                Cash + UPI (50/50)
              </button>
              <button
                type="button"
                id="split-preset-card-upi"
                onClick={() => handleQuick5050('card', 'upi')}
                className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-2 py-1 rounded-lg border border-slate-700 transition-colors font-medium cursor-pointer"
              >
                Card + UPI (50/50)
              </button>
              <button
                type="button"
                id="split-preset-clear"
                onClick={handleClearSplit}
                className="text-slate-400 hover:text-rose-400 px-1.5 py-1 transition-colors flex items-center gap-1 cursor-pointer"
                title="Reset all split amounts"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Clear</span>
              </button>
            </div>
          </div>

          {/* Multiple Payment Entries: Cash, UPI, Card, Other */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* 1. Cash */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <Banknote className="w-3.5 h-3.5" />
                  <span>Cash</span>
                </div>
                <button
                  type="button"
                  id="fill-balance-cash-btn"
                  onClick={() => handleFillBalance('cash')}
                  className="text-[10px] text-slate-400 hover:text-emerald-300 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                  {currencySymbol}
                </span>
                <input
                  id="split-cash-amount-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={cashInput}
                  onChange={(e) => handleSplitFieldChange('cash', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-emerald-400 transition-all"
                />
              </div>
            </div>

            {/* 2. UPI */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
                  <QrCode className="w-3.5 h-3.5" />
                  <span>UPI</span>
                </div>
                <button
                  type="button"
                  id="fill-balance-upi-btn"
                  onClick={() => handleFillBalance('upi')}
                  className="text-[10px] text-slate-400 hover:text-cyan-300 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                  {currencySymbol}
                </span>
                <input
                  id="split-upi-amount-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={upiInput}
                  onChange={(e) => handleSplitFieldChange('upi', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-cyan-400 transition-all"
                />
              </div>
            </div>

            {/* 3. Card */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-400">
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Card</span>
                </div>
                <button
                  type="button"
                  id="fill-balance-card-btn"
                  onClick={() => handleFillBalance('card')}
                  className="text-[10px] text-slate-400 hover:text-indigo-300 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                  {currencySymbol}
                </span>
                <input
                  id="split-card-amount-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={cardInput}
                  onChange={(e) => handleSplitFieldChange('card', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-indigo-400 transition-all"
                />
              </div>
            </div>

            {/* 4. Other */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                  <MoreHorizontal className="w-3.5 h-3.5" />
                  <span>Other</span>
                </div>
                <button
                  type="button"
                  id="fill-balance-other-btn"
                  onClick={() => handleFillBalance('other')}
                  className="text-[10px] text-slate-400 hover:text-amber-300 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                  {currencySymbol}
                </span>
                <input
                  id="split-other-amount-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={otherInput}
                  onChange={(e) => handleSplitFieldChange('other', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400 transition-all"
                />
              </div>
            </div>
          </div>

          {/* Automatic Calculation Summary */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 space-y-2">
            {/* Total Paid = Sum of all payment amounts */}
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-semibold">Total Paid (Sum of entries):</span>
              <span
                id="split-total-paid-display"
                className={`text-sm font-black font-mono ${
                  splitTotalPaid === totalBill
                    ? 'text-emerald-400'
                    : splitTotalPaid > 0
                    ? 'text-amber-400'
                    : 'text-slate-400'
                }`}
              >
                {currencySymbol} {splitTotalPaid.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Remaining */}
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-400 font-semibold">Remaining Balance:</span>
              <span
                id="split-remaining-display"
                className={`font-mono font-bold ${
                  splitRemaining === 0 ? 'text-slate-400' : 'text-amber-400'
                }`}
              >
                {currencySymbol} {splitRemaining.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
