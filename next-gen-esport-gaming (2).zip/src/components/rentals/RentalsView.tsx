import React, { useState } from 'react';
import {
  Package,
  Plus,
  Search,
  Filter,
  AlertCircle,
  CheckCircle2,
  Clock,
  RotateCcw,
  Edit2,
  Trash2,
  Layers,
  ShieldCheck,
  User,
  Phone,
  Calendar,
  AlertTriangle,
  ArrowDownLeft,
  Gamepad2,
  MapPin,
  Monitor,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { RentalItem, RentalRecord, RentalCategory } from '../../types';
import { RENTAL_PRICING } from '../../config/rentalPricing';

interface RentalsViewProps {
  onOpenNewRental: (preselectedItemId?: string) => void;
  onOpenReturnRental: (record: RentalRecord) => void;
  onOpenExtendRental?: (record: RentalRecord) => void;
  onOpenRentalItemModal: (itemToEdit?: RentalItem) => void;
}

export const RentalsView: React.FC<RentalsViewProps> = ({
  onOpenNewRental,
  onOpenReturnRental,
  onOpenExtendRental,
  onOpenRentalItemModal,
}) => {
  const {
    rentalItems,
    rentalRecords,
    activeRentals,
    isAdmin,
    settings,
    deleteRentalItem,
  } = useCafe();

  const [activeTab, setActiveTab] = useState<'inventory' | 'active_rentals' | 'history'>('inventory');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories: RentalCategory[] = [
    'Controller',
    'VR Headset',
    'Headphones',
    'Racing Wheel',
    'Accessory',
    'Console',
    'Game Disc',
    'Other',
  ];

  const filteredItems = rentalItems.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const filteredRecords = rentalRecords.filter((rec) => {
    return (
      rec.rentalItemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.customerPhone.includes(searchQuery)
    );
  });

  const [itemToDelete, setItemToDelete] = useState<RentalItem | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const confirmDeleteItem = async () => {
    if (!itemToDelete || !isAdmin) return;
    if (itemToDelete.rentedQuantity > 0) {
      setDeleteError(`Cannot delete "${itemToDelete.name}" while ${itemToDelete.rentedQuantity} unit(s) are currently rented out. Settle all returns first.`);
      return;
    }
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteRentalItem(itemToDelete.id);
      setItemToDelete(null);
    } catch (err: any) {
      setDeleteError(err?.message || 'Failed to delete rental gear.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div id="rentals-view" className="space-y-6 pb-12">
      {/* Top Header & View Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4 bg-slate-900/80 p-3.5 sm:p-5 rounded-2xl border border-slate-800">
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 bg-slate-950/80 p-1 rounded-xl border border-slate-800 w-full md:w-auto">
          <button
            id="rentals-tab-inventory"
            onClick={() => setActiveTab('inventory')}
            className={`flex-1 sm:flex-initial px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all text-center cursor-pointer ${
              activeTab === 'inventory'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Gear Inventory ({rentalItems.length})
          </button>
          <button
            id="rentals-tab-active"
            onClick={() => setActiveTab('active_rentals')}
            className={`flex-1 sm:flex-initial px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all text-center cursor-pointer ${
              activeTab === 'active_rentals'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Active Rentals ({activeRentals.length})
          </button>
          <button
            id="rentals-tab-history"
            onClick={() => setActiveTab('history')}
            className={`flex-1 sm:flex-initial px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all text-center cursor-pointer ${
              activeTab === 'history'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Rental Log
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 w-full md:w-auto">
          <button
            id="create-rental-btn"
            onClick={() => onOpenNewRental()}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs sm:text-sm shadow-md shadow-amber-500/20 transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>New Rental Booking</span>
          </button>

          {isAdmin && activeTab === 'inventory' && (
            <button
              id="add-rental-item-btn"
              onClick={() => onOpenRentalItemModal()}
              className="flex-1 md:flex-initial flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold px-4 py-2 rounded-xl text-xs sm:text-sm border border-slate-700 transition-all cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4 text-cyan-400" />
              <span>Add Hardware Item</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="flex flex-wrap items-center gap-3 bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="rentals-search-input"
            type="text"
            placeholder="Search gear, customer, or equipment name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-9 pr-4 py-1.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {activeTab === 'inventory' && (
          <select
            id="rental-category-filter"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* TAB 1: Inventory Management */}
      {activeTab === 'inventory' && (
        <div className="space-y-6">
          {/* Standard Rental Packages Quick Reference */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                <Monitor className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white uppercase tracking-wider">Standard Rental Packages</h3>
                <p className="text-xs text-slate-400">Fixed business pricing for PS4 & PS5 bundles</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* PS5 Table */}
              <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl overflow-hidden">
                <div className="bg-slate-800/40 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-black text-white tracking-widest uppercase">PS5 Standard Bundle</span>
                  <span className="text-[10px] font-bold text-cyan-400">Incl. 2 Ctrl + 1 Game</span>
                </div>
                <div className="p-3">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-slate-500 font-bold uppercase text-[9px] border-b border-slate-800/50">
                        <td className="py-2">Duration</td>
                        <td className="py-2 text-right">Price</td>
                      </tr>
                    </thead>
                    <tbody className="text-slate-300 font-medium">
                      <tr className="border-b border-slate-800/30">
                        <td className="py-2.5">1 Day Package</td>
                        <td className="py-2.5 text-right font-bold text-white">₹{RENTAL_PRICING.PS5.base['1day']}</td>
                      </tr>
                      <tr className="border-b border-slate-800/30">
                        <td className="py-2.5">3 Days Package</td>
                        <td className="py-2.5 text-right font-bold text-white">₹{RENTAL_PRICING.PS5.base['3days']}</td>
                      </tr>
                      <tr className="border-b border-slate-800/30">
                        <td className="py-2.5">7 Days Package</td>
                        <td className="py-2.5 text-right font-bold text-white">₹{RENTAL_PRICING.PS5.base['7days']}</td>
                      </tr>
                      <tr>
                        <td className="py-2.5">1 Month (30 Days)</td>
                        <td className="py-2.5 text-right font-black text-emerald-400">₹{RENTAL_PRICING.PS5.base['30days']}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* PS4 Table */}
              <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl overflow-hidden">
                <div className="bg-slate-800/40 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-black text-white tracking-widest uppercase">PS4 Standard Bundle</span>
                  <span className="text-[10px] font-bold text-blue-400">Incl. 2 Ctrl + 1 Game</span>
                </div>
                <div className="p-3">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-slate-500 font-bold uppercase text-[9px] border-b border-slate-800/50">
                        <td className="py-2">Duration</td>
                        <td className="py-2 text-right">Price</td>
                      </tr>
                    </thead>
                    <tbody className="text-slate-300 font-medium">
                      <tr className="border-b border-slate-800/30">
                        <td className="py-2.5">1 Day Package</td>
                        <td className="py-2.5 text-right font-bold text-white">₹{RENTAL_PRICING.PS4.base['1day']}</td>
                      </tr>
                      <tr className="border-b border-slate-800/30">
                        <td className="py-2.5">3 Days Package</td>
                        <td className="py-2.5 text-right font-bold text-white">₹{RENTAL_PRICING.PS4.base['3days']}</td>
                      </tr>
                      <tr className="border-b border-slate-800/30">
                        <td className="py-2.5">7 Days Package</td>
                        <td className="py-2.5 text-right font-bold text-white">₹{RENTAL_PRICING.PS4.base['7days']}</td>
                      </tr>
                      <tr>
                        <td className="py-2.5">1 Month (30 Days)</td>
                        <td className="py-2.5 text-right font-black text-emerald-400">₹{RENTAL_PRICING.PS4.base['30days']}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2 text-[10px] text-slate-500 bg-slate-950/40 p-2.5 rounded-lg border border-slate-800/50">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
              <span>Note: These standard packages are pre-configured. Use "New Rental Booking" and select "Standard Rental" mode to apply these prices automatically.</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredItems.map((item) => {
            const hasStock = item.availableQuantity > 0;
            return (
              <div
                key={item.id}
                id={`rental-item-card-${item.id}`}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between shadow-lg shadow-black/20 hover:border-slate-700 transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                        {item.category}
                      </span>
                      <h3 className="text-base font-bold text-white mt-1.5 leading-tight">
                        {item.name}
                      </h3>
                    </div>

                    <div className="text-right shrink-0">
                      <span
                        className={`text-xs font-bold px-2 py-1 rounded-lg ${
                          hasStock
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/20'
                            : 'bg-rose-500/15 text-rose-300 border border-rose-500/20'
                        }`}
                      >
                        {item.availableQuantity} / {item.totalQuantity} Left
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2 mb-4">
                    {item.description || 'Premium cafe gaming equipment available for hourly or daily rental.'}
                  </p>

                  {/* Pricing Matrix */}
                  <div className="grid grid-cols-3 gap-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 text-xs">
                    <div>
                      <p className="text-[10px] text-slate-500 uppercase font-semibold">Hourly</p>
                      <p className="font-bold text-slate-200 mt-0.5">
                        {settings.currencySymbol} {item.hourlyRate}/h
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 uppercase font-semibold">Daily</p>
                      <p className="font-bold text-slate-200 mt-0.5">
                        {settings.currencySymbol} {item.dailyRate}/d
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 uppercase font-semibold">Deposit</p>
                      <p className="font-bold text-amber-400 mt-0.5">
                        {settings.currencySymbol} {item.securityDeposit}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Card Bottom Actions */}
                <div className="flex items-center justify-between gap-2 mt-5 pt-3 border-t border-slate-800">
                  <button
                    id={`rent-now-btn-${item.id}`}
                    onClick={() => onOpenNewRental(item.id)}
                    disabled={!hasStock}
                    className="flex-1 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold py-2 px-3 rounded-xl text-xs transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {hasStock ? 'Rent Gear' : 'Out of Stock'}
                  </button>

                  {isAdmin && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onOpenRentalItemModal(item)}
                        title="Edit Item"
                        className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded-lg transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        id={`delete-rental-btn-${item.id}`}
                        onClick={() => {
                          setDeleteError(null);
                          setItemToDelete(item);
                        }}
                        title="Delete Item"
                        disabled={item.rentedQuantity > 0}
                        className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-40 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          </div>
        </div>
      )}

      {activeTab === 'inventory' && filteredItems.length === 0 && (
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-10 text-center space-y-3">
          <Gamepad2 className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-semibold text-slate-300">No Rental Equipment Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Your rental gear inventory is currently empty. Click "Add Rental Gear" above to register controllers, headsets, or accessories.
          </p>
          {isAdmin && (
            <button
              onClick={() => onOpenRentalItemModal()}
              className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add First Rental Item</span>
            </button>
          )}
        </div>
      )}

      {/* TAB 2: Active Rentals & Returns */}
      {activeTab === 'active_rentals' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeRentals.map((record) => {
              const isOverdue =
                record.status === 'overdue' ||
                new Date(record.expectedReturnTime).getTime() < Date.now();

              return (
                <div
                  key={record.id}
                  id={`active-rental-card-${record.id}`}
                  className={`bg-slate-900/90 border rounded-2xl p-5 flex flex-col justify-between shadow-lg ${
                    isOverdue
                      ? 'border-rose-500/40 shadow-rose-500/10'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div>
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                            isOverdue
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                          }`}
                        >
                          {isOverdue ? 'Overdue Return' : 'Active Gear Out'}
                        </span>
                        <h3 className="text-base font-bold text-white mt-1.5">
                          {record.rentalItemName}
                        </h3>
                        <p className="text-xs text-slate-400">
                          Qty: <span className="text-white font-bold">{record.quantity} unit(s)</span>
                        </p>
                      </div>

                      <div className="text-right">
                        <p className="text-xs text-slate-400">Held Deposit</p>
                        <p className="text-sm font-bold text-amber-400">
                          {settings.currencySymbol} {record.depositAmount}
                        </p>
                      </div>
                    </div>

                    {/* Customer Info Box */}
                    <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 space-y-2 text-xs">
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="flex items-center gap-1.5 font-medium">
                          <User className="w-3.5 h-3.5 text-cyan-400" />
                          {record.customerName}
                        </span>
                        <span className="font-mono text-slate-400">{record.customerPhone}</span>
                      </div>

                      {/* Aadhaar ID Verification Badge */}
                      <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-800/80">
                        <span className="text-slate-400">Aadhaar Proof:</span>
                        {record.aadhaarCollected ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 text-[10px]">
                            <ShieldCheck className="w-3 h-3 text-emerald-400" />
                            Verified {record.customerAadhaar ? `(${record.customerAadhaar})` : ''}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-400/90 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 text-[10px]">
                            Pending ID Proof
                          </span>
                        )}
                      </div>

                      {/* Customer Address if recorded */}
                      {record.customerAddress && (
                        <div className="text-[11px] text-slate-300 flex items-start gap-1.5 pt-1.5 border-t border-slate-800/80">
                          <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                          <span className="text-slate-300 line-clamp-2" title={record.customerAddress}>
                            {record.customerAddress}
                          </span>
                        </div>
                      )}

                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1.5 border-t border-slate-800">
                        <span>Expected Return:</span>
                        <span className={`font-mono font-bold ${isOverdue ? 'text-rose-400' : 'text-slate-300'}`}>
                          {new Date(record.expectedReturnTime).toLocaleString([], {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Return Action Button */}
                  <div className="mt-4 pt-3 border-t border-slate-800 flex gap-2">
                    {onOpenExtendRental && (
                      <button
                        onClick={() => onOpenExtendRental(record)}
                        className="flex-1 flex items-center justify-center gap-2 bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 font-bold py-2.5 px-3 rounded-xl text-xs transition-all border border-amber-500/30 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Extend</span>
                      </button>
                    )}
                    <button
                      id={`return-gear-btn-${record.id}`}
                      onClick={() => onOpenReturnRental(record)}
                      className="flex-[2] flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs sm:text-sm shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Return & Settle</span>
                    </button>
                  </div>
                </div>
              );
            })}

            {activeRentals.length === 0 && (
              <div className="col-span-full py-16 text-center bg-slate-900/60 rounded-2xl border border-slate-800 text-slate-400">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <p className="text-base font-semibold text-slate-300">All Gear Accounted For</p>
                <p className="text-xs text-slate-500 mt-1">No active hardware rentals currently out.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: Complete Rental History */}
      {activeTab === 'history' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 overflow-hidden shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Equipment</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Qty</th>
                  <th className="p-3">Rented At</th>
                  <th className="p-3">Returned At</th>
                  <th className="p-3">Fee Paid</th>
                  <th className="p-3">Deposit Refunded</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-800/40">
                    <td className="p-3 font-semibold text-white">{r.rentalItemName}</td>
                    <td className="p-3">
                      <div className="font-semibold text-white">{r.customerName}</div>
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-0.5 font-mono">
                        <span>{r.customerPhone}</span>
                        {r.aadhaarCollected && (
                          <span
                            className="inline-flex items-center text-emerald-400 font-semibold"
                            title={r.customerAadhaar ? `Aadhaar ID: ${r.customerAadhaar}` : 'Aadhaar Verified'}
                          >
                            • ID Verified
                          </span>
                        )}
                      </div>
                      {r.customerAddress && (
                        <div className="text-[10px] text-slate-400 truncate max-w-[180px] mt-0.5" title={r.customerAddress}>
                          📍 {r.customerAddress}
                        </div>
                      )}
                    </td>
                    <td className="p-3 font-mono">{r.quantity}</td>
                    <td className="p-3 font-mono text-slate-400">
                      {new Date(r.startTime).toLocaleDateString()}
                    </td>
                    <td className="p-3 font-mono text-slate-400">
                      {r.actualReturnTime ? new Date(r.actualReturnTime).toLocaleDateString() : '--'}
                    </td>
                    <td className="p-3 font-bold text-emerald-400">
                      {settings.currencySymbol} {r.rentalFee}
                    </td>
                    <td className="p-3 font-bold text-amber-400">
                      {settings.currencySymbol} {r.depositRefunded}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                          r.status === 'returned'
                            ? 'bg-emerald-500/15 text-emerald-300'
                            : r.status === 'overdue'
                            ? 'bg-rose-500/15 text-rose-300'
                            : 'bg-cyan-500/15 text-cyan-300'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* In-App Delete Rental Item Modal */}
      {itemToDelete && (
        <div
          id="delete-rental-item-modal-backdrop"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
        >
          <div
            id="delete-rental-item-modal-card"
            className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete Rental Equipment</h3>
                <p className="text-xs text-slate-400">Remove item from rental inventory.</p>
              </div>
            </div>

            {deleteError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Equipment:</span>
                <span className="font-semibold text-white">{itemToDelete.name}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Category:</span>
                <span className="text-amber-400 font-medium">{itemToDelete.category}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Total Stock:</span>
                <span className="font-mono text-white">{itemToDelete.totalQuantity} units</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Currently Rented:</span>
                <span className={`font-mono font-bold ${itemToDelete.rentedQuantity > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {itemToDelete.rentedQuantity} units
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setItemToDelete(null);
                  setDeleteError(null);
                }}
                disabled={isDeleting}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="confirm-delete-rental-btn"
                type="button"
                onClick={confirmDeleteItem}
                disabled={isDeleting || itemToDelete.rentedQuantity > 0}
                className="bg-rose-600 hover:bg-rose-500 text-white font-bold px-5 py-2 rounded-xl text-xs transition-all shadow-md shadow-rose-600/20 cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Delete Gear'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
