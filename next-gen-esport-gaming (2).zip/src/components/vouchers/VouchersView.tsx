import React, { useState, useMemo } from 'react';
import {
  Ticket,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  Tag,
  DollarSign,
  User,
  Gamepad2,
  Filter,
  History,
  Printer,
  Copy,
  Check,
  ChevronRight,
  ShieldCheck,
  Sparkles,
  Calendar,
  Layers,
  ShoppingBag,
  Download,
  MinusCircle,
  Hourglass,
  Trash2,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import {
  Voucher,
  VoucherCategory,
  VoucherStatus,
  Customer,
  PaymentMethod,
} from '../../types';
import { OFFICIAL_VOUCHERS } from '../../data/voucherCatalog';

export const VouchersView: React.FC = () => {
  const {
    vouchers,
    voucherUsages,
    customers,
    addVoucher,
    updateVoucher,
    deleteVoucher,
    startVoucher,
    pauseVoucher,
    resumeVoucher,
    redeemVoucher,
    sellVoucher,
    isAdmin,
  } = useCafe();

  // Local state for live ticking UI (prevents full context re-renders every second)
  const [now, setNow] = useState(Date.now());
  React.useEffect(() => {
    const hasRunning = (vouchers || []).some(v => v.status === 'running');
    if (!hasRunning) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [vouchers]);

  const [activeTab, setActiveTab] = useState<'vouchers' | 'history'>('vouchers');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Modal states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isRedeemModalOpen, setIsRedeemModalOpen] = useState(false);
  const [isSellModalOpen, setIsSellModalOpen] = useState(false);
  const [selectedVoucherForSell, setSelectedVoucherForSell] = useState<Voucher | null>(null);
  const [printedVoucher, setPrintedVoucher] = useState<Voucher | null>(null);
  const [voucherToDelete, setVoucherToDelete] = useState<Voucher | null>(null);
  const [isDeletingVoucher, setIsDeletingVoucher] = useState(false);

  // Deduct / Log played hours modal
  const [isDeductModalOpen, setIsDeductModalOpen] = useState(false);
  const [selectedVoucherForDeduct, setSelectedVoucherForDeduct] = useState<Voucher | null>(null);
  const [deductHours, setDeductHours] = useState<number>(1);
  const [deductConsoleCode, setDeductConsoleCode] = useState('');
  const [deductNotes, setDeductNotes] = useState('');
  const [deductError, setDeductError] = useState<string | null>(null);
  const [deductSuccess, setDeductSuccess] = useState<string | null>(null);

  // Form states - Create
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    category: 'all' as VoucherCategory,
    type: 'time' as 'time' | 'value' | 'discount_percentage',
    hours: 7,
    durationMinutes: 420,
    valueAmount: 100,
    price: 350,
    usageLimit: 99,
    expiryDays: 30,
    purchaseDate: new Date().toISOString().split('T')[0],
    assignedCustomerId: '',
    notes: '',
  });

  // Form states - Redeem
  const [redeemCode, setRedeemCode] = useState('');
  const [redeemCustomerId, setRedeemCustomerId] = useState('');
  const [redeemConsoleCode, setRedeemConsoleCode] = useState('');
  const [redeemNotes, setRedeemNotes] = useState('');
  const [redeemError, setRedeemError] = useState<string | null>(null);
  const [redeemSuccess, setRedeemSuccess] = useState<string | null>(null);

  // Form states - Sell
  const [sellCustomerId, setSellCustomerId] = useState('');
  const [sellPaymentMethod, setSellPaymentMethod] = useState<PaymentMethod>('cash');
  const [sellPaidAmount, setSellPaidAmount] = useState<number>(0);
  const [sellNotes, setSellNotes] = useState('');

  // Copied code feedback
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Filtered Vouchers
  const filteredVouchers = useMemo(() => {
    return (vouchers || []).filter((v) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        v.code.toLowerCase().includes(q) ||
        v.name.toLowerCase().includes(q) ||
        (v.assignedCustomerName && v.assignedCustomerName.toLowerCase().includes(q));

      const matchesCat =
        selectedCategory === 'all' || v.category === selectedCategory;

      let isExpired = false;
      if (v.expiryDate && v.expiryDate !== 'never') {
        isExpired = new Date(v.expiryDate).getTime() < Date.now();
      }

      let statusCalculated = v.status;
      if (isExpired && v.status === 'active') {
        statusCalculated = 'expired';
      }

      const matchesStatus =
        selectedStatus === 'all' || statusCalculated === selectedStatus || v.status === selectedStatus;

      return matchesSearch && matchesCat && matchesStatus;
    });
  }, [vouchers, searchQuery, selectedCategory, selectedStatus]);

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle Create Voucher
  const handleCreateVoucher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || isSubmitting) return;

    setIsSubmitting(true);
    try {
      let expiryDate: string | undefined = undefined;
      if (formData.expiryDays > 0) {
        const d = new Date();
        d.setDate(d.getDate() + Number(formData.expiryDays));
        expiryDate = d.toISOString();
      } else {
        expiryDate = 'never';
      }

      const totalHours = formData.type === 'time' ? (Number(formData.hours) || Number(formData.durationMinutes) / 60) : 0;
      const durMinutes = formData.type === 'time' ? Math.round(totalHours * 60) : undefined;
      const assignedCust = customers.find((c) => c.id === formData.assignedCustomerId);

      const res = await addVoucher({
        name: formData.name.trim(),
        code: formData.code.trim().toUpperCase() || undefined,
        category: formData.category,
        type: formData.type,
        totalPurchasedHours: totalHours,
        usedHours: 0,
        remainingHours: totalHours,
        usedMinutes: 0,
        remainingMinutes: durMinutes,
        purchaseDate: formData.purchaseDate || new Date().toISOString(),
        assignedCustomerId: assignedCust?.id,
        assignedCustomerName: assignedCust?.name,
        assignedCustomerPhone: assignedCust?.phone,
        durationMinutes: durMinutes,
        valueAmount: formData.type === 'value' ? Number(formData.valueAmount) : undefined,
        price: Number(formData.price) || 0,
        usageLimit: Number(formData.usageLimit) || 99,
        expiryDate,
        status: 'active',
        notes: formData.notes.trim() || undefined,
      });

      if (res.success) {
        setIsCreateModalOpen(false);
        setFormData({
          name: '',
          code: '',
          category: 'all',
          type: 'time',
          hours: 7,
          durationMinutes: 420,
          valueAmount: 100,
          price: 350,
          usageLimit: 99,
          expiryDays: 30,
          purchaseDate: new Date().toISOString().split('T')[0],
          assignedCustomerId: '',
          notes: '',
        });
      } else {
        alert(res.error || 'Failed to create voucher');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Open Deduct Hours modal
  const handleOpenDeduct = (v: Voucher) => {
    setSelectedVoucherForDeduct(v);
    const rem = v.remainingHours !== undefined ? v.remainingHours : ((v.durationMinutes - (v.usedMinutes || 0)) / 60);
    setDeductHours(Math.min(5, Math.max(1, rem)));
    setDeductConsoleCode('');
    setDeductNotes('');
    setDeductError(null);
    setDeductSuccess(null);
    setIsDeductModalOpen(true);
  };

  // Handle Submit Deduct Hours
  const handleSubmitDeduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVoucherForDeduct) return;

    const hours = Number(deductHours);
    if (isNaN(hours) || hours <= 0) {
      setDeductError('Please enter a valid number of hours to deduct (greater than 0).');
      return;
    }

    const currentRem = selectedVoucherForDeduct.remainingHours !== undefined
      ? selectedVoucherForDeduct.remainingHours
      : ((selectedVoucherForDeduct.durationMinutes - (selectedVoucherForDeduct.usedMinutes || 0)) / 60);

    if (hours > currentRem) {
      setDeductError(`Cannot deduct ${hours} hrs. Only ${currentRem.toFixed(1)} hrs remaining on this voucher.`);
      return;
    }

    const res = await redeemVoucher({
      code: selectedVoucherForDeduct.code,
      customerId: selectedVoucherForDeduct.assignedCustomerId || 'walk_in',
      customerName: selectedVoucherForDeduct.assignedCustomerName,
      customerPhone: selectedVoucherForDeduct.assignedCustomerPhone,
      hoursToUse: hours,
      consoleCode: deductConsoleCode.trim() || undefined,
      notes: deductNotes.trim() || `Session usage deduction: ${hours} hrs`,
    });

    if (res.success) {
      setDeductSuccess(`Deducted ${hours} hrs successfully! Remaining: ${res.voucher?.remainingHours ?? 0} hrs.`);
      setTimeout(() => {
        setIsDeductModalOpen(false);
        setSelectedVoucherForDeduct(null);
        setDeductSuccess(null);
      }, 1000);
    } else {
      setDeductError(res.error || 'Failed to deduct hours');
    }
  };

  // Handle Redeem Voucher
  const handleRedeemVoucher = async (e: React.FormEvent) => {
    e.preventDefault();
    setRedeemError(null);
    setRedeemSuccess(null);

    if (!redeemCode.trim()) {
      setRedeemError('Please enter a voucher code.');
      return;
    }

    const selectedCust = customers.find((c) => c.id === redeemCustomerId);

    const res = await redeemVoucher({
      code: redeemCode.trim(),
      customerId: redeemCustomerId || 'walk_in',
      customerName: selectedCust?.name || 'Walk-in Guest',
      customerPhone: selectedCust?.phone,
      consoleCode: redeemConsoleCode.trim() || undefined,
      notes: redeemNotes.trim() || undefined,
    });

    if (res.success) {
      setRedeemSuccess(
        `Voucher "${res.voucher?.code}" successfully applied! Discount: ₹${res.discountApplied || 0}`
      );
      setTimeout(() => {
        setIsRedeemModalOpen(false);
        setRedeemCode('');
        setRedeemCustomerId('');
        setRedeemConsoleCode('');
        setRedeemNotes('');
        setRedeemSuccess(null);
      }, 1500);
    } else {
      setRedeemError(res.error || 'Redemption failed');
    }
  };

  // Handle Sell Voucher
  const handleOpenSell = (v: Voucher) => {
    setSelectedVoucherForSell(v);
    setSellPaidAmount(v.price);
    setIsSellModalOpen(true);
  };

  const handleImportOfficialPricing = async () => {
    if (!confirm("Are you sure you want to import all official vouchers from the price list? This will add them to your database.")) return;

    for (const v of OFFICIAL_VOUCHERS) {
      await addVoucher({
        name: v.name,
        category: v.category as VoucherCategory,
        type: 'time',
        durationMinutes: v.durationMinutes,
        price: v.price,
        usageLimit: 1,
        expiryDate: 'never',
        status: 'active',
      });
    }
    alert('Official vouchers imported successfully!');
  };

  const handleSellSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVoucherForSell) return;

    const customer = customers.find((c) => c.id === sellCustomerId);
    if (!customer) {
      alert('Please select a customer.');
      return;
    }

    const res = await sellVoucher({
      voucherId: selectedVoucherForSell.id,
      customerId: customer.id,
      customerName: customer.name,
      customerPhone: customer.phone,
      paymentMethod: sellPaymentMethod,
      paidAmount: Number(sellPaidAmount),
      notes: sellNotes,
    });

    if (res.success) {
      setIsSellModalOpen(false);
      setSelectedVoucherForSell(null);
      setSellCustomerId('');
      setSellNotes('');
    } else {
      alert(res.error || 'Failed to complete sale');
    }
  };

  // Hours metrics calculation
  const { totalHoursPurchased, totalHoursUsed, totalHoursRemaining } = useMemo(() => {
    let purchased = 0;
    let used = 0;
    let remaining = 0;

    for (const v of vouchers || []) {
      const p = v.totalPurchasedHours ?? (v.durationMinutes ? v.durationMinutes / 60 : 0);
      const u = v.usedHours ?? (v.usedMinutes ? v.usedMinutes / 60 : 0);
      const r = v.remainingHours ?? Math.max(0, p - u);
      purchased += p;
      used += u;
      remaining += r;
    }

    return {
      totalHoursPurchased: Math.round(purchased * 10) / 10,
      totalHoursUsed: Math.round(used * 10) / 10,
      totalHoursRemaining: Math.round(remaining * 10) / 10,
    };
  }, [vouchers]);

  return (
    <div id="vouchers-view" className="space-y-6 pb-12">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-violet-600/20 text-violet-400 border border-violet-500/30">
              <Ticket className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Voucher Management</h1>
              <p className="text-sm text-slate-400">
                Track purchased hours, log used session time, and manage remaining customer balances
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {isAdmin && (
            <button
              onClick={handleImportOfficialPricing}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-medium text-sm transition shadow-lg shadow-slate-950/30"
            >
              <Download className="w-4 h-4" />
              Import Official Pricing
            </button>
          )}
          <button
            id="open-redeem-modal-btn"
            onClick={() => {
              setRedeemError(null);
              setRedeemSuccess(null);
              setIsRedeemModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition shadow-lg shadow-emerald-950/30"
          >
            <CheckCircle2 className="w-4 h-4" />
            Redeem Code
          </button>

          <button
            id="open-create-voucher-btn"
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition shadow-lg shadow-indigo-950/30"
          >
            <Plus className="w-4 h-4" />
            Create Voucher
          </button>
        </div>
      </div>

      {/* Tabs & Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-slate-400">Total Vouchers</p>
          <p className="text-xl font-bold text-white mt-1">{(vouchers || []).length}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-emerald-400">Active / Valid</p>
          <p className="text-xl font-bold text-emerald-400 mt-1">
            {(vouchers || []).filter((v) => v.status === 'active').length}
          </p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-cyan-400">Total Purchased</p>
          <p className="text-xl font-bold text-cyan-400 mt-1">
            {totalHoursPurchased.toFixed(1)} hrs
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">{totalHoursUsed.toFixed(1)} hrs used</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-emerald-400">Total Remaining</p>
          <p className="text-xl font-bold text-emerald-400 mt-1">
            {totalHoursRemaining.toFixed(1)} hrs
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Player active balance</p>
        </div>
      </div>

      {/* View Switcher & Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
          <button
            id="tab-vouchers-list"
            onClick={() => setActiveTab('vouchers')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
              activeTab === 'vouchers'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tag className="w-4 h-4" />
            Voucher Catalog ({(vouchers || []).length})
          </button>
          <button
            id="tab-vouchers-history"
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
              activeTab === 'history'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-4 h-4" />
            Redemption History ({(voucherUsages || []).length})
          </button>
        </div>

        {activeTab === 'vouchers' && (
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative min-w-[200px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                id="search-voucher-input"
                type="text"
                placeholder="Search code or name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <select
              id="filter-category-select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-sm focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Devices</option>
              <option value="PS4">PS4</option>
              <option value="PS5">PS5</option>
              <option value="PC">PC</option>
              <option value="Simulator">Simulator</option>
            </select>

            <select
              id="filter-status-select"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-sm focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="used">Fully Used</option>
              <option value="expired">Expired</option>
              <option value="disabled">Disabled</option>
            </select>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      {activeTab === 'vouchers' ? (
        filteredVouchers.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-slate-900/30 border border-dashed border-slate-800">
            <Ticket className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 font-medium">No vouchers found</p>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Create vouchers for gaming hours, hourly discounts, or promotional events to reward your players.
            </p>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="mt-4 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-500 transition"
            >
              Create First Voucher
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredVouchers.map((v) => {
              const isExpired =
                v.expiryDate && v.expiryDate !== 'never'
                  ? new Date(v.expiryDate).getTime() < Date.now()
                  : false;

              // Total, used, remaining hours calculation
              const totalHours = v.totalPurchasedHours ?? (v.durationMinutes ? v.durationMinutes / 60 : 0);
              const usageSumMinutes = (voucherUsages || [])
                .filter((u) => u.voucherId === v.id)
                .reduce((acc, curr) => acc + (curr.durationUsedMinutes || 0), 0);
              
              const usedMinutesStored = Math.max(v.usedMinutes || 0, usageSumMinutes);
              let liveUsedMinutes = usedMinutesStored;
              
              if (v.status === 'running' && v.lastCalculatedAt) {
                const elapsedMs = now - new Date(v.lastCalculatedAt).getTime();
                liveUsedMinutes += Math.max(0, elapsedMs / 60000);
              }

              const usedHours = liveUsedMinutes / 60;
              const remainingHours = Math.max(0, totalHours - usedHours);

              const isFullyUsed = totalHours > 0 && remainingHours <= 0;
              const isMaxUsed = isFullyUsed || (v.usedCount >= v.usageLimit && v.type !== 'time');
              
              let displayStatus = isExpired
                ? 'expired'
                : isMaxUsed
                ? 'used'
                : v.status;
              
              // Handle running/paused override
              if (v.status === 'running' && !isExpired && !isMaxUsed) displayStatus = 'running';
              if (v.status === 'paused' && !isExpired && !isMaxUsed) displayStatus = 'paused';

              const progressPercent = totalHours > 0 ? Math.min(100, Math.max(0, (usedHours / totalHours) * 100)) : 0;
              const purchaseDateStr = v.purchaseDate ? new Date(v.purchaseDate).toLocaleDateString() : new Date(v.createdAt).toLocaleDateString();

              return (
                <div
                  key={v.id}
                  id={`voucher-card-${v.id}`}
                  className="relative group rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 p-5 transition flex flex-col justify-between"
                >
                  <div>
                    {/* Top row: Category badge & status */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-violet-500/10 text-violet-400 border border-violet-500/20">
                        {v.category === 'all' ? 'All Stations / Consoles' : v.category}
                      </span>

                      <span
                        className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                          displayStatus === 'active'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : displayStatus === 'running'
                            ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30 animate-pulse'
                            : displayStatus === 'paused'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : displayStatus === 'used'
                            ? 'bg-slate-500/10 text-slate-400 border border-slate-500/20'
                            : displayStatus === 'expired'
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}
                      >
                        {displayStatus === 'used' ? 'USED / EXPIRED' : displayStatus.toUpperCase()}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-white">{v.name}</h3>

                    {/* Voucher Code Chip */}
                    <div className="mt-3 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-2">
                      <div className="font-mono text-sm tracking-wider font-bold text-indigo-300">
                        {v.code}
                      </div>
                      <button
                        onClick={() => handleCopy(v.code)}
                        title="Copy code"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                      >
                        {copiedCode === v.code ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>

                    {/* Customer & Hours Details */}
                    <div className="mt-4 p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2.5 text-xs">
                      {/* Customer Name */}
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-slate-400">
                          <User className="w-3.5 h-3.5 text-indigo-400 shrink-0" /> Customer:
                        </span>
                        <span className="font-semibold text-white truncate max-w-[170px]" title={v.assignedCustomerName || 'Walk-in'}>
                          {v.assignedCustomerName ? `${v.assignedCustomerName}${v.assignedCustomerPhone ? ` (${v.assignedCustomerPhone})` : ''}` : 'General / Walk-in'}
                        </span>
                      </div>

                      {/* Voucher Type / Console */}
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-slate-400">
                          <Gamepad2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" /> Console / Type:
                        </span>
                        <span className="font-semibold text-cyan-300">
                          {v.category === 'all' ? 'All Stations' : v.category}
                        </span>
                      </div>

                      {/* Hours Breakdown */}
                      <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Total Purchased:</span>
                          <span className="font-bold text-white">{totalHours.toFixed(1)} Hours</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Used Hours:</span>
                          <span className="font-semibold text-amber-400">{usedHours.toFixed(1)} Hours</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-300 font-medium">Remaining Hours:</span>
                          <span className={`font-bold text-sm ${remainingHours <= 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                            {remainingHours.toFixed(1)} Hours
                          </span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden mt-1">
                          <div
                            className={`h-full transition-all duration-300 ${remainingHours <= 0 ? 'bg-rose-500' : 'bg-gradient-to-r from-emerald-500 to-cyan-400'}`}
                            style={{ width: `${Math.min(100, Math.max(5, ((totalHours - usedHours) / (totalHours || 1)) * 100))}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                          <span>{usedHours.toFixed(1)} hrs used</span>
                          <span>{remainingHours.toFixed(1)} hrs left</span>
                        </div>
                      </div>

                      {/* Purchase Date & Price */}
                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                        <span className="flex items-center gap-1 text-slate-400">
                          <Calendar className="w-3 h-3 text-slate-500" />
                          <span>Purchased: <strong className="text-slate-300">{purchaseDateStr}</strong></span>
                        </span>
                        <span className="font-semibold text-emerald-400">
                          ₹{v.price}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2 flex-wrap">
                    <button
                      onClick={() => setPrintedVoucher(v)}
                      title="Print / View Slip"
                      className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
                    >
                      <Printer className="w-4 h-4" />
                    </button>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      {displayStatus === 'active' && (
                        <button
                          onClick={() => startVoucher(v.id)}
                          className="px-2.5 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-xs font-bold transition flex items-center gap-1"
                        >
                          <Clock className="w-3.5 h-3.5" />
                          Start
                        </button>
                      )}

                      {displayStatus === 'running' && (
                        <button
                          onClick={() => pauseVoucher(v.id)}
                          className="px-2.5 py-1.5 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 text-xs font-bold transition flex items-center gap-1"
                        >
                          <Hourglass className="w-3.5 h-3.5" />
                          Pause
                        </button>
                      )}

                      {displayStatus === 'paused' && (
                        <button
                          onClick={() => resumeVoucher(v.id)}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition flex items-center gap-1"
                        >
                          <Clock className="w-3.5 h-3.5" />
                          Continue
                        </button>
                      )}

                      {displayStatus === 'active' && (
                        <button
                          onClick={() => handleOpenDeduct(v)}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-600/20 hover:bg-slate-600/30 text-slate-300 border border-slate-500/30 text-xs font-semibold transition flex items-center gap-1"
                          title="Manual override: Log played hours"
                        >
                          <MinusCircle className="w-3.5 h-3.5" />
                          Manual Deduct
                        </button>
                      )}

                      {!v.assignedCustomerId && displayStatus === 'active' && (
                        <button
                          onClick={() => handleOpenSell(v)}
                          className="px-2.5 py-1.5 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 text-violet-300 border border-violet-500/30 text-xs font-medium transition flex items-center gap-1"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          Sell
                        </button>
                      )}

                      {displayStatus === 'active' && (
                        <button
                          onClick={() => {
                            setRedeemCode(v.code);
                            setIsRedeemModalOpen(true);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-medium transition flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Redeem
                        </button>
                      )}

                      {isAdmin && (
                        <button
                          id={`delete-voucher-btn-${v.id}`}
                          onClick={() => setVoucherToDelete(v)}
                          className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 rounded-xl transition-colors border border-slate-800 hover:border-rose-800/50 cursor-pointer flex items-center justify-center"
                          title="Delete Voucher"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : (
        /* Redemptions History Tab */
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 overflow-hidden">
          {(voucherUsages || []).length === 0 ? (
            <div className="p-12 text-center">
              <History className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-slate-400 font-medium">No redemptions logged yet</p>
              <p className="text-xs text-slate-500 mt-1">
                When players redeem voucher codes at game checkout or station intake, the records will appear here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-900/90 text-slate-400 text-xs uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Code / Voucher</th>
                    <th className="px-4 py-3">Customer</th>
                    <th className="px-4 py-3">Station</th>
                    <th className="px-4 py-3">Benefit Applied</th>
                    <th className="px-4 py-3">Date & Time</th>
                    <th className="px-4 py-3">Recorded By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {(voucherUsages || []).map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/30">
                      <td className="px-4 py-3 font-medium text-white">
                        <span className="font-mono text-xs px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mr-2">
                          {u.voucherCode}
                        </span>
                        {u.voucherName}
                      </td>
                      <td className="px-4 py-3 text-slate-300">
                        {u.customerName}
                        {u.customerPhone && (
                          <span className="block text-xs text-slate-500">
                            {u.customerPhone}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-300">
                        {u.consoleCode || 'General Checkout'}
                      </td>
                      <td className="px-4 py-3 text-emerald-400 font-semibold">
                        {u.durationUsedMinutes
                          ? `${u.durationUsedMinutes} mins play`
                          : `₹${u.valueDiscountApplied} off`}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400">
                        {new Date(u.usedAt).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400">
                        {u.recordedBy || 'Staff'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* CREATE VOUCHER MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Ticket className="w-5 h-5 text-indigo-400" />
                <h2 className="text-lg font-bold text-white">Create New Voucher</h2>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateVoucher} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Voucher Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 2 Hours PS5 Weekend Pass"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Voucher Code (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Leave blank to auto-gen"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Station Category
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        category: e.target.value as VoucherCategory,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="all">All Devices</option>
                    <option value="PS4">PS4</option>
                    <option value="PS5">PS5</option>
                    <option value="PC">PC</option>
                    <option value="Simulator">Driving Simulator</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Customer Name (Assign Player)
                  </label>
                  <select
                    value={formData.assignedCustomerId}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        assignedCustomerId: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="">-- General / Unassigned (Walk-in) --</option>
                    {(customers || []).map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Purchase Date
                  </label>
                  <input
                    type="date"
                    value={formData.purchaseDate}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        purchaseDate: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Benefit Type
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        type: e.target.value as any,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="time">Gaming Hours Pass (Hours)</option>
                    <option value="value">Fixed Cash Discount (₹)</option>
                  </select>
                </div>

                {formData.type === 'time' ? (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                      Total Purchased Hours *
                    </label>
                    <input
                      type="number"
                      min="0.5"
                      step="0.5"
                      value={formData.hours || formData.durationMinutes / 60}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setFormData({
                          ...formData,
                          hours: val,
                          durationMinutes: Math.round(val * 60),
                        });
                      }}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm font-bold focus:border-indigo-500 focus:outline-none"
                    />
                    <div className="flex items-center gap-1 mt-1 flex-wrap">
                      {[1, 2, 3, 5, 7, 10].map((h) => (
                        <button
                          key={h}
                          type="button"
                          onClick={() => {
                            setFormData({
                              ...formData,
                              hours: h,
                              durationMinutes: h * 60,
                            });
                          }}
                          className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                            formData.hours === h ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                          }`}
                        >
                          {h}h
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                      Discount Value (₹)
                    </label>
                    <input
                      type="number"
                      min="10"
                      value={formData.valueAmount}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          valueAmount: Number(e.target.value),
                        })
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Price (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({ ...formData, price: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Usage Limit
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.usageLimit}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        usageLimit: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Valid Days
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0 for never"
                    value={formData.expiryDays}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        expiryDays: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Internal Notes
                </label>
                <textarea
                  rows={2}
                  placeholder="Terms, special campaign instructions, etc."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition shadow-lg shadow-indigo-950/30 disabled:opacity-50"
                >
                  {isSubmitting ? 'Generating...' : 'Generate Voucher'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DEDUCT / LOG PLAYED HOURS MODAL */}
      {isDeductModalOpen && selectedVoucherForDeduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-400" />
                <h2 className="text-lg font-bold text-white">Log Played Hours</h2>
              </div>
              <button
                onClick={() => setIsDeductModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSubmitDeduct} className="space-y-4 mt-4">
              {/* Voucher info card */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Voucher:</span>
                  <span className="font-bold text-white">{selectedVoucherForDeduct.name} ({selectedVoucherForDeduct.code})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Customer Name:</span>
                  <span className="font-semibold text-indigo-300">
                    {selectedVoucherForDeduct.assignedCustomerName || 'Walk-in Customer'}
                  </span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-800/80">
                  <span className="text-slate-400">Total Purchased:</span>
                  <span className="font-semibold text-white">
                    {(selectedVoucherForDeduct.totalPurchasedHours ?? (selectedVoucherForDeduct.durationMinutes / 60)).toFixed(1)} Hours
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Current Used:</span>
                  <span className="font-semibold text-amber-400">
                    {(selectedVoucherForDeduct.usedHours ?? ((selectedVoucherForDeduct.usedMinutes || 0) / 60)).toFixed(1)} Hours
                  </span>
                </div>
                <div className="flex justify-between text-sm pt-1 border-t border-slate-800/80">
                  <span className="text-slate-300 font-medium">Current Remaining:</span>
                  <span className="font-bold text-emerald-400">
                    {(selectedVoucherForDeduct.remainingHours ?? Math.max(0, (selectedVoucherForDeduct.totalPurchasedHours || selectedVoucherForDeduct.durationMinutes / 60) - (selectedVoucherForDeduct.usedHours || (selectedVoucherForDeduct.usedMinutes || 0) / 60))).toFixed(1)} Hours
                  </span>
                </div>
              </div>

              {/* Deduct Hours Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Played Duration to Deduct (Hours) *
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0.5"
                  required
                  value={deductHours}
                  onChange={(e) => setDeductHours(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-base focus:border-indigo-500 focus:outline-none"
                />
                <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                  {[1, 2, 3, 5].map((h) => (
                    <button
                      key={h}
                      type="button"
                      onClick={() => setDeductHours(h)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                        deductHours === h
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {h} hr{h > 1 ? 's' : ''}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      const curRem = selectedVoucherForDeduct.remainingHours ?? Math.max(0, (selectedVoucherForDeduct.totalPurchasedHours || selectedVoucherForDeduct.durationMinutes / 60) - (selectedVoucherForDeduct.usedHours || (selectedVoucherForDeduct.usedMinutes || 0) / 60));
                      setDeductHours(curRem);
                    }}
                    className="px-2.5 py-1 rounded-lg text-xs font-medium bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30"
                  >
                    All Remaining
                  </button>
                </div>
              </div>

              {/* Calculation Preview */}
              {(() => {
                const curTotal = selectedVoucherForDeduct.totalPurchasedHours ?? (selectedVoucherForDeduct.durationMinutes / 60);
                const curUsed = selectedVoucherForDeduct.usedHours ?? ((selectedVoucherForDeduct.usedMinutes || 0) / 60);
                const nextUsed = curUsed + Number(deductHours || 0);
                const nextRemaining = Math.max(0, curTotal - nextUsed);

                return (
                  <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-800/50 space-y-1 text-xs">
                    <p className="font-semibold text-indigo-300">Preview After Deduction:</p>
                    <div className="flex justify-between text-slate-300">
                      <span>Total Purchased: <strong>{curTotal.toFixed(1)} Hours</strong></span>
                      <span>New Used: <strong className="text-amber-300">{nextUsed.toFixed(1)} Hours</strong></span>
                    </div>
                    <div className="flex justify-between text-sm font-bold pt-1 border-t border-indigo-900">
                      <span>New Remaining:</span>
                      <span className={nextRemaining <= 0 ? 'text-rose-400' : 'text-emerald-400'}>
                        {nextRemaining.toFixed(1)} Hours {nextRemaining <= 0 ? '(Voucher will be fully used)' : ''}
                      </span>
                    </div>
                  </div>
                );
              })()}

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Station / Console Code (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. PS5-01, PC-04"
                  value={deductConsoleCode}
                  onChange={(e) => setDeductConsoleCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Session Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 5 hours match completed"
                  value={deductNotes}
                  onChange={(e) => setDeductNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              {deductError && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{deductError}</span>
                </div>
              )}

              {deductSuccess && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{deductSuccess}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsDeductModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-950/40 transition"
                >
                  Confirm & Deduct Hours
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REDEEM VOUCHER MODAL */}
      {isRedeemModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <h2 className="text-lg font-bold text-white">Redeem Voucher Code</h2>
              </div>
              <button
                onClick={() => setIsRedeemModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleRedeemVoucher} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Voucher Code *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. VOUCH-4X8A"
                  value={redeemCode}
                  onChange={(e) => setRedeemCode(e.target.value.toUpperCase())}
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-lg font-bold tracking-widest focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Player / Customer
                </label>
                <select
                  value={redeemCustomerId}
                  onChange={(e) => setRedeemCustomerId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-emerald-500 focus:outline-none"
                >
                  <option value="">-- Walk-in / Unregistered Guest --</option>
                  {(customers || []).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Station Code (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. PS5-01 or PC-04"
                  value={redeemConsoleCode}
                  onChange={(e) => setRedeemConsoleCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Notes
                </label>
                <input
                  type="text"
                  placeholder="Redemption note..."
                  value={redeemNotes}
                  onChange={(e) => setRedeemNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>

              {redeemError && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{redeemError}</span>
                </div>
              )}

              {redeemSuccess && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{redeemSuccess}</span>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRedeemModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition shadow-lg shadow-emerald-950/30"
                >
                  Validate & Redeem
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SELL VOUCHER MODAL */}
      {isSellModalOpen && selectedVoucherForSell && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-violet-400" />
                <h2 className="text-lg font-bold text-white">Sell Voucher</h2>
              </div>
              <button
                onClick={() => setIsSellModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <div className="p-3 my-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
              <div className="font-semibold text-white text-sm">{selectedVoucherForSell.name}</div>
              <div className="font-mono text-indigo-400 mt-0.5">{selectedVoucherForSell.code}</div>
              <div className="text-emerald-400 mt-1 font-bold">Price: ₹{selectedVoucherForSell.price}</div>
            </div>

            <form onSubmit={handleSellSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Customer *
                </label>
                <select
                  required
                  value={sellCustomerId}
                  onChange={(e) => setSellCustomerId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-violet-500 focus:outline-none"
                >
                  <option value="">-- Choose Customer --</option>
                  {(customers || []).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Amount Paid (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={sellPaidAmount}
                    onChange={(e) => setSellPaidAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-violet-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Payment Method
                  </label>
                  <select
                    value={sellPaymentMethod}
                    onChange={(e) => setSellPaymentMethod(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-violet-500 focus:outline-none"
                  >
                    <option value="cash">Cash</option>
                    <option value="upi">UPI / QR</option>
                    <option value="card">Card</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSellModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold transition shadow-lg shadow-violet-950/30"
                >
                  Confirm Sale & Issue
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINT SLIP PREVIEW MODAL */}
      {printedVoucher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center text-white shadow-lg">
              <Ticket className="w-8 h-8" />
            </div>

            <div>
              <p className="text-xs uppercase tracking-widest text-indigo-400 font-bold">
                NEXT GEN ESPORT
              </p>
              <p className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold">
                GAMING LAUNCHER
              </p>
              <h3 className="text-xl font-extrabold text-white mt-1">
                {printedVoucher.name}
              </h3>
              <p className="text-xs text-slate-400">
                {printedVoucher.category === 'all'
                  ? 'Valid on All Stations'
                  : `Exclusive for ${printedVoucher.category}`}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border-2 border-dashed border-indigo-500/50">
              <p className="text-xs text-slate-500 font-mono uppercase">VOUCHER PASSCODE</p>
              <p className="text-2xl font-black text-indigo-300 font-mono tracking-widest mt-1">
                {printedVoucher.code}
              </p>
              <p className="text-xs text-emerald-400 font-medium mt-2">
                {printedVoucher.type === 'time'
                  ? `${(printedVoucher.totalPurchasedHours ?? (printedVoucher.durationMinutes / 60)).toFixed(1)} Hours Total Gameplay`
                  : `₹${printedVoucher.valueAmount} Bill Discount`}
              </p>
            </div>

            <div className="text-xs text-slate-400 space-y-1.5 text-left bg-slate-950/50 p-3.5 rounded-xl border border-slate-800">
              <div className="flex justify-between">
                <span>Customer Name:</span>
                <span className="text-indigo-300 font-medium truncate max-w-[150px]">
                  {printedVoucher.assignedCustomerName || 'Walk-in Player'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Console / Category:</span>
                <span className="text-cyan-300 font-medium">
                  {printedVoucher.category === 'all' ? 'All Stations' : printedVoucher.category}
                </span>
              </div>
              {printedVoucher.type === 'time' && (
                <>
                  <div className="flex justify-between pt-1 border-t border-slate-800">
                    <span>Purchased Hours:</span>
                    <span className="text-white font-bold">
                      {(printedVoucher.totalPurchasedHours ?? (printedVoucher.durationMinutes / 60)).toFixed(1)} Hours
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Used Hours:</span>
                    <span className="text-amber-400 font-semibold">
                      {(printedVoucher.usedHours ?? ((printedVoucher.usedMinutes || 0) / 60)).toFixed(1)} Hours
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Remaining Hours:</span>
                    <span className="text-emerald-400 font-bold">
                      {(printedVoucher.remainingHours ?? Math.max(0, (printedVoucher.totalPurchasedHours || printedVoucher.durationMinutes / 60) - (printedVoucher.usedHours || (printedVoucher.usedMinutes || 0) / 60))).toFixed(1)} Hours
                    </span>
                  </div>
                </>
              )}
              <div className="flex justify-between pt-1 border-t border-slate-800">
                <span>Purchase Date:</span>
                <span className="text-slate-300 font-medium">
                  {new Date(printedVoucher.purchaseDate || printedVoucher.createdAt).toLocaleDateString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Status:</span>
                <span className="text-white font-bold uppercase text-[11px]">
                  {printedVoucher.status}
                </span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setPrintedVoucher(null)}
                className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium transition"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition flex items-center justify-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                Print Slip
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Voucher Delete Confirmation Modal */}
      {voucherToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center font-bold">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-white">Delete Voucher</h4>
                <p className="text-xs text-slate-400">Permanently delete voucher from catalog</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-sm text-slate-300 space-y-2">
              <p>
                Are you sure you want to delete voucher{' '}
                <strong className="text-white font-semibold">"{voucherToDelete.name}"</strong>?
              </p>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>Code:</span>
                <span className="font-mono font-bold text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                  {voucherToDelete.code}
                </span>
                <span className="ml-auto uppercase text-[11px] font-bold text-slate-400">
                  Status: {voucherToDelete.status}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isDeletingVoucher}
                onClick={() => setVoucherToDelete(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-delete-voucher-btn"
                disabled={isDeletingVoucher}
                onClick={async () => {
                  setIsDeletingVoucher(true);
                  try {
                    await deleteVoucher(voucherToDelete.id);
                    setVoucherToDelete(null);
                  } finally {
                    setIsDeletingVoucher(false);
                  }
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition flex items-center gap-1.5 shadow-lg shadow-rose-600/20"
              >
                {isDeletingVoucher ? (
                  <span>Deleting...</span>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Yes, Delete Voucher</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
