import React, { useState } from 'react';
import {
  ShieldCheck,
  UserPlus,
  Edit2,
  Trash2,
  Key,
  Phone,
  Mail,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Lock,
  Eye,
  EyeOff,
  Users,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { UserAccount, MAX_WORKERS_ALLOWED } from '../../types';

interface WorkersViewProps {
  onOpenWorkerModal: (workerToEdit?: UserAccount) => void;
}

export const WorkersView: React.FC<WorkersViewProps> = ({ onOpenWorkerModal }) => {
  const { workers, currentUser, isAdmin, deleteWorker, updateWorker } = useCafe();
  const [revealedCodes, setRevealedCodes] = useState<Record<string, boolean>>({});
  const [workerToDelete, setWorkerToDelete] = useState<UserAccount | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const staffWorkers = workers.filter((w) => w.role === 'worker');
  const adminAccount = workers.find((w) => w.role === 'admin') || currentUser;
  const workerCount = staffWorkers.length;
  const isMaxWorkersReached = workerCount >= MAX_WORKERS_ALLOWED;

  const toggleRevealCode = (id: string) => {
    setRevealedCodes((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleToggleStatus = async (worker: UserAccount) => {
    if (worker.id === currentUser?.id) {
      setErrorMessage('Cannot change status of currently logged in user.');
      return;
    }
    const newStatus = worker.status === 'active' ? 'inactive' : 'active';
    await updateWorker(worker.id, { status: newStatus });
  };

  const handleDeleteClick = (worker: UserAccount) => {
    if (worker.id === currentUser?.id) {
      setErrorMessage('Cannot delete your own active administrator account.');
      return;
    }
    setErrorMessage('');
    setWorkerToDelete(worker);
  };

  const handleConfirmDelete = async () => {
    if (!workerToDelete) return;
    setIsDeleting(true);
    setErrorMessage('');
    try {
      await deleteWorker(workerToDelete.id);
      setWorkerToDelete(null);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to delete worker');
    } finally {
      setIsDeleting(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="py-20 text-center text-slate-400">
        <Lock className="w-12 h-12 text-slate-600 mx-auto mb-3" />
        <p className="text-base font-bold text-slate-300">Administrator Access Restricted</p>
        <p className="text-xs text-slate-500 mt-1">
          Staff management is only accessible from an Administrator terminal.
        </p>
      </div>
    );
  }

  return (
    <div id="workers-view" className="space-y-6 pb-12">
      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 p-4 sm:p-5 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2.5">
            <h3 className="text-lg font-bold text-white">Staff Management & Access Codes</h3>
            <span
              id="worker-quota-badge"
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                isMaxWorkersReached
                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  : 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
              }`}
            >
              {workerCount} / {MAX_WORKERS_ALLOWED} Active Staff
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Set unique Staff Access Codes for each staff member. Staff use their assigned code to log in to the Staff Terminal.
          </p>
        </div>

        <button
          id="add-worker-btn"
          onClick={() => !isMaxWorkersReached && onOpenWorkerModal()}
          disabled={isMaxWorkersReached}
          title={isMaxWorkersReached ? `Maximum ${MAX_WORKERS_ALLOWED} staff accounts reached` : 'Add Staff Worker'}
          className={`flex items-center justify-center gap-2 font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-md transition-all ${
            isMaxWorkersReached
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              : 'bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 shadow-cyan-500/20 cursor-pointer'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>{isMaxWorkersReached ? `Max Staff Reached (${MAX_WORKERS_ALLOWED}/${MAX_WORKERS_ALLOWED})` : '+ Add Staff Worker'}</span>
        </button>
      </div>

      {/* Security Architecture & Role Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase tracking-wider mb-2">
            <ShieldCheck className="w-4 h-4" />
            <span>Administrator Security Code</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mb-2">
            The Administrator Panel is protected by the fixed security access code <strong className="font-mono text-cyan-300 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/40">756569</strong>.
          </p>
          <p className="text-[11px] text-slate-500">
            • Admin Code cannot be used to unlock the Staff Panel.<br />
            • Admin Code is never revealed or pre-filled on the login screen.
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider mb-2">
            <Key className="w-4 h-4" />
            <span>Staff Access Codes</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mb-2">
            Each staff member receives a custom Staff Code set by the Administrator below (e.g. <strong>458921</strong> for Rahul).
          </p>
          <p className="text-[11px] text-slate-500">
            • No default demo codes exist in the system.<br />
            • Staff codes cannot unlock the Administrator Panel.
          </p>
        </div>
      </div>

      {/* Staff Roster Heading */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-cyan-400" />
          <h4 className="font-bold text-white text-base">Registered Staff Members</h4>
        </div>
        <span className="text-xs text-slate-400">
          {staffWorkers.length === 0 ? 'No staff configured' : `${staffWorkers.length} staff member${staffWorkers.length > 1 ? 's' : ''}`}
        </span>
      </div>

      {/* Empty State when no staff members exist */}
      {staffWorkers.length === 0 ? (
        <div
          id="staff-empty-state"
          className="py-14 px-6 bg-slate-900/50 border border-slate-800/80 rounded-2xl text-center flex flex-col items-center justify-center space-y-3"
        >
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
            <Users className="w-7 h-7" />
          </div>
          <h4 className="text-base font-bold text-white">Staff Management Initially Empty</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            No default or demo staff accounts exist. Click <strong>Add Staff Worker</strong> to register your first staff member (e.g. <em>Rahul</em>) and assign their custom Staff Access Code (e.g. <em>458921</em>).
          </p>
          <button
            id="empty-state-add-worker-btn"
            onClick={() => onOpenWorkerModal()}
            className="mt-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-xs transition-all shadow-md shadow-cyan-500/20 flex items-center gap-2 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add First Staff Member</span>
          </button>
        </div>
      ) : (
        /* Worker List Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {staffWorkers.map((worker) => {
            const isCurrentUser = worker.id === currentUser?.id;
            const staffCode = worker.accessCode || worker.pin || '';
            const isCodeVisible = !!revealedCodes[worker.id];

            return (
              <div
                key={worker.id}
                id={`worker-card-${worker.id}`}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between shadow-lg shadow-black/20 hover:border-slate-700 transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center font-black text-sm bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {worker.name
                          .split(' ')
                          .map((n) => n[0])
                          .slice(0, 2)
                          .join('')
                          .toUpperCase()}
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-base leading-tight">
                          {worker.name}
                        </h4>
                        <span className="inline-block text-[9px] font-bold px-1.5 py-0.2 rounded uppercase mt-1 text-emerald-300 bg-emerald-500/15 border border-emerald-500/30">
                          Staff Terminal Operator
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleStatus(worker)}
                      className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full cursor-pointer transition-colors ${
                        worker.status === 'active'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'
                          : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700'
                      }`}
                      title="Click to toggle active/inactive status"
                    >
                      {worker.status}
                    </button>
                  </div>

                  {/* Staff Credentials Box */}
                  <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-2.5 text-xs text-slate-300 mt-4">
                    {/* Staff Access Code Display */}
                    <div className="flex items-center justify-between bg-slate-900/80 p-2.5 rounded-lg border border-cyan-500/20">
                      <div className="flex items-center gap-2">
                        <Key className="w-4 h-4 text-cyan-400" />
                        <div>
                          <div className="text-[10px] uppercase font-bold text-slate-400">Staff Access Code</div>
                          <div className="font-mono font-bold text-sm text-cyan-300 tracking-wider">
                            {isCodeVisible ? staffCode : '••••••'}
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => toggleRevealCode(worker.id)}
                        className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
                        title={isCodeVisible ? 'Hide Code' : 'Reveal Code'}
                      >
                        {isCodeVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>

                    {worker.phone && (
                      <div className="flex items-center gap-2 text-slate-400 text-xs">
                        <Phone className="w-3.5 h-3.5" />
                        <span>{worker.phone}</span>
                      </div>
                    )}

                    {worker.email && (
                      <div className="flex items-center gap-2 text-slate-400 text-xs">
                        <Mail className="w-3.5 h-3.5" />
                        <span className="truncate">{worker.email}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Action Controls */}
                <div className="flex items-center justify-between gap-2 mt-5 pt-3 border-t border-slate-800">
                  <button
                    id={`edit-worker-btn-${worker.id}`}
                    onClick={() => onOpenWorkerModal(worker)}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-semibold py-2 px-3 rounded-xl text-xs border border-slate-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Change Code / Edit</span>
                  </button>

                  <button
                    id={`delete-worker-btn-${worker.id}`}
                    onClick={() => handleDeleteClick(worker)}
                    title="Remove Staff Account & Invalidate Code"
                    className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 rounded-xl transition-colors border border-slate-800 hover:border-rose-800/50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {workerToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center font-bold">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-white">Delete Staff Member</h4>
                <p className="text-xs text-slate-400">Permanently remove staff account</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-sm text-slate-300 space-y-2">
              <p>
                Are you sure you want to remove staff member{' '}
                <strong className="text-white font-semibold">"{workerToDelete.name}"</strong>?
              </p>
              <p className="text-xs text-rose-400/90">
                Their Staff Access Code (
                <span className="font-mono font-bold">
                  {workerToDelete.accessCode || workerToDelete.pin || 'assigned code'}
                </span>
                ) will immediately become invalid for terminal login.
              </p>
            </div>

            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-400 font-medium">
                {errorMessage}
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setWorkerToDelete(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-delete-worker-btn"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition flex items-center gap-1.5 shadow-lg shadow-rose-600/20"
              >
                {isDeleting ? (
                  <span>Deleting...</span>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Yes, Delete Staff</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
