import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import {
  BarChart3,
  Calendar,
  Download,
  Gamepad2,
  Package,
  TrendingUp,
  Receipt,
  Clock,
  Filter,
  Users,
  CreditCard,
  QrCode,
  Banknote,
  FileSpreadsheet,
  Coffee,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { GamingSession, RentalRecord, PaymentTransaction } from '../../types';
import * as XLSX from 'xlsx';

export const ReportsView: React.FC = () => {
  const { sessions, rentalRecords, payments, cafeteriaOrders, customers, settings, isAdmin } = useCafe();

  if (!isAdmin) {
    return <Navigate to="/dashboard" replace />;
  }

  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'all'>('month');
  const [activeReportTab, setActiveReportTab] = useState<'sessions' | 'rentals' | 'cafeteria' | 'payments'>('sessions');

  // Filter payments by date range
  const now = new Date();
  const getFilterStartTime = () => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    if (dateRange === 'today') {
      return d.getTime();
    }
    if (dateRange === 'week') {
      d.setDate(d.getDate() - 7);
      return d.getTime();
    }
    if (dateRange === 'month') {
      d.setDate(d.getDate() - 30);
      return d.getTime();
    }
    return 0; // all time
  };

  const filterStartTime = getFilterStartTime();

  const filteredSessions = sessions.filter(
    (s) => new Date(s.startTime).getTime() >= filterStartTime
  );

  const filteredRentals = rentalRecords.filter(
    (r) => new Date(r.startTime).getTime() >= filterStartTime
  );

  const filteredCafeteriaOrders = (cafeteriaOrders || []).filter(
    (o) => new Date(o.createdAt).getTime() >= filterStartTime
  );

  const filteredPayments = payments.filter(
    (p) => new Date(p.timestamp).getTime() >= filterStartTime
  );

  // Financial aggregates
  const totalRevenue = filteredPayments
    .filter((p) => p.amount > 0)
    .reduce((acc, p) => acc + p.amount, 0);

  const gamingRevenue = filteredPayments
    .filter((p) => p.type === 'gaming_session')
    .reduce((acc, p) => acc + p.amount, 0);

  const cafeteriaRevenue = filteredPayments
    .filter((p) => p.type === 'cafeteria_order')
    .reduce((acc, p) => acc + p.amount, 0);

  const rentalRevenue = filteredPayments
    .filter((p) => p.type === 'rental_fee' || p.type === 'late_fee')
    .reduce((acc, p) => acc + p.amount, 0);

  const depositsHeld = filteredRentals
    .filter((r) => r.status === 'active' || r.status === 'overdue')
    .reduce((acc, r) => acc + (r.depositAmount - (r.depositRefunded || 0)), 0);

  const totalGamingMinutes = filteredSessions.reduce(
    (acc, s) => acc + (s.durationMinutes || 0),
    0
  );

  // Export genuine multi-column Excel (.xlsx) file with auto-fit column widths
  const exportToExcel = () => {
    let headers: string[] = [];
    let rows: any[] = [];
    let sheetName = 'Report';

    if (activeReportTab === 'sessions') {
      sheetName = 'Sessions';
      headers = ['Session ID', 'Console', 'Customer', 'Phone', 'Start Time', 'End Time', 'Duration (Mins)', 'Rate/Hr', 'Total Amount', 'Paid Amount', 'Payment Method', 'Payment Splits', 'Status'];
      rows = filteredSessions.map((s) => {
        const splitText = s.splitPayments && s.splitPayments.length > 0
          ? s.splitPayments.map((sp) => `${String(sp.method).toUpperCase()}: ₹${sp.amount}`).join(' | ')
          : (s.paymentMethod || 'cash');
        return {
          'Session ID': s.id,
          'Console': s.consoleCode,
          'Customer': s.customerName,
          'Phone': s.customerPhone || 'N/A',
          'Start Time': s.startTime,
          'End Time': s.endTime || 'Active',
          'Duration (Mins)': s.durationMinutes,
          'Rate/Hr': s.ratePerHour,
          'Total Amount': s.totalAmount,
          'Paid Amount': s.paidAmount,
          'Payment Method': s.paymentMethod || 'cash',
          'Payment Splits': splitText,
          'Status': s.status,
        };
      });
    } else if (activeReportTab === 'rentals') {
      sheetName = 'Rentals';
      headers = ['Record ID', 'Item Name', 'Customer', 'Phone', 'Quantity', 'Start Time', 'Return Time', 'Rental Fee', 'Deposit', 'Deposit Refunded', 'Status'];
      rows = filteredRentals.map((r) => ({
        'Record ID': r.id,
        'Item Name': r.rentalItemName,
        'Customer': r.customerName,
        'Phone': r.customerPhone,
        'Quantity': r.quantity,
        'Start Time': r.startTime,
        'Return Time': r.actualReturnTime || 'Out',
        'Rental Fee': r.rentalFee,
        'Deposit': r.depositAmount,
        'Deposit Refunded': r.depositRefunded,
        'Status': r.status,
      }));
    } else if (activeReportTab === 'cafeteria') {
      sheetName = 'Cafeteria_Orders';
      headers = ['Order ID', 'Customer', 'Phone', 'Items Ordered', 'Subtotal', 'Discount', 'Total Amount', 'Paid Amount', 'Payment Status', 'Payment Method', 'Date'];
      rows = filteredCafeteriaOrders.map((o) => ({
        'Order ID': o.id,
        'Customer': o.customerName,
        'Phone': o.customerPhone || 'N/A',
        'Items Ordered': o.items.map((i) => `${i.quantity}x ${i.name} (₹${i.totalPrice || (i.price * i.quantity)})`).join('; '),
        'Subtotal': o.subtotal,
        'Discount': o.discountAmount,
        'Total Amount': o.totalAmount,
        'Paid Amount': o.paidAmount,
        'Payment Status': o.status === 'cancelled' ? 'Cancelled' : o.paymentStatus,
        'Payment Method': o.paymentMethod,
        'Date': o.createdAt,
      }));
    } else {
      sheetName = 'Payments';
      headers = ['Payment ID', 'Type', 'Customer', 'Reference', 'Method', 'Split Details', 'Amount', 'Timestamp', 'Recorded By'];
      rows = filteredPayments.map((p) => {
        const splitText = p.splitDetails && p.splitDetails.length > 0
          ? p.splitDetails.map((s) => `${s.method.toUpperCase()}: ₹${s.amount}`).join(' | ')
          : '-';
        return {
          'Payment ID': p.id,
          'Type': p.type,
          'Customer': p.customerName,
          'Reference': p.referenceTitle,
          'Method': p.method,
          'Split Details': splitText,
          'Amount': p.amount,
          'Timestamp': p.timestamp,
          'Recorded By': p.recordedBy,
        };
      });
    }

    const wb = XLSX.utils.book_new();
    const ws = rows.length > 0
      ? XLSX.utils.json_to_sheet(rows, { header: headers })
      : XLSX.utils.aoa_to_sheet([headers]);

    // Auto-fit column widths so data is neatly aligned
    ws['!cols'] = headers.map((h) => {
      let maxLen = h.length;
      for (const row of rows) {
        const val = row[h];
        if (val !== undefined && val !== null) {
          const str = String(val);
          if (str.length > maxLen) maxLen = str.length;
        }
      }
      return { wch: Math.min(Math.max(maxLen + 3, 12), 45) };
    });

    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    const dateStr = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, `NextGen_${sheetName}_Report_${dateStr}.xlsx`);
  };

  // CSV Exporter with UTF-8 BOM so Excel opens it in distinct columns
  const exportToCSV = () => {
    let headers: string[] = [];
    let rows: string[][] = [];

    if (activeReportTab === 'sessions') {
      headers = ['Session ID', 'Console', 'Customer', 'Start Time', 'End Time', 'Duration (Mins)', 'Rate/Hr', 'Total Amount', 'Paid Amount', 'Status'];
      rows = filteredSessions.map((s) => [
        s.id,
        s.consoleCode,
        `"${s.customerName}"`,
        s.startTime,
        s.endTime || 'Active',
        s.durationMinutes.toString(),
        s.ratePerHour.toString(),
        s.totalAmount.toString(),
        s.paidAmount.toString(),
        s.status,
      ]);
    } else if (activeReportTab === 'rentals') {
      headers = ['Record ID', 'Item Name', 'Customer', 'Phone', 'Quantity', 'Start Time', 'Return Time', 'Fee Paid', 'Deposit', 'Status'];
      rows = filteredRentals.map((r) => [
        r.id,
        `"${r.rentalItemName}"`,
        `"${r.customerName}"`,
        r.customerPhone,
        r.quantity.toString(),
        r.startTime,
        r.actualReturnTime || 'Out',
        r.rentalFee.toString(),
        r.depositAmount.toString(),
        r.status,
      ]);
    } else if (activeReportTab === 'cafeteria') {
      headers = ['Order ID', 'Customer', 'Phone', 'Items Count', 'Items Summary', 'Subtotal', 'Discount', 'Total Amount', 'Paid Amount', 'Payment Status', 'Payment Method', 'Date'];
      rows = filteredCafeteriaOrders.map((o) => [
        o.id,
        `"${o.customerName}"`,
        o.customerPhone || 'N/A',
        o.items.reduce((acc, i) => acc + i.quantity, 0).toString(),
        `"${o.items.map((i) => `${i.quantity}x ${i.name}`).join('; ')}"`,
        o.subtotal.toString(),
        o.discountAmount.toString(),
        o.totalAmount.toString(),
        o.paidAmount.toString(),
        o.status === 'cancelled' ? 'Cancelled' : o.paymentStatus,
        o.paymentMethod,
        o.createdAt,
      ]);
    } else {
      headers = ['Payment ID', 'Type', 'Customer', 'Reference', 'Method', 'Split Details', 'Amount', 'Timestamp', 'Recorded By'];
      rows = filteredPayments.map((p) => {
        const splitText = p.splitDetails && p.splitDetails.length > 0
          ? p.splitDetails.map((s) => `${s.method.toUpperCase()}: ${s.amount}`).join(' | ')
          : '-';
        return [
          p.id,
          p.type,
          `"${p.customerName}"`,
          `"${p.referenceTitle}"`,
          p.method,
          `"${splitText}"`,
          p.amount.toString(),
          p.timestamp,
          `"${p.recordedBy}"`,
        ];
      });
    }

    // Prepend UTF-8 BOM so Microsoft Excel automatically recognises delimiters and columns
    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `NextGen_${activeReportTab}_report_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="reports-view" className="space-y-6 pb-12">
      {/* Date Range Selector Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 p-4 sm:p-5 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-cyan-400" />
          <span className="text-xs sm:text-sm font-semibold text-slate-300">Reporting Window:</span>
          <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
            {(['today', 'week', 'month', 'all'] as const).map((range) => (
              <button
                key={range}
                id={`date-range-${range}`}
                onClick={() => setDateRange(range)}
                className={`px-3 py-1.5 rounded-lg capitalize font-medium transition-all ${
                  dateRange === range
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {range === 'all' ? 'All Time' : range === 'today' ? 'Today' : `Past ${range}`}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="export-excel-btn"
            onClick={exportToExcel}
            className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-4 py-2 rounded-xl text-xs sm:text-sm border border-emerald-500 transition-all shadow-md"
          >
            <FileSpreadsheet className="w-4 h-4 text-white" />
            <span>Export Excel (.xlsx)</span>
          </button>
          <button
            id="export-csv-btn"
            onClick={exportToCSV}
            className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-3 py-2 rounded-xl text-xs sm:text-sm border border-slate-700 transition-all shadow-md"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>CSV</span>
          </button>
        </div>
      </div>

      {/* Financial Bento Summary Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <p className="text-xs uppercase font-semibold text-slate-400">Total Net Revenue</p>
          <p className="text-2xl sm:text-3xl font-black text-white mt-1">
            {settings.currencySymbol} {totalRevenue.toLocaleString('en-IN')}
          </p>
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 mt-2">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Actual collected income</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <p className="text-xs uppercase font-semibold text-slate-400">Gaming Revenue</p>
          <p className="text-2xl sm:text-3xl font-black text-cyan-400 mt-1">
            {settings.currencySymbol} {gamingRevenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">
            {Math.floor(totalGamingMinutes / 60)}h {totalGamingMinutes % 60}m playtime logged
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <p className="text-xs uppercase font-semibold text-slate-400">Cafeteria Revenue</p>
          <p className="text-2xl sm:text-3xl font-black text-amber-400 mt-1">
            {settings.currencySymbol} {cafeteriaRevenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">
            {filteredCafeteriaOrders.length} food & drink orders
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <p className="text-xs uppercase font-semibold text-slate-400">Rental & Gear</p>
          <p className="text-2xl sm:text-3xl font-black text-indigo-400 mt-1">
            {settings.currencySymbol} {rentalRevenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">{filteredRentals.length} bookings processed</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <p className="text-xs uppercase font-semibold text-slate-400">Deposits Held</p>
          <p className="text-2xl sm:text-3xl font-black text-emerald-400 mt-1">
            {settings.currencySymbol} {depositsHeld.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">Refundable to active customers</p>
        </div>
      </div>

      {/* Report Table Selector & Content */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 overflow-hidden shadow-lg space-y-4">
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveReportTab('sessions')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeReportTab === 'sessions'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Gaming Sessions ({filteredSessions.length})
          </button>
          <button
            onClick={() => setActiveReportTab('cafeteria')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeReportTab === 'cafeteria'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Cafeteria Orders ({filteredCafeteriaOrders.length})
          </button>
          <button
            onClick={() => setActiveReportTab('rentals')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeReportTab === 'rentals'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Hardware Rentals ({filteredRentals.length})
          </button>
          <button
            onClick={() => setActiveReportTab('payments')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeReportTab === 'payments'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Payment Transactions ({filteredPayments.length})
          </button>
        </div>

        {/* Sessions Tab */}
        {activeReportTab === 'sessions' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Console</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Start Time</th>
                  <th className="p-3">End Time</th>
                  <th className="p-3">Duration</th>
                  <th className="p-3">Rate</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredSessions.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-800/40">
                    <td className="p-3 font-mono font-bold text-cyan-400">{s.consoleCode}</td>
                    <td className="p-3 text-white font-semibold">{s.customerName}</td>
                    <td className="p-3 font-mono text-slate-400">
                      {new Date(s.startTime).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="p-3 font-mono text-slate-400">
                      {s.endTime
                        ? new Date(s.endTime).toLocaleString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : 'Active Session'}
                    </td>
                    <td className="p-3 font-mono">{s.durationMinutes} mins</td>
                    <td className="p-3 font-mono">₹{s.ratePerHour}/hr</td>
                    <td className="p-3 font-bold text-emerald-400">
                      {settings.currencySymbol} {s.totalAmount}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                          s.status === 'completed'
                            ? 'bg-emerald-500/15 text-emerald-300'
                            : 'bg-cyan-500/15 text-cyan-300'
                        }`}
                      >
                        {s.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Cafeteria Tab */}
        {activeReportTab === 'cafeteria' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Order ID</th>
                  <th className="p-3">Date & Time</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Items Summary</th>
                  <th className="p-3">Subtotal</th>
                  <th className="p-3">Total Paid</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Payment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredCafeteriaOrders.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-6 text-center text-slate-500">
                      No cafeteria orders found for this timeframe.
                    </td>
                  </tr>
                ) : (
                  filteredCafeteriaOrders.map((o) => (
                    <tr key={o.id} className="hover:bg-slate-800/40">
                      <td className="p-3 font-mono font-bold text-amber-400">{o.id}</td>
                      <td className="p-3 font-mono text-slate-400">
                        {new Date(o.createdAt).toLocaleString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-white">{o.customerName}</div>
                        {o.customerPhone && (
                          <div className="text-[10px] text-slate-500">{o.customerPhone}</div>
                        )}
                      </td>
                      <td className="p-3">
                        <span className="text-slate-300 line-clamp-1 max-w-xs">
                          {o.items.map((i) => `${i.quantity}x ${i.name}`).join(', ')}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-slate-400">
                        {settings.currencySymbol} {o.subtotal}
                      </td>
                      <td className="p-3 font-mono font-bold text-emerald-400">
                        {settings.currencySymbol} {o.totalAmount}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                            o.status === 'cancelled'
                              ? 'bg-rose-500/15 text-rose-300'
                              : o.paymentStatus === 'paid'
                              ? 'bg-emerald-500/15 text-emerald-300'
                              : 'bg-amber-500/15 text-amber-300'
                          }`}
                        >
                          {o.status === 'cancelled' ? 'CANCELLED' : o.paymentStatus}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="uppercase font-mono text-[10px] bg-slate-800/80 px-2 py-1 rounded text-slate-300 border border-slate-700">
                          {o.paymentMethod}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Rentals Tab */}
        {activeReportTab === 'rentals' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Equipment</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Qty</th>
                  <th className="p-3">Start Date</th>
                  <th className="p-3">Rental Fee</th>
                  <th className="p-3">Security Deposit</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredRentals.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-800/40">
                    <td className="p-3 font-bold text-white">{r.rentalItemName}</td>
                    <td className="p-3">{r.customerName}</td>
                    <td className="p-3 font-mono">{r.quantity}</td>
                    <td className="p-3 font-mono text-slate-400">
                      {new Date(r.startTime).toLocaleDateString()}
                    </td>
                    <td className="p-3 font-bold text-emerald-400">
                      {settings.currencySymbol} {r.rentalFee}
                    </td>
                    <td className="p-3 font-bold text-amber-400">
                      {settings.currencySymbol} {r.depositAmount}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                          r.status === 'returned'
                            ? 'bg-emerald-500/15 text-emerald-300'
                            : r.status === 'overdue'
                            ? 'bg-rose-500/15 text-rose-300'
                            : 'bg-cyan-500/15 text-cyan-300'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Payments Tab */}
        {activeReportTab === 'payments' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Date</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Description</th>
                  <th className="p-3">Method</th>
                  <th className="p-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredPayments.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-800/40">
                    <td className="p-3 font-mono text-slate-400">
                      {new Date(p.timestamp).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="p-3 font-bold text-white">{p.customerName}</td>
                    <td className="p-3">{p.referenceTitle}</td>
                    <td className="p-3">
                      {p.splitDetails && p.splitDetails.length > 0 ? (
                        <div className="space-y-1">
                          <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 uppercase">
                            SPLIT
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {p.splitDetails.map((s, idx) => (
                              <span key={idx} className="text-[10px] bg-slate-950 px-1.5 py-0.5 rounded text-slate-400 border border-slate-800">
                                <span className="uppercase text-[9px]">{s.method}:</span> ₹{s.amount}
                              </span>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <span className="uppercase font-mono">{p.method}</span>
                      )}
                    </td>
                    <td className="p-3 text-right font-bold text-emerald-400">
                      {settings.currencySymbol} {p.amount}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
