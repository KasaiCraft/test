import React, { useState, useMemo } from 'react';
import {
  Wrench,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  DollarSign,
  User,
  Phone,
  Printer,
  Calendar,
  Layers,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Package,
  Check,
  ChevronRight,
  FileText,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import {
  RepairRecord,
  RepairStatus,
  RepairCategory,
  PaymentMethod,
  Customer,
} from '../../types';

export const RepairsView: React.FC = () => {
  const {
    repairRecords,
    customers,
    createRepairRecord,
    updateRepairRecord,
    addRepairPayment,
    deliverRepair,
    deleteRepairRecord,
    isAdmin,
  } = useCafe();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Modals
  const [isIntakeModalOpen, setIsIntakeModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isDeliverModalOpen, setIsDeliverModalOpen] = useState(false);
  const [isUpdateStatusModalOpen, setIsUpdateStatusModalOpen] = useState(false);
  const [selectedRepair, setSelectedRepair] = useState<RepairRecord | null>(null);
  const [printedRepair, setPrintedRepair] = useState<RepairRecord | null>(null);

  // Intake Form
  const [intakeData, setIntakeData] = useState({
    customerId: '',
    customerName: '',
    customerPhone: '',
    itemName: '',
    category: 'Controllers' as RepairCategory,
    serialNumber: '',
    problemDescription: '',
    accessoriesReceived: '',
    technician: '',
    estimatedCost: 0,
    customerCharge: 500,
    advancePaid: 0,
    paymentMethod: 'cash' as PaymentMethod,
    expectedDate: '',
    notes: '',
  });

  // Payment Form
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [paymentNotes, setPaymentNotes] = useState('');

  // Status Form
  const [newStatus, setNewStatus] = useState<RepairStatus>('Diagnosing');
  const [statusNotes, setStatusNotes] = useState('');

  // Deliver Form
  const [deliverCollectAmount, setDeliverCollectAmount] = useState<number>(0);
  const [deliverPaymentMethod, setDeliverPaymentMethod] = useState<PaymentMethod>('cash');
  const [deliverNotes, setDeliverNotes] = useState('');

  // Filtered records
  const filteredRepairs = useMemo(() => {
    return (repairRecords || []).filter((r) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        r.repairNumber.toLowerCase().includes(q) ||
        r.itemName.toLowerCase().includes(q) ||
        r.customerName.toLowerCase().includes(q) ||
        (r.customerPhone && r.customerPhone.includes(q)) ||
        (r.serialNumber && r.serialNumber.toLowerCase().includes(q));

      const matchesStatus =
        selectedStatus === 'all' || r.status === selectedStatus;
      const matchesCat =
        selectedCategory === 'all' || r.category === selectedCategory;

      return matchesSearch && matchesStatus && matchesCat;
    });
  }, [repairRecords, searchQuery, selectedStatus, selectedCategory]);

  // Statistics
  const stats = useMemo(() => {
    const list = repairRecords || [];
    const inProgress = list.filter((r) =>
      ['Received', 'Diagnosing', 'Waiting for Parts', 'Under Repair'].includes(r.status)
    ).length;
    const ready = list.filter((r) => r.status === 'Ready').length;
    const delivered = list.filter((r) => r.status === 'Delivered').length;
    const totalRevenue = list.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
    const pendingAmount = list.reduce((sum, r) => sum + (r.pendingAmount || 0), 0);
    return { inProgress, ready, delivered, totalRevenue, pendingAmount };
  }, [repairRecords]);

  // Handle Intake
  const handleIntakeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!intakeData.itemName.trim()) {
      alert('Please provide item name.');
      return;
    }

    let customerName = intakeData.customerName.trim();
    let customerPhone = intakeData.customerPhone.trim();

    if (intakeData.customerId) {
      const found = customers.find((c) => c.id === intakeData.customerId);
      if (found) {
        customerName = found.name;
        customerPhone = found.phone || customerPhone;
      }
    }

    if (!customerName) {
      alert('Please enter or select a customer.');
      return;
    }

    const res = await createRepairRecord({
      customerId: intakeData.customerId || undefined,
      customerName,
      customerPhone,
      itemName: intakeData.itemName.trim(),
      category: intakeData.category,
      serialNumber: intakeData.serialNumber.trim() || undefined,
      problemDescription: intakeData.problemDescription.trim(),
      technicianName: intakeData.technician.trim() || undefined,
      customerCharge: Number(intakeData.customerCharge) || 0,
      advancePayment: Number(intakeData.advancePaid) || 0,
      paymentMethod: intakeData.paymentMethod,
      expectedCompletionDate: intakeData.expectedDate || undefined,
      notes: intakeData.notes.trim() || undefined,
    });

    if (res.success) {
      setIsIntakeModalOpen(false);
      setIntakeData({
        customerId: '',
        customerName: '',
        customerPhone: '',
        itemName: '',
        category: 'Controllers',
        serialNumber: '',
        problemDescription: '',
        accessoriesReceived: '',
        technician: '',
        estimatedCost: 0,
        customerCharge: 500,
        advancePaid: 0,
        paymentMethod: 'cash',
        expectedDate: '',
        notes: '',
      });
      if (res.repair) {
        setPrintedRepair(res.repair);
      }
    } else {
      alert(res.error || 'Failed to register repair');
    }
  };

  // Open Payment Modal
  const handleOpenPayment = (repair: RepairRecord) => {
    setSelectedRepair(repair);
    setPaymentAmount(repair.pendingAmount || 0);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRepair) return;
    if (paymentAmount <= 0) {
      alert('Payment amount must be greater than 0.');
      return;
    }

    const res = await addRepairPayment(
      selectedRepair.id,
      Number(paymentAmount),
      paymentMethod,
      paymentNotes
    );

    if (res.success) {
      setIsPaymentModalOpen(false);
      setSelectedRepair(null);
      setPaymentNotes('');
    } else {
      alert(res.error || 'Failed to record payment');
    }
  };

  // Open Status Modal
  const handleOpenStatus = (repair: RepairRecord) => {
    setSelectedRepair(repair);
    setNewStatus(repair.status);
    setStatusNotes('');
    setIsUpdateStatusModalOpen(true);
  };

  const handleStatusSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRepair) return;

    await updateRepairRecord(selectedRepair.id, {
      status: newStatus,
      notes: statusNotes ? `${selectedRepair.notes || ''}\n[Status: ${newStatus}] ${statusNotes}` : undefined,
    });

    setIsUpdateStatusModalOpen(false);
    setSelectedRepair(null);
  };

  // Open Deliver Modal
  const handleOpenDeliver = (repair: RepairRecord) => {
    setSelectedRepair(repair);
    setDeliverCollectAmount(repair.pendingAmount || 0);
    setIsDeliverModalOpen(true);
  };

  const handleDeliverSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRepair) return;

    const res = await deliverRepair(
      selectedRepair.id,
      Number(deliverCollectAmount) || 0,
      deliverPaymentMethod,
      deliverNotes
    );

    if (res.success) {
      setIsDeliverModalOpen(false);
      setSelectedRepair(null);
      setDeliverNotes('');
    } else {
      alert(res.error || 'Failed to deliver repair');
    }
  };

  const getStatusBadge = (status: RepairStatus) => {
    switch (status) {
      case 'Received':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'Diagnosing':
        return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
      case 'Waiting for Parts':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'Under Repair':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'Ready':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'Delivered':
        return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
      case 'Cancelled':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  return (
    <div id="repairs-view" className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30">
              <Wrench className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Repair & Service Tracking</h1>
              <p className="text-sm text-slate-400">
                Track consoles, controllers, rigs, and accessories from intake to diagnosis, repair, and handover.
              </p>
            </div>
          </div>
        </div>

        <button
          id="open-intake-modal-btn"
          onClick={() => setIsIntakeModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-sm transition shadow-lg shadow-purple-950/30"
        >
          <Plus className="w-4 h-4" />
          Intake New Repair
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-slate-400">Total Jobs</p>
          <p className="text-xl font-bold text-white mt-1">{(repairRecords || []).length}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-amber-400">In Progress</p>
          <p className="text-xl font-bold text-amber-400 mt-1">{stats.inProgress}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-emerald-400">Ready for Delivery</p>
          <p className="text-xl font-bold text-emerald-400 mt-1">{stats.ready}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-purple-400">Delivered</p>
          <p className="text-xl font-bold text-purple-400 mt-1">{stats.delivered}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-rose-400">Pending Balance</p>
          <p className="text-xl font-bold text-rose-400 mt-1">₹{stats.pendingAmount}</p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            id="search-repairs-input"
            type="text"
            placeholder="Search by REP#, customer, phone, item..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-white text-sm focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            id="filter-repair-status"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-sm focus:outline-none focus:border-purple-500"
          >
            <option value="all">All Statuses</option>
            <option value="Received">Received</option>
            <option value="Diagnosing">Diagnosing</option>
            <option value="Waiting for Parts">Waiting for Parts</option>
            <option value="Under Repair">Under Repair</option>
            <option value="Ready">Ready for Delivery</option>
            <option value="Delivered">Delivered</option>
            <option value="Cancelled">Cancelled</option>
          </select>

          <select
            id="filter-repair-category"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-sm focus:outline-none focus:border-purple-500"
          >
            <option value="all">All Categories</option>
            <option value="PS4">PS4 Console</option>
            <option value="PS5">PS5 Console</option>
            <option value="Controllers">Controllers</option>
            <option value="Games">Games</option>
            <option value="Other Equipment">Other Equipment</option>
          </select>
        </div>
      </div>

      {/* Repairs Table / Cards */}
      {filteredRepairs.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-slate-900/30 border border-dashed border-slate-800">
          <Wrench className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 font-medium">No repair records found</p>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Log incoming customer console repairs, controller stick drift fixes, or driving rig maintenance.
          </p>
          <button
            onClick={() => setIsIntakeModalOpen(true)}
            className="mt-4 px-4 py-2 rounded-xl bg-purple-600 text-white text-sm font-medium hover:bg-purple-500 transition"
          >
            Intake First Repair
          </button>
        </div>
      ) : (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-900/90 text-slate-400 text-xs uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3">Repair #</th>
                  <th className="px-4 py-3">Customer</th>
                  <th className="px-4 py-3">Item & Category</th>
                  <th className="px-4 py-3">Problem Reported</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Bill & Pending</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredRepairs.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-800/30">
                    <td className="px-4 py-3 font-mono text-xs font-bold text-purple-400">
                      {r.repairNumber}
                      <span className="block text-[10px] text-slate-500 font-sans mt-0.5">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-slate-300">
                      <div className="font-semibold text-white">{r.customerName}</div>
                      {r.customerPhone && (
                        <div className="text-xs text-slate-500 flex items-center gap-1">
                          <Phone className="w-3 h-3" /> {r.customerPhone}
                        </div>
                      )}
                    </td>

                    <td className="px-4 py-3 text-slate-300">
                      <div className="font-medium text-white">{r.itemName}</div>
                      <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300">
                        {r.category.toUpperCase()}
                      </span>
                      {r.serialNumber && (
                        <span className="text-xs text-slate-500 ml-2">
                          SN: {r.serialNumber}
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-xs text-slate-400 max-w-[200px] truncate">
                      {r.problemDescription}
                    </td>

                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStatusBadge(
                          r.status
                        )}`}
                      >
                        {r.status}
                      </span>
                      {r.technician && (
                        <div className="text-[10px] text-slate-500 mt-0.5">
                          Tech: {r.technician}
                        </div>
                      )}
                    </td>

                    <td className="px-4 py-3">
                      <div className="font-semibold text-white">₹{r.customerCharge}</div>
                      <div className="text-xs flex items-center gap-1.5 mt-0.5">
                        <span className="text-emerald-400">Paid: ₹{r.paidAmount || 0}</span>
                        {(r.pendingAmount || 0) > 0 && (
                          <span className="text-rose-400 font-medium">
                            Due: ₹{r.pendingAmount}
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setPrintedRepair(r)}
                          title="Print Job Slip"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleOpenStatus(r)}
                          className="px-2 py-1 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                        >
                          Status
                        </button>

                        {(r.pendingAmount || 0) > 0 && (
                          <button
                            onClick={() => handleOpenPayment(r)}
                            className="px-2 py-1 rounded-lg text-xs font-medium bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 transition"
                          >
                            Pay Due
                          </button>
                        )}

                        {r.status !== 'Delivered' && (
                          <button
                            onClick={() => handleOpenDeliver(r)}
                            className="px-2 py-1 rounded-lg text-xs font-medium bg-purple-600 hover:bg-purple-500 text-white transition flex items-center gap-1"
                          >
                            <Check className="w-3 h-3" />
                            Deliver
                          </button>
                        )}

                        {isAdmin && (
                          <button
                            onClick={() => {
                              if (confirm(`Delete repair #${r.repairNumber}?`)) {
                                deleteRepairRecord(r.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 transition"
                            title="Delete"
                          >
                            &times;
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* INTAKE MODAL */}
      {isIntakeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Wrench className="w-5 h-5 text-purple-400" />
                <h2 className="text-lg font-bold text-white">Intake New Repair</h2>
              </div>
              <button
                onClick={() => setIsIntakeModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleIntakeSubmit} className="space-y-4 mt-4">
              {/* Customer selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Select Customer
                  </label>
                  <select
                    value={intakeData.customerId}
                    onChange={(e) => {
                      const c = customers.find((cust) => cust.id === e.target.value);
                      setIntakeData({
                        ...intakeData,
                        customerId: e.target.value,
                        customerName: c ? c.name : intakeData.customerName,
                        customerPhone: c ? c.phone || '' : intakeData.customerPhone,
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">-- New / Walk-in Customer --</option>
                    {(customers || []).map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Full name"
                    value={intakeData.customerName}
                    onChange={(e) =>
                      setIntakeData({ ...intakeData, customerName: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    placeholder="Mobile number"
                    value={intakeData.customerPhone}
                    onChange={(e) =>
                      setIntakeData({ ...intakeData, customerPhone: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Device Category
                  </label>
                  <select
                    value={intakeData.category}
                    onChange={(e) =>
                      setIntakeData({
                        ...intakeData,
                        category: e.target.value as RepairCategory,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  >
                    <option value="Controllers">Controller (DualSense / Xbox / Mod)</option>
                    <option value="PS4">PS4 Console</option>
                    <option value="PS5">PS5 Console</option>
                    <option value="Games">Game Discs / Media</option>
                    <option value="Other Equipment">Other Hardware / Accessories</option>
                  </select>
                </div>
              </div>

              {/* Item Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Item / Device Model *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={
                      intakeData.category === 'Controllers'
                        ? 'e.g. PS5 DualSense Midnight Black / Xbox Series'
                        : intakeData.category === 'PS5'
                        ? 'e.g. Sony PS5 Disc / Digital Edition'
                        : intakeData.category === 'PS4'
                        ? 'e.g. Sony PS4 Slim 500GB / PS4 Pro 1TB'
                        : intakeData.category === 'Games'
                        ? 'e.g. EA Sports FC 25 PS5 Blu-ray'
                        : 'e.g. Logitech G29 Wheel / Headset'
                    }
                    value={intakeData.itemName}
                    onChange={(e) =>
                      setIntakeData({ ...intakeData, itemName: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Serial # (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Device serial or barcode"
                    value={intakeData.serialNumber}
                    onChange={(e) =>
                      setIntakeData({ ...intakeData, serialNumber: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Problem Description *
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="Describe the issue reported by the customer (e.g. Left analog stick drifts upward, HDMI port damaged)..."
                  value={intakeData.problemDescription}
                  onChange={(e) =>
                    setIntakeData({
                      ...intakeData,
                      problemDescription: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Accessories Handed In
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Cable, box, original dock"
                    value={intakeData.accessoriesReceived}
                    onChange={(e) =>
                      setIntakeData({
                        ...intakeData,
                        accessoriesReceived: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Assigned Technician
                  </label>
                  <input
                    type="text"
                    placeholder="Technician name"
                    value={intakeData.technician}
                    onChange={(e) =>
                      setIntakeData({ ...intakeData, technician: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Charges and Advance */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Total Charge (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={intakeData.customerCharge}
                    onChange={(e) =>
                      setIntakeData({
                        ...intakeData,
                        customerCharge: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Advance Paid (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={intakeData.advancePaid}
                    onChange={(e) =>
                      setIntakeData({
                        ...intakeData,
                        advancePaid: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Payment Method
                  </label>
                  <select
                    value={intakeData.paymentMethod}
                    onChange={(e) =>
                      setIntakeData({
                        ...intakeData,
                        paymentMethod: e.target.value as any,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                  >
                    <option value="cash">Cash</option>
                    <option value="upi">UPI / QR</option>
                    <option value="card">Card</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Expected Delivery Date
                </label>
                <input
                  type="date"
                  value={intakeData.expectedDate}
                  onChange={(e) =>
                    setIntakeData({ ...intakeData, expectedDate: e.target.value })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsIntakeModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold transition shadow-lg shadow-purple-950/30"
                >
                  Confirm Intake & Print Slip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* UPDATE STATUS MODAL */}
      {isUpdateStatusModalOpen && selectedRepair && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h2 className="text-lg font-bold text-white">
                Update Status: {selectedRepair.repairNumber}
              </h2>
              <button
                onClick={() => setIsUpdateStatusModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleStatusSubmit} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Current Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as RepairStatus)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                >
                  <option value="Received">Received</option>
                  <option value="Diagnosing">Diagnosing</option>
                  <option value="Waiting for Parts">Waiting for Parts</option>
                  <option value="Under Repair">Under Repair</option>
                  <option value="Ready">Ready for Customer Delivery</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Progress Note
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Replaced analog module, tested for 30 minutes with zero drift."
                  value={statusNotes}
                  onChange={(e) => setStatusNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsUpdateStatusModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold transition"
                >
                  Update Status
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* COLLECT PAYMENT MODAL */}
      {isPaymentModalOpen && selectedRepair && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h2 className="text-lg font-bold text-white">
                Collect Payment: {selectedRepair.repairNumber}
              </h2>
              <button
                onClick={() => setIsPaymentModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <div className="p-3 my-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Charge:</span>
                <span className="text-white font-semibold">₹{selectedRepair.customerCharge}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Already Paid:</span>
                <span className="text-emerald-400 font-semibold">₹{selectedRepair.paidAmount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Due Remaining:</span>
                <span className="text-rose-400 font-semibold">₹{selectedRepair.pendingAmount}</span>
              </div>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Payment Amount (₹) *
                </label>
                <input
                  type="number"
                  min="1"
                  max={selectedRepair.pendingAmount}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-lg focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-emerald-500 focus:outline-none"
                >
                  <option value="cash">Cash</option>
                  <option value="upi">UPI / QR</option>
                  <option value="card">Card</option>
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition"
                >
                  Record Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELIVER REPAIR MODAL */}
      {isDeliverModalOpen && selectedRepair && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-purple-400" />
                <h2 className="text-lg font-bold text-white">Deliver Repair to Customer</h2>
              </div>
              <button
                onClick={() => setIsDeliverModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <div className="p-3 my-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
              <div className="font-semibold text-white text-sm">
                [{selectedRepair.repairNumber}] {selectedRepair.itemName}
              </div>
              <div className="text-slate-400">Customer: {selectedRepair.customerName}</div>
              <div className="text-rose-400 font-bold pt-1">
                Outstanding Balance: ₹{selectedRepair.pendingAmount || 0}
              </div>
            </div>

            <form onSubmit={handleDeliverSubmit} className="space-y-4">
              {(selectedRepair.pendingAmount || 0) > 0 && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                      Collect Now (₹)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={deliverCollectAmount}
                      onChange={(e) => setDeliverCollectAmount(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                      Payment Method
                    </label>
                    <select
                      value={deliverPaymentMethod}
                      onChange={(e) => setDeliverPaymentMethod(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                    >
                      <option value="cash">Cash</option>
                      <option value="upi">UPI / QR</option>
                      <option value="card">Card</option>
                    </select>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Handover Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Tested in presence of customer, 15 days warranty on stick."
                  value={deliverNotes}
                  onChange={(e) => setDeliverNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsDeliverModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold transition"
                >
                  Complete Handover
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINT JOB SHEET MODAL */}
      {printedRepair && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-white text-slate-900 p-6 shadow-2xl space-y-4">
            <div className="text-center border-b pb-3">
              <h3 className="text-lg font-black tracking-tight">NEXT GEN GAMING CAFE</h3>
              <p className="text-xs text-slate-500 uppercase tracking-widest">
                Official Repair Job Sheet
              </p>
              <div className="font-mono text-xl font-bold text-indigo-600 mt-1">
                {printedRepair.repairNumber}
              </div>
            </div>

            <div className="text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Date Received:</span>
                <span className="font-semibold">
                  {new Date(printedRepair.createdAt).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Customer Name:</span>
                <span className="font-semibold">{printedRepair.customerName}</span>
              </div>
              {printedRepair.customerPhone && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Phone:</span>
                  <span className="font-semibold">{printedRepair.customerPhone}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-slate-500">Item / Model:</span>
                <span className="font-semibold">{printedRepair.itemName}</span>
              </div>
              {printedRepair.serialNumber && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Serial #:</span>
                  <span className="font-mono">{printedRepair.serialNumber}</span>
                </div>
              )}
            </div>

            <div className="p-3 bg-slate-100 rounded-xl text-xs">
              <p className="font-bold text-slate-700">Problem Description:</p>
              <p className="text-slate-600 mt-0.5">{printedRepair.problemDescription}</p>
            </div>

            <div className="text-xs border-t pt-2 space-y-1">
              <div className="flex justify-between font-bold">
                <span>Total Charge:</span>
                <span>₹{printedRepair.customerCharge}</span>
              </div>
              <div className="flex justify-between text-emerald-600">
                <span>Advance Paid:</span>
                <span>₹{printedRepair.paidAmount || 0}</span>
              </div>
              <div className="flex justify-between text-rose-600 font-bold">
                <span>Balance Due on Pickup:</span>
                <span>₹{printedRepair.pendingAmount || 0}</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 text-center italic">
              Please present this job slip when collecting your equipment. Next Gen Gaming Cafe is not responsible for uncollected items after 45 days.
            </p>

            <div className="flex gap-2 pt-2 border-t">
              <button
                onClick={() => setPrintedRepair(null)}
                className="flex-1 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" />
                Print Slip
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
