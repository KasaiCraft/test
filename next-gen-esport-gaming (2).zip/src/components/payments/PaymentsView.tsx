import React, { useState, useMemo } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Filter,
  CreditCard,
  QrCode,
  Banknote,
  MoreHorizontal,
  CheckCircle2,
  Clock,
  Printer,
  Calendar,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { PaymentTransaction, PaymentMethod, PaymentStatus } from '../../types';
import { SettlePendingPaymentModal, SettlePendingTarget } from '../modals/SettlePendingPaymentModal';

interface PaymentsViewProps {
  onOpenNewPaymentModal: () => void;
  onOpenReceiptModal: (transaction: PaymentTransaction) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  onOpenNewPaymentModal,
  onOpenReceiptModal,
}) => {
  const { payments, settings, currentUser, deleteTransaction } = useCafe();
  const isAdmin = currentUser?.role === 'admin';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Settlement modal state
  const [settleTarget, setSettleTarget] = useState<SettlePendingTarget | null>(null);
  const [isSettleModalOpen, setIsSettleModalOpen] = useState(false);

  // Strictly enforce 2-week window (Present Week + Last Week) for Staff at the root data layer.
  // Admin/Owner has unrestricted access to all history.
  const roleFilteredPayments = useMemo(() => {
    if (isAdmin) return payments;

    const now = new Date();
    // In standard ISO-8601 calendar Monday is start of week:
    // Sunday: getDay() === 0 -> diff is -6
    // Other days: getDay() === d -> diff is (1 - d)
    const day = now.getDay();
    const diffToMonday = (day === 0 ? -6 : 1) - day;

    // Start of Present Week (Monday 00:00:00.000)
    const presentWeekMonday = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + diffToMonday,
      0, 0, 0, 0
    );

    // Start of Last Week (Monday of previous week 00:00:00.000)
    const lastWeekMonday = new Date(presentWeekMonday);
    lastWeekMonday.setDate(presentWeekMonday.getDate() - 7);

    // End of Present Week (Sunday 23:59:59.999)
    const presentWeekSunday = new Date(presentWeekMonday);
    presentWeekSunday.setDate(presentWeekMonday.getDate() + 6);
    presentWeekSunday.setHours(23, 59, 59, 999);

    const minTime = lastWeekMonday.getTime();
    const maxTime = presentWeekSunday.getTime();

    return payments.filter((p) => {
      const ts = p.timestamp ? new Date(p.timestamp).getTime() : 0;
      return !isNaN(ts) && ts >= minTime && ts <= maxTime;
    });
  }, [payments, isAdmin]);

  const filteredPayments = useMemo(() => {
    return roleFilteredPayments
      .filter((p) => {
        const matchesSearch =
          p.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.referenceTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (p.notes && p.notes.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesMethod =
          selectedMethod === 'all' ||
          p.method === selectedMethod ||
          (selectedMethod === 'split' && (p.method === 'split' || (p.splitDetails && p.splitDetails.length > 0))) ||
          (p.splitDetails && p.splitDetails.some((s) => s.method === selectedMethod));

        const matchesType = selectedType === 'all' || p.type === selectedType;

        const matchesStatus =
          selectedStatus === 'all' ||
          p.status === selectedStatus ||
          (selectedStatus === 'partial' && (p.status === 'partial' || (p.pendingAmount && p.pendingAmount > 0)));

        return matchesSearch && matchesMethod && matchesType && matchesStatus;
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [roleFilteredPayments, searchQuery, selectedMethod, selectedType, selectedStatus]);

  const totalCollected = useMemo(() => {
    return filteredPayments
      .filter((p) => p.amount > 0)
      .reduce((acc, p) => acc + p.amount, 0);
  }, [filteredPayments]);

  const totalRefunded = useMemo(() => {
    return filteredPayments
      .filter((p) => p.amount < 0)
      .reduce((acc, p) => acc + Math.abs(p.amount), 0);
  }, [filteredPayments]);

  // Total pending amount from role-filtered payments (Deduplicated by Reference ID to avoid double-counting)
  const totalPendingAmount = useMemo(() => {
    const latestPendingByRef = new Map<string, number>();
    
    roleFilteredPayments.forEach((p) => {
      if (p.status === 'pending' || p.status === 'partial' || (p.pendingAmount && p.pendingAmount > 0)) {
        const refId = p.referenceId || p.id;
        // Since payments are typically sorted or added chronologically, 
        // we might want the latest one. But CafeContext updates ALL of them,
        // so any one will do, but we must only count it ONCE per reference.
        latestPendingByRef.set(refId, p.pendingAmount || 0);
      }
    });

    return Array.from(latestPendingByRef.values()).reduce((acc, val) => acc + val, 0);
  }, [roleFilteredPayments]);

  const pendingCount = useMemo(() => {
    const uniquePendingRefs = new Set<string>();
    roleFilteredPayments.forEach((p) => {
      if (p.status === 'pending' || p.status === 'partial' || (p.pendingAmount && p.pendingAmount > 0)) {
        uniquePendingRefs.add(p.referenceId || p.id);
      }
    });
    return uniquePendingRefs.size;
  }, [roleFilteredPayments]);

  // Calculate channel revenues including split breakdowns
  const { netCash, netUpi, netCard } = useMemo(() => {
    let cash = 0;
    let upi = 0;
    let card = 0;

    filteredPayments.forEach((p) => {
      if (p.splitDetails && p.splitDetails.length > 0) {
        p.splitDetails.forEach((item) => {
          if (item.method === 'cash') cash += item.amount;
          else if (item.method === 'upi') upi += item.amount;
          else if (item.method === 'card') card += item.amount;
        });
      } else {
        if (p.method === 'cash') cash += p.amount;
        else if (p.method === 'upi') upi += p.amount;
        else if (p.method === 'card') card += p.amount;
      }
    });

    return { netCash: cash, netUpi: upi, netCard: card };
  }, [filteredPayments]);

  const getMethodIcon = (method: PaymentMethod) => {
    switch (method) {
      case 'upi':
        return <QrCode className="w-3.5 h-3.5 text-cyan-400" />;
      case 'card':
        return <CreditCard className="w-3.5 h-3.5 text-indigo-400" />;
      case 'cash':
        return <Banknote className="w-3.5 h-3.5 text-emerald-400" />;
      case 'split':
        return <TrendingUp className="w-3.5 h-3.5 text-amber-400" />;
      default:
        return <MoreHorizontal className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div id="payments-view" className="space-y-6 pb-12">
      {/* Staff View Limitation Notice */}
      {!isAdmin && (
        <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs">
          <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
          <div className="flex-1 flex flex-wrap items-center justify-between gap-2">
            <span>
              <strong>Staff Security Mode:</strong> Displaying <strong>Present Week</strong> and <strong>Last Week</strong> payment data only. Older payment records and archives are protected and accessible solely to Admin.
            </span>
            <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-[10px] font-bold uppercase tracking-wider text-amber-200">
              2-Week Scope Enforced
            </span>
          </div>
        </div>
      )}

      {/* Top Bento Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <p className="text-xs uppercase font-semibold text-slate-400">Total Collected</p>
          <p className="text-2xl font-black text-emerald-400 mt-1">
            {settings.currencySymbol} {totalCollected.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Filtered transactions sum</p>
        </div>

        <div className={`bg-slate-900/90 border rounded-2xl p-5 shadow-lg ${
          totalPendingAmount > 0 ? 'border-amber-500/40 bg-amber-950/10' : 'border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <p className="text-xs uppercase font-semibold text-slate-400">Pending Amount</p>
            <AlertCircle className={`w-4 h-4 ${totalPendingAmount > 0 ? 'text-amber-400' : 'text-slate-500'}`} />
          </div>
          <p className={`text-2xl font-black mt-1 ${totalPendingAmount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
            {settings.currencySymbol} {totalPendingAmount.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">{pendingCount} transactions due</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <p className="text-xs uppercase font-semibold text-slate-400">UPI / QR Code</p>
            <QrCode className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-black text-cyan-300 mt-1">
            {settings.currencySymbol} {netUpi.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">GPay, PhonePe, Paytm</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <p className="text-xs uppercase font-semibold text-slate-400">Cash Counter</p>
            <Banknote className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-300 mt-1">
            {settings.currencySymbol} {netCash.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Physical drawer cash</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <p className="text-xs uppercase font-semibold text-slate-400">Card & POS</p>
            <CreditCard className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-2xl font-black text-indigo-300 mt-1">
            {settings.currencySymbol} {netCard.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Swipe machine transactions</p>
        </div>
      </div>

      {/* Filter and Action Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4 bg-slate-900/80 p-3.5 sm:p-5 rounded-2xl border border-slate-800">
        <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 flex-1 w-full md:w-auto">
          <div className="relative flex-1 sm:flex-initial sm:w-64 min-w-[160px] w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="payments-search-input"
              type="text"
              placeholder="Search by customer name, ref, or note..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-9 pr-4 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <select
            id="payments-method-filter"
            value={selectedMethod}
            onChange={(e) => setSelectedMethod(e.target.value)}
            className="w-full sm:w-auto bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="all">All Payment Methods</option>
            <option value="upi">UPI / QR</option>
            <option value="cash">Cash</option>
            <option value="card">Credit/Debit Card</option>
            <option value="split">Split Payments</option>
            <option value="other">Other</option>
          </select>

          <select
            id="payments-type-filter"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="w-full sm:w-auto bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="all">All Transaction Types</option>
            <option value="gaming_session">Gaming Sessions</option>
            <option value="cafeteria_order">Cafeteria Orders</option>
            <option value="rental_fee">Rental Fees & Deposits</option>
            <option value="deposit_refund">Deposit Refunds</option>
            <option value="direct_payment">Direct Counter Payments</option>
          </select>

          <select
            id="payments-status-filter"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full sm:w-auto bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="all">All Payment Statuses</option>
            <option value="paid">Paid</option>
            <option value="partial">Partial (Unsettled)</option>
            <option value="pending">Pending</option>
          </select>
        </div>

        <button
          id="record-direct-payment-btn"
          onClick={onOpenNewPaymentModal}
          className="w-full md:w-auto flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs sm:text-sm shadow-md shadow-emerald-500/20 transition-all cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Record Counter Payment</span>
        </button>
      </div>

      {/* Ledger Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3.5">Date & Time</th>
                <th className="p-3.5">Customer</th>
                <th className="p-3.5">Reference / Description</th>
                <th className="p-3.5">Method</th>
                <th className="p-3.5">Recorded By</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-right">Amount</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredPayments.map((p) => {
                const isPositive = p.amount >= 0;
                const isPartial = p.status === 'partial' || (p.pendingAmount !== undefined && p.pendingAmount > 0);
                const isPending = p.status === 'pending';
                const hasDue = isPartial || isPending;

                return (
                  <tr key={p.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono text-slate-400">
                      {new Date(p.timestamp).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="p-3.5 font-bold text-white">{p.customerName}</td>
                    <td className="p-3.5 text-slate-300">
                      <p className="font-medium">{p.referenceTitle}</p>
                      {p.notes && <p className="text-[10px] text-slate-500 mt-0.5">{p.notes}</p>}
                    </td>
                    <td className="p-3.5">
                      {p.splitDetails && p.splitDetails.length > 0 ? (
                        <div className="space-y-1">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/20 border border-amber-500/40 text-amber-300 uppercase">
                            <TrendingUp className="w-3 h-3 text-amber-400" />
                            SPLIT
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {p.splitDetails.map((s, idx) => (
                              <span
                                key={idx}
                                className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-950 border border-slate-700 text-slate-300"
                              >
                                <span className="uppercase text-[9px] text-slate-400">{s.method}:</span>
                                <span className="font-bold text-slate-200">₹{s.amount}</span>
                              </span>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-800 border border-slate-700 text-slate-200 uppercase">
                          {getMethodIcon(p.method)}
                          {p.method}
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 text-slate-400">{p.recordedBy}</td>
                    
                    {/* Status Column */}
                    <td className="p-3.5 text-center">
                      {isPartial ? (
                        <div className="flex flex-col items-center">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                            Partial
                          </span>
                          {p.pendingAmount !== undefined && (
                            <span className="text-[10px] text-amber-400 font-semibold mt-0.5">
                              Due: ₹{p.pendingAmount}
                            </span>
                          )}
                        </div>
                      ) : isPending ? (
                        <div className="flex flex-col items-center">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 uppercase">
                            Pending
                          </span>
                          {p.pendingAmount !== undefined && (
                            <span className="text-[10px] text-rose-400 font-semibold mt-0.5">
                              Due: ₹{p.pendingAmount}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase">
                          Paid
                        </span>
                      )}
                    </td>

                    <td className="p-3.5 text-right font-bold text-sm">
                      <span className={isPositive ? 'text-emerald-400' : 'text-rose-400'}>
                        {isPositive ? '+' : ''}
                        {settings.currencySymbol} {Math.abs(p.amount).toLocaleString('en-IN')}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {hasDue && (
                          <button
                            id={`settle-btn-${p.id}`}
                            onClick={() => {
                              const totalBill = p.totalBill || p.amount + (p.pendingAmount || 0);
                              const pendingAmount = p.pendingAmount || 0;
                              const previouslyPaid = Math.max(0, totalBill - pendingAmount);

                              setSettleTarget({
                                type:
                                  p.type === 'gaming_session'
                                    ? 'session'
                                    : p.type === 'cafeteria_order'
                                    ? 'cafeteria'
                                    : 'rental',
                                referenceId: p.referenceId,
                                referenceTitle: p.referenceTitle,
                                customerId: p.customerId,
                                customerName: p.customerName,
                                totalBill,
                                previouslyPaid,
                                pendingAmount,
                              });
                              setIsSettleModalOpen(true);
                            }}
                            title="Settle Pending Balance"
                            className="p-1.5 text-amber-400 hover:text-amber-300 hover:bg-amber-500/20 rounded-lg transition-colors flex items-center gap-1 text-[11px] font-bold"
                          >
                            <Banknote className="w-3.5 h-3.5" />
                            <span>Settle</span>
                          </button>
                        )}
                        <button
                          id={`print-receipt-btn-${p.id}`}
                          onClick={() => onOpenReceiptModal(p)}
                          title="View / Print Receipt"
                          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded-lg transition-colors"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        {isAdmin && (
                          <button
                            id={`delete-payment-btn-${p.id}`}
                            onClick={async () => {
                              if (window.confirm(`Are you sure you want to DELETE this transaction for ₹${p.amount}? This will revert the customer's total spent and update outstanding balance.`)) {
                                const res = await deleteTransaction(p.id);
                                if (!res.success) alert(res.error);
                              }
                            }}
                            title="Delete Transaction (Admin Only)"
                            className="p-1.5 text-slate-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredPayments.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-12 text-center text-slate-500">
                    No payment records found matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Settle Pending Payment Modal */}
      <SettlePendingPaymentModal
        isOpen={isSettleModalOpen}
        onClose={() => {
          setIsSettleModalOpen(false);
          setSettleTarget(null);
        }}
        target={settleTarget}
      />
    </div>
  );
};
