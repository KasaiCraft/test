import React, { useState, useCallback } from 'react';
import {
  X,
  Square,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { GamingSession, PaymentMethod, PaymentStatus, PaymentSplitItem } from '../../types';
import { PaymentInputSection, PaymentInputData } from '../common/PaymentInputSection';

interface ModalPaymentState {
  isSplit: boolean;
  paymentMethod: PaymentMethod;
  totalPaid: number;
  remaining: number;
  paymentStatus: PaymentStatus;
  splitDetails?: PaymentSplitItem[];
}

interface EndSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  session: GamingSession | null;
  onSessionCompleted?: (session: GamingSession) => void;
}

export const EndSessionModal: React.FC<EndSessionModalProps> = ({
  isOpen,
  onClose,
  session,
  onSessionCompleted,
}) => {
  const { stopSession, settings, calculateLiveSessionBill, payments } = useCafe();

  const [discount, setDiscount] = useState<string>(String(session?.discountAmount || 0));
  const [extraCharges, setExtraCharges] = useState<string>(String(session?.extraCharges || 0));
  const [paymentState, setPaymentState] = useState<ModalPaymentState>({
    isSplit: false,
    paymentMethod: 'upi',
    totalPaid: 0,
    remaining: 0,
    paymentStatus: 'paid',
  });
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handlePaymentChange = useCallback((data: PaymentInputData) => {
    setPaymentState({
      isSplit: data.paymentMode === 'split',
      paymentMethod: data.paymentMethod,
      totalPaid: data.paidAmount,
      remaining: data.remaining,
      paymentStatus: data.paymentStatus,
      splitDetails: data.splitPayments,
    });
  }, []);

  if (!isOpen || !session) return null;

  const live = calculateLiveSessionBill(session);
  const isPreset = Boolean(session.presetDurationMinutes && session.presetDurationMinutes > 0);
  const originalBase = isPreset
    ? (Number(session.initialBaseAmount) || Number(session.baseAmount) || Number(live.baseAmount) || 0)
    : Number(live.baseAmount ?? 0);
  const extensionChargesTotal = Number(session.extensionCharges || 0);

  // alreadyPaid tracks all payments made towards this specific session so far
  const alreadyPaid = Number(session.paidAmount) || 0;
  
  const discountNum = parseFloat(discount) || 0;
  const extraNum = parseFloat(extraCharges) || 0;
  
  // Total Session Value = Base Gaming Charge + Extension Charges (+ Extras - Discount)
  const fullBill = Math.max(0, originalBase + extensionChargesTotal - discountNum + extraNum);
  
  // Amount Due = Total Bill - Payments already received
  const calculatedTotal = Math.max(0, fullBill - alreadyPaid);

  const formatDuration = (mins: number) => {
    const hrs = Math.floor(mins / 60);
    const m = mins % 60;
    return hrs > 0 ? `${hrs} hr ${m} min` : `${m} minutes`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (paymentState.totalPaid > calculatedTotal) {
      setError(`Payment amount (₹${paymentState.totalPaid}) cannot exceed total bill (₹${calculatedTotal})`);
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await stopSession({
        sessionId: session.id,
        discountAmount: discountNum,
        extraCharges: extraNum,
        paymentMethod: paymentState.paymentMethod,
        paidAmount: paymentState.totalPaid,
        splitPayments: paymentState.splitDetails,
        notes: notes.trim(),
      });

      if (res.success && res.session) {
        if (onSessionCompleted) {
          onSessionCompleted(res.session);
        }
        onClose();
      } else {
        setError(res.error || 'Failed to stop session');
      }
    } catch (err: any) {
      setError(err?.message || 'Error stopping session');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
              <Square className="w-4 h-4 fill-rose-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Stop Session & Checkout</h3>
              <p className="text-xs text-slate-400">
                {session.consoleCode} • Player: {session.customerName} {session.playerCount && session.playerCount > 1 ? `(${session.playerCount}P)` : ''}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Bill Breakdown Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold">
              {error}
            </div>
          )}

          {/* Session Summary Card */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="grid grid-cols-1 gap-3 text-xs">
              <div>
                <p className="text-slate-400">Elapsed Time</p>
                <p className="text-sm font-bold text-white font-mono mt-0.5">
                  {formatDuration(live.elapsedMinutes)}
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-400">Base Gaming Charge</span>
              <span className="font-bold text-slate-200">
                {settings.currencySymbol} {originalBase}
              </span>
            </div>

            {extensionChargesTotal > 0 && (
              <div className="pt-2 flex justify-between items-center text-xs">
                <span className="text-cyan-400">Extension Charge</span>
                <span className="font-bold text-cyan-400">
                  + {settings.currencySymbol} {extensionChargesTotal}
                </span>
              </div>
            )}

            <div className="pt-3 border-t border-slate-800/60 flex justify-between items-center text-xs">
              <span className="text-slate-300 font-semibold">Total Session Value</span>
              <span className="font-bold text-white">
                {settings.currencySymbol} {fullBill}
              </span>
            </div>

            {alreadyPaid > 0 && (
              <div className="pt-2 flex justify-between items-center text-xs">
                <span className="text-emerald-400 font-semibold">Total Already Paid</span>
                <span className="font-bold text-emerald-400">
                  - {settings.currencySymbol} {alreadyPaid}
                </span>
              </div>
            )}

            <div className="pt-2 border-t border-slate-800/60 flex justify-between items-center text-xs">
              <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px]">Amount Due</span>
              <span className="font-extrabold text-amber-300 text-sm">
                {settings.currencySymbol} {calculatedTotal}
              </span>
            </div>
          </div>

          {/* Adjustments: Discount & Extra Snacks/Beverages */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Discount ({settings.currencySymbol})
              </label>
              <input
                id="end-session-discount-input"
                type="number"
                min="0"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Extra / Snacks ({settings.currencySymbol})
              </label>
              <input
                id="end-session-extra-input"
                type="number"
                min="0"
                value={extraCharges}
                onChange={(e) => setExtraCharges(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-bold"
              />
            </div>
          </div>

          {/* Total Payable Display */}
          <div className="bg-gradient-to-r from-slate-950 to-slate-900 border border-cyan-500/30 rounded-xl p-4 flex items-center justify-between shadow-inner">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Total Payable Bill
              </p>
              <p className="text-xs text-slate-400 mt-0.5">Net amount due after adjustments</p>
            </div>
            <div className="text-2xl font-black text-emerald-400 tracking-tight">
              {settings.currencySymbol} {calculatedTotal.toLocaleString('en-IN')}
            </div>
          </div>

          {/* Single / Split Payment Section */}
          <PaymentInputSection
            totalBill={calculatedTotal}
            currencySymbol={settings.currencySymbol}
            onChange={handlePaymentChange}
            defaultMethod="upi"
          />

          {/* Optional Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Optional Transaction Notes
            </label>
            <input
              id="end-session-notes-input"
              type="text"
              placeholder="e.g. Paid ₹500 via GPay + ₹500 Cash"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-4 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl text-center cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="confirm-end-session-btn"
              type="submit"
              disabled={isSubmitting || paymentState.totalPaid > calculatedTotal}
              className="w-full sm:w-auto bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-bold px-5 py-2.5 rounded-xl text-sm shadow-md shadow-rose-600/20 transition-all disabled:opacity-40 cursor-pointer text-center"
            >
              {isSubmitting ? 'Finalizing...' : 'Collect & Complete Checkout'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
