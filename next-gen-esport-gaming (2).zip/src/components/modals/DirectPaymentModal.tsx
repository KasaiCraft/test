import React, { useState, useMemo } from 'react';
import { X, DollarSign } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { Customer } from '../../types';
import { SplitPaymentSection, SplitPaymentState } from '../common/SplitPaymentSection';

interface DirectPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DirectPaymentModal: React.FC<DirectPaymentModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { customers, recordPayment, settings } = useCafe();

  const uniqueCustomers = useMemo(() => {
    const seenIds = new Set<string>();
    const seenPhones = new Set<string>();
    const result: Customer[] = [];

    for (const c of customers) {
      if (!c || !c.id) continue;
      const cleanPhone = (c.phone || '').trim().replace(/[\s\-()]/g, '');
      if (seenIds.has(c.id)) continue;
      if (cleanPhone && seenPhones.has(cleanPhone)) continue;

      seenIds.add(c.id);
      if (cleanPhone) seenPhones.add(cleanPhone);
      result.push(c);
    }
    return result;
  }, [customers]);

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(
    uniqueCustomers.length > 0 ? uniqueCustomers[0].id : ''
  );
  const [customerName, setCustomerName] = useState<string>('');
  const [amount, setAmount] = useState<string>('100');
  const [referenceTitle, setReferenceTitle] = useState<string>('Counter Snacks & Beverages');
  const [paymentState, setPaymentState] = useState<SplitPaymentState>({
    isSplit: false,
    paymentMethod: 'upi',
    totalPaid: 100,
    remaining: 0,
    paymentStatus: 'paid',
  });
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen) return null;

  const parsedAmount = parseFloat(amount) || 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (parsedAmount <= 0) {
      setError('Please enter a valid bill amount.');
      return;
    }

    if (paymentState.totalPaid > parsedAmount) {
      setError(`Payment amount (₹${paymentState.totalPaid}) cannot exceed bill amount (₹${parsedAmount}).`);
      return;
    }

    let resolvedCustomerId = selectedCustomerId;
    let resolvedCustomerName = customerName;

    const matched = uniqueCustomers.find((c) => c.id === selectedCustomerId);
    if (matched) {
      resolvedCustomerName = matched.name;
    } else if (!customerName.trim()) {
      resolvedCustomerName = 'Walk-in Counter Guest';
    }

    setIsSubmitting(true);
    try {
      await recordPayment({
        type: 'direct_payment',
        customerId: resolvedCustomerId || 'counter-guest',
        customerName: resolvedCustomerName,
        referenceId: 'counter-bill',
        referenceTitle: referenceTitle.trim() || 'Counter Sales',
        amount: paymentState.totalPaid,
        method: paymentState.paymentMethod,
        status: paymentState.paymentStatus,
        splitDetails: paymentState.splitDetails,
        notes: notes.trim() || undefined,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to record payment');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <DollarSign className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-white">Record Counter Payment</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto custom-scrollbar">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Select Customer (or Walk-in)
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            >
              <option value="">Walk-in Counter Guest</option>
              {uniqueCustomers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Payment Reference / Item
            </label>
            <input
              type="text"
              placeholder="e.g. Red Bull + Energy Snacks"
              value={referenceTitle}
              onChange={(e) => setReferenceTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Bill Amount ({settings.currencySymbol})
            </label>
            <input
              type="number"
              min="1"
              placeholder="100"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-emerald-400 font-bold focus:outline-none focus:border-cyan-500"
              required
            />
          </div>

          <SplitPaymentSection
            totalBill={parsedAmount}
            currencySymbol={settings.currencySymbol}
            onChange={setPaymentState}
            defaultMethod="upi"
          />

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Notes (Optional)</label>
            <input
              type="text"
              placeholder="e.g. Paid at beverage cooler"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              id="confirm-direct-payment-submit"
              type="submit"
              disabled={isSubmitting || paymentState.totalPaid > parsedAmount}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs transition-all shadow-md shadow-emerald-500/20 disabled:opacity-40"
            >
              {isSubmitting ? 'Recording...' : 'Record Payment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
