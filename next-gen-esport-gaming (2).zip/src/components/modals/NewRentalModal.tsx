import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { X, Package, ShieldCheck, Tag, AlertCircle, CheckCircle2, User, FileText, MapPin, Monitor, Gamepad, Minus, Plus, Info } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { Customer, PaymentMethod, PaymentStatus, PaymentSplitItem } from '../../types';
import { PaymentInputSection, PaymentInputData } from '../common/PaymentInputSection';
import { RENTAL_PRICING, RentalDuration, DURATION_LABELS, DURATION_UNITS } from '../../config/rentalPricing';

interface ModalPaymentState {
  isSplit: boolean;
  paymentMethod: PaymentMethod;
  totalPaid: number;
  remaining: number;
  paymentStatus: PaymentStatus;
  splitDetails?: PaymentSplitItem[];
  isValid: boolean;
  errorMessage?: string | null;
}

interface NewRentalModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedItemId?: string;
  preselectedCustomer?: Customer;
}

const itemMatchesConsole = (item: { name: string; category?: string; description?: string }, console: 'PS4' | 'PS5'): boolean => {
  const cat = (item.category || '').trim();
  const catUpper = cat.toUpperCase();

  // Only items whose category is 'PS5', 'PS4', or 'Console' can match as a standard console unit
  if (catUpper !== 'PS5' && catUpper !== 'PS4' && catUpper !== 'CONSOLE') {
    return false;
  }

  const nameUpper = (item.name || '').toUpperCase();
  const descUpper = (item.description || '').toUpperCase();
  const combinedText = `${nameUpper} ${descUpper}`;

  const hasPS4 = combinedText.includes('PS4') || combinedText.includes('PLAYSTATION 4');
  const hasPS5 = combinedText.includes('PS5') || combinedText.includes('PLAYSTATION 5');

  if (catUpper === 'PS5') {
    if (console !== 'PS5') return false;
    // Name is ignored unless it clearly names the other console (PS4)
    if (hasPS4 && !hasPS5) return false;
    return true;
  }

  if (catUpper === 'PS4') {
    if (console !== 'PS4') return false;
    // Name is ignored unless it clearly names the other console (PS5)
    if (hasPS5 && !hasPS4) return false;
    return true;
  }

  if (catUpper === 'CONSOLE') {
    // If both or neither appear -> no match
    if ((hasPS4 && hasPS5) || (!hasPS4 && !hasPS5)) {
      return false;
    }

    // Exclude names containing words like controller, gamepad, dualshock, dualsense, game, disc, headset, charger
    const accessoryWords = [
      'CONTROLLER',
      'GAMEPAD',
      'DUALSHOCK',
      'DUALSENSE',
      'GAME',
      'DISC',
      'HEADSET',
      'CHARGER',
    ];
    if (accessoryWords.some((word) => combinedText.includes(word))) {
      return false;
    }

    if (console === 'PS4') {
      return hasPS4;
    } else {
      return hasPS5;
    }
  }

  return false;
};

export const NewRentalModal: React.FC<NewRentalModalProps> = ({
  isOpen,
  onClose,
  preselectedItemId,
  preselectedCustomer,
}) => {
  const { rentalItems, customers, addCustomer, createRental, settings } = useCafe();

  // Load existing customers with valid IDs, deduplicated by unique customer ID
  const existingCustomers = useMemo(() => {
    const seenIds = new Set<string>();
    const result: Customer[] = [];

    for (const c of (customers || [])) {
      if (!c) continue;
      const id = String(c.id || '').trim();
      if (!id || seenIds.has(id)) continue;

      seenIds.add(id);
      result.push({
        ...c,
        id,
      });
    }
    return result;
  }, [customers]);

  const inStockItems = useMemo(
    () => rentalItems.filter((i) => i.availableQuantity > 0),
    [rentalItems]
  );

  const [selectedItemId, setSelectedItemId] = useState<string>(
    preselectedItemId || (inStockItems.length > 0 ? inStockItems[0].id : (rentalItems[0]?.id || ''))
  );

  const [rentalType, setRentalType] = useState<'standard' | 'custom'>('custom');
  const [standardConsole, setStandardConsole] = useState<'PS4' | 'PS5'>('PS5');
  const [standardDuration, setStandardDuration] = useState<RentalDuration>('1day');
  const [extraControllers, setExtraControllers] = useState<number>(0);
  const [extraGames, setExtraGames] = useState<number>(0);
  const [standardDeposit, setStandardDeposit] = useState<number | string>(0);
  const [customStandardFee, setCustomStandardFee] = useState<number | string | null>(null);

  // Derive matching hardware item strictly for standard mode
  const standardHardwareItem = useMemo(() => {
    const matchingInStock = rentalItems.find(
      (item) => itemMatchesConsole(item, standardConsole) && item.availableQuantity > 0
    );
    if (matchingInStock) return matchingInStock;

    return rentalItems.find((item) => itemMatchesConsole(item, standardConsole));
  }, [rentalItems, standardConsole]);

  const isStandardOutOfStock = useMemo(() => {
    if (rentalItems.length === 0) return false;
    const matchingConsoleItems = rentalItems.filter((item) => itemMatchesConsole(item, standardConsole));
    if (matchingConsoleItems.length > 0) {
      return matchingConsoleItems.every((i) => i.availableQuantity <= 0);
    }
    return inStockItems.length === 0;
  }, [rentalItems, standardConsole, inStockItems]);

  const [quantity, setQuantity] = useState<number>(1);
  const [periodType, setPeriodType] = useState<'hourly' | 'daily'>('daily');
  const [durationUnits, setDurationUnits] = useState<number>(1);
  const [paymentState, setPaymentState] = useState<ModalPaymentState>({
    isSplit: false,
    paymentMethod: 'cash',
    totalPaid: 0,
    remaining: 0,
    paymentStatus: 'pending',
    isValid: true,
    errorMessage: null,
  });

  const [isNewCustomer, setIsNewCustomer] = useState<boolean>(!preselectedCustomer && existingCustomers.length === 0);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(
    preselectedCustomer ? String(preselectedCustomer.id).trim() : existingCustomers.length > 0 ? existingCustomers[0].id : ''
  );
  const [newCustomerName, setNewCustomerName] = useState<string>('');
  const [newCustomerPhone, setNewCustomerPhone] = useState<string>('');
  const [customerAadhaar, setCustomerAadhaar] = useState<string>('');
  const [aadhaarCollected, setAadhaarCollected] = useState<boolean>(false);
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Selected item fetched from saved Rental & Gear data
  const targetItem = rentalItems.find((i) => i.id === selectedItemId);

  // Dirty tracking & last synced customer ID refs to prevent background polling/syncs from wiping user inputs
  const aadhaarTouchedRef = useRef(false);
  const aadhaarCheckTouchedRef = useRef(false);
  const addressTouchedRef = useRef(false);
  const lastSyncedCustomerIdRef = useRef<string>('');
  const lastPreselectedIdRef = useRef<string>('');
  const createdCustomerRef = useRef<{ key: string; id: string; name: string; phone: string } | null>(null);

  const loadCustomerData = useCallback((cust: Customer | undefined) => {
    const custId = cust ? String(cust.id || '').trim() : '';
    lastSyncedCustomerIdRef.current = custId;
    aadhaarTouchedRef.current = false;
    aadhaarCheckTouchedRef.current = false;
    addressTouchedRef.current = false;
    if (cust) {
      setCustomerAadhaar(cust.aadhaarNumber || '');
      setAadhaarCollected(!!cust.aadhaarVerified);
      setCustomerAddress(cust.address || '');
    } else {
      setCustomerAadhaar('');
      setAadhaarCollected(false);
      setCustomerAddress('');
    }
  }, []);

  // Synchronize item and customer selection whenever modal opens
  const prevIsOpenRef = useRef(false);
  useEffect(() => {
    if (isOpen && !prevIsOpenRef.current) {
      // 1. Sync item selection
      if (preselectedItemId && rentalItems.some((i) => i.id === preselectedItemId)) {
        setSelectedItemId(preselectedItemId);
      } else if (!selectedItemId || !rentalItems.some((i) => i.id === selectedItemId)) {
        const firstAvailable = rentalItems.find((i) => i.availableQuantity > 0) || rentalItems[0];
        if (firstAvailable) {
          setSelectedItemId(firstAvailable.id);
        }
      }

      // 2. Sync customer selection on modal open
      if (preselectedCustomer && preselectedCustomer.id) {
        const pId = String(preselectedCustomer.id).trim();
        setSelectedCustomerId(pId);
        lastPreselectedIdRef.current = pId;
        setIsNewCustomer(false);
        loadCustomerData(preselectedCustomer);
      } else if (existingCustomers.length > 0) {
        const initialCust = existingCustomers[0];
        const initialId = initialCust.id;
        setSelectedCustomerId(initialId);
        lastPreselectedIdRef.current = '';
        setIsNewCustomer(false);
        loadCustomerData(initialCust);
      } else {
        setSelectedCustomerId('');
        lastPreselectedIdRef.current = '';
        setIsNewCustomer(true);
        loadCustomerData(undefined);
      }

      createdCustomerRef.current = null;
      setQuantity(1);
      setDurationUnits(1);
      setStandardDeposit(0);
      setExtraControllers(0);
      setExtraGames(0);
      setStandardDuration('1day');
      setStandardConsole('PS5');
      setCustomStandardFee(null);
      setNewCustomerName('');
      setNewCustomerPhone('');
      setNotes('');
      setError('');
      setIsSubmitting(false);
    }
    prevIsOpenRef.current = isOpen;
  }, [isOpen, preselectedItemId, preselectedCustomer, rentalItems, existingCustomers, selectedItemId, loadCustomerData]);

  // Synchronize customer ONLY when preselectedCustomer.id genuinely changes while modal is open
  useEffect(() => {
    if (isOpen && preselectedCustomer && preselectedCustomer.id) {
      const pId = String(preselectedCustomer.id).trim();
      if (pId && pId !== lastPreselectedIdRef.current) {
        lastPreselectedIdRef.current = pId;
        setSelectedCustomerId(pId);
        setIsNewCustomer(false);
        loadCustomerData(preselectedCustomer);
      }
    }
  }, [isOpen, preselectedCustomer?.id, loadCustomerData]);

  // Reset custom standard fee whenever console, duration, or extras change
  const prevStandardConfigRef = useRef(`${standardConsole}-${standardDuration}-${extraControllers}-${extraGames}`);
  useEffect(() => {
    const key = `${standardConsole}-${standardDuration}-${extraControllers}-${extraGames}`;
    if (prevStandardConfigRef.current !== key) {
      prevStandardConfigRef.current = key;
      setCustomStandardFee(null);
    }
  }, [standardConsole, standardDuration, extraControllers, extraGames]);

  // If modal is open in existing customer mode and selectedCustomerId is empty or not in existing list
  useEffect(() => {
    if (isOpen && !isNewCustomer && existingCustomers.length > 0) {
      setSelectedCustomerId((prev) => {
        const cleanPrev = String(prev || '').trim();
        if (cleanPrev && existingCustomers.some((c) => c.id === cleanPrev)) {
          return cleanPrev;
        }
        const fallbackId = existingCustomers[0].id;
        if (fallbackId !== lastSyncedCustomerIdRef.current) {
          const found = existingCustomers.find((c) => c.id === fallbackId);
          loadCustomerData(found);
        }
        return fallbackId;
      });
    }
  }, [isOpen, isNewCustomer, existingCustomers, loadCustomerData]);

  const handleToggleCustomerMode = () => {
    setIsNewCustomer((prev) => {
      const next = !prev;
      if (!next) {
        // Switched to existing customer mode
        let idToUse = '';
        setSelectedCustomerId((currentId) => {
          const clean = String(currentId || '').trim();
          idToUse = (clean && existingCustomers.some((c) => c.id === clean))
            ? clean
            : existingCustomers[0]?.id || '';
          return idToUse;
        });
        const found = existingCustomers.find((c) => c.id === (idToUse || existingCustomers[0]?.id));
        loadCustomerData(found);
      } else {
        // Switched to new customer mode
        loadCustomerData(undefined);
      }
      return next;
    });
    setError('');
  };

  const handlePaymentChange = useCallback((data: PaymentInputData) => {
    setPaymentState({
      isSplit: data.paymentMode === 'split',
      paymentMethod: data.paymentMethod,
      totalPaid: data.paidAmount,
      remaining: data.remaining,
      paymentStatus: data.paymentStatus,
      splitDetails: data.splitPayments,
      isValid: data.isValid,
      errorMessage: data.errorMessage,
    });
  }, []);

  // Fetch actual prices saved in Rental & Gear (no hardcoding)
  const savedDailyRate = targetItem?.dailyRate ?? 0;
  const savedHourlyRate = targetItem?.hourlyRate ?? 0;
  const savedDeposit = targetItem?.securityDeposit ?? 0;

  // Standard Rental calculation
  const standardPricing = RENTAL_PRICING[standardConsole];
  const baseStandardPrice = standardPricing.base[standardDuration];
  const extraControllerPrice = standardPricing.extraController[standardDuration] * extraControllers;
  const extraGamePrice = standardPricing.extraGame[standardDuration] * extraGames;
  const totalStandardFee = baseStandardPrice + extraControllerPrice + extraGamePrice;

  let effectiveStandardFee = totalStandardFee;
  if (customStandardFee !== null) {
    if (customStandardFee === '') {
      effectiveStandardFee = 0;
    } else {
      const parsed = Number(customStandardFee);
      effectiveStandardFee = isNaN(parsed) ? 0 : Math.max(0, parsed);
    }
  }

  // Active rate based on duration selection
  const activeRate = periodType === 'daily' ? savedDailyRate : savedHourlyRate;
  
  // Final fees based on rental type
  const rentalFee = rentalType === 'standard' ? effectiveStandardFee : (activeRate * durationUnits * quantity);
  const totalDeposit = rentalType === 'standard'
    ? (standardDeposit === '' ? 0 : Math.max(0, Number(standardDeposit) || 0))
    : (savedDeposit * quantity);
  const totalPayable = rentalFee + totalDeposit;

  // Validation logic scoped cleanly per rental mode
  const isCustomerValid = isNewCustomer
    ? Boolean(newCustomerName.trim() && newCustomerPhone.trim())
    : Boolean(selectedCustomerId);

  const isPaymentValid = paymentState.isValid && paymentState.totalPaid <= totalPayable;

  const isCustomRentalValid = Boolean(
    targetItem &&
    targetItem.availableQuantity > 0 &&
    inStockItems.length > 0 &&
    quantity >= 1 &&
    quantity <= targetItem.availableQuantity &&
    durationUnits >= 1
  );

  const isStandardFeeValid = customStandardFee === null || (
    customStandardFee !== '' &&
    !isNaN(Number(customStandardFee)) &&
    Number(customStandardFee) >= 0
  );

  const isStandardRentalValid = Boolean(
    standardConsole &&
    standardDuration &&
    isStandardFeeValid
  );

  const isSubmitDisabled =
    isSubmitting ||
    !isCustomerValid ||
    !isPaymentValid ||
    (rentalType === 'standard' ? !isStandardRentalValid : !isCustomRentalValid);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setError('');

    if (rentalType === 'custom') {
      if (!targetItem) {
        setError('Please select an equipment item.');
        return;
      }

      if (targetItem.availableQuantity <= 0) {
        setError(`${targetItem.name} is currently out of stock.`);
        return;
      }

      if (quantity > targetItem.availableQuantity) {
        setError(`Only ${targetItem.availableQuantity} units available in stock.`);
        return;
      }

      if (quantity < 1) {
        setError('Quantity must be at least 1.');
        return;
      }

      if (durationUnits < 1) {
        setError('Duration must be at least 1.');
        return;
      }
    } else {
      // Standard Rental:
      if (customStandardFee === '') {
        setError('Rental amount cannot be empty. Please enter a valid amount.');
        return;
      }
      if (customStandardFee !== null) {
        const feeNum = Number(customStandardFee);
        if (isNaN(feeNum) || feeNum < 0) {
          setError('Rental amount must be a number greater than or equal to 0.');
          return;
        }
      }

      // If actual inventory exists for this console, check if units are available
      if (rentalItems.length > 0) {
        const consoleItems = rentalItems.filter(item => itemMatchesConsole(item, standardConsole));
        if (consoleItems.length > 0 && consoleItems.every(i => i.availableQuantity <= 0)) {
          setError(`All ${standardConsole} hardware units are currently out of stock.`);
          return;
        }
        if (consoleItems.length === 0 && inStockItems.length === 0) {
          setError('All hardware units are currently out of stock.');
          return;
        }
      }
    }

    if (!paymentState.isValid) {
      setError(paymentState.errorMessage || 'Invalid payment amounts entered.');
      return;
    }

    if (paymentState.totalPaid > totalPayable) {
      setError(
        `Total payment (${settings.currencySymbol}${paymentState.totalPaid}) cannot exceed bill (${settings.currencySymbol}${totalPayable}).`
      );
      return;
    }

    let customerId = String(selectedCustomerId || '').trim();
    let customerName = '';
    let customerPhone = '';

    if (isNewCustomer) {
      if (!newCustomerName.trim() || !newCustomerPhone.trim()) {
        setError('Please provide customer name and phone number.');
        return;
      }
      const customerKey = `${newCustomerName.trim()}|${newCustomerPhone.trim()}`;
      if (createdCustomerRef.current && createdCustomerRef.current.key === customerKey) {
        customerId = createdCustomerRef.current.id;
        customerName = createdCustomerRef.current.name;
        customerPhone = createdCustomerRef.current.phone;
      } else {
        try {
          const created = await addCustomer({
            name: newCustomerName.trim(),
            phone: newCustomerPhone.trim(),
            aadhaarNumber: customerAadhaar.trim() || undefined,
            aadhaarVerified: aadhaarCollected,
            address: customerAddress.trim() || undefined,
          });
          customerId = String(created.id).trim();
          customerName = created.name;
          customerPhone = created.phone || '';
          createdCustomerRef.current = {
            key: customerKey,
            id: customerId,
            name: customerName,
            phone: customerPhone,
          };
        } catch (err: any) {
          setError(err?.message || 'Failed to create customer');
          return;
        }
      }
    } else {
      // Validate that a genuine customer ID was selected
      if (!customerId) {
        setError('Please select a valid customer.');
        return;
      }

      // Load against valid existing customer IDs
      const found =
        existingCustomers.find((c) => c.id === customerId) ||
        (customers || []).find((c) => String(c?.id || '').trim() === customerId);

      if (!found || !found.id) {
        setError('Please select a valid customer.');
        return;
      }
      customerId = String(found.id).trim();
      customerName = found.name;
      customerPhone = found.phone || '';
    }

    setIsSubmitting(true);
    try {
      const standardNotes = rentalType === 'standard' 
        ? `[Standard Rental] ${standardConsole} | ${DURATION_LABELS[standardDuration]} | Rental: ₹${rentalFee}${totalDeposit > 0 ? ` | Deposit: ₹${totalDeposit}` : ' | Deposit: ₹0'}${extraControllers > 0 ? ` | +${extraControllers} Ctrl` : ''}${extraGames > 0 ? ` | +${extraGames} Game` : ''}`
        : '';
      
      const finalNotes = notes.trim() 
        ? (standardNotes ? `${standardNotes}\nNotes: ${notes.trim()}` : notes.trim())
        : standardNotes;

      const res = await createRental({
        rentalItemId: rentalType === 'standard'
          ? (standardHardwareItem?.id || `std_${standardConsole.toLowerCase()}`)
          : (targetItem?.id || `std_${standardConsole.toLowerCase()}`),
        rentalItemName: rentalType === 'standard'
          ? (standardHardwareItem?.name || `${standardConsole} Standard Console Package`)
          : (targetItem?.name || `${standardConsole} Standard Console Package`),
        customerId,
        customerName,
        customerPhone,
        customerAadhaar: customerAadhaar.trim() || undefined,
        aadhaarCollected,
        customerAddress: customerAddress.trim() || undefined,
        quantity: rentalType === 'standard' ? 1 : quantity,
        periodType: rentalType === 'standard' ? 'daily' : periodType,
        durationUnits: rentalType === 'standard' ? DURATION_UNITS[standardDuration] : durationUnits,
        depositAmount: totalDeposit,
        paymentMethod: paymentState.paymentMethod,
        paidAmount: paymentState.totalPaid,
        splitPayments: paymentState.splitDetails,
        notes: finalNotes,
        totalFeeOverride: rentalType === 'standard' ? rentalFee : undefined,
        totalDepositOverride: rentalType === 'standard' ? totalDeposit : undefined,
        isStandardRental: rentalType === 'standard',
        standardConsole: rentalType === 'standard' ? standardConsole : undefined,
      });

      if (res.success) {
        onClose();
      } else {
        setError(res.error || 'Failed to create rental booking');
      }
    } catch (err: any) {
      setError(err?.message || 'Error processing rental booking');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">New Hardware Rental Booking</h3>
              <p className="text-xs text-slate-400">
                Live equipment pricing, duration calculation & payment collection
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar">
          {/* Rental Type Toggle */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Rental Mode
            </label>
            <div className="grid grid-cols-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setRentalType('standard')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  rentalType === 'standard'
                    ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Standard Rental</span>
              </button>
              <button
                type="button"
                onClick={() => setRentalType('custom')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  rentalType === 'custom'
                    ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Tag className="w-3.5 h-3.5" />
                <span>Custom Rental</span>
              </button>
            </div>
          </div>

          {/* Out of Stock & Inventory Status Banner */}
          {rentalType === 'standard' ? (
            <>
              {isStandardOutOfStock && (
                <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-start gap-3 text-rose-300">
                  <AlertCircle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold">All {standardConsole} Hardware Out of Stock</p>
                    <p className="text-xs opacity-80 mt-1">
                      All {standardConsole} hardware units in your inventory are currently rented out or have 0 stock. Please settle returns first.
                    </p>
                  </div>
                </div>
              )}
              {rentalItems.length === 0 && (
                <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl flex items-start gap-2.5 text-slate-400 text-xs">
                  <Info className="w-4 h-4 shrink-0 text-cyan-400 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-300">Standard Rental Package</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      No custom gear items added in inventory yet. You can proceed with standard console package booking.
                    </p>
                  </div>
                </div>
              )}
            </>
          ) : (
            inStockItems.length === 0 && (
              <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-start gap-3 text-rose-300">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
                <div>
                  <p className="text-sm font-bold">All Hardware Out of Stock</p>
                  <p className="text-xs opacity-80 mt-1">
                    You cannot create new bookings because every item in your Gear Inventory is currently rented out or has 0 stock. Please settle returns first.
                  </p>
                </div>
              </div>
            )
          )}

          {error && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. Item Selector - Only shown for Custom Rental */}
          {rentalType === 'custom' && (
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                1. Select Rental Item
              </label>
              {rentalItems.length > 0 ? (
                <select
                  id="rental-item-select"
                  value={selectedItemId}
                  onChange={(e) => {
                    setSelectedItemId(e.target.value);
                    setQuantity(1);
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500 font-medium"
                  required={rentalType === 'custom'}
                >
                  {rentalItems.map((item) => (
                    <option
                      key={item.id}
                      value={item.id}
                      disabled={item.availableQuantity <= 0}
                    >
                      {item.name} {item.availableQuantity > 0 ? `(${item.availableQuantity} in stock)` : '(Out of Stock)'} — ₹{item.dailyRate}/day • ₹{item.hourlyRate}/hr
                    </option>
                  ))}
                </select>
              ) : (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-xs">
                  No rental gear configured in inventory. Add items in Rental & Gear view first.
                </div>
              )}
            </div>
          )}

          {/* Dedicated Saved Price & Gear Details Box - Only shown for Custom Rental */}
          {rentalType === 'custom' && targetItem && (
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">{targetItem.name}</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                    {targetItem.category}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400">
                  Stock: <strong className="text-emerald-400 font-mono">{targetItem.availableQuantity}</strong> of {targetItem.totalQuantity} available
                </div>
              </div>

              {/* Saved Prices from Rental & Gear */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                {/* Saved Daily Rate */}
                <div
                  className={`p-2 rounded-lg border text-center transition-all ${
                    periodType === 'daily'
                      ? 'bg-amber-500/15 border-amber-500/50 shadow-sm shadow-amber-500/10'
                      : 'bg-slate-900 border-slate-800 opacity-70'
                  }`}
                >
                  <p className="text-[10px] uppercase font-bold text-slate-400">Daily Rate</p>
                  <p className="text-xs sm:text-sm font-extrabold text-amber-300 font-mono mt-0.5">
                    {settings.currencySymbol} {savedDailyRate}
                    <span className="text-[10px] font-normal text-slate-400"> /day</span>
                  </p>
                  {periodType === 'daily' && (
                    <span className="text-[9px] font-bold text-amber-400 uppercase tracking-wider block mt-0.5">
                      ● Active Rate
                    </span>
                  )}
                </div>

                {/* Saved Hourly Rate */}
                <div
                  className={`p-2 rounded-lg border text-center transition-all ${
                    periodType === 'hourly'
                      ? 'bg-cyan-500/15 border-cyan-500/50 shadow-sm shadow-cyan-500/10'
                      : 'bg-slate-900 border-slate-800 opacity-70'
                  }`}
                >
                  <p className="text-[10px] uppercase font-bold text-slate-400">Hourly Rate</p>
                  <p className="text-xs sm:text-sm font-extrabold text-cyan-300 font-mono mt-0.5">
                    {settings.currencySymbol} {savedHourlyRate}
                    <span className="text-[10px] font-normal text-slate-400"> /hr</span>
                  </p>
                  {periodType === 'hourly' && (
                    <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-wider block mt-0.5">
                      ● Active Rate
                    </span>
                  )}
                </div>

                {/* Saved Security Deposit */}
                <div className="p-2 rounded-lg border border-slate-800 bg-slate-900 text-center">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Security Deposit</p>
                  <p className="text-xs sm:text-sm font-extrabold text-emerald-300 font-mono mt-0.5">
                    {settings.currencySymbol} {savedDeposit}
                    <span className="text-[10px] font-normal text-slate-400"> /unit</span>
                  </p>
                  <span className="text-[9px] text-emerald-400/80 block mt-0.5">
                    Refundable
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 2. Standard vs Custom Configuration */}
          {rentalType === 'standard' ? (
            <div className="space-y-4">
              {/* Console Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  2. Select Console
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {(['PS4', 'PS5'] as const).map((console) => (
                    <button
                      key={console}
                      type="button"
                      onClick={() => {
                        setStandardConsole(console);
                        setCustomStandardFee(null);
                      }}
                      className={`py-2.5 px-4 rounded-xl border font-bold text-sm transition-all cursor-pointer ${
                        standardConsole === console
                          ? 'bg-blue-500/20 border-blue-500 text-blue-300 shadow-sm shadow-blue-500/10'
                          : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {console}
                    </button>
                  ))}
                </div>
              </div>

              {/* Package Details (Fixed for Standard) */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  3. Select Package & Extras
                </label>
                <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                        <Package className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white">{standardConsole} Base Package</p>
                        <p className="text-[10px] text-slate-400">Includes console, 2 controllers, 1 game</p>
                      </div>
                    </div>
                    <div className="text-xs font-bold text-white font-mono">
                      {settings.currencySymbol} {baseStandardPrice}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-800/60 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                          <Gamepad className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">Extra Controllers</p>
                          <p className="text-[10px] text-slate-400">Add more for multiplayer</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-xs font-bold text-blue-400 font-mono mr-2">
                          + {settings.currencySymbol} {extraControllerPrice}
                        </div>
                        <div className="flex items-center bg-slate-900 rounded-lg border border-slate-700 p-0.5">
                          <button
                            type="button"
                            onClick={() => {
                              setExtraControllers(Math.max(0, extraControllers - 1));
                              setCustomStandardFee(null);
                            }}
                            className="p-1 text-slate-400 hover:text-white cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-xs font-bold text-white">{extraControllers}</span>
                          <button
                            type="button"
                            onClick={() => {
                              setExtraControllers(extraControllers + 1);
                              setCustomStandardFee(null);
                            }}
                            className="p-1 text-slate-400 hover:text-white cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
                          <Monitor className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">Extra Games</p>
                          <p className="text-[10px] text-slate-400">Add specific titles</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-xs font-bold text-purple-400 font-mono mr-2">
                          + {settings.currencySymbol} {extraGamePrice}
                        </div>
                        <div className="flex items-center bg-slate-900 rounded-lg border border-slate-700 p-0.5">
                          <button
                            type="button"
                            onClick={() => {
                              setExtraGames(Math.max(0, extraGames - 1));
                              setCustomStandardFee(null);
                            }}
                            className="p-1 text-slate-400 hover:text-white cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-xs font-bold text-white">{extraGames}</span>
                          <button
                            type="button"
                            onClick={() => {
                              setExtraGames(extraGames + 1);
                              setCustomStandardFee(null);
                            }}
                            className="p-1 text-slate-400 hover:text-white cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Duration Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  4. Select Duration
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(Object.keys(DURATION_LABELS) as RentalDuration[]).map((dur) => (
                    <button
                      key={dur}
                      type="button"
                      onClick={() => {
                        setStandardDuration(dur);
                        setCustomStandardFee(null);
                      }}
                      className={`py-2 px-1 rounded-xl border font-bold text-[10px] sm:text-xs transition-all cursor-pointer ${
                        standardDuration === dur
                          ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/20'
                          : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {DURATION_LABELS[dur]}
                    </button>
                  ))}
                </div>
              </div>

              {/* 5. Optional Security Deposit for Standard Rental */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                    5. Security Deposit (Optional)
                  </label>
                  <span className="text-[11px] text-slate-400">
                    Default: {settings.currencySymbol}0 • Refundable on return
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400 font-mono">
                    {settings.currencySymbol}
                  </span>
                  <input
                    id="standard-security-deposit-input"
                    type="number"
                    min="0"
                    placeholder="0"
                    value={standardDeposit}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '') {
                        setStandardDeposit('');
                      } else {
                        const num = parseInt(val, 10);
                        setStandardDeposit(isNaN(num) ? 0 : Math.max(0, num));
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-4 py-2.5 text-sm font-bold text-white focus:outline-none focus:border-cyan-500 font-mono placeholder:text-slate-600"
                  />
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase">Presets:</span>
                  {[0, 500, 1000, 2000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setStandardDeposit(amt)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                        Number(standardDeposit) === amt && standardDeposit !== ''
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {settings.currencySymbol}{amt}
                    </button>
                  ))}
                  {standardDeposit !== '' && Number(standardDeposit) > 0 && (
                    <button
                      type="button"
                      onClick={() => setStandardDeposit(0)}
                      className="text-[10px] text-rose-400 hover:underline ml-auto cursor-pointer"
                    >
                      Reset to ₹0
                    </button>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 mt-1.5">
                  Security deposit is tracked separately from rental charges and will be refunded upon equipment return.
                </p>
              </div>
            </div>
          ) : (
            <>
              {/* Existing Custom Duration & Quantity Configuration */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  2. Quantity & Rental Duration
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">
                      Quantity (Max {targetItem?.availableQuantity || 1})
                    </label>
                    <input
                      type="number"
                      min="1"
                      max={targetItem?.availableQuantity || 1}
                      value={quantity}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        setQuantity(isNaN(val) ? 1 : Math.max(1, Math.min(val, targetItem?.availableQuantity || 99)));
                      }}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-cyan-500 font-mono"
                      required={rentalType === 'custom'}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">
                      Duration Type
                    </label>
                    <select
                      value={periodType}
                      onChange={(e) => setPeriodType(e.target.value as 'hourly' | 'daily')}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="daily">Daily (Per Day)</option>
                      <option value="hourly">Hourly (Per Hour)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">
                      {periodType === 'daily' ? 'No. of Days' : 'No. of Hours'}
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={durationUnits}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        setDurationUnits(isNaN(val) ? 1 : Math.max(1, val));
                      }}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-cyan-500 font-mono"
                      required={rentalType === 'custom'}
                    />
                  </div>
                </div>
              </div>
            </>
          )}

          {/* 3. Dynamic Calculation Breakdown Box */}
          <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3.5 space-y-2.5 text-xs">
            {rentalType === 'standard' ? (
              <div className="space-y-1.5 pb-1">
                <div className="flex items-center justify-between text-slate-300 flex-wrap gap-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Tag className="w-3.5 h-3.5 text-amber-400" />
                    <span className="font-semibold text-slate-200">
                      Rental Amount ({standardConsole} {DURATION_LABELS[standardDuration]} Package{extraControllers > 0 ? ` + ${extraControllers} Ctrl` : ''}{extraGames > 0 ? ` + ${extraGames} Game` : ''}):
                    </span>
                    {customStandardFee !== null && Number(customStandardFee) !== totalStandardFee && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Custom
                      </span>
                    )}
                  </div>
                  {customStandardFee !== null && Number(customStandardFee) !== totalStandardFee && (
                    <button
                      type="button"
                      onClick={() => setCustomStandardFee(null)}
                      className="text-[11px] text-cyan-400 hover:underline cursor-pointer font-medium"
                    >
                      Reset to default ({settings.currencySymbol}{totalStandardFee})
                    </button>
                  )}
                </div>

                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400 font-mono">
                    {settings.currencySymbol}
                  </span>
                  <input
                    id="standard-rental-amount-input"
                    type="number"
                    min="0"
                    placeholder={String(totalStandardFee)}
                    value={customStandardFee !== null ? customStandardFee : totalStandardFee}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '') {
                        setCustomStandardFee('');
                      } else {
                        const num = parseInt(val, 10);
                        setCustomStandardFee(isNaN(num) ? 0 : Math.max(0, num));
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-4 py-2 text-sm font-bold text-white focus:outline-none focus:border-amber-500 font-mono placeholder:text-slate-600"
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 px-0.5">
                  <span>Default package price: {settings.currencySymbol}{totalStandardFee}</span>
                  {customStandardFee === '' && (
                    <span className="text-rose-400 font-semibold">Amount is required (≥ 0)</span>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  <span>
                    Rental Fee ({quantity} unit{quantity > 1 ? 's' : ''} × {durationUnits} {periodType === 'daily' ? (durationUnits === 1 ? 'day' : 'days') : (durationUnits === 1 ? 'hour' : 'hours')} @ {settings.currencySymbol}{activeRate}/{periodType === 'daily' ? 'day' : 'hr'}):
                  </span>
                </span>
                <span className="font-bold text-white font-mono text-sm">
                  {settings.currencySymbol} {rentalFee}
                </span>
              </div>
            )}

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  {rentalType === 'standard' ? (
                    `Security Deposit (${totalDeposit > 0 ? 'Refundable' : 'Optional / None'}):`
                  ) : (
                    `Refundable Security Deposit (${quantity} unit{quantity > 1 ? 's' : ''} × ${settings.currencySymbol}{savedDeposit}):`
                  )}
                </span>
              </span>
              <span className="font-bold text-emerald-400 font-mono text-sm">
                {settings.currencySymbol} {totalDeposit}
              </span>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm font-bold">
              <div>
                <span className="text-white uppercase text-xs tracking-wider">Total Payable:</span>
                <p className="text-[10px] text-slate-400 font-normal">
                  Rental amount {totalDeposit > 0 ? `+ security deposit (${settings.currencySymbol}${totalDeposit})` : ''}
                </p>
              </div>
              <span className="text-emerald-400 text-xl font-black font-mono">
                {settings.currencySymbol} {totalPayable}
              </span>
            </div>
          </div>

          {/* 4. Payment Input Section (Single & Split) */}
          <PaymentInputSection
            totalBill={totalPayable}
            currencySymbol={settings.currencySymbol}
            onChange={handlePaymentChange}
            defaultMethod="cash"
            initialPaidAmount={0}
          />

          {/* 5. Customer Selection */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Customer Information
              </label>
              <button
                type="button"
                onClick={handleToggleCustomerMode}
                className="text-xs text-cyan-400 hover:underline font-semibold cursor-pointer"
              >
                {isNewCustomer ? 'Select Existing Player' : '+ New Customer'}
              </button>
            </div>

            {isNewCustomer ? (
              <div className="grid grid-cols-2 gap-3 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Customer Full Name</label>
                  <input
                    id="rental-new-customer-name"
                    type="text"
                    placeholder="e.g. Rohan Verma"
                    value={newCustomerName}
                    onChange={(e) => setNewCustomerName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    required={isNewCustomer}
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Mobile Phone</label>
                  <input
                    id="rental-new-customer-phone"
                    type="tel"
                    placeholder="e.g. 9876543210"
                    value={newCustomerPhone}
                    onChange={(e) => setNewCustomerPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    required={isNewCustomer}
                  />
                </div>
              </div>
            ) : (
              <select
                id="rental-customer-select"
                value={selectedCustomerId}
                onChange={(e) => {
                  const newId = e.target.value;
                  setSelectedCustomerId(newId);
                  if (error) setError('');
                  const found = existingCustomers.find((c) => c.id === newId);
                  loadCustomerData(found);
                }}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                required={!isNewCustomer}
              >
                {existingCustomers.length === 0 ? (
                  <option value="">No existing customers found</option>
                ) : (
                  <>
                    {!selectedCustomerId && (
                      <option value="" disabled>
                        -- Select Existing Customer --
                      </option>
                    )}
                    {existingCustomers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone || 'No phone'}){c.membershipId ? ` • ${c.membershipId}` : ''}
                      </option>
                    ))}
                  </>
                )}
              </select>
            )}

            {/* Aadhaar ID & Address Proof Filing */}
            <div className="bg-slate-950/80 border border-cyan-500/30 rounded-xl p-3.5 space-y-3">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800/80">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Aadhaar ID & Address Proof Filing
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-medium">
                  Worker Verification Checklist
                </span>
              </div>

              {/* Aadhaar Checkbox & ID Field */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Aadhaar Proof Checkbox / Status */}
                <div
                  id="rental-aadhaar-collected-container"
                  onClick={() => {
                    aadhaarCheckTouchedRef.current = true;
                    setAadhaarCollected((prev) => !prev);
                  }}
                  className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer select-none transition-all ${
                    aadhaarCollected
                      ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 shadow-sm shadow-emerald-500/10'
                      : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <input
                    id="rental-aadhaar-collected"
                    type="checkbox"
                    checked={aadhaarCollected}
                    onChange={(e) => {
                      aadhaarCheckTouchedRef.current = true;
                      setAadhaarCollected(e.target.checked);
                    }}
                    onClick={(e) => e.stopPropagation()}
                    className="mt-0.5 h-4 w-4 rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-emerald-400 cursor-pointer"
                  />
                  <div className="text-xs">
                    <span className="font-semibold block">
                      Aadhaar Card Received / Verified
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {aadhaarCollected ? '✓ Physical / Original ID verified' : 'Tick when Aadhaar is submitted / checked'}
                    </span>
                  </div>
                </div>

                {/* Aadhaar Number Input */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1 flex items-center gap-1">
                    <FileText className="w-3 h-3 text-cyan-400" />
                    <span>Aadhaar / Gov ID Number</span>
                  </label>
                  <input
                    id="rental-customer-aadhaar"
                    type="text"
                    placeholder="e.g. 1234 5678 9012"
                    value={customerAadhaar}
                    onChange={(e) => {
                      aadhaarTouchedRef.current = true;
                      setCustomerAadhaar(e.target.value);
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              {/* Address Blank Space (Customer Address Filing) */}
              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-amber-400" />
                    <span>Customer Address Proof (Blank Space for Address Entry)</span>
                  </span>
                  <span className="text-[10px] text-slate-400">Worker Address Note</span>
                </label>
                <textarea
                  id="rental-customer-address"
                  rows={2}
                  placeholder="Enter customer's complete residential address, flat/house no., street, area, city, pincode..."
                  value={customerAddress}
                  onChange={(e) => {
                    addressTouchedRef.current = true;
                    setCustomerAddress(e.target.value);
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 custom-scrollbar resize-none"
                />
              </div>
            </div>
          </div>

          {/* 6. Optional Rental Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Booking Notes (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Extra cable provided, serial #XYZ, deposit split notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer transition-colors"
            >
              Cancel
            </button>
            <button
              id="confirm-rental-btn"
              type="submit"
              disabled={isSubmitDisabled}
              className="bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm shadow-md shadow-amber-500/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                'Processing Booking...'
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Confirm Booking (
                    {paymentState.totalPaid >= totalPayable
                      ? `Collect ${settings.currencySymbol}${paymentState.totalPaid}`
                      : paymentState.totalPaid > 0
                      ? `Collect ${settings.currencySymbol}${paymentState.totalPaid} • Due ${settings.currencySymbol}${paymentState.remaining}`
                      : `Pay Later • Due ${settings.currencySymbol}${totalPayable}`}
                    )
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
