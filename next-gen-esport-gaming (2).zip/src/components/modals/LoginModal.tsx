import React, { useState } from 'react';
import { X, Lock, Key, ShieldCheck, User, CheckCircle2, AlertCircle } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const { workers, currentUser, authTenantRole, loginWithPin, switchUserRole } = useCafe();

  const [selectedWorkerId, setSelectedWorkerId] = useState(currentUser?.id || (workers[0]?.id ?? ''));
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!pin.trim()) {
      setError('Please enter your 4-digit terminal PIN.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await loginWithPin(pin.trim(), selectedWorkerId);
      if (res.success) {
        onClose();
      } else {
        setError(res.error || 'Incorrect PIN');
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickSwitch = (role: 'admin' | 'worker') => {
    switchUserRole(role);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Terminal Authorization</h3>
              <p className="text-xs text-slate-400">Switch user profile or enter security PIN</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Role Switch for Admin only */}
        {authTenantRole === 'admin' && (
          <div className="p-5 border-b border-slate-800 bg-slate-950/60">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Preview View (Admin Only)
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="switch-to-admin-btn"
                type="button"
                onClick={() => handleQuickSwitch('admin')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-bold transition-all ${
                  currentUser?.role === 'admin'
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                <span>Administrator</span>
              </button>

              <button
                id="switch-to-worker-btn"
                type="button"
                onClick={() => handleQuickSwitch('worker')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-bold transition-all ${
                  currentUser?.role === 'worker'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <User className="w-4 h-4 text-emerald-400" />
                <span>Counter Worker</span>
              </button>
            </div>
          </div>
        )}

        {/* PIN verification Form */}
        <form onSubmit={handlePinSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Select Staff Member
            </label>
            <select
              value={selectedWorkerId}
              onChange={(e) => setSelectedWorkerId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            >
              {workers.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} ({w.role.toUpperCase()})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Terminal Security PIN
            </label>
            <input
              id="terminal-pin-input"
              type="password"
              maxLength={8}
              placeholder="Enter Security Code / PIN"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-center text-lg tracking-widest text-white font-mono focus:outline-none focus:border-cyan-500"
            />
            <p className="text-[10px] text-slate-500 text-center mt-1">
              Enter your assigned role access code or terminal PIN
            </p>
          </div>

          <button
            id="login-pin-submit"
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs transition-all shadow-md shadow-cyan-500/20"
          >
            {isSubmitting ? 'Authenticating...' : 'Unlock Terminal'}
          </button>
        </form>
      </div>
    </div>
  );
};
