import React, { useState } from 'react';
import { X, UserCheck, Key, AlertCircle, Eye, EyeOff, Lock, Phone, Mail, ShieldCheck } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { UserAccount, UserRole } from '../../types';

interface WorkerModalProps {
  isOpen: boolean;
  onClose: () => void;
  workerToEdit?: UserAccount | null;
}

export const WorkerModal: React.FC<WorkerModalProps> = ({
  isOpen,
  onClose,
  workerToEdit,
}) => {
  const { workers, addWorker, updateWorker } = useCafe();

  const [name, setName] = useState(workerToEdit?.name || '');
  const [staffCode, setStaffCode] = useState(workerToEdit?.accessCode || workerToEdit?.pin || '');
  const [showCode, setShowCode] = useState(false);
  const [phone, setPhone] = useState(workerToEdit?.phone || '');
  const [email, setEmail] = useState(workerToEdit?.email || '');
  const [password, setPassword] = useState(workerToEdit?.password || '');
  const [showPassword, setShowPassword] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [role, setRole] = useState<UserRole>(workerToEdit?.role || 'worker');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanName = name.trim();
    if (!cleanName) {
      setError('Staff Name is required (e.g. Rahul).');
      return;
    }

    const cleanCode = staffCode.trim();
    if (!cleanCode) {
      setError('Staff Access Code is required (e.g. 458921).');
      return;
    }

    if (cleanCode.length < 3) {
      setError('Staff Access Code must be at least 3 characters.');
      return;
    }

    // Strict validation: Admin code 756569 cannot be used as staff code
    if (cleanCode === '756569') {
      setError('Cannot use Administrator Security Code (756569) as a Staff Code. Please choose a different code.');
      return;
    }

    // Check duplicate code with existing workers
    const otherWorkers = workers.filter((w) => w.id !== workerToEdit?.id && w.role === 'worker');
    const duplicate = otherWorkers.find((w) => {
      const existing = (w.accessCode || w.pin || '').trim();
      return existing === cleanCode;
    });

    if (duplicate) {
      setError(`Staff Code "${cleanCode}" is already assigned to ${duplicate.name}. Each staff member must have a unique code.`);
      return;
    }

    // Auto-generate clean email if omitted
    const defaultEmailSlug = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'staff';
    const cleanEmail = email.trim()
      ? email.trim().toLowerCase()
      : (workerToEdit?.email || `${defaultEmailSlug}@nextgencafe.com`);

    // Auto-generate password if omitted
    const cleanPassword = password.trim()
      ? password.trim()
      : (workerToEdit?.password || `Staff#${cleanCode}`);

    setIsSubmitting(true);
    try {
      if (workerToEdit) {
        await updateWorker(workerToEdit.id, {
          name: cleanName,
          email: cleanEmail,
          password: cleanPassword,
          phone: phone.trim() || undefined,
          pin: cleanCode,
          accessCode: cleanCode,
          role,
        });
      } else {
        await addWorker({
          name: cleanName,
          email: cleanEmail,
          password: cleanPassword,
          phone: phone.trim() || undefined,
          pin: cleanCode,
          accessCode: cleanCode,
          status: 'active',
        });
      }
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save staff account');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {workerToEdit ? `Edit Staff: ${workerToEdit.name}` : 'Add New Staff Member'}
              </h3>
              <p className="text-[11px] text-slate-400">Configure staff account & assigned access code</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Staff Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Staff Name <span className="text-cyan-400">*</span>
            </label>
            <input
              id="worker-modal-name"
              type="text"
              placeholder="e.g. Rahul"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500"
              required
              autoFocus
            />
          </div>

          {/* Staff Access Code (Primary code used on login screen) */}
          <div className="bg-slate-950/70 border border-cyan-500/30 rounded-xl p-3.5">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-cyan-400" />
                Staff Access Code <span className="text-cyan-400">*</span>
              </label>
              <span className="text-[10px] text-slate-400 font-mono">For Staff Login</span>
            </div>
            <div className="relative">
              <input
                id="worker-modal-staff-code"
                type={showCode ? 'text' : 'password'}
                placeholder="e.g. 458921"
                value={staffCode}
                onChange={(e) => setStaffCode(e.target.value)}
                maxLength={12}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-3.5 pr-10 py-2.5 text-sm text-white font-mono tracking-wider focus:outline-none focus:border-cyan-400"
                required
              />
              <button
                type="button"
                onClick={() => setShowCode(!showCode)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                tabIndex={-1}
              >
                {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
              Staff will use this code to log in to the Staff Terminal. (Example: <strong>458921</strong>)
            </p>
          </div>

          {/* Contact Phone */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              Contact Phone <span className="text-slate-500 font-normal">(Optional)</span>
            </label>
            <input
              id="worker-modal-phone"
              type="tel"
              placeholder="e.g. 9876543210"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          {/* Advanced / Optional Credentials Toggle */}
          <div className="pt-1">
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>{showAdvanced ? '− Hide' : '+ Show'} Advanced Account Credentials (Email & Password)</span>
            </button>

            {showAdvanced && (
              <div className="mt-3 space-y-3 p-3 bg-slate-950/50 border border-slate-800 rounded-xl">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    Custom Email Address
                  </label>
                  <input
                    id="worker-modal-email"
                    type="email"
                    placeholder={`e.g. ${name ? name.toLowerCase().replace(/[^a-z0-9]/g, '') : 'staff'}@nextgencafe.com`}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    Leave blank to auto-generate based on staff name.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    Custom Password
                  </label>
                  <div className="relative">
                    <input
                      id="worker-modal-password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder={workerToEdit ? '•••••••• (unchanged)' : 'Auto-generated from staff code if blank'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-3 pr-9 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="worker-modal-submit"
              type="submit"
              disabled={isSubmitting}
              className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : workerToEdit ? 'Update Staff Code & Details' : 'Save Staff & Access Code'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
