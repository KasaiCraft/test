import React, { useState, useEffect } from 'react';
import { X, Package, AlertCircle } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { RentalItem, RentalCategory } from '../../types';

interface RentalItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemToEdit?: RentalItem | null;
}

export const RentalItemModal: React.FC<RentalItemModalProps> = ({
  isOpen,
  onClose,
  itemToEdit,
}) => {
  const { addRentalItem, updateRentalItem, settings } = useCafe();

  const [name, setName] = useState('');
  const [category, setCategory] = useState<RentalCategory>('Controller');
  const [totalQuantity, setTotalQuantity] = useState('4');
  const [hourlyRate, setHourlyRate] = useState('40');
  const [dailyRate, setDailyRate] = useState('200');
  const [securityDeposit, setSecurityDeposit] = useState('500');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync state whenever modal opens or itemToEdit changes
  useEffect(() => {
    if (isOpen) {
      if (itemToEdit) {
        setName(itemToEdit.name || '');
        setCategory(itemToEdit.category || 'Controller');
        setTotalQuantity(itemToEdit.totalQuantity !== undefined ? itemToEdit.totalQuantity.toString() : '1');
        setHourlyRate(itemToEdit.hourlyRate !== undefined ? itemToEdit.hourlyRate.toString() : '0');
        setDailyRate(itemToEdit.dailyRate !== undefined ? itemToEdit.dailyRate.toString() : '0');
        setSecurityDeposit(itemToEdit.securityDeposit !== undefined ? itemToEdit.securityDeposit.toString() : '0');
        setDescription(itemToEdit.description || '');
      } else {
        setName('');
        setCategory('Controller');
        setTotalQuantity('4');
        setHourlyRate('40');
        setDailyRate('200');
        setSecurityDeposit('500');
        setDescription('');
      }
      setError('');
      setIsSubmitting(false);
    }
  }, [isOpen, itemToEdit]);

  if (!isOpen) return null;

  const categories: RentalCategory[] = [
    'Controller',
    'VR Headset',
    'Headphones',
    'Racing Wheel',
    'Accessory',
    'Console',
    'Game Disc',
    'Other',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError('Equipment name is required (e.g. DualSense Wireless Controller).');
      return;
    }

    const totalQty = parseInt(totalQuantity, 10);
    const hourly = parseFloat(hourlyRate);
    const daily = parseFloat(dailyRate);
    const deposit = parseFloat(securityDeposit);

    if (isNaN(totalQty) || totalQty < 1) {
      setError('Total stock quantity must be at least 1.');
      return;
    }

    if (isNaN(hourly) || hourly < 0) {
      setError('Hourly rate must be a non-negative number.');
      return;
    }

    if (isNaN(daily) || daily < 0) {
      setError('Daily rate must be a non-negative number.');
      return;
    }

    if (isNaN(deposit) || deposit < 0) {
      setError('Security deposit must be a non-negative number.');
      return;
    }

    if (itemToEdit && totalQty < (itemToEdit.rentedQuantity || 0)) {
      setError(`Cannot reduce total quantity to ${totalQty} because ${itemToEdit.rentedQuantity} units are currently rented out.`);
      return;
    }

    setIsSubmitting(true);
    try {
      if (itemToEdit) {
        await updateRentalItem(itemToEdit.id, {
          name: trimmedName,
          category,
          totalQuantity: totalQty,
          hourlyRate: hourly,
          dailyRate: daily,
          securityDeposit: deposit,
          description: description.trim() || undefined,
        });
      } else {
        await addRentalItem({
          name: trimmedName,
          category,
          totalQuantity: totalQty,
          hourlyRate: hourly,
          dailyRate: daily,
          securityDeposit: deposit,
          description: description.trim() || undefined,
          status: 'available',
        });
      }
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save rental equipment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="rental-item-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in"
    >
      <div
        id="rental-item-modal-card"
        className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Package className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-white">
              {itemToEdit ? `Edit Gear: ${itemToEdit.name}` : 'Add New Rental Equipment'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto custom-scrollbar">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Equipment Name <span className="text-amber-400">*</span>
            </label>
            <input
              id="rental-modal-name"
              type="text"
              placeholder="e.g. DualSense Wireless Controller (Midnight Black)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Category</label>
              <select
                id="rental-modal-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as RentalCategory)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Total Stock Qty <span className="text-amber-400">*</span>
              </label>
              <input
                id="rental-modal-qty"
                type="number"
                min="1"
                value={totalQuantity}
                onChange={(e) => setTotalQuantity(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono font-bold"
                required
              />
              {itemToEdit && itemToEdit.rentedQuantity > 0 && (
                <p className="text-[10px] text-amber-400 mt-1">
                  Currently rented out: {itemToEdit.rentedQuantity} units
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div>
              <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                Hourly ({settings.currencySymbol})
              </label>
              <input
                id="rental-modal-hourly"
                type="number"
                min="0"
                step="any"
                value={hourlyRate}
                onChange={(e) => setHourlyRate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-semibold"
                required
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                Daily ({settings.currencySymbol})
              </label>
              <input
                id="rental-modal-daily"
                type="number"
                min="0"
                step="any"
                value={dailyRate}
                onChange={(e) => setDailyRate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-semibold"
                required
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                Deposit ({settings.currencySymbol})
              </label>
              <input
                id="rental-modal-deposit"
                type="number"
                min="0"
                step="any"
                value={securityDeposit}
                onChange={(e) => setSecurityDeposit(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-amber-400 font-bold"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Equipment Description / Notes</label>
            <input
              id="rental-modal-desc"
              type="text"
              placeholder="e.g. Includes braided USB-C cable and carrying case"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              id="cancel-rental-modal-btn"
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="rental-item-modal-submit"
              type="submit"
              disabled={isSubmitting}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs transition-all shadow-md shadow-amber-500/20 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : itemToEdit ? 'Update Hardware' : 'Save to Inventory'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
