import React, { useState } from 'react';
import { X, RotateCcw, ShieldCheck, AlertTriangle, CheckCircle2, MapPin } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { RentalRecord, PaymentMethod } from '../../types';

interface ReturnRentalModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: RentalRecord | null;
}

export const ReturnRentalModal: React.FC<ReturnRentalModalProps> = ({
  isOpen,
  onClose,
  record,
}) => {
  const { returnRental, settings } = useCafe();

  const [damageDeduction, setDamageDeduction] = useState<string>('0');
  const [lateFee, setLateFee] = useState<string>('0');
  const [inspectionNotes, setInspectionNotes] = useState<string>('Returned in good working condition');
  const [refundPaymentMethod, setRefundPaymentMethod] = useState<PaymentMethod>('cash');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  if (!isOpen || !record) return null;

  const damageNum = parseFloat(damageDeduction) || 0;
  const lateNum = parseFloat(lateFee) || 0;

  // Full Settlement Calculation
  const unpaidFee = Math.max(0, record.rentalFee - (record.paidAmount || 0));
  const totalOwed = unpaidFee + damageNum + lateNum;
  const depositHeld = record.depositAmount;
  
  const netRefund = Math.max(0, depositHeld - totalOwed);
  const stillOwedByCustomer = Math.max(0, totalOwed - depositHeld);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      const res = await returnRental({
        recordId: record.id,
        damageDeduction: damageNum,
        lateFee: lateNum,
        notes: inspectionNotes.trim(),
      });

      if (res.success) {
        onClose();
      } else {
        setError(res.error || 'Failed to process return');
      }
    } catch (err: any) {
      setError(err?.message || 'Error processing return');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <RotateCcw className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Process Equipment Return</h3>
              <p className="text-xs text-slate-400">
                {record.rentalItemName} (Qty: {record.quantity}) • {record.customerName}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold">
              {error}
            </div>
          )}

          {/* Deposit & Fee Info */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 sm:p-4 space-y-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Customer:</span>
              <span className="font-bold text-white">{record.customerName}</span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 py-2 border-y border-slate-800/60 my-1">
              <div className="space-y-1">
                <p className="text-[10px] uppercase text-slate-500 font-bold">Initial Deposit</p>
                <p className="text-sm font-bold text-amber-400 font-mono">
                  {settings.currencySymbol} {depositHeld}
                </p>
              </div>
              <div className="space-y-1 text-right">
                <p className="text-[10px] uppercase text-slate-500 font-bold">Unpaid Rental Fee</p>
                <p className={`text-sm font-bold font-mono ${unpaidFee > 0 ? 'text-rose-400' : 'text-slate-400'}`}>
                  {settings.currencySymbol} {unpaidFee}
                </p>
              </div>
            </div>

            {(record.aadhaarCollected || record.customerAadhaar) && (
              <div className="flex justify-between items-center text-slate-400 pt-1 border-t border-slate-800/60">
                <span>Identity / ID Proof:</span>
                <span className="inline-flex items-center gap-1 font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 text-[10px]">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Aadhaar {record.aadhaarCollected ? 'Verified' : ''} {record.customerAadhaar ? `(${record.customerAadhaar})` : ''}
                </span>
              </div>
            )}
            {record.customerAddress && (
              <div className="flex justify-between items-start text-slate-400 pt-1 border-t border-slate-800/60">
                <span className="shrink-0 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  Address:
                </span>
                <span className="font-medium text-slate-300 text-right ml-2 break-words max-w-[260px]">
                  {record.customerAddress}
                </span>
              </div>
            )}
            <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800/60">
              <span>Initial Security Deposit Held:</span>
              <span className="font-bold text-amber-400 font-mono text-sm">
                {settings.currencySymbol} {depositHeld}
              </span>
            </div>
          </div>

          {/* Inspection and Deductions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Damage Deduction ({settings.currencySymbol})
              </label>
              <input
                type="number"
                min="0"
                max={depositHeld}
                value={damageDeduction}
                onChange={(e) => setDamageDeduction(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Late Return Fee ({settings.currencySymbol})
              </label>
              <input
                type="number"
                min="0"
                value={lateFee}
                onChange={(e) => setLateFee(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Inspection / Return Notes
            </label>
            <input
              type="text"
              value={inspectionNotes}
              onChange={(e) => setInspectionNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Refund / Owed Box */}
          <div className={`bg-gradient-to-r rounded-xl p-4 flex items-center justify-between border ${
            stillOwedByCustomer > 0 
              ? 'from-rose-500/10 to-rose-600/5 border-rose-500/30' 
              : 'from-emerald-500/10 to-emerald-600/5 border-emerald-500/30'
          }`}>
            <div>
              <p className={`text-xs font-bold uppercase tracking-wider ${stillOwedByCustomer > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {stillOwedByCustomer > 0 ? 'Balance Owed by Customer' : 'Deposit Refund Amount'}
              </p>
              <p className="text-[11px] text-slate-400">
                {stillOwedByCustomer > 0 
                  ? 'Deposit was insufficient to cover all fees' 
                  : 'Returned to customer immediately'}
              </p>
            </div>
            <div className={`text-2xl font-black ${stillOwedByCustomer > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {settings.currencySymbol} {(stillOwedByCustomer > 0 ? stillOwedByCustomer : netRefund).toLocaleString('en-IN')}
            </div>
          </div>

          {/* Refund Method */}
          {netRefund > 0 && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Refund Method
              </label>
              <select
                value={refundPaymentMethod}
                onChange={(e) => setRefundPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="cash">Cash Counter</option>
                <option value="upi">UPI / Online Transfer</option>
                <option value="card">Card Refund</option>
              </select>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-4 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white text-center cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="confirm-return-btn"
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm shadow-md shadow-emerald-500/20 transition-all disabled:opacity-40 text-center cursor-pointer"
            >
              {isSubmitting ? 'Processing...' : 'Complete Return & Restock Gear'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
