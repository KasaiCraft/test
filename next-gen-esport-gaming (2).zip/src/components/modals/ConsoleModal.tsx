import React, { useState, useEffect } from 'react';
import { X, Gamepad2, AlertCircle, Plus, Trash2, Tag, Clock } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { GamingConsole, ConsoleType, ConsoleStatus, CustomPricingTier } from '../../types';

interface ConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  consoleToEdit?: GamingConsole | null;
}

export const ConsoleModal: React.FC<ConsoleModalProps> = ({
  isOpen,
  onClose,
  consoleToEdit,
}) => {
  const { addConsole, updateConsole, consoles, settings } = useCafe();

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState<ConsoleType>('PS5');

  // Multi-tier hourly pricing states
  const [price1Hour, setPrice1Hour] = useState('150');
  const [price2Hour, setPrice2Hour] = useState('');
  const [price3Hour, setPrice3Hour] = useState('');
  const [customPricing, setCustomPricing] = useState<CustomPricingTier[]>([]);
  
  // Player-based pricing state
  // [hours]: { [playerCount]: price }
  const [playerPricing, setPlayerPricing] = useState<{
    [hours: number]: { [playerCount: number]: string };
  }>({});

  // New custom tier input state
  const [newHours, setNewHours] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [tierError, setTierError] = useState('');

  const [location, setLocation] = useState('');
  const [specs, setSpecs] = useState('');
  const [status, setStatus] = useState<ConsoleStatus>('available');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync form inputs whenever modal opens or consoleToEdit changes
  useEffect(() => {
    if (isOpen) {
      if (consoleToEdit) {
        setCode(consoleToEdit.code || '');
        setName(consoleToEdit.name || '');
        setType(consoleToEdit.type || 'PS5');
        const p1 = consoleToEdit.price1Hour ?? consoleToEdit.hourlyRate ?? 150;
        setPrice1Hour(p1.toString());
        setPrice2Hour(
          consoleToEdit.price2Hour !== undefined && consoleToEdit.price2Hour !== null
            ? consoleToEdit.price2Hour.toString()
            : ''
        );
        setPrice3Hour(
          consoleToEdit.price3Hour !== undefined && consoleToEdit.price3Hour !== null
            ? consoleToEdit.price3Hour.toString()
            : ''
        );
        setCustomPricing(
          Array.isArray(consoleToEdit.customPricing)
            ? consoleToEdit.customPricing.map((cp) => ({ hours: Number(cp.hours), price: Number(cp.price) }))
            : []
        );
        // Initialize playerPricing
        const initialPlayerPricing: { [hours: number]: { [playerCount: number]: string } } = {};
        if (consoleToEdit.playerPricing) {
          Object.entries(consoleToEdit.playerPricing).forEach(([hours, players]) => {
            initialPlayerPricing[Number(hours)] = {};
            Object.entries(players).forEach(([playerCount, price]) => {
              initialPlayerPricing[Number(hours)][Number(playerCount)] = price.toString();
            });
          });
        }
        setPlayerPricing(initialPlayerPricing);
        setLocation(consoleToEdit.location || '');
        setSpecs(consoleToEdit.specifications || consoleToEdit.specs || '');
        setStatus(consoleToEdit.status || 'available');
      } else {
        setCode('');
        setName('');
        setType('PS5');
        const defaultRate = '150';
        setPrice1Hour(defaultRate);
        setPrice2Hour('');
        setPrice3Hour('');
        setCustomPricing([]);
        setPlayerPricing({});
        setLocation('');
        setSpecs('');
        setStatus('available');
      }
      setNewHours('');
      setNewPrice('');
      setTierError('');
      setError('');
      setIsSubmitting(false);
    }
  }, [isOpen, consoleToEdit]);

  if (!isOpen) return null;

  const consoleTypes: ConsoleType[] = [
    'PS5',
    'PS4',
    'PS4 Pro',
    'Xbox Series X',
    'Xbox Series S',
    'Xbox One',
    'PC Gaming',
    'Gaming PC Ultra',
    'VR Station',
    'Nintendo Switch',
    'Sim Racing',
    'Racing Simulator',
    'Retro Arcade',
    'Other',
  ];

  const handleAddCustomTier = () => {
    setTierError('');
    const h = parseFloat(newHours);
    const p = parseFloat(newPrice);

    if (isNaN(h) || h <= 0) {
      setTierError('Please enter valid hours (e.g. 4, 5, 6).');
      return;
    }

    if (h === 1 || h === 2 || h === 3) {
      setTierError(`Hours 1, 2, and 3 are already configured above.`);
      return;
    }

    if (isNaN(p) || p <= 0) {
      setTierError('Please enter valid package price (e.g. 500).');
      return;
    }

    if (customPricing.some((cp) => cp.hours === h)) {
      setTierError(`A pricing tier for ${h} hours already exists.`);
      return;
    }

    setCustomPricing((prev) => [...prev, { hours: h, price: p }].sort((a, b) => a.hours - b.hours));
    setNewHours('');
    setNewPrice('');
  };

  const handleRemoveCustomTier = (hoursToRemove: number) => {
    setCustomPricing((prev) => prev.filter((cp) => cp.hours !== hoursToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedCode = code.trim().toUpperCase();
    const trimmedName = name.trim();

    if (!trimmedCode) {
      setError('Station Code is required (e.g. PS5-01, PC-04).');
      return;
    }

    if (!trimmedName) {
      setError('Display Name is required (e.g. PlayStation 5 Pro Arena 1).');
      return;
    }

    const p1 = parseFloat(price1Hour);
    if (isNaN(p1) || p1 <= 0) {
      setError('1 Hour price must be a valid number greater than 0.');
      return;
    }

    let p2: number | undefined;
    if (price2Hour.trim()) {
      p2 = parseFloat(price2Hour);
      if (isNaN(p2) || p2 <= 0) {
        setError('2 Hours price must be a valid number greater than 0.');
        return;
      }
    }

    let p3: number | undefined;
    if (price3Hour.trim()) {
      p3 = parseFloat(price3Hour);
      if (isNaN(p3) || p3 <= 0) {
        setError('3 Hours price must be a valid number greater than 0.');
        return;
      }
    }

    // Check for duplicate station code
    const isDuplicate = consoles.some(
      (c) => c.code.toUpperCase() === trimmedCode && c.id !== consoleToEdit?.id
    );
    if (isDuplicate) {
      setError(`Station code "${trimmedCode}" already exists. Please choose a unique code.`);
      return;
    }

    // Prepare playerPricing for saving
    const sanitizedPlayerPricing: { [hours: number]: { [playerCount: number]: number } } = {};
    Object.entries(playerPricing).forEach(([hours, players]) => {
      sanitizedPlayerPricing[Number(hours)] = {};
      Object.entries(players).forEach(([playerCount, priceStr]) => {
        const price = parseFloat(priceStr);
        if (!isNaN(price)) {
          sanitizedPlayerPricing[Number(hours)][Number(playerCount)] = price;
        }
      });
    });

    setIsSubmitting(true);
    try {
      if (consoleToEdit) {
        await updateConsole(consoleToEdit.id, {
          code: trimmedCode,
          name: trimmedName,
          type,
          hourlyRate: p1, // Base 1-hr rate for backward compatibility
          price1Hour: p1,
          price2Hour: p2,
          price3Hour: p3,
          customPricing,
          playerPricing: sanitizedPlayerPricing,
          location: location.trim() || undefined,
          specifications: specs.trim() || undefined,
          specs: specs.trim() || undefined,
          status:
            consoleToEdit.status === 'in_use' || consoleToEdit.status === 'occupied'
              ? consoleToEdit.status
              : status,
        });
      } else {
        await addConsole({
          code: trimmedCode,
          name: trimmedName,
          type,
          hourlyRate: p1, // Base 1-hr rate
          price1Hour: p1,
          price2Hour: p2,
          price3Hour: p3,
          customPricing,
          playerPricing: sanitizedPlayerPricing,
          status: 'available',
          location: location.trim() || undefined,
          specifications: specs.trim() || undefined,
          specs: specs.trim() || undefined,
        });
      }
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save gaming station.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const p1Val = parseFloat(price1Hour) || 0;

  return (
    <div
      id="console-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in"
    >
      <div
        id="console-modal-card"
        className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
              <Gamepad2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {consoleToEdit ? `Edit Station: ${consoleToEdit.code}` : 'Add New Gaming Station'}
              </h3>
              <p className="text-xs text-slate-400">Configure station specs & tiered hourly pricing</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* Basic Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Station Code <span className="text-cyan-400">*</span>
              </label>
              <input
                id="console-modal-code"
                type="text"
                placeholder="e.g. PS5-04"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono font-bold uppercase"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Hardware Type</label>
              <select
                id="console-modal-type"
                value={type}
                onChange={(e) => setType(e.target.value as ConsoleType)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                {consoleTypes.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Station Display Name <span className="text-cyan-400">*</span>
            </label>
            <input
              id="console-modal-name"
              type="text"
              placeholder="e.g. PlayStation 5 Pro Arena 4"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              required
            />
          </div>

          {/* Pricing Section (1 Hr, 2 Hr, 3 Hr, Custom Hr & Value) */}
          <div className="bg-slate-950/70 border border-cyan-500/30 rounded-xl p-3.5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Hourly & Package Pricing ({settings.currencySymbol})
                </span>
              </div>
              <span className="text-[10px] text-cyan-400 font-medium bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-500/30">
                Tiered Rates
              </span>
            </div>

            {/* Standard 1 Hr, 2 Hr, 3 Hr Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* 1 Hour */}
              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-bold text-slate-200">1 Hour Price</span>
                  <span className="text-[9px] text-cyan-400 font-bold uppercase">Required</span>
                </div>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-500 font-bold">
                    {settings.currencySymbol}
                  </span>
                  <input
                    id="console-modal-price-1hr"
                    type="number"
                    min="1"
                    step="any"
                    placeholder="150"
                    value={price1Hour}
                    onChange={(e) => setPrice1Hour(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2 py-1.5 text-xs text-emerald-400 font-bold focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>
                <p className="text-[10px] text-slate-500 mt-1">Base rate</p>
              </div>

              {/* 2 Hours */}
              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-bold text-slate-200">2 Hours Price</span>
                  {p1Val > 0 && !price2Hour && (
                    <button
                      type="button"
                      onClick={() => setPrice2Hour((p1Val * 2).toString())}
                      className="text-[9px] text-cyan-400 hover:text-cyan-300 font-semibold underline cursor-pointer"
                    >
                      Auto 2x
                    </button>
                  )}
                </div>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-500 font-bold">
                    {settings.currencySymbol}
                  </span>
                  <input
                    id="console-modal-price-2hr"
                    type="number"
                    min="1"
                    step="any"
                    placeholder={p1Val > 0 ? (p1Val * 2).toString() : '280'}
                    value={price2Hour}
                    onChange={(e) => setPrice2Hour(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2 py-1.5 text-xs text-cyan-300 font-bold focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <p className="text-[10px] text-slate-500 mt-1">
                  {price2Hour && p1Val > 0 && parseFloat(price2Hour) < p1Val * 2
                    ? `Save ₹${p1Val * 2 - parseFloat(price2Hour)}`
                    : '2h special rate'}
                </p>
              </div>

              {/* 3 Hours */}
              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-bold text-slate-200">3 Hours Price</span>
                  {p1Val > 0 && !price3Hour && (
                    <button
                      type="button"
                      onClick={() => setPrice3Hour((p1Val * 3).toString())}
                      className="text-[9px] text-cyan-400 hover:text-cyan-300 font-semibold underline cursor-pointer"
                    >
                      Auto 3x
                    </button>
                  )}
                </div>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-500 font-bold">
                    {settings.currencySymbol}
                  </span>
                  <input
                    id="console-modal-price-3hr"
                    type="number"
                    min="1"
                    step="any"
                    placeholder={p1Val > 0 ? (p1Val * 3).toString() : '390'}
                    value={price3Hour}
                    onChange={(e) => setPrice3Hour(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2 py-1.5 text-xs text-amber-300 font-bold focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <p className="text-[10px] text-slate-500 mt-1">
                  {price3Hour && p1Val > 0 && parseFloat(price3Hour) < p1Val * 3
                    ? `Save ₹${p1Val * 3 - parseFloat(price3Hour)}`
                    : '3h special rate'}
                </p>
              </div>
            </div>

            {/* Custom Hours and Custom Values Section */}
            <div className="pt-2 border-t border-slate-800/80 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-cyan-400" />
                  <span className="text-[11px] font-semibold text-slate-300">
                    Custom Hours & Player Pricing (1-5 Players)
                  </span>
                </div>
              </div>

              {/* Pricing Grid */}
              <div className="space-y-3">
                {[1, 2, 3, ...customPricing.map((cp) => cp.hours)].map((h) => (
                  <div key={h} className="bg-slate-900/60 p-2 rounded-xl border border-slate-800/80">
                    <div className="text-[10px] font-bold text-slate-400 mb-1.5">{h} Hour Pricing</div>
                    <div className="grid grid-cols-5 gap-1.5">
                      {[1, 2, 3, 4, 5].map((pCount) => (
                        <div key={pCount} className="relative">
                          <input
                            type="number"
                            min="0"
                            placeholder={`${pCount}P`}
                            value={playerPricing[h]?.[pCount] || ''}
                            onChange={(e) =>
                              setPlayerPricing((prev) => ({
                                ...prev,
                                [h]: { ...(prev[h] || {}), [pCount]: e.target.value },
                              }))
                            }
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-1 py-1 text-[10px] text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Add new custom tier input row */}
              <div className="bg-slate-900/60 p-2 rounded-xl border border-slate-800/80 space-y-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-1/3">
                    <input
                      type="number"
                      min="0.5"
                      step="any"
                      placeholder="Add Hours"
                      value={newHours}
                      onChange={(e) => setNewHours(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-semibold"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const h = parseFloat(newHours);
                      if (!isNaN(h) && h > 0 && !customPricing.some(cp => cp.hours === h)) {
                          setCustomPricing(prev => [...prev, { hours: h, price: 0 }].sort((a,b) => a.hours - b.hours));
                          setNewHours('');
                      }
                    }}
                    className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 hover:text-cyan-200 border border-cyan-500/40 rounded-lg px-3 py-1.5 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Duration</span>
                  </button>
                </div>
                {tierError && <p className="text-[11px] text-rose-400 font-medium">{tierError}</p>}
              </div>
            </div>
          </div>

          {/* Location & Specs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Zone / Room Location</label>
              <input
                id="console-modal-location"
                type="text"
                placeholder="e.g. VIP Booth 2 / Main Hall"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            {consoleToEdit && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Station Status</label>
                <select
                  id="console-modal-status"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as ConsoleStatus)}
                  disabled={consoleToEdit.status === 'in_use' || consoleToEdit.status === 'occupied'}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 disabled:opacity-40"
                >
                  <option value="available">Available (Free)</option>
                  <option value="maintenance">Maintenance</option>
                  <option value="disabled">Disabled</option>
                  {(consoleToEdit.status === 'in_use' || consoleToEdit.status === 'occupied') && (
                    <option value="in_use">In Use (Active Session)</option>
                  )}
                </select>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Hardware / Display Specs</label>
            <input
              id="console-modal-specs"
              type="text"
              placeholder="e.g. 65-inch OLED 120Hz + 2 DualSense Controllers"
              value={specs}
              onChange={(e) => setSpecs(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              id="cancel-console-modal-btn"
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="console-modal-submit"
              type="submit"
              disabled={isSubmitting}
              className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : consoleToEdit ? 'Save Changes' : 'Create Station'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

