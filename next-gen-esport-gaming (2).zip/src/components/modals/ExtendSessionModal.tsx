import React, { useState, useEffect } from 'react';
import { X, Clock, DollarSign, AlertCircle } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { GamingSession, PaymentMethod } from '../../types';
import { calculateStationPricing } from '../../utils/pricing';
import { getFixedStationType } from '../../data/gamingPricing';

interface ExtendSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  session: GamingSession | null;
}

export const ExtendSessionModal: React.FC<ExtendSessionModalProps> = ({
  isOpen,
  onClose,
  session,
}) => {
  const { extendSession, settings, consoles } = useCafe();
  const [extraMinutes, setExtraMinutes] = useState<number>(30);
  const [customPrice, setCustomPrice] = useState<number | string>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const targetConsole = session ? consoles.find(c => c.id === session.consoleId) : null;

  // Auto-calculate suggested extension cost based on station pricing rules
  useEffect(() => {
    if (session && targetConsole) {
      const fixedType = getFixedStationType(targetConsole.type);
      let suggested = 0;
      if (fixedType) {
        const currentMins = session.presetDurationMinutes || 60;
        const oldPricing = calculateStationPricing(targetConsole, currentMins, session.ratePerHour, session.playerCount);
        const newPricing = calculateStationPricing(targetConsole, currentMins + extraMinutes, session.ratePerHour, session.playerCount);
        suggested = Math.max(0, newPricing.baseAmount - oldPricing.baseAmount);
      } else {
        const adminRate = Number(targetConsole.hourlyRate ?? targetConsole.price1Hour ?? session.ratePerHour) || 0;
        suggested = Math.round((extraMinutes / 60) * adminRate);
      }
      setCustomPrice(suggested);
      setPaidAmount(suggested);
    }
  }, [extraMinutes, session, targetConsole]);

  if (!isOpen || !session) return null;

  const currentCustomPrice = customPrice === '' ? 0 : Math.max(0, Number(customPrice));
  const currentPaidAmount = Math.max(0, Number(paidAmount) || 0);
  const dueAtCheckout = Math.max(0, currentCustomPrice - currentPaidAmount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (extraMinutes <= 0) {
      setError('Please enter a valid duration.');
      return;
    }

    if (currentPaidAmount > currentCustomPrice) {
      setError(`Paid amount (${settings.currencySymbol}${currentPaidAmount}) cannot exceed the extension charge (${settings.currencySymbol}${currentCustomPrice}).`);
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const res = await extendSession({
        sessionId: session.id,
        extraMinutes,
        customExtensionPrice: currentCustomPrice,
        paidAmount: currentPaidAmount,
        paymentMethod,
        notes: notes.trim(),
      });

      if (res.success) {
        onClose();
      } else {
        setError(res.error || 'Failed to extend session');
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md max-h-[90vh] rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white">Extend Gaming Session</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
          <div className="p-4 sm:p-5 space-y-3.5 overflow-y-auto custom-scrollbar flex-1">
            <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-800 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Station:</span>
              <span className="font-bold text-white">{session.consoleCode}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Player:</span>
              <span className="font-semibold text-cyan-300">{session.customerName}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
              Add Extra Time (Minutes)
            </label>
            <div className="grid grid-cols-4 gap-2 mb-2">
              {[15, 30, 60, 120].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setExtraMinutes(m)}
                  className={`py-2 rounded-lg text-xs font-bold transition-all ${
                    extraMinutes === m
                      ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {m}m
                </button>
              ))}
            </div>
            <input
              type="number"
              min="1"
              value={extraMinutes}
              onChange={(e) => setExtraMinutes(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Custom Extension Price */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="block text-xs font-bold text-slate-400 uppercase">
                Custom Extension Price ({settings.currencySymbol})
              </label>
              <span className="text-[11px] text-cyan-400 font-semibold">Editable</span>
            </div>
            <input
              id="custom-extension-price-input"
              type="number"
              min="0"
              value={customPrice}
              onChange={(e) => {
                const val = e.target.value;
                const num = val === '' ? '' : Math.max(0, Number(val));
                setCustomPrice(num);
                // Also default the paid amount if it was matching the previous custom price
                if (Number(paidAmount) === currentCustomPrice) {
                  setPaidAmount(num === '' ? 0 : num);
                }
              }}
              placeholder="e.g. 80, 150, 250"
              className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl px-4 py-2.5 text-sm text-white font-bold focus:outline-none"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Set custom price for this extension. Base station rates remain unchanged.
            </p>
          </div>

          {/* Payment Collection Option */}
          <div className="space-y-2 pt-1 border-t border-slate-800">
            <div className="flex justify-between items-center">
              <label className="block text-xs font-bold text-slate-400 uppercase">
                Payment Collection
              </label>
              <span className="text-[11px] text-slate-400">
                {currentPaidAmount > 0 ? 'Paying Immediately' : 'Pay at Checkout'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPaidAmount(currentCustomPrice)}
                className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all text-center ${
                  currentPaidAmount === currentCustomPrice && currentCustomPrice > 0
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400 shadow-sm shadow-emerald-500/10'
                    : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                Pay Immediately ({settings.currencySymbol}{currentCustomPrice})
              </button>
              <button
                type="button"
                onClick={() => setPaidAmount(0)}
                className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all text-center ${
                  currentPaidAmount === 0
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-400 shadow-sm shadow-amber-500/10'
                    : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                Pay at Checkout ({settings.currencySymbol}0 Now)
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                  Amount Paid Now ({settings.currencySymbol})
                </label>
                <input
                  id="extension-paid-amount-input"
                  type="number"
                  min="0"
                  max={currentCustomPrice}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white font-bold focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                  Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                  disabled={currentPaidAmount <= 0}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500 cursor-pointer disabled:opacity-40"
                >
                  <option value="upi">UPI / QR</option>
                  <option value="cash">Cash</option>
                  <option value="card">Card</option>
                </select>
              </div>
            </div>
          </div>

          {/* Extension Billing Breakdown Preview */}
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Extension Charge:</span>
              <span className="font-bold text-cyan-300">{settings.currencySymbol} {currentCustomPrice}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Paid Immediately:</span>
              <span className="font-bold text-emerald-400">{settings.currencySymbol} {currentPaidAmount}</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-slate-800/80">
              <span className="text-slate-400 font-semibold">Added to Checkout Due:</span>
              <span className={`font-bold ${dueAtCheckout > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                {settings.currencySymbol} {dueAtCheckout}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
              Notes (Optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Reason for extension..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-cyan-500 min-h-[60px] resize-none"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <p className="text-xs text-rose-300 font-medium">{error}</p>
            </div>
          )}
        </div>

        {/* Pinned Action Buttons Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900 shrink-0 flex gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 px-4 py-2.5 rounded-xl text-slate-400 hover:text-white text-sm font-bold transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-sm transition-all shadow-lg shadow-cyan-500/20 disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? 'Processing...' : 'Extend Session'}
          </button>
        </div>
      </form>
      </div>
    </div>
  );
};
