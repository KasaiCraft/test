import React, { useState, useEffect, useMemo } from 'react';
import { X, Clock, DollarSign, AlertCircle, Calendar } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { RentalRecord, PaymentMethod, RentalPeriodType } from '../../types';
import { RENTAL_PRICING } from '../../config/rentalPricing';

interface ExtendRentalModalProps {
  isOpen: boolean;
  onClose: () => void;
  rental: RentalRecord | null;
}

export const ExtendRentalModal: React.FC<ExtendRentalModalProps> = ({
  isOpen,
  onClose,
  rental,
}) => {
  const { extendRental, settings, rentalItems } = useCafe();
  const [extraUnits, setExtraUnits] = useState<number>(1);
  const [periodType, setPeriodType] = useState<RentalPeriodType>('hourly');
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const item = rental ? rentalItems.find(i => i.id === rental.rentalItemId) : null;

  // Detect if this is a standard rental (by explicit field, std_ item id, or [Standard Rental] notes)
  const isStandard = Boolean(
    rental?.isStandardRental ??
    (rental?.rentalItemId?.startsWith('std_') ||
      (rental?.notes ? rental.notes.startsWith('[Standard Rental]') : false))
  );

  let standardConsole: 'PS4' | 'PS5' = rental?.standardConsole ?? 'PS5';
  if (rental && !rental.standardConsole && isStandard) {
    const textToCheck = `${rental.rentalItemId || ''} ${rental.notes || ''} ${rental.rentalItemName || ''}`.toUpperCase();
    if (textToCheck.includes('PS4')) {
      standardConsole = 'PS4';
    } else if (textToCheck.includes('PS5')) {
      standardConsole = 'PS5';
    }
  }

  // Sync period type with rental record
  useEffect(() => {
    if (rental) {
      setPeriodType(rental.periodType || 'hourly');
    }
  }, [rental]);

  // Suggested extension amount
  const suggestedAmount = useMemo(() => {
    if (!rental) return 0;
    if (isStandard) {
      const oneDayPrice = RENTAL_PRICING[standardConsole].base['1day'];
      if (periodType === 'daily') {
        return oneDayPrice * extraUnits;
      } else {
        return Math.round((oneDayPrice / 24) * extraUnits);
      }
    } else if (item) {
      const rate = periodType === 'daily' ? item.dailyRate : item.hourlyRate;
      return rate * extraUnits;
    }
    return 0;
  }, [rental, isStandard, standardConsole, periodType, extraUnits, item]);

  // Auto-calculate price
  useEffect(() => {
    if (rental) {
      if (isStandard) {
        const oneDayPrice = RENTAL_PRICING[standardConsole].base['1day'];
        const amount = periodType === 'daily'
          ? oneDayPrice * extraUnits
          : Math.round((oneDayPrice / 24) * extraUnits);
        setPaidAmount(amount);
      } else if (item) {
        const rate = periodType === 'daily' ? item.dailyRate : item.hourlyRate;
        setPaidAmount(extraUnits * rate);
      }
    }
  }, [extraUnits, periodType, rental, item, isStandard, standardConsole]);

  if (!isOpen || !rental) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (extraUnits <= 0) {
      setError('Please enter a valid amount.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const res = await extendRental({
        rentalId: rental.id,
        extraUnits,
        periodType,
        paidAmount,
        paymentMethod,
        notes: notes.trim(),
      });

      if (res.success) {
        onClose();
      } else {
        setError(res.error || 'Failed to extend rental');
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-white">Extend Rental Period</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-800 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Gear:</span>
              <span className="font-bold text-white">{rental.rentalItemName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Customer:</span>
              <span className="font-semibold text-amber-300">{rental.customerName}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Extra Units
              </label>
              <input
                type="number"
                min="1"
                value={extraUnits}
                onChange={(e) => setExtraUnits(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Unit Type
              </label>
              <select
                value={periodType}
                onChange={(e) => setPeriodType(e.target.value as RentalPeriodType)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="hourly">Hours</option>
                <option value="daily">Days</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-400 uppercase">
                  Extension Fee ({settings.currencySymbol})
                </label>
                {suggestedAmount > 0 && (
                  <span className="text-[10px] text-amber-400 font-bold">
                    Suggested: {settings.currencySymbol}{suggestedAmount}
                  </span>
                )}
              </div>
              <input
                type="number"
                min="0"
                value={paidAmount}
                onChange={(e) => setPaidAmount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 font-mono"
              />
              {!isStandard && !item && (
                <p className="text-[10px] text-amber-400 mt-1 font-medium">
                  Item rate not found in inventory. Please enter fee manually.
                </p>
              )}
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="upi">UPI / QR</option>
                <option value="cash">Cash</option>
                <option value="card">Card</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
              Notes (Optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional instructions..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-amber-500 min-h-[60px] resize-none"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <p className="text-xs text-rose-300 font-medium">{error}</p>
            </div>
          )}

          <div className="pt-2 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2.5 rounded-xl text-slate-400 hover:text-white text-sm font-bold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-sm transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50"
            >
              {isSubmitting ? 'Processing...' : 'Extend Rental'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
