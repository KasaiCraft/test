import React from 'react';
import { X, Printer, CheckCircle2, Gamepad2 } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { PaymentTransaction } from '../../types';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: PaymentTransaction | null;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  transaction,
}) => {
  const { settings } = useCafe();

  if (!isOpen || !transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Customer Receipt
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
              title="Print Receipt"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Thermal Slip Content */}
        <div className="p-4 sm:p-6 bg-white text-slate-950 font-mono text-xs space-y-4 printable-receipt overflow-y-auto custom-scrollbar">
          {/* Cafe Header */}
          <div className="text-center space-y-1 pb-3 border-b border-dashed border-slate-300">
            <h2 className="text-base font-black uppercase tracking-wider">{settings.cafeName}</h2>
            <p className="text-[10px] text-slate-600">{settings.tagline}</p>
            <p className="text-[10px] text-slate-600">{settings.address}</p>
            <p className="text-[10px] text-slate-600">Ph: {settings.phone}</p>
          </div>

          {/* Metadata */}
          <div className="text-[11px] space-y-1 pb-3 border-b border-dashed border-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-500">Receipt Ref:</span>
              <span className="font-bold">{transaction.id.slice(0, 10).toUpperCase()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Date/Time:</span>
              <span>{new Date(transaction.timestamp).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Customer:</span>
              <span className="font-bold">{transaction.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Cashier:</span>
              <span>{transaction.recordedBy}</span>
            </div>
          </div>

          {/* Item / Description */}
          <div className="space-y-2 pb-3 border-b border-dashed border-slate-300">
            <div className="flex justify-between font-bold">
              <span>Item / Service</span>
              <span>Amount</span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span className="max-w-[180px]">{transaction.referenceTitle}</span>
              <span className="font-bold">
                {settings.currencySymbol} {Math.abs(transaction.amount).toLocaleString('en-IN')}
              </span>
            </div>
            {transaction.notes && (
              <p className="text-[10px] text-slate-600 italic">Note: {transaction.notes}</p>
            )}
          </div>

          {/* Total & Payment Mode */}
          <div className="space-y-1.5 pb-3 border-b border-slate-900">
            <div className="flex justify-between text-sm font-black">
              <span>NET TOTAL PAID:</span>
              <span>
                {settings.currencySymbol} {Math.abs(transaction.amount).toLocaleString('en-IN')}
              </span>
            </div>
            {transaction.splitDetails && transaction.splitDetails.length > 0 ? (
              <div className="pt-1 space-y-1">
                <div className="text-[10px] font-bold text-slate-700 uppercase tracking-wide">
                  Split Payment Breakdown:
                </div>
                {transaction.splitDetails.map((split, idx) => (
                  <div key={idx} className="flex justify-between text-[10px] text-slate-600 pl-2">
                    <span className="uppercase font-semibold">• {split.method}:</span>
                    <span className="font-bold">{settings.currencySymbol} {split.amount.toLocaleString('en-IN')}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex justify-between text-[10px] text-slate-600 uppercase">
                <span>Payment Mode:</span>
                <span className="font-bold">{transaction.method}</span>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="text-center pt-2 text-[10px] text-slate-500 space-y-0.5">
            <p className="font-bold">Thank you for gaming with us!</p>
            <p>Visit again soon for pro tournaments & gear rentals.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
