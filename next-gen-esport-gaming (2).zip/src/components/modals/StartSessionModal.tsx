import React, { useState, useEffect, useMemo } from 'react';
import { X, Gamepad2, User, Phone, Plus, AlertCircle, Clock, CheckCircle2, Tag, Ticket } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { Customer } from '../../types';
import { calculateStationPricing, getConsolePricingTiers } from '../../utils/pricing';
import { getGamingPrice } from '../../data/gamingPricing';

interface StartSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedConsoleId?: string;
  preselectedCustomer?: Customer;
}

export const StartSessionModal: React.FC<StartSessionModalProps> = ({
  isOpen,
  onClose,
  preselectedConsoleId,
  preselectedCustomer,
}) => {
  const {
    consoles,
    customers,
    addCustomer,
    startSession,
    isAdmin,
    settings,
    vouchers,
    voucherUsages,
  } = useCafe();

  const availableConsoles = consoles.filter((c) => c.status === 'available');

  // Deduplicate customers strictly by unique ID and phone number
  const uniqueCustomers = useMemo(() => {
    const seenIds = new Set<string>();
    const seenPhones = new Set<string>();
    const result: Customer[] = [];

    for (const c of customers) {
      if (!c || !c.id) continue;
      const cleanPhone = (c.phone || '').trim().replace(/[\s\-()]/g, '');
      if (seenIds.has(c.id)) continue;
      if (cleanPhone && seenPhones.has(cleanPhone)) continue;

      seenIds.add(c.id);
      if (cleanPhone) seenPhones.add(cleanPhone);
      result.push(c);
    }
    return result;
  }, [customers]);

  const [selectedConsoleId, setSelectedConsoleId] = useState<string>('');
  const targetConsole = consoles.find((c) => c.id === selectedConsoleId);
  const [isNewCustomer, setIsNewCustomer] = useState<boolean>(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');

  // Duration selection states: e.g. '30', '60', '120', '180', 'custom', or minutes
  const [durationPreset, setDurationPreset] = useState<string>('60');
  const [customMinutes, setCustomMinutes] = useState<string>('45');
  const [playerCount, setPlayerCount] = useState<number>(1);
  
  const availablePlayerCounts = useMemo(() => {
    if (!targetConsole) return [1];
    
    // PS4/PS5/PC Gaming/etc - if it has playerPricing in the DB, show it.
    // Also PS4/PS5 have defaults in GAMING_PRICING.
    const isConsole = targetConsole.type === 'PS4' || targetConsole.type === 'PS5' || targetConsole.type === 'PS4 Pro';
    const hasConfiguredPricing = targetConsole.playerPricing && Object.keys(targetConsole.playerPricing).length > 0;
    
    if (isConsole || hasConfiguredPricing || targetConsole.type.includes('PC')) {
      return [1, 2, 3, 4, 5];
    }
    
    return [1];
  }, [targetConsole]);

  const showPlayerSelector = availablePlayerCounts.length > 1;

  // Reset player count if it exceeds available options
  useEffect(() => {
    if (playerCount > availablePlayerCounts.length) {
      setPlayerCount(1);
    }
  }, [availablePlayerCounts, playerCount]);

  const [newCustomerName, setNewCustomerName] = useState<string>('');
  const [newCustomerPhone, setNewCustomerPhone] = useState<string>('');
  const [selectedVoucherId, setSelectedVoucherId] = useState<string>('');
  const [applyCreditMinutes, setApplyCreditMinutes] = useState<number>(0);
  const [useCustomStartTime, setUseCustomStartTime] = useState<boolean>(false);
  const [customStartTime, setCustomStartTime] = useState<string>(() => {
    const now = new Date();
    return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
  });
  const [customRate, setCustomRate] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Synchronize state dynamically whenever modal opens or preselected targets change
  useEffect(() => {
    if (!isOpen) return;

    // Pick only from currently present and available consoles in database
    const preselectedValid = preselectedConsoleId && availableConsoles.some((c) => c.id === preselectedConsoleId);
    if (preselectedValid) {
      setSelectedConsoleId(preselectedConsoleId);
    } else if (availableConsoles.length > 0) {
      setSelectedConsoleId(availableConsoles[0].id);
    } else {
      setSelectedConsoleId('');
    }

    // Customer setup
    if (preselectedCustomer) {
      setSelectedCustomerId(preselectedCustomer.id);
      setIsNewCustomer(false);
    } else if (uniqueCustomers.length > 0) {
      setSelectedCustomerId(uniqueCustomers[0].id);
      setIsNewCustomer(false);
    } else {
      setSelectedCustomerId('');
      setIsNewCustomer(true);
    }

    setDurationPreset('60');
    setCustomMinutes('45');
    setNewCustomerName('');
    setNewCustomerPhone('');
    setSelectedVoucherId('');
    setApplyCreditMinutes(0);
    setUseCustomStartTime(false);
    const now = new Date();
    setCustomStartTime(`${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`);
    setCustomRate('');
    setError('');
    setIsSubmitting(false);
  }, [isOpen, preselectedConsoleId, preselectedCustomer]);

  // Available pricing tiers for selected console
  const availableTiers = useMemo(() => {
    return getConsolePricingTiers(targetConsole, playerCount);
  }, [targetConsole, playerCount]);

  // Computed play duration in minutes
  const effectivePlayMinutes = useMemo(() => {
    if (durationPreset === 'custom') {
      const parsed = parseInt(customMinutes, 10);
      return isNaN(parsed) || parsed <= 0 ? 60 : parsed;
    }
    const mins = parseInt(durationPreset, 10);
    return isNaN(mins) || mins <= 0 ? 60 : mins;
  }, [durationPreset, customMinutes]);

  // Estimated scheduled end time
  const estimatedEndTimeFormatted = useMemo(() => {
    const totalMins = effectivePlayMinutes + applyCreditMinutes;
    let baseTime = Date.now();

    if (useCustomStartTime && customStartTime) {
      const [hours, minutes] = customStartTime.split(':').map(Number);
      const d = new Date();
      d.setHours(hours, minutes, 0, 0);

      // If selected time is in future compared to now, check if it should be yesterday
      // (e.g. it's 1 AM and user enters 11:30 PM)
      if (d.getTime() > Date.now() + 6 * 60 * 60 * 1000) { // If > 6 hours in future, assume yesterday
        d.setDate(d.getDate() - 1);
      }
      
      baseTime = d.getTime();
    }

    const end = new Date(baseTime + totalMins * 60000);
    return end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }, [effectivePlayMinutes, applyCreditMinutes, useCustomStartTime, customStartTime]);

  // Matched existing player when entering customer details
  const normalizedNewCustomerPhone = (newCustomerPhone || '').trim().replace(/[\s\-()]/g, '');
  const matchedExistingPlayer = useMemo(() => {
    if (!isNewCustomer || !normalizedNewCustomerPhone) return null;
    return (
      uniqueCustomers.find((c) => {
        const cPhone = (c.phone || '').trim().replace(/[\s\-()]/g, '');
        return Boolean(cPhone && cPhone === normalizedNewCustomerPhone);
      }) || null
    );
  }, [isNewCustomer, normalizedNewCustomerPhone, uniqueCustomers]);

  // Available credit for the selected customer
  const availableCreditMinutes = useMemo(() => {
    const custId = isNewCustomer ? matchedExistingPlayer?.id : selectedCustomerId;
    if (!custId) return 0;
    const cust = uniqueCustomers.find(c => c.id === custId);
    return cust?.unusedMinutesBalance || 0;
  }, [isNewCustomer, matchedExistingPlayer, selectedCustomerId, uniqueCustomers]);

  // Estimated pricing calculation using station tiers
  const pricingDetails = useMemo(() => {
    let baseAmount: number;
    let effectiveRatePerHour: number;
    let appliedTierLabel: string;

    if (customRate && isAdmin) {
      const override = parseFloat(customRate);
      if (!isNaN(override) && override > 0) {
        baseAmount = Math.round((effectivePlayMinutes / 60) * override);
        effectiveRatePerHour = override;
        appliedTierLabel = `Admin Override @ ₹${override}/hr`;
      } else {
        const pricing = calculateStationPricing(targetConsole, effectivePlayMinutes, undefined, playerCount);
        baseAmount = pricing.baseAmount;
        effectiveRatePerHour = pricing.effectiveRatePerHour;
        appliedTierLabel = pricing.appliedTierLabel;
      }
    } else {
      const pricing = calculateStationPricing(targetConsole, effectivePlayMinutes, undefined, playerCount);
      baseAmount = pricing.baseAmount;
      effectiveRatePerHour = pricing.effectiveRatePerHour;
      appliedTierLabel = pricing.appliedTierLabel;
    }

    return {
      baseAmount,
      effectiveRatePerHour,
      appliedTierLabel
    };
  }, [effectivePlayMinutes, customRate, isAdmin, targetConsole, playerCount]);

  const estimatedCharge = pricingDetails.baseAmount;

  // Active customer vouchers for tracking and redemption
  const activeCustomerVouchers = useMemo(() => {
    const custId = isNewCustomer ? matchedExistingPlayer?.id : selectedCustomerId;
    const custPhone = isNewCustomer ? normalizedNewCustomerPhone : uniqueCustomers.find(c => c.id === selectedCustomerId)?.phone?.replace(/[\s\-()]/g, '');
    const custName = isNewCustomer ? newCustomerName.trim().toLowerCase() : uniqueCustomers.find(c => c.id === selectedCustomerId)?.name?.toLowerCase();

    return (vouchers || []).filter((v) => {
      if (v.status !== 'active') return false;
      const rem = v.remainingHours !== undefined ? v.remainingHours : ((v.durationMinutes - (v.usedMinutes || 0)) / 60);
      if (rem <= 0) return false;

      // Check category match if voucher specifies category
      if (v.category && v.category !== 'all' && targetConsole?.type) {
        if (!v.category.toLowerCase().includes(targetConsole.type.toLowerCase()) && !targetConsole.type.toLowerCase().includes(v.category.toLowerCase())) {
          return false;
        }
      }

      const assignedPhone = v.assignedCustomerPhone?.replace(/[\s\-()]/g, '');
      return (
        (custId && v.assignedCustomerId === custId) ||
        (custPhone && assignedPhone === custPhone) ||
        (custName && v.assignedCustomerName?.toLowerCase() === custName) ||
        (!v.assignedCustomerId && !v.assignedCustomerPhone)
      );
    });
  }, [vouchers, isNewCustomer, matchedExistingPlayer, selectedCustomerId, normalizedNewCustomerPhone, newCustomerName, uniqueCustomers, targetConsole]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (consoles.length === 0) {
      setError('No consoles available. Please add a console first.');
      return;
    }

    if (!selectedConsoleId) {
      setError('Please select an available gaming station.');
      return;
    }

    const currentConsole = consoles.find((c) => c.id === selectedConsoleId);
    if (!currentConsole) {
      setError('Selected console does not exist. Please select an available station.');
      return;
    }

    if (currentConsole.status !== 'available') {
      setError(`Station ${currentConsole.code} is currently ${currentConsole.status}.`);
      return;
    }

    let customerId = selectedCustomerId;
    let customerName = '';
    let customerPhone = '';

    if (isNewCustomer) {
      const cleanName = newCustomerName.trim();
      const cleanPhone = newCustomerPhone.trim();

      if (!cleanName || !cleanPhone) {
        setError('Please provide customer name and contact phone.');
        return;
      }

      // Check if this phone number already matches an existing customer
      const normalizedInputPhone = cleanPhone.replace(/[\s\-()]/g, '');
      const existingMatch = uniqueCustomers.find((c) => {
        const cPhone = (c.phone || '').trim().replace(/[\s\-()]/g, '');
        return Boolean(cPhone && cPhone === normalizedInputPhone);
      });

      if (existingMatch) {
        // Reuse existing customer ID — never create a duplicate
        customerId = existingMatch.id;
        customerName = cleanName || existingMatch.name;
        customerPhone = cleanPhone || existingMatch.phone;
      } else {
        // Create the customer record before creating the session
        try {
          const created = await addCustomer({
            name: cleanName,
            phone: cleanPhone,
          });
          customerId = created.id;
          customerName = created.name;
          customerPhone = created.phone;
        } catch (err: any) {
          setError(err?.message || 'Failed to create customer');
          return;
        }
      }
    } else {
      const found = uniqueCustomers.find((c) => c.id === customerId);
      if (!found) {
        setError('Please select a valid customer.');
        return;
      }
      customerName = found.name;
      customerPhone = found.phone;
    }

    setIsSubmitting(true);
    try {
      let startTimeIso: string | undefined;
      if (useCustomStartTime && customStartTime) {
        const [hours, minutes] = customStartTime.split(':').map(Number);
        const d = new Date();
        d.setHours(hours, minutes, 0, 0);

        // If selected time is in future compared to now, check if it should be yesterday
        // (e.g. it's 1 AM and user enters 11:30 PM)
        if (d.getTime() > Date.now() + 6 * 60 * 60 * 1000) { // If > 6 hours in future, assume yesterday
          d.setDate(d.getDate() - 1);
        }
        startTimeIso = d.toISOString();
      }

      const parsedOverride = customRate ? parseFloat(customRate) : NaN;
      const isOverride = Boolean(customRate && isAdmin && !isNaN(parsedOverride) && parsedOverride > 0);

      const res = await startSession({
        consoleId: selectedConsoleId,
        customerId,
        customerName,
        customerPhone,
        presetMinutes: effectivePlayMinutes,
        customRate: isOverride ? parsedOverride : pricingDetails.effectiveRatePerHour,
        isRateOverride: isOverride ? true : undefined,
        playerCount: showPlayerSelector ? playerCount : undefined,
        voucherId: selectedVoucherId || undefined,
        creditMinutesToApply: applyCreditMinutes,
        startTime: startTimeIso,
      });

      if (res.success) {
        onClose();
      } else {
        setError(res.error || 'Failed to start session');
      }
    } catch (err: any) {
      setError(err?.message || 'Unexpected error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
              <Gamepad2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Start New Gaming Session</h3>
              <p className="text-xs text-slate-400">Lock station, set play duration, and start automatic timer</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. Station Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Select Available Gaming Station
            </label>
            {consoles.length === 0 ? (
              <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>No consoles available. Please add a console first.</span>
              </div>
            ) : availableConsoles.length > 0 ? (
              <select
                id="start-session-console-select"
                value={selectedConsoleId}
                onChange={(e) => setSelectedConsoleId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                required
              >
                {availableConsoles.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} — {c.name} ({settings.currencySymbol} {c.hourlyRate}/hr)
                  </option>
                ))}
              </select>
            ) : (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>All gaming stations are currently occupied or under maintenance.</span>
              </div>
            )}
          </div>

          {/* 1b. Player Count Selector (Generalized) */}
          {showPlayerSelector && (
            <div className="pt-2 border-t border-slate-800">
                <label className="text-xs font-semibold text-slate-300 mb-1.5 block">Player Count</label>
                <div className="flex gap-2">
                    {availablePlayerCounts.map(p => (
                        <button 
                          key={p} 
                          type="button"
                          onClick={() => setPlayerCount(p as any)}
                          className={`flex-1 py-2 text-xs font-bold rounded-lg border transition-all ${
                            playerCount === p 
                            ? 'bg-cyan-600 border-cyan-500 text-white' 
                            : 'bg-slate-950 border-slate-700 text-slate-400'
                          }`}
                        >
                            {p}P
                        </button>
                    ))}
                </div>
            </div>
          )}

          {/* 2. Play Duration Selector */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                Play Duration
              </label>
              <span className="text-[11px] text-cyan-400 font-medium">
                Auto-ends at {estimatedEndTimeFormatted}
              </span>
            </div>

            {/* Quick preset buttons including 1h, 2h, 3h, custom tiers, and custom input */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-1.5">
              <button
                type="button"
                id="duration-30m-btn"
                onClick={() => setDurationPreset('30')}
                className={`py-2 px-1 text-xs font-semibold rounded-lg border transition-all cursor-pointer text-center ${
                  durationPreset === '30'
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                }`}
              >
                <div>30 Min</div>
                <div className="text-[10px] opacity-75 font-normal">Quick play</div>
              </button>

              <button
                type="button"
                id="duration-1h-btn"
                onClick={() => setDurationPreset('60')}
                className={`py-2 px-1 text-xs font-semibold rounded-lg border transition-all cursor-pointer text-center ${
                  durationPreset === '60'
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                }`}
              >
                <div>1 Hour</div>
                <div className="text-[10px] text-cyan-400 font-bold">
                  {targetConsole ? `${settings.currencySymbol}${availableTiers.find(t => t.hours === 1)?.price || (targetConsole.price1Hour ?? targetConsole.hourlyRate)}` : ''}
                </div>
              </button>

              <button
                type="button"
                id="duration-2h-btn"
                onClick={() => setDurationPreset('120')}
                className={`py-2 px-1 text-xs font-semibold rounded-lg border transition-all cursor-pointer text-center ${
                  durationPreset === '120'
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                }`}
              >
                <div>2 Hours</div>
                <div className="text-[10px] text-cyan-400 font-bold">
                  {targetConsole ? `${settings.currencySymbol}${availableTiers.find(t => t.hours === 2)?.price || (targetConsole.price2Hour || (targetConsole.hourlyRate * 2))}` : ''}
                </div>
              </button>

              <button
                type="button"
                id="duration-3h-btn"
                onClick={() => setDurationPreset('180')}
                className={`py-2 px-1 text-xs font-semibold rounded-lg border transition-all cursor-pointer text-center ${
                  durationPreset === '180'
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                }`}
              >
                <div>3 Hours</div>
                <div className="text-[10px] text-cyan-400 font-bold">
                  {targetConsole ? `${settings.currencySymbol}${availableTiers.find(t => t.hours === 3)?.price || (targetConsole.price3Hour || (targetConsole.hourlyRate * 3))}` : ''}
                </div>
              </button>

              {/* Station-specific custom tiers (e.g. 4 Hours, 5 Hours) */}
              {Array.isArray(targetConsole?.customPricing) && targetConsole.customPricing.map((cp) => {
                const mins = cp.hours * 60;
                return (
                  <button
                    key={cp.hours}
                    type="button"
                    onClick={() => setDurationPreset(mins.toString())}
                    className={`py-2 px-1 text-xs font-semibold rounded-lg border transition-all cursor-pointer text-center ${
                      durationPreset === mins.toString()
                        ? 'bg-purple-500/20 border-purple-500 text-purple-300 shadow-sm shadow-purple-500/20'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    <div>{cp.hours} Hours</div>
                    <div className="text-[10px] text-purple-400 font-bold">
                      {settings.currencySymbol}{cp.price}
                    </div>
                  </button>
                );
              })}

              <button
                type="button"
                id="duration-custom-btn"
                onClick={() => setDurationPreset('custom')}
                className={`py-2 px-1 text-xs font-semibold rounded-lg border transition-all cursor-pointer text-center ${
                  durationPreset === 'custom'
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                }`}
              >
                <div>Custom</div>
                <div className="text-[10px] opacity-75 font-normal">Any mins</div>
              </button>
            </div>

            {/* Custom Duration input if 'custom' is selected */}
            {durationPreset === 'custom' && (
              <div className="flex items-center gap-2 pt-1.5">
                <input
                  type="number"
                  min="5"
                  max="1440"
                  step="5"
                  placeholder="Enter minutes (e.g. 45 or 90)"
                  value={customMinutes}
                  onChange={(e) => setCustomMinutes(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  required
                />
                <span className="text-xs text-slate-400 whitespace-nowrap">Minutes total</span>
              </div>
            )}

            {/* NEW: Custom Start Time Selector */}
            <div className="pt-3 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  Actual Session Timing
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Use Custom Start Time?</span>
                  <button
                    type="button"
                    onClick={() => setUseCustomStartTime(!useCustomStartTime)}
                    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${
                      useCustomStartTime ? 'bg-cyan-600' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                        useCustomStartTime ? 'translate-x-4.5' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {useCustomStartTime && (
                <div className="grid grid-cols-2 gap-3 animate-in fade-in slide-in-from-top-1">
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-1">Session Start Time</label>
                    <input
                      type="time"
                      value={customStartTime}
                      onChange={(e) => setCustomStartTime(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                      required={useCustomStartTime}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-1">Auto-Calculated End</label>
                    <div className="w-full bg-slate-900/50 border border-slate-800 rounded-xl px-3 py-2 text-xs text-cyan-400 font-bold">
                      {estimatedEndTimeFormatted}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Live duration & pricing estimation card */}
            {targetConsole && (
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 space-y-2 mt-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Total Playable Time:</span>
                    <span className="font-bold text-white text-xs">
                      {Math.floor((effectivePlayMinutes + applyCreditMinutes) / 60) > 0 ? `${Math.floor((effectivePlayMinutes + applyCreditMinutes) / 60)}h ` : ''}
                      {(effectivePlayMinutes + applyCreditMinutes) % 60 > 0 ? `${(effectivePlayMinutes + applyCreditMinutes) % 60}m` : ''}
                    </span>
                    {applyCreditMinutes > 0 && (
                      <div className="text-[10px] text-cyan-400 font-medium">
                        ({effectivePlayMinutes}m Paid + {applyCreditMinutes}m Extra)
                      </div>
                    )}
                  </div>
                  <div className="text-center">
                    <span className="text-slate-400 block text-[11px]">Applied Plan:</span>
                    <span className="font-semibold text-cyan-300 text-xs">
                      {pricingDetails.appliedTierLabel}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-400 block text-[11px]">Amount Due:</span>
                    <span className="font-bold text-emerald-400 text-sm">
                      {settings.currencySymbol} {estimatedCharge}
                    </span>
                  </div>
                </div>

                {/* Station Tiered Rate Summary */}
                <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-1.5 text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Tag className="w-3 h-3 text-cyan-400" />
                    <span>Configured Rates ({playerCount}P):</span>
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {availableTiers.map((tier) => (
                      <span key={tier.hours} className={`px-2 py-0.5 rounded font-semibold border border-slate-800 ${
                        tier.hours === 1 ? 'text-slate-200 bg-slate-900' :
                        tier.hours === 2 ? 'text-cyan-300 bg-slate-900' :
                        tier.hours === 3 ? 'text-amber-300 bg-slate-900' :
                        'text-purple-300 bg-slate-900'
                      }`}>
                        {tier.hours}h: {settings.currencySymbol}{tier.price}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Locked Pricing preview */}
          {targetConsole && (
            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Locked Base Hourly Rate:</span>
              <span className="font-bold text-cyan-300 text-sm">
                {settings.currencySymbol} {targetConsole.hourlyRate} / hour
              </span>
            </div>
          )}

          {/* Admin Custom Rate override */}
          {isAdmin && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Special Rate Override (Admin Optional)
              </label>
              <input
                type="number"
                placeholder={`Default: ${targetConsole?.hourlyRate || 0}`}
                value={customRate}
                onChange={(e) => setCustomRate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          )}

          {/* 2. Customer Selector / Creator */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300">Customer Details</label>
              <button
                type="button"
                onClick={() => setIsNewCustomer(!isNewCustomer)}
                className="text-xs text-cyan-400 hover:underline font-semibold cursor-pointer"
              >
                {isNewCustomer ? 'Choose Existing Player' : '+ Add New Player'}
              </button>
            </div>

            {isNewCustomer ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Player Full Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Vikram Seth"
                    value={newCustomerName}
                    onChange={(e) => setNewCustomerName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                    required={isNewCustomer}
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    placeholder="e.g. 9876543210"
                    value={newCustomerPhone}
                    onChange={(e) => setNewCustomerPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                    required={isNewCustomer}
                  />
                </div>
                {matchedExistingPlayer && (
                  <div className="sm:col-span-2 text-[11px] text-cyan-300 bg-cyan-950/40 border border-cyan-800/60 rounded-lg p-2 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                    <span>
                      Existing player detected: <strong>{matchedExistingPlayer.name}</strong> ({matchedExistingPlayer.phone}). This session will reuse their account without creating a duplicate.
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <select
                id="start-session-customer-select"
                value={selectedCustomerId}
                onChange={(e) => setSelectedCustomerId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                required={!isNewCustomer}
              >
                {uniqueCustomers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.phone}) — {c.totalVisits} visits
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Active Voucher Selection */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Ticket className="w-3.5 h-3.5 text-indigo-400" />
                <span>Apply Unused Time Credit / Vouchers</span>
              </label>
              <div className="flex gap-2">
                {availableCreditMinutes > 0 && (
                  <span className="text-[11px] text-cyan-400 font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/20">
                    {availableCreditMinutes}m Credit Available
                  </span>
                )}
                {activeCustomerVouchers.length > 0 && (
                  <span className="text-[11px] text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                    {activeCustomerVouchers.length} Vouchers
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-3">
              {/* Credit Selection */}
              {availableCreditMinutes > 0 && (
                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">Apply Unused Time Credit:</span>
                    <span className="text-[11px] font-bold text-cyan-400">{applyCreditMinutes}m / {availableCreditMinutes}m</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max={Math.min(availableCreditMinutes, effectivePlayMinutes)}
                    step="5"
                    value={applyCreditMinutes}
                    onChange={(e) => setApplyCreditMinutes(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                  />
                  <div className="flex justify-between">
                    <button
                      type="button"
                      onClick={() => setApplyCreditMinutes(0)}
                      className="text-[10px] text-slate-500 hover:text-white"
                    >
                      None
                    </button>
                    <button
                      type="button"
                      onClick={() => setApplyCreditMinutes(Math.min(availableCreditMinutes, effectivePlayMinutes))}
                      className="text-[10px] text-cyan-500 hover:text-cyan-400 font-bold"
                    >
                      Apply Max ({Math.min(availableCreditMinutes, effectivePlayMinutes)}m)
                    </button>
                  </div>
                </div>
              )}

              {/* Voucher Selection */}
              {activeCustomerVouchers.length > 0 ? (
                <div className="space-y-2">
                  <select
                    value={selectedVoucherId}
                    onChange={(e) => setSelectedVoucherId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="">-- No Voucher Selected --</option>
                    {activeCustomerVouchers.map((v) => {
                      const rem = v.remainingHours !== undefined ? v.remainingHours : ((v.durationMinutes - (v.usedMinutes || 0)) / 60);
                      return (
                        <option key={v.id} value={v.id}>
                          [{v.code}] {v.name} — {rem.toFixed(1)} hrs remaining
                        </option>
                      );
                    })}
                  </select>
                </div>
              ) : !availableCreditMinutes && (
                <div className="text-[11px] text-slate-500 italic">
                  No active credit or vouchers found for this customer.
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="confirm-start-session-btn"
              type="submit"
              disabled={isSubmitting || consoles.length === 0 || availableConsoles.length === 0 || !selectedConsoleId}
              className="bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm shadow-md shadow-cyan-500/20 transition-all disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Starting...' : 'Confirm & Start Session'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
