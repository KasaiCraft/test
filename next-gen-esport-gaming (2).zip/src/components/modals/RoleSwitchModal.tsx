import React, { useState } from 'react';
import {
  ShieldCheck,
  User,
  KeyRound,
  Eye,
  EyeOff,
  AlertCircle,
  X,
  Lock,
  ArrowRight,
  LogOut,
  RefreshCw,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCafe } from '../../context/CafeContext';

interface RoleSwitchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RoleSwitchModal: React.FC<RoleSwitchModalProps> = ({ isOpen, onClose }) => {
  const { verifiedRole, verifyRoleCode, switchRoleToStaff, clearRoleVerification, logout } = useAuth();
  const { database, settings } = useCafe();

  const [adminCode, setAdminCode] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [error, setError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  if (!isOpen) return null;

  const handleAdminVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsVerifying(true);

    try {
      const result = verifyRoleCode(
        'admin',
        adminCode,
        settings || database?.settings,
        database?.users || []
      );

      if (!result.success) {
        setError(result.error || 'Invalid Admin Code.');
        setIsVerifying(false);
        return;
      }

      setAdminCode('');
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Verification failed.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSwitchToStaff = () => {
    switchRoleToStaff();
    onClose();
  };

  const handleLockRole = () => {
    clearRoleVerification();
    onClose();
  };

  return (
    <div
      id="role-switch-modal-overlay"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div
        id="role-switch-modal"
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden"
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
            <RefreshCw className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Switch Terminal Mode</h3>
            <p className="text-xs text-slate-400">
              Current: <strong className="text-white uppercase">{verifiedRole === 'admin' ? 'Administrator' : 'Staff Counter'}</strong>
            </p>
          </div>
        </div>

        {verifiedRole === 'admin' ? (
          /* Admin can switch to Staff perspective */
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center gap-2 mb-1.5 text-emerald-400">
                <User className="w-4 h-4" />
                <h4 className="font-semibold text-sm">Staff Counter Perspective</h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Switch to Staff Panel view to experience the counter terminal interface with restricted reports, settings, and data center.
              </p>
            </div>

            <button
              id="switch-to-staff-btn"
              onClick={handleSwitchToStaff}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-bold text-xs sm:text-sm tracking-wide shadow-md shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <User className="w-4 h-4" />
              <span>Switch to Staff Mode</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          /* Staff needs Admin Code verification to escalate to Admin */
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center gap-2 mb-1 text-cyan-400">
                <ShieldCheck className="w-4 h-4" />
                <h4 className="font-semibold text-sm">Administrator Escalation</h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                To unlock the Administrator Panel, you must verify the Administrator Security Code.
              </p>
            </div>

            <form onSubmit={handleAdminVerify} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  Administrator Security Code
                </label>
                <div className="relative">
                  <input
                    id="admin-security-code-input"
                    type={showCode ? 'text' : 'password'}
                    value={adminCode}
                    onChange={(e) => {
                      setAdminCode(e.target.value);
                      setError('');
                    }}
                    placeholder="Enter Admin Access Code"
                    autoFocus
                    className="w-full bg-slate-950/80 border border-slate-700 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 rounded-xl px-4 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none transition-all pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCode(!showCode)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                    tabIndex={-1}
                  >
                    {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-2 text-rose-400 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <button
                id="verify-admin-code-submit-btn"
                type="submit"
                disabled={isVerifying || !adminCode.trim()}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold text-xs sm:text-sm tracking-wide shadow-md shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Lock className="w-4 h-4" />
                <span>Verify Admin Code & Unlock</span>
              </button>
            </form>
          </div>
        )}

        {/* Lock Role / Re-select Role option */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            onClick={handleLockRole}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
            <span>Lock Terminal Role</span>
          </button>

          <button
            onClick={() => {
              logout();
              onClose();
            }}
            className="flex items-center gap-1.5 text-xs text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out Firebase</span>
          </button>
        </div>
      </div>
    </div>
  );
};
