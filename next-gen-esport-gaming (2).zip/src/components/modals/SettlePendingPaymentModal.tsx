import React, { useState } from 'react';
import {
  X,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Clock,
  User,
  FileText,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { PaymentInputSection, PaymentInputData } from '../common/PaymentInputSection';

export interface SettlePendingTarget {
  type: 'session' | 'rental' | 'cafeteria' | 'payment' | 'repair' | 'buysell';
  referenceId: string;
  transactionId?: string;
  referenceTitle: string;
  customerId?: string;
  customerName?: string;
  totalBill: number;
  previouslyPaid: number;
  pendingAmount: number;
}

interface SettlePendingPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  target: SettlePendingTarget | null;
  onSuccess?: () => void;
}

export const SettlePendingPaymentModal: React.FC<SettlePendingPaymentModalProps> = ({
  isOpen,
  onClose,
  target,
  onSuccess,
}) => {
  const { settings, settlePendingPayment } = useCafe();
  const [paymentData, setPaymentData] = useState<PaymentInputData | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notes, setNotes] = useState('');

  if (!isOpen || !target) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentData || !paymentData.isValid) {
      setError(paymentData?.errorMessage || 'Please enter a valid payment amount.');
      return;
    }

    if (paymentData.paidAmount <= 0) {
      setError('Amount paid must be greater than zero.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const res = await settlePendingPayment({
        type: target.type,
        referenceId: target.referenceId,
        transactionId: target.transactionId,
        customerId: target.customerId,
        customerName: target.customerName,
        amountPaid: paymentData.paidAmount,
        paymentMethod: paymentData.paymentMethod,
        splitPayments: paymentData.splitPayments,
        notes: notes.trim() || undefined,
      });

      if (!res.success) {
        setError(res.error || 'Failed to record settlement.');
        setIsSubmitting(false);
        return;
      }

      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Error occurred while saving payment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div
        id="settle-pending-payment-modal"
        className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-150 my-8"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                Collect Pending Payment
              </h3>
              <p className="text-xs text-slate-400">
                Settle outstanding balance for customer
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Reference Info Card */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                Customer:
              </span>
              <span className="text-xs font-bold text-white">
                {target.customerName || 'Walk-in Customer'}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
                <FileText className="w-3.5 h-3.5 text-indigo-400" />
                Item / Order:
              </span>
              <span className="text-xs font-semibold text-slate-200 truncate max-w-[220px]">
                {target.referenceTitle}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-center">
              <div className="bg-slate-900/60 p-2 rounded-lg">
                <p className="text-[10px] uppercase font-semibold text-slate-400">Total Bill</p>
                <p className="text-xs font-bold text-slate-200 mt-0.5">
                  {settings.currencySymbol} {target.totalBill.toLocaleString('en-IN')}
                </p>
              </div>

              <div className="bg-slate-900/60 p-2 rounded-lg">
                <p className="text-[10px] uppercase font-semibold text-slate-400">Already Paid</p>
                <p className="text-xs font-bold text-emerald-400 mt-0.5">
                  {settings.currencySymbol} {target.previouslyPaid.toLocaleString('en-IN')}
                </p>
              </div>

              <div className="bg-amber-500/10 border border-amber-500/20 p-2 rounded-lg">
                <p className="text-[10px] uppercase font-bold text-amber-400">Balance Due</p>
                <p className="text-xs font-black text-amber-300 mt-0.5">
                  {settings.currencySymbol} {target.pendingAmount.toLocaleString('en-IN')}
                </p>
              </div>
            </div>
          </div>

          {/* Payment Input Section for collecting the pending amount */}
          <div className="bg-slate-950/40 p-1 rounded-xl">
            <PaymentInputSection
              totalBill={target.pendingAmount}
              currencySymbol={settings.currencySymbol}
              onChange={setPaymentData}
              defaultMode="single"
              defaultMethod="cash"
              initialPaidAmount={target.pendingAmount}
            />
          </div>

          {/* Optional Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Payment Settlement Note (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Settle remaining balance via GooglePay"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="confirm-settle-btn"
              disabled={isSubmitting || !paymentData?.isValid || (paymentData?.paidAmount || 0) <= 0}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Clock className="w-4 h-4 animate-spin" />
                  <span>Recording...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Confirm Settlement ({settings.currencySymbol}{' '}
                    {(paymentData?.paidAmount || 0).toLocaleString('en-IN')})
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
