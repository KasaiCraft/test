import React, { useState, useMemo } from 'react';
import {
  Database,
  Calendar as CalendarIcon,
  Search,
  ChevronLeft,
  ChevronRight,
  UserCheck,
  Gamepad2,
  Coffee,
  Package,
  Receipt,
  Download,
  Filter,
  ArrowUpDown,
  Clock,
  Phone,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Banknote,
  QrCode,
  DollarSign,
  TrendingUp,
  FileSpreadsheet,
  ChevronDown,
  ChevronUp,
  History,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { GamingSession, CafeteriaOrder, RentalRecord, PaymentTransaction, Customer } from '../../types';
import * as XLSX from 'xlsx';

// Helper to format Date into YYYY-MM-DD
const formatDateKey = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Helper to parse ISO string or timestamp into YYYY-MM-DD
const getRecordDateKey = (timestampStr?: string | number | null): string => {
  if (!timestampStr) return '';
  const d = new Date(timestampStr);
  if (isNaN(d.getTime())) return '';
  return formatDateKey(d);
};

// Helper to reliably parse any timestamp format (ISO string, epoch ms, epoch s, Firebase timestamp, Date) into milliseconds
const getRecordTimestampMs = (val: any): number | null => {
  if (!val) return null;
  if (typeof val === 'number') {
    return val < 10000000000 ? val * 1000 : val;
  }
  if (typeof val === 'object') {
    if (typeof val.seconds === 'number') return val.seconds * 1000;
    if (typeof val._seconds === 'number') return val._seconds * 1000;
    if (val instanceof Date) return val.getTime();
  }
  if (typeof val === 'string') {
    const d = new Date(val);
    if (!isNaN(d.getTime())) return d.getTime();
  }
  return null;
};

// Helper for human-readable time (e.g. 03:45 PM)
const formatTimeOnly = (timestampStr?: string | null): string => {
  if (!timestampStr) return '--:--';
  const d = new Date(timestampStr);
  if (isNaN(d.getTime())) return '--:--';
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
};

// Helper for human-readable full date
const formatDisplayDate = (dateKey: string): string => {
  if (!dateKey) return '';
  const [year, month, day] = dateKey.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

interface CustomerDayDossier {
  customerId: string;
  customerName: string;
  customerPhone: string;
  firstSeen: string;
  lastSeen: string;
  sessions: GamingSession[];
  cafeteriaOrders: CafeteriaOrder[];
  rentals: RentalRecord[];
  payments: PaymentTransaction[];
  totalGamingBill: number;
  totalCafeteriaBill: number;
  totalRentalBill: number;
  totalDayBill: number;
  totalPaid: number;
  paymentMethods: string[];
}

export const DataCenterView: React.FC = () => {
  const {
    sessions = [],
    cafeteriaOrders = [],
    rentalRecords = [],
    payments = [],
    customers = [],
    settings,
  } = useCafe();

  const currency = settings.currencySymbol || '₹';

  // Default to today's date
  const todayKey = useMemo(() => formatDateKey(new Date()), []);
  const [dateRange, setDateRange] = useState<{from: string, to: string}>({from: todayKey, to: todayKey});
  const [filterActive, setFilterActive] = useState(false);

  const displayDateRange = useMemo(() => {
    if (!filterActive) return 'All Records';
    if (dateRange.from === dateRange.to) {
      return `${formatDisplayDate(dateRange.from)} (Entire Day 00:00 - 23:59)`;
    }
    return `${formatDisplayDate(dateRange.from)} – ${formatDisplayDate(dateRange.to)} (Inclusive)`;
  }, [dateRange, filterActive]);

  // Search & Filter within the selected date range
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'visitors' | 'sessions' | 'cafeteria' | 'rentals' | 'payments'>('visitors');
  const [visitorFilter, setVisitorFilter] = useState<'all' | 'gaming' | 'cafeteria' | 'rentals' | 'due'>('all');

  // Comprehensive Date Range Check:
  // - If filterActive is false, show normal all data
  // - If filterActive is true, verify timestamp is >= From Date 00:00:00.000 and <= To Date 23:59:59.999
  // - Handles single-day full-day inclusion seamlessly
  const isDateInRange = (rawTimestampVal: any): boolean => {
    if (!filterActive) return true; // Normal all data when reset/cleared

    const ts = getRecordTimestampMs(rawTimestampVal);
    if (ts === null) return false;

    if (dateRange.from) {
      const [fy, fm, fd] = dateRange.from.split('-').map(Number);
      const startOfFrom = new Date(fy, fm - 1, fd, 0, 0, 0, 0).getTime();
      if (ts < startOfFrom) return false;
    }

    if (dateRange.to) {
      const [ty, tm, td] = dateRange.to.split('-').map(Number);
      const endOfTo = new Date(ty, tm - 1, td, 23, 59, 59, 999).getTime();
      if (ts > endOfTo) return false;
    }

    return true;
  };

  // Quick Preset Handlers
  const handleSetPreset = (preset: 'today' | 'yesterday' | 'week' | 'month' | 'all') => {
    const now = new Date();
    if (preset === 'today') {
      const tk = formatDateKey(now);
      setDateRange({ from: tk, to: tk });
      setFilterActive(true);
    } else if (preset === 'yesterday') {
      const y = new Date(now);
      y.setDate(now.getDate() - 1);
      const yk = formatDateKey(y);
      setDateRange({ from: yk, to: yk });
      setFilterActive(true);
    } else if (preset === 'week') {
      const day = now.getDay();
      const diffToMonday = (day === 0 ? -6 : 1) - day;
      const mon = new Date(now.getFullYear(), now.getMonth(), now.getDate() + diffToMonday);
      setDateRange({ from: formatDateKey(mon), to: formatDateKey(now) });
      setFilterActive(true);
    } else if (preset === 'month') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      setDateRange({ from: formatDateKey(firstDay), to: formatDateKey(now) });
      setFilterActive(true);
    } else if (preset === 'all') {
      setDateRange({ from: todayKey, to: todayKey });
      setFilterActive(false);
    }
  };

  // Expanded customer card IDs (all open by default or toggleable)
  const [expandedCustomers, setExpandedCustomers] = useState<Record<string, boolean>>({});

  // Toggle customer expansion
  const toggleCustomerExpand = (id: string) => {
    setExpandedCustomers((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // 1. Filter raw records for the selected date range
  const daySessions = useMemo(() => {
    return sessions.filter((s) => isDateInRange(s.startTime || s.createdAt));
  }, [sessions, dateRange, filterActive]);

  const dayCafeteriaOrders = useMemo(() => {
    return cafeteriaOrders.filter((o) => isDateInRange(o.createdAt));
  }, [cafeteriaOrders, dateRange, filterActive]);

  const dayRentals = useMemo(() => {
    return rentalRecords.filter((r) => isDateInRange(r.startTime || r.rentedAt || r.createdAt));
  }, [rentalRecords, dateRange, filterActive]);

  const dayPayments = useMemo(() => {
    return payments.filter((p) => isDateInRange(p.timestamp));
  }, [payments, dateRange, filterActive]);

  // 2. Build Customer Dossiers for Selected Range
  const customerDossiers = useMemo(() => {
    const map = new Map<string, CustomerDayDossier>();

    const getOrCreate = (id: string, name: string, phone?: string): CustomerDayDossier => {
      // Clean phone or ID as grouping key
      const key = (id && id !== 'guest') ? id : (phone && phone.trim() ? phone.trim() : (name || 'Guest'));
      if (!map.has(key)) {
        map.set(key, {
          customerId: id || key,
          customerName: name || 'Guest Player',
          customerPhone: phone || '',
          firstSeen: '',
          lastSeen: '',
          sessions: [],
          cafeteriaOrders: [],
          rentals: [],
          payments: [],
          totalGamingBill: 0,
          totalCafeteriaBill: 0,
          totalRentalBill: 0,
          totalDayBill: 0,
          totalPaid: 0,
          paymentMethods: [],
        });
      }
      const item = map.get(key)!;
      if (phone && !item.customerPhone) item.customerPhone = phone;
      if (name && item.customerName === 'Guest Player') item.customerName = name;
      return item;
    };

    // Process Sessions
    daySessions.forEach((s) => {
      const dossier = getOrCreate(s.customerId, s.customerName, s.customerPhone);
      dossier.sessions.push(s);
      dossier.totalGamingBill += Number(s.totalAmount || 0);
      dossier.totalPaid += Number(s.paidAmount || 0);

      const time = s.startTime || s.createdAt;
      if (time) {
        if (!dossier.firstSeen || time < dossier.firstSeen) dossier.firstSeen = time;
        if (!dossier.lastSeen || time > dossier.lastSeen) dossier.lastSeen = time;
      }
      if (s.paymentMethod && !dossier.paymentMethods.includes(s.paymentMethod)) {
        dossier.paymentMethods.push(s.paymentMethod);
      }
    });

    // Process Cafeteria Orders
    dayCafeteriaOrders.forEach((o) => {
      const dossier = getOrCreate(o.customerId, o.customerName, o.customerPhone);
      dossier.cafeteriaOrders.push(o);
      dossier.totalCafeteriaBill += Number(o.totalAmount || 0);
      dossier.totalPaid += Number(o.paidAmount || 0);

      const time = o.createdAt;
      if (time) {
        if (!dossier.firstSeen || time < dossier.firstSeen) dossier.firstSeen = time;
        if (!dossier.lastSeen || time > dossier.lastSeen) dossier.lastSeen = time;
      }
      if (o.paymentMethod && !dossier.paymentMethods.includes(o.paymentMethod)) {
        dossier.paymentMethods.push(o.paymentMethod);
      }
    });

    // Process Rentals
    dayRentals.forEach((r) => {
      const dossier = getOrCreate(r.customerId, r.customerName, r.customerPhone);
      dossier.rentals.push(r);
      const rentalFee = Number(r.rentalFee || 0);
      dossier.totalRentalBill += rentalFee;
      dossier.totalPaid += Number(r.totalPaid || r.paidAmount || 0);

      const time = r.startTime || r.rentedAt || r.createdAt;
      if (time) {
        if (!dossier.firstSeen || time < dossier.firstSeen) dossier.firstSeen = time;
        if (!dossier.lastSeen || time > dossier.lastSeen) dossier.lastSeen = time;
      }
      if (r.paymentMethod && !dossier.paymentMethods.includes(r.paymentMethod)) {
        dossier.paymentMethods.push(r.paymentMethod);
      }
    });

    // Process Payments
    dayPayments.forEach((p) => {
      const dossier = getOrCreate(p.customerId, p.customerName);
      dossier.payments.push(p);

      const time = p.timestamp;
      if (time) {
        if (!dossier.firstSeen || time < dossier.firstSeen) dossier.firstSeen = time;
        if (!dossier.lastSeen || time > dossier.lastSeen) dossier.lastSeen = time;
      }
      if (p.method && !dossier.paymentMethods.includes(p.method)) {
        dossier.paymentMethods.push(p.method);
      }
    });

    // Calculate total bills
    const list = Array.from(map.values());
    list.forEach((d) => {
      d.totalDayBill = d.totalGamingBill + d.totalCafeteriaBill + d.totalRentalBill;
    });

    // Sort by latest arrival time
    list.sort((a, b) => (b.firstSeen || '').localeCompare(a.firstSeen || ''));

    return list;
  }, [daySessions, dayCafeteriaOrders, dayRentals, dayPayments]);

  // 3. Filtered Customers based on search and sub-filter
  const filteredDossiers = useMemo(() => {
    let result = customerDossiers;

    // Filter by category
    if (visitorFilter === 'gaming') {
      result = result.filter((d) => d.sessions.length > 0);
    } else if (visitorFilter === 'cafeteria') {
      result = result.filter((d) => d.cafeteriaOrders.length > 0);
    } else if (visitorFilter === 'rentals') {
      result = result.filter((d) => d.rentals.length > 0);
    } else if (visitorFilter === 'due') {
      result = result.filter((d) => d.totalDayBill > d.totalPaid);
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter((d) => {
        const matchesName = d.customerName.toLowerCase().includes(q);
        const matchesPhone = d.customerPhone.toLowerCase().includes(q);
        const matchesConsole = d.sessions.some((s) => s.consoleCode.toLowerCase().includes(q));
        const matchesFood = d.cafeteriaOrders.some((o) =>
          o.items.some((i) => i.name.toLowerCase().includes(q))
        );
        const matchesRental = d.rentals.some((r) => r.rentalItemName.toLowerCase().includes(q));
        return matchesName || matchesPhone || matchesConsole || matchesFood || matchesRental;
      });
    }

    return result;
  }, [customerDossiers, visitorFilter, searchQuery]);

  // 4. Overall Day Totals
  const daySummary = useMemo(() => {
    const totalRevenue = dayPayments.reduce((acc, p) => acc + Number(p.amount || 0), 0);
    const gamingRevenue = daySessions.reduce((acc, s) => acc + Number(s.paidAmount || 0), 0);
    const cafeteriaRevenue = dayCafeteriaOrders.reduce((acc, o) => acc + Number(o.paidAmount || 0), 0);
    const rentalRevenue = dayRentals.reduce((acc, r) => acc + Number(r.rentalFee || 0), 0);

    const totalGamingMinutes = daySessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0);
    const totalCafeteriaItemsSold = dayCafeteriaOrders.reduce(
      (acc, o) => acc + o.items.reduce((sum, item) => sum + (item.quantity || 0), 0),
      0
    );

    return {
      totalVisitors: customerDossiers.length,
      totalRevenue,
      gamingRevenue,
      cafeteriaRevenue,
      rentalRevenue,
      totalSessions: daySessions.length,
      totalGamingMinutes,
      totalCafeteriaOrders: dayCafeteriaOrders.length,
      totalCafeteriaItemsSold,
      totalRentals: dayRentals.length,
      totalPaymentsCount: dayPayments.length,
    };
  }, [customerDossiers, dayPayments, daySessions, dayCafeteriaOrders, dayRentals]);

  // 5. Export this date's complete dossier to Excel (.xlsx)
  const exportDateToExcel = () => {
    const wb = XLSX.utils.book_new();

    // Sheet 1: Summary of the Date
    const summaryData = [
      ['Next Gen Gaming Cafe - Date Center Record', ''],
      ['Selected Date', displayDateRange],
      ['Formatted Date', displayDateRange],
      ['Total Unique Visitors', daySummary.totalVisitors],
      ['Total Revenue Collected', `${currency} ${daySummary.totalRevenue}`],
      ['Gaming Playtime Revenue', `${currency} ${daySummary.gamingRevenue}`],
      ['Cafeteria Sales Revenue', `${currency} ${daySummary.cafeteriaRevenue}`],
      ['Rentals Revenue', `${currency} ${daySummary.rentalRevenue}`],
      ['Total Sessions Logged', daySummary.totalSessions],
      ['Total Playtime Hours', `${Math.floor(daySummary.totalGamingMinutes / 60)}h ${daySummary.totalGamingMinutes % 60}m`],
      ['Total Food & Drink Orders', daySummary.totalCafeteriaOrders],
      ['Total Food Items Sold', daySummary.totalCafeteriaItemsSold],
      ['Total Gear Rentals', daySummary.totalRentals],
      ['Export Timestamp', new Date().toLocaleString('en-IN')],
    ];
    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    wsSummary['!cols'] = [{ wch: 28 }, { wch: 35 }];
    XLSX.utils.book_append_sheet(wb, wsSummary, 'Day_Summary');

    // Sheet 2: Visitors & Purchases (Kon Aya Aur Kya Kharida)
    const visitorRows = customerDossiers.map((d, index) => {
      const consolesPlayed = d.sessions
        .map((s) => `${s.consoleCode} (${s.durationMinutes || 0}m - ₹${s.totalAmount})`)
        .join('; ') || 'None';

      const foodItemsBought = d.cafeteriaOrders
        .flatMap((o) => o.items.map((i) => `${i.quantity}x ${i.name} (₹${i.totalPrice || (i.unitPrice * i.quantity)})`))
        .join('; ') || 'None';

      const gearRented = d.rentals
        .map((r) => `${r.rentalItemName} (Qty: ${r.quantity}, Fee: ₹${r.rentalFee})`)
        .join('; ') || 'None';

      return {
        'S.No': index + 1,
        'Customer Name': d.customerName,
        'Phone': d.customerPhone || 'N/A',
        'First Arrival Time': formatTimeOnly(d.firstSeen),
        'Consoles Played': consolesPlayed,
        'Food & Drinks Ordered': foodItemsBought,
        'Gear Rented': gearRented,
        'Gaming Bill (₹)': d.totalGamingBill,
        'Cafeteria Bill (₹)': d.totalCafeteriaBill,
        'Rental Bill (₹)': d.totalRentalBill,
        'Total Bill (₹)': d.totalDayBill,
        'Total Paid (₹)': d.totalPaid,
        'Pending (₹)': Math.max(0, d.totalDayBill - d.totalPaid),
        'Payment Methods': d.paymentMethods.join(', ') || 'N/A',
      };
    });

    const wsVisitors = visitorRows.length > 0
      ? XLSX.utils.json_to_sheet(visitorRows)
      : XLSX.utils.aoa_to_sheet([['No visitors recorded for this date']]);

    wsVisitors['!cols'] = [
      { wch: 6 },
      { wch: 20 },
      { wch: 15 },
      { wch: 18 },
      { wch: 32 },
      { wch: 40 },
      { wch: 25 },
      { wch: 15 },
      { wch: 16 },
      { wch: 15 },
      { wch: 14 },
      { wch: 14 },
      { wch: 14 },
      { wch: 20 },
    ];
    XLSX.utils.book_append_sheet(wb, wsVisitors, 'Visitors_Purchases');

    // Sheet 3: Gaming Sessions on this Date
    if (daySessions.length > 0) {
      const sessionRows = daySessions.map((s) => ({
        'Session ID': s.id,
        'Console': s.consoleCode,
        'Customer': s.customerName,
        'Phone': s.customerPhone || 'N/A',
        'Start Time': formatTimeOnly(s.startTime),
        'End Time': s.endTime ? formatTimeOnly(s.endTime) : 'Active',
        'Duration (Mins)': s.durationMinutes,
        'Rate/Hr (₹)': s.ratePerHour,
        'Total Amount (₹)': s.totalAmount,
        'Paid Amount (₹)': s.paidAmount,
        'Payment Method': s.paymentMethod || 'cash',
        'Status': s.status,
      }));
      const wsSessions = XLSX.utils.json_to_sheet(sessionRows);
      wsSessions['!cols'] = [
        { wch: 14 },
        { wch: 10 },
        { wch: 18 },
        { wch: 14 },
        { wch: 12 },
        { wch: 12 },
        { wch: 15 },
        { wch: 12 },
        { wch: 16 },
        { wch: 15 },
        { wch: 15 },
        { wch: 12 },
      ];
      XLSX.utils.book_append_sheet(wb, wsSessions, 'Gaming_Sessions');
    }

    // Sheet 4: Cafeteria Orders on this Date
    if (dayCafeteriaOrders.length > 0) {
      const foodRows = dayCafeteriaOrders.map((o) => ({
        'Order ID': o.id,
        'Customer': o.customerName,
        'Phone': o.customerPhone || 'N/A',
        'Items Ordered': o.items.map((i) => `${i.quantity}x ${i.name} (₹${i.totalPrice || (i.unitPrice * i.quantity)})`).join('; '),
        'Order Time': formatTimeOnly(o.createdAt),
        'Subtotal (₹)': o.subtotal,
        'Discount (₹)': o.discountAmount,
        'Total Amount (₹)': o.totalAmount,
        'Paid Amount (₹)': o.paidAmount,
        'Payment Method': o.paymentMethod || 'cash',
        'Status': o.status,
      }));
      const wsFood = XLSX.utils.json_to_sheet(foodRows);
      wsFood['!cols'] = [
        { wch: 14 },
        { wch: 18 },
        { wch: 14 },
        { wch: 40 },
        { wch: 12 },
        { wch: 14 },
        { wch: 14 },
        { wch: 16 },
        { wch: 15 },
        { wch: 15 },
        { wch: 12 },
      ];
      XLSX.utils.book_append_sheet(wb, wsFood, 'Cafeteria_Orders');
    }

    // Sheet 5: Rentals on this Date
    if (dayRentals.length > 0) {
      const rentalRows = dayRentals.map((r) => ({
        'Record ID': r.id,
        'Item Name': r.rentalItemName,
        'Customer': r.customerName,
        'Phone': r.customerPhone,
        'Quantity': r.quantity,
        'Start Time': formatTimeOnly(r.startTime),
        'Return Time': r.actualReturnTime ? formatTimeOnly(r.actualReturnTime) : 'Out',
        'Rental Fee (₹)': r.rentalFee,
        'Deposit (₹)': r.depositAmount,
        'Deposit Refunded (₹)': r.depositRefunded,
        'Status': r.status,
      }));
      const wsRentals = XLSX.utils.json_to_sheet(rentalRows);
      wsRentals['!cols'] = [
        { wch: 14 },
        { wch: 20 },
        { wch: 18 },
        { wch: 14 },
        { wch: 10 },
        { wch: 12 },
        { wch: 12 },
        { wch: 14 },
        { wch: 14 },
        { wch: 18 },
        { wch: 12 },
      ];
      XLSX.utils.book_append_sheet(wb, wsRentals, 'Rentals');
    }

    // Sheet 6: Payments on this Date
    if (dayPayments.length > 0) {
      const payRows = dayPayments.map((p) => ({
        'Payment ID': p.id,
        'Customer': p.customerName,
        'Type': p.type,
        'Reference': p.referenceTitle,
        'Method': p.method,
        'Amount (₹)': p.amount,
        'Time': formatTimeOnly(p.timestamp),
        'Recorded By': p.recordedBy,
      }));
      const wsPayments = XLSX.utils.json_to_sheet(payRows);
      wsPayments['!cols'] = [
        { wch: 14 },
        { wch: 18 },
        { wch: 16 },
        { wch: 25 },
        { wch: 12 },
        { wch: 14 },
        { wch: 12 },
        { wch: 16 },
      ];
      XLSX.utils.book_append_sheet(wb, wsPayments, 'Payments_Ledger');
    }

    const exportFileName = filterActive
      ? `NextGen_Esport_DataCenter_${dateRange.from}_to_${dateRange.to}.xlsx`
      : `NextGen_Esport_DataCenter_All_Records.xlsx`;
    XLSX.writeFile(wb, exportFileName);
  };

  return (
    <div id="data-center-view" className="space-y-6 pb-16">
      {/* Top Banner & Date Picker Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl backdrop-blur-md">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          {/* Header Title */}
          <div>
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 rounded-2xl text-cyan-400 shadow-sm">
                <Database className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  <span>Data Center</span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/60 font-semibold uppercase tracking-wider">
                    Date-Wise Archive
                  </span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                  Check who visited on any date, what games they played, what they ordered, and payment details.
                </p>
              </div>
            </div>
          </div>

          {/* Date Selector Navigation Controls */}
          <div className="flex flex-wrap items-center gap-2.5 bg-slate-950/90 p-2 sm:p-2.5 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-700/80">
              <span className="text-[10px] uppercase font-bold text-slate-400">From Date</span>
              <input
                id="datacenter-from-date"
                type="date"
                value={dateRange.from}
                onChange={(e) => setDateRange((prev) => ({ ...prev, from: e.target.value }))}
                className="bg-transparent text-white font-bold text-xs sm:text-sm focus:outline-none cursor-pointer"
              />
            </div>

            <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-700/80">
              <span className="text-[10px] uppercase font-bold text-slate-400">To Date</span>
              <input
                id="datacenter-to-date"
                type="date"
                value={dateRange.to}
                onChange={(e) => setDateRange((prev) => ({ ...prev, to: e.target.value }))}
                className="bg-transparent text-white font-bold text-xs sm:text-sm focus:outline-none cursor-pointer"
              />
            </div>

            <button
              id="apply-view-data-btn"
              onClick={() => {
                if (dateRange.from && dateRange.to && dateRange.from > dateRange.to) {
                  alert('Invalid date range: "From Date" must be earlier than or equal to "To Date".');
                  return;
                }
                setFilterActive(true);
              }}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white transition-all shadow-md shadow-cyan-950/40 cursor-pointer flex items-center gap-1.5"
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Apply / View Data</span>
            </button>

            <button
              id="clear-reset-filter-btn"
              onClick={() => handleSetPreset('all')}
              className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 transition-all cursor-pointer"
            >
              Clear / Reset Filter
            </button>

            {/* Export Day to Excel */}
            <button
              id="export-date-excel-btn"
              onClick={exportDateToExcel}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl transition-all shadow-md shadow-emerald-900/30 ml-auto"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span className="hidden sm:inline">Export Excel</span>
            </button>
          </div>
        </div>

        {/* Selected Date Formatted Bar with Quick History Presets */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-500 font-medium">Viewing Data:</span>
            <span className="font-bold text-cyan-300 text-sm">{displayDateRange}</span>
            {filterActive && (
              <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase">
                Date Range Filter Applied
              </span>
            )}
            {!filterActive && (
              <span className="bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded-full text-[10px] font-medium">
                Unfiltered (All Records)
              </span>
            )}
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar py-1">
            <span className="text-[11px] text-slate-500 shrink-0 font-medium">Presets:</span>
            <button
              type="button"
              onClick={() => handleSetPreset('today')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                filterActive && dateRange.from === todayKey && dateRange.to === todayKey
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'bg-slate-800/70 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              Today
            </button>
            <button
              type="button"
              onClick={() => handleSetPreset('yesterday')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-slate-800/70 text-slate-400 hover:text-slate-200 border border-slate-800 transition-all"
            >
              Yesterday
            </button>
            <button
              type="button"
              onClick={() => handleSetPreset('week')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-slate-800/70 text-slate-400 hover:text-slate-200 border border-slate-800 transition-all"
            >
              This Week
            </button>
            <button
              type="button"
              onClick={() => handleSetPreset('month')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-slate-800/70 text-slate-400 hover:text-slate-200 border border-slate-800 transition-all"
            >
              This Month
            </button>
            <button
              type="button"
              onClick={() => handleSetPreset('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                !filterActive
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-slate-800/70 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              All Records
            </button>
          </div>
        </div>
      </div>

      {/* Bento Grid: Day Key Performance Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Visitors */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs uppercase font-bold text-slate-400">Total Visitors</span>
            <UserCheck className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-black text-white mt-1">{daySummary.totalVisitors}</p>
          <p className="text-[11px] text-slate-500 mt-1">Unique persons visited</p>
        </div>

        {/* Total Day Revenue */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs uppercase font-bold text-slate-400">Total Revenue</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-400 mt-1">
            {currency} {daySummary.totalRevenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Actual collected income</p>
        </div>

        {/* Gaming Revenue & Playtime */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs uppercase font-bold text-slate-400">Gaming Play</span>
            <Gamepad2 className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-2xl font-black text-blue-400 mt-1">
            {currency} {daySummary.gamingRevenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            {daySummary.totalSessions} sessions ({Math.floor(daySummary.totalGamingMinutes / 60)}h {daySummary.totalGamingMinutes % 60}m)
          </p>
        </div>

        {/* Cafeteria Sales */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs uppercase font-bold text-slate-400">Cafeteria Food</span>
            <Coffee className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-400 mt-1">
            {currency} {daySummary.cafeteriaRevenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            {daySummary.totalCafeteriaOrders} orders ({daySummary.totalCafeteriaItemsSold} items)
          </p>
        </div>

        {/* Gear Rentals */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs uppercase font-bold text-slate-400">Gear Rentals</span>
            <Package className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-black text-purple-400 mt-1">
            {currency} {daySummary.rentalRevenue.toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">{daySummary.totalRentals} rentals issued</p>
        </div>

        {/* Total Payments Recorded */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs uppercase font-bold text-slate-400">Transactions</span>
            <Receipt className="w-4 h-4 text-teal-400" />
          </div>
          <p className="text-2xl font-black text-white mt-1">{daySummary.totalPaymentsCount}</p>
          <p className="text-[11px] text-slate-500 mt-1">Receipts recorded</p>
        </div>
      </div>

      {/* Main Tabs Header & Search Filter */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar pb-1 md:pb-0">
          <button
            id="tab-visitors"
            onClick={() => setActiveTab('visitors')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'visitors'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Visitors & Purchases ({customerDossiers.length})</span>
          </button>

          <button
            id="tab-sessions"
            onClick={() => setActiveTab('sessions')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'sessions'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Gamepad2 className="w-4 h-4" />
            <span>Gaming ({daySessions.length})</span>
          </button>

          <button
            id="tab-cafeteria"
            onClick={() => setActiveTab('cafeteria')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'cafeteria'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Coffee className="w-4 h-4" />
            <span>Cafeteria ({dayCafeteriaOrders.length})</span>
          </button>

          <button
            id="tab-rentals"
            onClick={() => setActiveTab('rentals')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'rentals'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Rentals ({dayRentals.length})</span>
          </button>

          <button
            id="tab-payments"
            onClick={() => setActiveTab('payments')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'payments'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Payments ({dayPayments.length})</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative min-w-[240px] lg:w-72">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="data-center-search-input"
            type="text"
            placeholder="Search visitor, phone, item..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/80 border border-slate-800 text-white placeholder-slate-500 text-xs sm:text-sm rounded-xl pl-9 pr-3.5 py-2 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* TAB 1: VISITORS & WHAT THEY BOUGHT (Kon Aya & Kya Buy Kiya) */}
      {activeTab === 'visitors' && (
        <div className="space-y-4">
          {/* Sub Filter Chips */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-slate-500 font-medium">Filter Visitors:</span>
              {(['all', 'gaming', 'cafeteria', 'rentals', 'due'] as const).map((filterType) => (
                <button
                  key={filterType}
                  onClick={() => setVisitorFilter(filterType)}
                  className={`px-3 py-1.5 rounded-lg capitalize font-semibold transition-all ${
                    visitorFilter === filterType
                      ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {filterType === 'all'
                    ? 'All Visitors'
                    : filterType === 'gaming'
                    ? 'Gaming Players'
                    : filterType === 'cafeteria'
                    ? 'Food Buyers'
                    : filterType === 'rentals'
                    ? 'Gear Renters'
                    : 'Pending Due'}
                </button>
              ))}
            </div>

            <span className="text-xs text-slate-400 font-medium">
              Showing <span className="text-cyan-400 font-bold">{filteredDossiers.length}</span> of{' '}
              {customerDossiers.length} visitors
            </span>
          </div>

          {/* If No Visitors on this date */}
          {filteredDossiers.length === 0 ? (
            <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center">
              <div className="w-16 h-16 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center mx-auto mb-4 text-slate-400">
                <UserCheck className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-white">No visitors found for {displayDateRange}</h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md mx-auto">
                {searchQuery || visitorFilter !== 'all'
                  ? 'No visitors matched your search or filter. Try clearing the filters.'
                  : 'There are no sessions, cafeteria orders, or payments recorded on this date. You can select another date using the date picker above.'}
              </p>
            </div>
          ) : (
            /* Visitor Cards List */
            <div className="grid grid-cols-1 gap-4">
              {filteredDossiers.map((dossier, idx) => {
                const isExpanded = expandedCustomers[dossier.customerId] ?? true;
                const isPaid = dossier.totalPaid >= dossier.totalDayBill;
                const pendingAmount = Math.max(0, dossier.totalDayBill - dossier.totalPaid);

                return (
                  <div
                    key={`${dossier.customerId}-${idx}`}
                    className="bg-slate-900/90 border border-slate-800 hover:border-slate-700/80 rounded-2xl overflow-hidden shadow-lg transition-all"
                  >
                    {/* Visitor Card Header */}
                    <div
                      onClick={() => toggleCustomerExpand(dossier.customerId)}
                      className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition-colors"
                    >
                      {/* Left: Avatar, Name, Phone & Arrival */}
                      <div className="flex items-center gap-3.5">
                        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center text-white font-black text-lg shadow-md shrink-0">
                          {dossier.customerName.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-base sm:text-lg font-bold text-white hover:text-cyan-400 transition-colors">
                              {dossier.customerName}
                            </h3>
                            {isPaid ? (
                              <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3 h-3" />
                                Paid
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 text-[11px] font-bold text-rose-400 bg-rose-500/10 border border-rose-500/30 px-2 py-0.5 rounded-full">
                                <AlertCircle className="w-3 h-3" />
                                Due {currency} {pendingAmount}
                              </span>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
                            {dossier.customerPhone && (
                              <span className="flex items-center gap-1">
                                <Phone className="w-3.5 h-3.5 text-slate-500" />
                                {dossier.customerPhone}
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-slate-500" />
                              Arrived: <strong className="text-slate-300">{formatTimeOnly(dossier.firstSeen)}</strong>
                            </span>
                            {dossier.paymentMethods.length > 0 && (
                              <span className="flex items-center gap-1 text-slate-500">
                                <span>via</span>
                                <span className="uppercase font-semibold text-slate-300">
                                  {dossier.paymentMethods.join(', ')}
                                </span>
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Quick Purchase Badges & Total Bill */}
                      <div className="flex items-center justify-between md:justify-end gap-5">
                        {/* Summary Badges of what they used */}
                        <div className="flex items-center gap-2">
                          {dossier.sessions.length > 0 && (
                            <span
                              title={`${dossier.sessions.length} Gaming Sessions`}
                              className="flex items-center gap-1 text-xs bg-blue-950/80 border border-blue-800 text-blue-300 px-2.5 py-1 rounded-xl font-medium"
                            >
                              <Gamepad2 className="w-3.5 h-3.5" />
                              <span>{dossier.sessions.length} Sessions</span>
                            </span>
                          )}
                          {dossier.cafeteriaOrders.length > 0 && (
                            <span
                              title={`${dossier.cafeteriaOrders.length} Food Orders`}
                              className="flex items-center gap-1 text-xs bg-amber-950/80 border border-amber-800 text-amber-300 px-2.5 py-1 rounded-xl font-medium"
                            >
                              <Coffee className="w-3.5 h-3.5" />
                              <span>{dossier.cafeteriaOrders.length} Orders</span>
                            </span>
                          )}
                          {dossier.rentals.length > 0 && (
                            <span
                              title={`${dossier.rentals.length} Rentals`}
                              className="flex items-center gap-1 text-xs bg-purple-950/80 border border-purple-800 text-purple-300 px-2.5 py-1 rounded-xl font-medium"
                            >
                              <Package className="w-3.5 h-3.5" />
                              <span>{dossier.rentals.length} Gear</span>
                            </span>
                          )}
                        </div>

                        {/* Bill Info */}
                        <div className="text-right">
                          <p className="text-[11px] uppercase font-bold text-slate-400">Total Day Bill</p>
                          <p className="text-lg sm:text-xl font-black text-cyan-400">
                            {currency} {dossier.totalDayBill.toLocaleString('en-IN')}
                          </p>
                        </div>

                        {/* Expand/Collapse Chevron */}
                        <div className="text-slate-400 hover:text-white p-1">
                          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                        </div>
                      </div>
                    </div>

                    {/* Detailed Purchase Breakdown (Kya Kya Buy Kiya) */}
                    {isExpanded && (
                      <div className="p-4 sm:p-5 bg-slate-950/70 border-t border-slate-800/80 space-y-4">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                          {/* 1. Gaming Sessions */}
                          <div className="bg-slate-900/90 border border-slate-800/90 rounded-xl p-3.5">
                            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                              <span className="text-xs font-bold text-blue-400 flex items-center gap-1.5 uppercase">
                                <Gamepad2 className="w-4 h-4" />
                                Gaming Consoles ({dossier.sessions.length})
                              </span>
                              <span className="text-xs font-bold text-slate-300">
                                {currency} {dossier.totalGamingBill}
                              </span>
                            </div>

                            {dossier.sessions.length === 0 ? (
                              <p className="text-xs text-slate-500 italic py-2">No gaming sessions on this date.</p>
                            ) : (
                              <div className="space-y-2">
                                {dossier.sessions.map((s) => (
                                  <div
                                    key={s.id}
                                    className="bg-slate-950/80 border border-slate-800/60 p-2.5 rounded-lg flex items-center justify-between text-xs"
                                  >
                                    <div>
                                      <div className="flex items-center gap-1.5 font-bold text-white">
                                        <span className="px-1.5 py-0.5 bg-blue-900/60 text-blue-300 rounded font-mono text-[11px]">
                                          {s.consoleCode}
                                        </span>
                                        <span>{s.durationMinutes} mins</span>
                                      </div>
                                      <p className="text-[11px] text-slate-400 mt-0.5">
                                        {formatTimeOnly(s.startTime)} - {s.endTime ? formatTimeOnly(s.endTime) : 'Active'}
                                      </p>
                                    </div>
                                    <div className="text-right">
                                      <p className="font-bold text-cyan-300">{currency} {s.totalAmount}</p>
                                      <p className="text-[10px] text-slate-500 capitalize">{s.paymentMethod || 'cash'}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* 2. Cafeteria Orders (Food & Drinks Bought) */}
                          <div className="bg-slate-900/90 border border-slate-800/90 rounded-xl p-3.5">
                            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5 uppercase">
                                <Coffee className="w-4 h-4" />
                                Cafeteria Purchases ({dossier.cafeteriaOrders.length})
                              </span>
                              <span className="text-xs font-bold text-slate-300">
                                {currency} {dossier.totalCafeteriaBill}
                              </span>
                            </div>

                            {dossier.cafeteriaOrders.length === 0 ? (
                              <p className="text-xs text-slate-500 italic py-2">No food or drink orders on this date.</p>
                            ) : (
                              <div className="space-y-2.5">
                                {dossier.cafeteriaOrders.map((order) => (
                                  <div
                                    key={order.id}
                                    className="bg-slate-950/80 border border-slate-800/60 p-2.5 rounded-lg text-xs"
                                  >
                                    <div className="flex items-center justify-between font-bold pb-1.5 border-b border-slate-800/60 text-[11px] text-slate-400">
                                      <span>Time: {formatTimeOnly(order.createdAt)}</span>
                                      <span className="text-amber-400">{currency} {order.totalAmount}</span>
                                    </div>
                                    <div className="mt-1.5 space-y-1">
                                      {order.items.map((item, iIdx) => (
                                        <div
                                          key={`${item.itemId}-${iIdx}`}
                                          className="flex items-center justify-between text-[11px] text-slate-300"
                                        >
                                          <span>
                                            <strong className="text-amber-300">{item.quantity}x</strong> {item.name}
                                          </span>
                                          <span className="text-slate-400 font-mono">
                                            {currency} {item.totalPrice || item.unitPrice * item.quantity}
                                          </span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* 3. Gear Rentals & Payments Ledger */}
                          <div className="bg-slate-900/90 border border-slate-800/90 rounded-xl p-3.5">
                            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                              <span className="text-xs font-bold text-purple-400 flex items-center gap-1.5 uppercase">
                                <Package className="w-4 h-4" />
                                Gear Rentals ({dossier.rentals.length})
                              </span>
                              <span className="text-xs font-bold text-slate-300">
                                {currency} {dossier.totalRentalBill}
                              </span>
                            </div>

                            {dossier.rentals.length === 0 ? (
                              <p className="text-xs text-slate-500 italic py-2">No gear rented on this date.</p>
                            ) : (
                              <div className="space-y-2">
                                {dossier.rentals.map((r) => (
                                  <div
                                    key={r.id}
                                    className="bg-slate-950/80 border border-slate-800/60 p-2.5 rounded-lg flex items-center justify-between text-xs"
                                  >
                                    <div>
                                      <p className="font-bold text-white">{r.rentalItemName}</p>
                                      <p className="text-[11px] text-slate-400">
                                        Qty: {r.quantity} | Time: {formatTimeOnly(r.startTime)}
                                      </p>
                                    </div>
                                    <div className="text-right">
                                      <p className="font-bold text-purple-300">{currency} {r.rentalFee}</p>
                                      <p className="text-[10px] text-slate-500">Deposit: {currency} {r.depositAmount}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Payment Transactions Recorded for this customer on this date */}
                            {dossier.payments.length > 0 && (
                              <div className="mt-3 pt-3 border-t border-slate-800">
                                <p className="text-[11px] uppercase font-bold text-slate-400 mb-1.5 flex items-center gap-1">
                                  <Receipt className="w-3.5 h-3.5 text-teal-400" />
                                  Payments Collected ({dossier.payments.length})
                                </p>
                                <div className="space-y-1">
                                  {dossier.payments.map((p) => (
                                    <div
                                      key={p.id}
                                      className="flex items-center justify-between text-[11px] bg-slate-950/60 p-1.5 rounded"
                                    >
                                      <span className="text-slate-400">
                                        {formatTimeOnly(p.timestamp)} via <strong className="text-white uppercase">{p.method}</strong>
                                      </span>
                                      <span className="font-bold text-emerald-400">{currency} {p.amount}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: GAMING SESSIONS LOG FOR THIS DATE */}
      {activeTab === 'sessions' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
              <Gamepad2 className="w-5 h-5 text-blue-400" />
              <span>All Gaming Sessions on {displayDateRange}</span>
            </h3>
            <span className="text-xs text-slate-400 font-semibold">{daySessions.length} total sessions</span>
          </div>

          {daySessions.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              No gaming sessions recorded on {displayDateRange}.
            </div>
          ) : (
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                    <th className="py-3 px-4">Console</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Start Time</th>
                    <th className="py-3 px-4">End Time</th>
                    <th className="py-3 px-4">Duration</th>
                    <th className="py-3 px-4">Rate/Hr</th>
                    <th className="py-3 px-4">Total Bill</th>
                    <th className="py-3 px-4">Paid</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {daySessions.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-cyan-400">{s.consoleCode}</td>
                      <td className="py-3 px-4 font-medium text-white">{s.customerName}</td>
                      <td className="py-3 px-4 text-slate-400">{formatTimeOnly(s.startTime)}</td>
                      <td className="py-3 px-4 text-slate-400">{s.endTime ? formatTimeOnly(s.endTime) : 'Active'}</td>
                      <td className="py-3 px-4 font-semibold text-slate-200">{s.durationMinutes} mins</td>
                      <td className="py-3 px-4 text-slate-400">{currency} {s.ratePerHour}</td>
                      <td className="py-3 px-4 font-bold text-white">{currency} {s.totalAmount}</td>
                      <td className="py-3 px-4 font-semibold text-emerald-400">{currency} {s.paidAmount}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            s.status === 'completed'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: CAFETERIA ORDERS LOG FOR THIS DATE */}
      {activeTab === 'cafeteria' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
              <Coffee className="w-5 h-5 text-amber-400" />
              <span>Cafeteria Sales & Orders on {displayDateRange}</span>
            </h3>
            <span className="text-xs text-slate-400 font-semibold">{dayCafeteriaOrders.length} total orders</span>
          </div>

          {dayCafeteriaOrders.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              No cafeteria orders recorded on {displayDateRange}.
            </div>
          ) : (
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                    <th className="py-3 px-4">Time</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Phone</th>
                    <th className="py-3 px-4">Items Ordered</th>
                    <th className="py-3 px-4">Total Bill</th>
                    <th className="py-3 px-4">Paid Amount</th>
                    <th className="py-3 px-4">Method</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {dayCafeteriaOrders.map((o) => (
                    <tr key={o.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-400">{formatTimeOnly(o.createdAt)}</td>
                      <td className="py-3 px-4 font-bold text-white">{o.customerName}</td>
                      <td className="py-3 px-4 text-slate-400">{o.customerPhone || 'N/A'}</td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1">
                          {o.items.map((i, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 bg-amber-950/60 text-amber-300 border border-amber-800/60 rounded text-[11px]"
                            >
                              {i.quantity}x {i.name}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-bold text-white">{currency} {o.totalAmount}</td>
                      <td className="py-3 px-4 font-semibold text-emerald-400">{currency} {o.paidAmount}</td>
                      <td className="py-3 px-4 uppercase text-slate-300 font-mono text-[11px]">{o.paymentMethod}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full text-[10px] font-bold uppercase">
                          {o.paymentStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: RENTALS LOG FOR THIS DATE */}
      {activeTab === 'rentals' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
              <Package className="w-5 h-5 text-purple-400" />
              <span>Gear Rentals on {displayDateRange}</span>
            </h3>
            <span className="text-xs text-slate-400 font-semibold">{dayRentals.length} total rentals</span>
          </div>

          {dayRentals.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              No gear rentals recorded on {displayDateRange}.
            </div>
          ) : (
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                    <th className="py-3 px-4">Item</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Phone</th>
                    <th className="py-3 px-4">Qty</th>
                    <th className="py-3 px-4">Start Time</th>
                    <th className="py-3 px-4">Return Time</th>
                    <th className="py-3 px-4">Rental Fee</th>
                    <th className="py-3 px-4">Deposit</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {dayRentals.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-bold text-white">{r.rentalItemName}</td>
                      <td className="py-3 px-4 font-medium text-slate-200">{r.customerName}</td>
                      <td className="py-3 px-4 text-slate-400">{r.customerPhone}</td>
                      <td className="py-3 px-4 font-mono font-bold text-purple-400">{r.quantity}</td>
                      <td className="py-3 px-4 text-slate-400">{formatTimeOnly(r.startTime)}</td>
                      <td className="py-3 px-4 text-slate-400">{r.actualReturnTime ? formatTimeOnly(r.actualReturnTime) : 'Out'}</td>
                      <td className="py-3 px-4 font-bold text-white">{currency} {r.rentalFee}</td>
                      <td className="py-3 px-4 font-semibold text-slate-300">{currency} {r.depositAmount}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            r.status === 'returned'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: PAYMENTS REGISTER FOR THIS DATE */}
      {activeTab === 'payments' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
              <Receipt className="w-5 h-5 text-teal-400" />
              <span>Payments Ledger on {displayDateRange}</span>
            </h3>
            <span className="text-xs text-slate-400 font-semibold">{dayPayments.length} transactions</span>
          </div>

          {dayPayments.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              No payments recorded on {displayDateRange}.
            </div>
          ) : (
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                    <th className="py-3 px-4">Time</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Payment For</th>
                    <th className="py-3 px-4">Method</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Staff</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {dayPayments.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-400">{formatTimeOnly(p.timestamp)}</td>
                      <td className="py-3 px-4 font-bold text-white">{p.customerName}</td>
                      <td className="py-3 px-4 text-slate-300 font-medium">{p.referenceTitle || p.type}</td>
                      <td className="py-3 px-4 font-mono uppercase text-xs">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700">
                          {p.method}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-bold text-emerald-400">{currency} {p.amount}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full text-[10px] font-bold uppercase">
                          {p.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-xs">{p.recordedBy || 'Staff'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
