import React, { useState, useMemo } from 'react';
import {
  Users,
  Plus,
  Search,
  Phone,
  Mail,
  Gamepad2,
  Package,
  Clock,
  ChevronRight,
  UserPlus,
  Edit2,
  Trash2,
  Receipt,
  AlertCircle,
  Sparkles,
  Calendar,
  Coffee,
  Banknote,
  CheckCircle2,
  Printer,
  QrCode,
  CreditCard,
  TrendingUp,
  ShieldCheck,
  MapPin,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { Customer, GamingSession, RentalRecord, CafeteriaOrder, PaymentTransaction } from '../../types';
import { SettlePendingPaymentModal, SettlePendingTarget } from '../modals/SettlePendingPaymentModal';

// Helper to mask sensitive information for staff display
const maskSensitiveValue = (val: string | undefined) => {
  if (!val) return '';
  const clean = val.trim();
  if (clean.length <= 4) return clean;
  const last4 = clean.slice(-4);
  const prefix = clean.slice(0, -4).replace(/[0-9a-zA-Z]/g, 'X');
  return prefix + last4;
};

interface CustomersViewProps {
  onOpenCustomerModal: (customerToEdit?: Customer) => void;
  onOpenStartSessionWithCustomer: (customer: Customer) => void;
  onOpenNewRentalWithCustomer: (customer: Customer) => void;
  onOpenReceiptModal?: (transaction: PaymentTransaction) => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  onOpenCustomerModal,
  onOpenStartSessionWithCustomer,
  onOpenNewRentalWithCustomer,
  onOpenReceiptModal,
}) => {
  const {
    customers,
    sessions,
    rentalRecords,
    cafeteriaOrders,
    payments,
    isAdmin,
    settings,
    deleteCustomer,
  } = useCafe();

  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'sessions' | 'rentals' | 'cafeteria' | 'payments'>('all');

  // Settlement modal state
  const [settleTarget, setSettleTarget] = useState<SettlePendingTarget | null>(null);
  const [isSettleModalOpen, setIsSettleModalOpen] = useState(false);

  // Deduplicate customers by unique ID and phone
  const uniqueCustomers = useMemo(() => {
    const seenIds = new Set<string>();
    const seenPhones = new Set<string>();
    const list: Customer[] = [];

    for (const c of customers) {
      if (!c || !c.id) continue;
      const cleanPhone = (c.phone || '').trim().replace(/[\s\-()]/g, '');
      if (seenIds.has(c.id)) continue;
      if (cleanPhone && seenPhones.has(cleanPhone)) continue;

      seenIds.add(c.id);
      if (cleanPhone) seenPhones.add(cleanPhone);
      list.push(c);
    }
    return list;
  }, [customers]);

  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(
    uniqueCustomers.length > 0 ? uniqueCustomers[0].id : null
  );

  const filteredCustomers = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return uniqueCustomers;
    return uniqueCustomers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.includes(q) ||
        (c.email && c.email.toLowerCase().includes(q)) ||
        (c.membershipId && c.membershipId.toLowerCase().includes(q))
    );
  }, [uniqueCustomers, searchQuery]);

  const selectedCustomer =
    uniqueCustomers.find((c) => c.id === selectedCustomerId) || filteredCustomers[0];

  // Customer activity records
  const customerSessions = useMemo(() => {
    if (!selectedCustomer) return [];
    return sessions
      .filter((s) => s.customerId === selectedCustomer.id)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }, [sessions, selectedCustomer]);

  const customerRentals = useMemo(() => {
    if (!selectedCustomer) return [];
    return rentalRecords
      .filter((r) => r.customerId === selectedCustomer.id)
      .sort((a, b) => new Date(b.rentedAt || b.startTime || b.createdAt).getTime() - new Date(a.rentedAt || a.startTime || a.createdAt).getTime());
  }, [rentalRecords, selectedCustomer]);

  const customerOrders = useMemo(() => {
    if (!selectedCustomer) return [];
    return cafeteriaOrders
      .filter((o) => o.customerId === selectedCustomer.id)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [cafeteriaOrders, selectedCustomer]);

  const customerPayments = useMemo(() => {
    if (!selectedCustomer) return [];
    return payments
      .filter((p) => p.customerId === selectedCustomer.id)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [payments, selectedCustomer]);

  // Derived financial metrics
  const sessionRevenue = customerSessions.reduce((acc, s) => acc + (s.totalAmount || 0), 0);
  const rentalRevenue = customerRentals.reduce((acc, r) => acc + (r.rentalFee || 0), 0);
  const cafeteriaRevenue = customerOrders.reduce(
    (acc, o) => acc + (o.status !== 'cancelled' ? o.finalAmount || o.totalAmount || 0 : 0),
    0
  );
  const totalRevenue = sessionRevenue + rentalRevenue + cafeteriaRevenue;

  // Actual amount paid by customer
  const totalPaid = customerPayments
    .filter((p) => p.amount > 0)
    .reduce((acc, p) => acc + p.amount, 0);

  // Unsettled / Pending balance calculation
  const pendingFromSessions = customerSessions
    .filter((s) => s.status === 'completed' && (s.paidAmount || 0) < s.totalAmount)
    .reduce((acc, s) => acc + (s.totalAmount - (s.paidAmount || 0)), 0);

  const pendingFromRentals = customerRentals
    .filter((r) => (r.paidAmount || 0) < (r.rentalFee || 0))
    .reduce((acc, r) => acc + ((r.rentalFee || 0) - (r.paidAmount || 0)), 0);

  const pendingFromCafeteria = customerOrders
    .filter(
      (o) =>
        o.status !== 'cancelled' &&
        (o.paidAmount || 0) < (o.finalAmount || o.totalAmount || 0)
    )
    .reduce(
      (acc, o) => acc + ((o.finalAmount || o.totalAmount || 0) - (o.paidAmount || 0)),
      0
    );

  const calculatedPending = pendingFromSessions + pendingFromRentals + pendingFromCafeteria;
  const pendingAmount = Math.max(calculatedPending, selectedCustomer?.totalOutstanding || 0);

  // Extract unique visit dates
  const visitDates = useMemo(() => {
    if (!selectedCustomer) return [];
    const dateMap = new Map<string, number>();

    const recordDate = (isoString?: string) => {
      if (!isoString) return;
      const d = new Date(isoString);
      if (isNaN(d.getTime())) return;
      const key = d.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
      dateMap.set(key, (dateMap.get(key) || 0) + 1);
    };

    customerSessions.forEach((s) => recordDate(s.startTime));
    customerRentals.forEach((r) => recordDate(r.rentedAt));
    customerOrders.forEach((o) => recordDate(o.createdAt));
    customerPayments.forEach((p) => recordDate(p.timestamp));

    return Array.from(dateMap.entries()).map(([dateStr, count]) => ({
      dateStr,
      count,
    }));
  }, [customerSessions, customerRentals, customerOrders, customerPayments, selectedCustomer]);

  const handleDelete = async (customer: Customer) => {
    if (!isAdmin) return;
    if (confirm(`Are you sure you want to remove customer "${customer.name}"?`)) {
      try {
        await deleteCustomer(customer.id);
        if (selectedCustomerId === customer.id) {
          setSelectedCustomerId(null);
        }
      } catch (err: any) {
        alert(err?.message || 'Failed to delete customer');
      }
    }
  };

  return (
    <div id="customers-view" className="space-y-6 pb-12">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4 bg-slate-900/80 p-3.5 sm:p-5 rounded-2xl border border-slate-800">
        <div className="relative flex-1 max-w-md w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="customer-search-input"
            type="text"
            placeholder="Search players by name, phone, or membership ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <button
          id="add-new-customer-btn"
          onClick={() => onOpenCustomerModal()}
          className="w-full sm:w-auto flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-sm shadow-md shadow-cyan-500/20 transition-all cursor-pointer shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add New Customer</span>
        </button>
      </div>

      {/* Main Grid: Customer List on Left, Detailed Profile on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Customer Directory List */}
        <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col max-h-[800px] overflow-hidden shadow-lg">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
            <span>Registered Players ({filteredCustomers.length})</span>
          </div>

          <div className="space-y-2 overflow-y-auto custom-scrollbar flex-1 pr-1">
            {filteredCustomers.map((cust) => {
              const isSelected = selectedCustomer?.id === cust.id;
              return (
                <div
                  key={cust.id}
                  id={`customer-item-${cust.id}`}
                  onClick={() => setSelectedCustomerId(cust.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-cyan-500/10 border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                      : 'bg-slate-800/40 border-slate-800 hover:bg-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {cust.name
                        .split(' ')
                        .map((n) => n[0])
                        .slice(0, 2)
                        .join('')
                        .toUpperCase()}
                    </div>
                    <div className="truncate">
                      <p className="text-sm font-bold text-white truncate leading-tight">
                        {cust.name}
                      </p>
                      <p className="text-xs text-slate-400 font-mono mt-0.5">
                        {isAdmin ? cust.phone : maskSensitiveValue(cust.phone)}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="text-xs font-bold text-emerald-400">
                      {settings.currencySymbol} {cust.totalSpent.toLocaleString('en-IN')}
                    </p>
                    <p className="text-[10px] text-slate-400">{cust.totalVisits} visits</p>
                    {cust.totalOutstanding > 0 && (
                      <span className="inline-block text-[9px] font-bold text-amber-400 bg-amber-500/10 px-1 rounded">
                        Due: ₹{cust.totalOutstanding}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}

            {filteredCustomers.length === 0 && (
              <div className="text-center py-12 text-slate-500 text-xs">
                No customers found matching your search.
              </div>
            )}
          </div>
        </div>

        {/* Selected Customer Detailed Profile & Complete History */}
        <div className="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg flex flex-col justify-between">
          {selectedCustomer ? (
            <div className="space-y-6">
              {/* Profile Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-600 to-cyan-400 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg shadow-cyan-500/20 shrink-0">
                    {selectedCustomer.name
                      .split(' ')
                      .map((n) => n[0])
                      .slice(0, 2)
                      .join('')
                      .toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-extrabold text-white leading-tight">
                        {selectedCustomer.name}
                      </h3>
                      {selectedCustomer.membershipId && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                          {selectedCustomer.membershipId}
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
                      <span className="flex items-center gap-1 font-mono">
                        <Phone className="w-3.5 h-3.5 text-cyan-400" />
                        {isAdmin ? selectedCustomer.phone : maskSensitiveValue(selectedCustomer.phone)}
                      </span>
                      {selectedCustomer.email && (
                        <span className="flex items-center gap-1">
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          {selectedCustomer.email}
                        </span>
                      )}
                      {selectedCustomer.aadhaarVerified ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 text-[10px]">
                          <ShieldCheck className="w-3 h-3 text-emerald-400" />
                          Aadhaar Verified {selectedCustomer.aadhaarNumber ? `(${isAdmin ? selectedCustomer.aadhaarNumber : maskSensitiveValue(selectedCustomer.aadhaarNumber)})` : ''}
                        </span>
                      ) : selectedCustomer.aadhaarNumber ? (
                        <span className="inline-flex items-center gap-1 font-mono text-slate-300 bg-slate-800 px-2 py-0.5 rounded text-[10px]">
                          ID: {isAdmin ? selectedCustomer.aadhaarNumber : maskSensitiveValue(selectedCustomer.aadhaarNumber)}
                        </span>
                      ) : null}
                    </div>
                    {selectedCustomer.address && (
                      <div className="flex items-start gap-1.5 text-xs text-slate-300 mt-1.5 pt-1.5 border-t border-slate-800/80">
                        <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                        <span className="text-slate-300">{selectedCustomer.address}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Edit & Settle Controls */}
                <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                  {pendingAmount > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        // Find first pending item or general settle
                        const firstSessionPending = customerSessions.find(
                          (s) => s.status === 'completed' && (s.paidAmount || 0) < s.totalAmount
                        );
                        const firstRentalPending = customerRentals.find(
                          (r) => (r.paidAmount || 0) < (r.rentalFee || 0)
                        );
                        const firstCafePending = customerOrders.find(
                          (o) =>
                            o.status !== 'cancelled' &&
                            (o.paidAmount || 0) < (o.finalAmount || o.totalAmount || 0)
                        );

                        if (firstSessionPending) {
                          setSettleTarget({
                            type: 'session',
                            referenceId: firstSessionPending.id,
                            referenceTitle: `${firstSessionPending.consoleCode} Session`,
                            customerId: selectedCustomer.id,
                            customerName: selectedCustomer.name,
                            totalBill: firstSessionPending.totalAmount,
                            previouslyPaid: firstSessionPending.paidAmount || 0,
                            pendingAmount:
                              firstSessionPending.totalAmount - (firstSessionPending.paidAmount || 0),
                          });
                        } else if (firstRentalPending) {
                          setSettleTarget({
                            type: 'rental',
                            referenceId: firstRentalPending.id,
                            referenceTitle: firstRentalPending.rentalItemName,
                            customerId: selectedCustomer.id,
                            customerName: selectedCustomer.name,
                            totalBill: firstRentalPending.rentalFee || 0,
                            previouslyPaid: firstRentalPending.paidAmount || 0,
                            pendingAmount:
                              (firstRentalPending.rentalFee || 0) -
                              (firstRentalPending.paidAmount || 0),
                          });
                        } else if (firstCafePending) {
                          const bill = firstCafePending.finalAmount || firstCafePending.totalAmount || 0;
                          setSettleTarget({
                            type: 'cafeteria',
                            referenceId: firstCafePending.id,
                            referenceTitle: `Cafe Order #${firstCafePending.id.slice(-4)}`,
                            customerId: selectedCustomer.id,
                            customerName: selectedCustomer.name,
                            totalBill: bill,
                            previouslyPaid: firstCafePending.paidAmount || 0,
                            pendingAmount: bill - (firstCafePending.paidAmount || 0),
                          });
                        } else {
                          // General customer settlement
                          setSettleTarget({
                            type: 'session',
                            referenceId: `due-${selectedCustomer.id}`,
                            referenceTitle: `Outstanding Balance Settlement`,
                            customerId: selectedCustomer.id,
                            customerName: selectedCustomer.name,
                            totalBill: pendingAmount,
                            previouslyPaid: 0,
                            pendingAmount: pendingAmount,
                          });
                        }
                        setIsSettleModalOpen(true);
                      }}
                      className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-xs rounded-xl border border-amber-500/40 flex items-center gap-1.5 cursor-pointer shadow-sm shadow-amber-500/10"
                    >
                      <Banknote className="w-3.5 h-3.5" />
                      <span>Settle Dues (₹{pendingAmount})</span>
                    </button>
                  )}

                  <button
                    id="edit-selected-customer-btn"
                    onClick={() => onOpenCustomerModal(selectedCustomer)}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl border border-slate-700 transition-colors cursor-pointer"
                    title="Edit Customer"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  {isAdmin && (
                    <button
                      id="delete-selected-customer-btn"
                      onClick={() => handleDelete(selectedCustomer)}
                      className="p-2 bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 rounded-xl border border-slate-700 transition-colors cursor-pointer"
                      title="Delete Customer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Requirement 4: Complete Financial & Visit Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {/* Metric 1: Total Revenue */}
                <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Total Revenue</p>
                  <p className="text-xl font-extrabold text-white mt-0.5">
                    {settings.currencySymbol} {totalRevenue.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Total billed value</p>
                </div>

                {/* Metric 2: Total Paid */}
                <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Total Paid</p>
                  <p className="text-xl font-extrabold text-emerald-400 mt-0.5">
                    {settings.currencySymbol} {totalPaid.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Actual money collected</p>
                </div>

                {/* Metric 3: Pending Amount */}
                <div
                  className={`p-3 rounded-xl border ${
                    pendingAmount > 0
                      ? 'bg-amber-950/20 border-amber-500/40'
                      : 'bg-slate-800/50 border-slate-700/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] uppercase font-bold text-slate-400">Pending Amount</p>
                    {pendingAmount > 0 && <AlertCircle className="w-3.5 h-3.5 text-amber-400" />}
                  </div>
                  <p
                    className={`text-xl font-extrabold mt-0.5 ${
                      pendingAmount > 0 ? 'text-amber-400' : 'text-slate-300'
                    }`}
                  >
                    {settings.currencySymbol} {pendingAmount.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    {pendingAmount > 0 ? 'Unsettled balance' : 'All clear'}
                  </p>
                </div>

                {/* Metric 4: Visit Dates count */}
                <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Visit Dates</p>
                  <p className="text-xl font-extrabold text-cyan-400 mt-0.5">
                    {visitDates.length > 0 ? visitDates.length : selectedCustomer.totalVisits}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Recorded active days</p>
                </div>
              </div>

              {/* Requirement 4: Visit Dates Display Bar */}
              {visitDates.length > 0 && (
                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Visit Dates Log ({visitDates.length} Days)
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto custom-scrollbar pr-1">
                    {visitDates.map((item, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-900 border border-slate-700/70 text-slate-300"
                      >
                        <span>{item.dateStr}</span>
                        <span className="text-[9px] bg-slate-800 text-cyan-400 px-1 rounded-full font-bold">
                          {item.count} ops
                        </span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Action Shortcuts */}
              <div className="flex flex-wrap gap-3">
                <button
                  id="customer-start-session-btn"
                  onClick={() => onOpenStartSessionWithCustomer(selectedCustomer)}
                  className="flex-1 flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold py-2 px-4 rounded-xl text-xs sm:text-sm transition-all cursor-pointer"
                >
                  <Gamepad2 className="w-4 h-4" />
                  <span>Start Gaming Session</span>
                </button>
                <button
                  id="customer-new-rental-btn"
                  onClick={() => onOpenNewRentalWithCustomer(selectedCustomer)}
                  className="flex-1 flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold py-2 px-4 rounded-xl text-xs sm:text-sm border border-slate-700 transition-all cursor-pointer"
                >
                  <Package className="w-4 h-4 text-amber-400" />
                  <span>Assign Rental Gear</span>
                </button>
              </div>

              {/* Requirement 4: Complete History Tabs */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('all')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        activeTab === 'all'
                          ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                          : 'bg-slate-800/60 text-slate-400 hover:text-white'
                      }`}
                    >
                      All Activities
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('sessions')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'sessions'
                          ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                          : 'bg-slate-800/60 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Gamepad2 className="w-3.5 h-3.5" />
                      <span>Gaming ({customerSessions.length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('rentals')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'rentals'
                          ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                          : 'bg-slate-800/60 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Package className="w-3.5 h-3.5" />
                      <span>Rentals ({customerRentals.length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('cafeteria')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'cafeteria'
                          ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                          : 'bg-slate-800/60 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Coffee className="w-3.5 h-3.5" />
                      <span>Cafeteria ({customerOrders.length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('payments')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'payments'
                          ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                          : 'bg-slate-800/60 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Receipt className="w-3.5 h-3.5" />
                      <span>Payments ({customerPayments.length})</span>
                    </button>
                  </div>
                </div>

                {/* History Tab Contents */}
                <div className="space-y-2 max-h-[360px] overflow-y-auto custom-scrollbar pr-1">
                  {/* TAB 1: GAMING SESSIONS */}
                  {(activeTab === 'all' || activeTab === 'sessions') &&
                    customerSessions.map((sess) => {
                      const pending = Math.max(0, sess.totalAmount - (sess.paidAmount || 0));
                      return (
                        <div
                          key={`sess-${sess.id}`}
                          className="p-3 bg-slate-800/40 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs hover:border-slate-700 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0">
                              <Gamepad2 className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-white font-bold">{sess.consoleCode} Gaming Session</p>
                              <p className="text-[11px] text-slate-400">
                                {new Date(sess.startTime).toLocaleDateString()} at{' '}
                                {new Date(sess.startTime).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}{' '}
                                • {sess.durationMinutes || 0} mins
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                            <div className="text-right">
                              <p className="font-bold text-white">
                                Bill: {settings.currencySymbol}{sess.totalAmount} | Paid: <span className="text-emerald-400">{settings.currencySymbol}{sess.paidAmount || 0}</span>
                              </p>
                              {pending > 0 ? (
                                <p className="text-[10px] font-bold text-amber-400">
                                  Pending: {settings.currencySymbol}{pending}
                                </p>
                              ) : (
                                <span className="text-[9px] uppercase font-bold text-emerald-400">
                                  Fully Paid
                                </span>
                              )}
                            </div>

                            {pending > 0 && (
                              <button
                                type="button"
                                onClick={() => {
                                  setSettleTarget({
                                    type: 'session',
                                    referenceId: sess.id,
                                    referenceTitle: `${sess.consoleCode} Session`,
                                    customerId: selectedCustomer.id,
                                    customerName: selectedCustomer.name,
                                    totalBill: sess.totalAmount,
                                    previouslyPaid: sess.paidAmount || 0,
                                    pendingAmount: pending,
                                  });
                                  setIsSettleModalOpen(true);
                                }}
                                className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold rounded-lg text-[10px] border border-amber-500/30 cursor-pointer"
                              >
                                Settle
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}

                  {/* TAB 2: RENTALS */}
                  {(activeTab === 'all' || activeTab === 'rentals') &&
                    customerRentals.map((rent) => {
                      const pending = Math.max(0, (rent.rentalFee || 0) - (rent.paidAmount || 0));
                      return (
                        <div
                          key={`rent-${rent.id}`}
                          className="p-3 bg-slate-800/40 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs hover:border-slate-700 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
                              <Package className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="text-white font-bold">{rent.rentalItemName}</p>
                                <span
                                  className={`text-[9px] uppercase font-bold px-1.5 py-0.2 rounded ${
                                    rent.status === 'overdue'
                                      ? 'bg-rose-500/20 text-rose-300'
                                      : rent.status === 'active'
                                      ? 'bg-cyan-500/20 text-cyan-300'
                                      : 'text-slate-400 bg-slate-800'
                                  }`}
                                >
                                  {rent.status}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400">
                                {new Date(rent.rentedAt || rent.startTime || rent.createdAt).toLocaleDateString()} • Qty: {rent.quantity} • Deposit: ₹{rent.depositAmount}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                            <div className="text-right">
                              <p className="font-bold text-white">
                                Fee: {settings.currencySymbol}{rent.rentalFee} | Paid: <span className="text-emerald-400">{settings.currencySymbol}{rent.paidAmount ?? rent.totalPaid ?? 0}</span>
                              </p>
                              {pending > 0 ? (
                                <p className="text-[10px] font-bold text-amber-400">
                                  Pending: {settings.currencySymbol}{pending}
                                </p>
                              ) : (
                                <span className="text-[9px] uppercase font-bold text-emerald-400">
                                  Fully Paid
                                </span>
                              )}
                            </div>

                            {pending > 0 && (
                              <button
                                type="button"
                                onClick={() => {
                                  setSettleTarget({
                                    type: 'rental',
                                    referenceId: rent.id,
                                    referenceTitle: rent.rentalItemName,
                                    customerId: selectedCustomer.id,
                                    customerName: selectedCustomer.name,
                                    totalBill: rent.rentalFee || 0,
                                    previouslyPaid: rent.paidAmount || 0,
                                    pendingAmount: pending,
                                  });
                                  setIsSettleModalOpen(true);
                                }}
                                className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold rounded-lg text-[10px] border border-amber-500/30 cursor-pointer"
                              >
                                Settle
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}

                  {/* TAB 3: CAFETERIA ORDERS */}
                  {(activeTab === 'all' || activeTab === 'cafeteria') &&
                    customerOrders.map((ord) => {
                      const bill = ord.finalAmount || ord.totalAmount || 0;
                      const pending = Math.max(0, bill - (ord.paidAmount || 0));
                      const itemsText = (ord.items || [])
                        .map((i) => `${i.quantity}x ${i.itemName || 'Item'}`)
                        .join(', ');

                      return (
                        <div
                          key={`cafe-${ord.id}`}
                          className="p-3 bg-slate-800/40 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs hover:border-slate-700 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-400 flex items-center justify-center shrink-0">
                              <Coffee className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-white font-bold">
                                Cafeteria Order #{ord.id.slice(-4)}
                              </p>
                              <p className="text-[11px] text-slate-400 truncate max-w-[280px]">
                                {itemsText || 'Cafeteria snacks & drinks'}
                              </p>
                              <p className="text-[10px] text-slate-500">
                                {new Date(ord.createdAt).toLocaleString([], {
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                            <div className="text-right">
                              <p className="font-bold text-white">
                                Bill: {settings.currencySymbol}{bill} | Paid: <span className="text-emerald-400">{settings.currencySymbol}{ord.paidAmount || 0}</span>
                              </p>
                              {pending > 0 ? (
                                <p className="text-[10px] font-bold text-amber-400">
                                  Pending: {settings.currencySymbol}{pending}
                                </p>
                              ) : (
                                <span className="text-[9px] uppercase font-bold text-emerald-400">
                                  Fully Paid
                                </span>
                              )}
                            </div>

                            {pending > 0 && ord.status !== 'cancelled' && (
                              <button
                                type="button"
                                onClick={() => {
                                  setSettleTarget({
                                    type: 'cafeteria',
                                    referenceId: ord.id,
                                    referenceTitle: `Cafe Order #${ord.id.slice(-4)}`,
                                    customerId: selectedCustomer.id,
                                    customerName: selectedCustomer.name,
                                    totalBill: bill,
                                    previouslyPaid: ord.paidAmount || 0,
                                    pendingAmount: pending,
                                  });
                                  setIsSettleModalOpen(true);
                                }}
                                className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold rounded-lg text-[10px] border border-amber-500/30 cursor-pointer"
                              >
                                Settle
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}

                  {/* TAB 4: PAYMENT TRANSACTIONS */}
                  {(activeTab === 'all' || activeTab === 'payments') &&
                    customerPayments.map((pmt) => {
                      const isPositive = pmt.amount >= 0;
                      return (
                        <div
                          key={`pay-${pmt.id}`}
                          className="p-3 bg-slate-800/40 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs hover:border-slate-700 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                              <Receipt className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="text-white font-bold">{pmt.referenceTitle}</p>
                                <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
                                  {pmt.method}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400">
                                {new Date(pmt.timestamp).toLocaleString([], {
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })} • By {pmt.recordedBy}
                              </p>
                              {pmt.splitDetails && pmt.splitDetails.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {pmt.splitDetails.map((s, idx) => (
                                    <span
                                      key={idx}
                                      className="text-[9px] bg-slate-900 px-1 py-0.5 rounded border border-slate-700 text-slate-400"
                                    >
                                      {s.method.toUpperCase()}: ₹{s.amount}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                            <div className="text-right">
                              <p
                                className={`font-bold text-sm ${
                                  isPositive ? 'text-emerald-400' : 'text-rose-400'
                                }`}
                              >
                                {isPositive ? '+' : ''}
                                {settings.currencySymbol} {Math.abs(pmt.amount).toLocaleString('en-IN')}
                              </p>
                              <span
                                className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${
                                  pmt.status === 'paid'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : 'bg-amber-500/10 text-amber-400'
                                }`}
                              >
                                {pmt.status}
                              </span>
                            </div>

                            {onOpenReceiptModal && (
                              <button
                                type="button"
                                onClick={() => onOpenReceiptModal(pmt)}
                                title="Print Receipt"
                                className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}

                  {/* Empty state */}
                  {customerSessions.length === 0 &&
                    customerRentals.length === 0 &&
                    customerOrders.length === 0 &&
                    customerPayments.length === 0 && (
                      <div className="text-center py-10 text-slate-500 text-xs">
                        No previous records found for this player.
                      </div>
                    )}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-20 text-slate-500">
              <Users className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p>Select a player to view detailed profile and complete history logs.</p>
            </div>
          )}
        </div>
      </div>

      {/* Settle Pending Payment Modal */}
      <SettlePendingPaymentModal
        isOpen={isSettleModalOpen}
        onClose={() => {
          setIsSettleModalOpen(false);
          setSettleTarget(null);
        }}
        target={settleTarget}
      />
    </div>
  );
};
