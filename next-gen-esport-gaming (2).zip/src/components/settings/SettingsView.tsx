import React, { useState } from 'react';
import {
  Building,
  Download,
  Upload,
  ShieldAlert,
  Save,
  CheckCircle2,
  RefreshCw,
  HardDrive,
  Cloud,
  CloudOff,
  Folder,
  FileSpreadsheet,
  AlertTriangle,
  Info,
  Copy,
  Check,
  ExternalLink,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { driveService, FOLDER_NAME, DEFAULT_FILE_NAME } from '../../services/googleDriveService';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    resetAllData,
    reloadStarterCatalog,
    exportBackup,
    importBackup,
    syncState,
    triggerSync,
  } = useCafe();

  const [cafeName, setCafeName] = useState(settings.cafeName);
  const [tagline, setTagline] = useState(settings.tagline);
  const [phone, setPhone] = useState(settings.phone);
  const [email, setEmail] = useState(settings.email);
  const [address, setAddress] = useState(settings.address);
  const [currencySymbol, setCurrencySymbol] = useState(settings.currencySymbol);
  const [minGamingTimeMinutes, setMinGamingTimeMinutes] = useState(settings.minGamingTimeMinutes.toString());

  // Google Drive state
  const [isConnectingDrive, setIsConnectingDrive] = useState(false);
  const [isDisconnectingDrive, setIsDisconnectingDrive] = useState(false);
  const [showDisconnectConfirm, setShowDisconnectConfirm] = useState(false);
  const [isSyncingDrive, setIsSyncingDrive] = useState(false);
  const [driveFeedbackMsg, setDriveFeedbackMsg] = useState('');
  const [showOAuthConfig, setShowOAuthConfig] = useState(false);
  const [copiedOrigin, setCopiedOrigin] = useState(false);
  const [customClientIdInput, setCustomClientIdInput] = useState(
    () => (typeof window !== 'undefined' ? localStorage.getItem('NEXTGEN_DRIVE_CUSTOM_CLIENT_ID') || '' : '')
  );
  const [customClientSecretInput, setCustomClientSecretInput] = useState('');
  const [showSecretInput, setShowSecretInput] = useState(false);
  const [customClientIdSaved, setCustomClientIdSaved] = useState(false);
  const [directTokenInput, setDirectTokenInput] = useState('');
  const [directTokenEmailInput, setDirectTokenEmailInput] = useState('');
  const [showDirectTokenInput, setShowDirectTokenInput] = useState(false);
  const [isConnectingDirectToken, setIsConnectingDirectToken] = useState(false);

  // Authoritatively re-verify Google Drive connection status whenever Settings is viewed
  React.useEffect(() => {
    driveService.checkVaultStatus();
  }, []);

  // Danger Zone options
  const [wipeStations, setWipeStations] = useState(true);
  const [wipeRentalGear, setWipeRentalGear] = useState(true);
  const [wipeCafeteriaItems, setWipeCafeteriaItems] = useState(true);
  const [isRestoringStarter, setIsRestoringStarter] = useState(false);
  const [restoreSuccess, setRestoreSuccess] = useState(false);

  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Danger Zone
  const [resetInput, setResetInput] = useState('');
  const [resetError, setResetError] = useState('');
  const [resetSuccess, setResetSuccess] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    try {
      await updateSettings({
        cafeName,
        tagline,
        phone,
        email,
        address,
        currencySymbol,
        minGamingTimeMinutes: parseInt(minGamingTimeMinutes, 10) || 15,
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      alert(err?.message || 'Failed to update settings');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await importBackup(file);
      alert('Database successfully restored from backup file!');
    } catch (err: any) {
      alert(err?.message || 'Failed to restore database');
    }
    e.target.value = '';
  };

  const handleConnectDrive = async () => {
    setIsConnectingDrive(true);
    setDriveFeedbackMsg('');
    try {
      const res = await driveService.connectWithOAuth();
      if (res.success) {
        setDriveFeedbackMsg('Google Drive connected successfully!');
        await triggerSync();
      } else {
        setDriveFeedbackMsg(res.error || 'Failed to connect Google Drive.');
      }
    } catch (err: any) {
      setDriveFeedbackMsg(err.message || 'Error connecting to Google Drive.');
    } finally {
      setIsConnectingDrive(false);
    }
  };

  const handleConnectSimulated = async () => {
    setIsConnectingDrive(true);
    setDriveFeedbackMsg('');
    try {
      const res = await driveService.connectSimulatedDrive();
      if (res.success) {
        setDriveFeedbackMsg('Simulated Drive (.xlsx) connected successfully!');
        await triggerSync();
      } else {
        setDriveFeedbackMsg(res.error || 'Failed to connect simulated drive.');
      }
    } catch (err: any) {
      setDriveFeedbackMsg(err.message || 'Error connecting to simulated storage.');
    } finally {
      setIsConnectingDrive(false);
    }
  };

  const handleDisconnectDrive = async () => {
    setIsDisconnectingDrive(true);
    setDriveFeedbackMsg('');
    try {
      const res = await driveService.disconnect();
      if (res.success) {
        setDriveFeedbackMsg('Google Drive disconnected successfully.');
        setShowDisconnectConfirm(false);
      } else {
        setDriveFeedbackMsg(res.error || 'Failed to disconnect.');
      }
    } catch (err: any) {
      setDriveFeedbackMsg(err.message || 'Error disconnecting.');
    } finally {
      setIsDisconnectingDrive(false);
    }
  };

  const handleSyncNow = async () => {
    setIsSyncingDrive(true);
    setDriveFeedbackMsg('');
    try {
      await triggerSync();
      setDriveFeedbackMsg('Synced with Google Drive successfully!');
    } catch (err: any) {
      setDriveFeedbackMsg(err.message || 'Sync failed.');
    } finally {
      setIsSyncingDrive(false);
    }
  };

  const handleResetButtonClick = () => {
    setResetError('');
    if (resetInput.trim().toUpperCase() !== 'RESET') {
      setResetError('Please type RESET in the text box first.');
      return;
    }
    setIsResetConfirmOpen(true);
  };

  const executeReset = async () => {
    setIsResetting(true);
    setResetError('');
    try {
      const res = await resetAllData('RESET', {
        wipeStations,
        wipeRentalGear,
        wipeCafeteriaItems,
      });
      if (res.success) {
        setResetSuccess(true);
        setResetInput('');
        setIsResetConfirmOpen(false);
        setTimeout(() => setResetSuccess(false), 5000);
      } else {
        setResetError(res.error || 'Failed to reset data');
        setIsResetConfirmOpen(false);
      }
    } catch (err: any) {
      setResetError(err?.message || 'Unexpected error while resetting data.');
      setIsResetConfirmOpen(false);
    } finally {
      setIsResetting(false);
    }
  };

  const handleRestoreStarter = async () => {
    setIsRestoringStarter(true);
    setResetError('');
    try {
      const res = await reloadStarterCatalog();
      if (res.success) {
        setRestoreSuccess(true);
        setTimeout(() => setRestoreSuccess(false), 4000);
      } else {
        setResetError(res.error || 'Failed to reload starter catalog');
      }
    } catch (err: any) {
      setResetError(err?.message || 'Unexpected error while reloading starter catalog.');
    } finally {
      setIsRestoringStarter(false);
    }
  };

  return (
    <div id="settings-view" className="space-y-6 pb-16 max-w-5xl mx-auto">
      {/* 1. Cafe Information Profile */}
      <form
        onSubmit={handleSaveProfile}
        className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg shadow-black/20 space-y-4"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Building className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-white">Cafe Profile & Currency</h3>
          </div>
          {savedSuccess && (
            <span className="flex items-center gap-1.5 text-emerald-400 text-xs font-semibold bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-lg">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Settings Saved
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Cafe Business Name
            </label>
            <input
              id="settings-cafe-name-input"
              type="text"
              value={cafeName}
              onChange={(e) => setCafeName(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Tagline / Subtitle
            </label>
            <input
              id="settings-tagline-input"
              type="text"
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Contact Phone
            </label>
            <input
              id="settings-phone-input"
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Contact Email
            </label>
            <input
              id="settings-email-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Currency Symbol
            </label>
            <input
              id="settings-currency-input"
              type="text"
              value={currencySymbol}
              onChange={(e) => setCurrencySymbol(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Minimum Session Billable Time (Minutes)
            </label>
            <input
              id="settings-min-time-input"
              type="number"
              min="1"
              value={minGamingTimeMinutes}
              onChange={(e) => setMinGamingTimeMinutes(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Cafe Address / Location
            </label>
            <input
              id="settings-address-input"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <div className="pt-3 flex justify-end">
          <button
            id="save-settings-btn"
            type="submit"
            disabled={isSavingSettings}
            className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm shadow-md shadow-cyan-500/20 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Save Cafe Profile</span>
          </button>
        </div>
      </form>

      {/* 2. Google Drive Single Source of Truth Storage */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg shadow-black/20 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
              syncState.isConnected 
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
            }`}>
              {syncState.isConnected ? <Cloud className="w-5 h-5" /> : <CloudOff className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Google Drive Cloud Storage</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                  Single Source of Truth
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                All business data is stored exclusively in Google Drive in Excel (.xlsx) format.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {syncState.isConnected ? (
              <span className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Google Drive Connected
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400">
                <AlertTriangle className="w-3.5 h-3.5" />
                Not Connected
              </span>
            )}
          </div>
        </div>

        {(driveFeedbackMsg || (syncState.errorMessage && !syncState.isConnected)) && (
          <div className={`p-3 rounded-xl text-xs font-semibold flex items-start gap-2 border ${
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('fail') || 
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('error') ||
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('closed') ||
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('mismatch') ||
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('rejected') ||
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('denied') ||
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('status 4') ||
            (driveFeedbackMsg || syncState.errorMessage || '').toLowerCase().includes('status 5')
              ? 'bg-rose-500/10 border-rose-500/20 text-rose-300'
              : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
          }`}>
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span>{driveFeedbackMsg || syncState.errorMessage}</span>
              {!syncState.isConnected && (
                <div className="mt-2 pt-2 border-t border-rose-500/20 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleConnectSimulated}
                    disabled={isConnectingDrive}
                    className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 text-white rounded-lg text-xs font-bold border border-rose-500/40 transition-all cursor-pointer"
                  >
                    Switch to Local Excel (.xlsx) Mode
                  </button>
                  <span className="text-[11px] text-slate-400 font-normal">
                    Stores data directly on the server's Excel workbook without requiring Google popup consent.
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Target Storage Specifications */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 text-xs">
          <div>
            <span className="text-slate-500 block font-medium">Target Folder</span>
            <span className="font-mono text-cyan-300 font-semibold flex items-center gap-1.5 mt-0.5">
              <Folder className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              {FOLDER_NAME}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block font-medium">Database Spreadsheet</span>
            <span className="font-mono text-emerald-300 font-semibold flex items-center gap-1.5 mt-0.5">
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              {DEFAULT_FILE_NAME}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block font-medium">Authorized Account</span>
            <span className="text-slate-300 font-medium truncate block mt-0.5">
              {syncState.isConnected ? (syncState.userEmail || settings.email || 'Owner Account') : 'No Active Authorization'}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block font-medium">Last Synchronized</span>
            <span className="text-slate-300 font-medium block mt-0.5">
              {syncState.lastSyncedAt ? new Date(syncState.lastSyncedAt).toLocaleTimeString() : 'Awaiting Connection'}
            </span>
          </div>
        </div>

        {/* Architectural Storage Policy Notice */}
        <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-3 text-[11px] text-slate-400 leading-relaxed flex items-start gap-2.5">
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0 mt-1.5" />
          <div>
            <strong className="text-slate-200">Zero Local Cache Rule:</strong> Local storage, session storage, and IndexedDB caching for business transactions are permanently disabled. All active gaming sessions, cafeteria orders, inventory, customers, and payments are committed directly to Google Drive spreadsheet <code className="text-cyan-300 font-mono">NextGenGaming_Cafe_Data.xlsx</code>.
          </div>
        </div>

        {/* Connect / Sync / Disconnect Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex flex-wrap items-center gap-2">
            {!syncState.isConnected ? (
              <>
                <button
                  id="connect-google-drive-btn"
                  type="button"
                  onClick={handleConnectDrive}
                  disabled={isConnectingDrive}
                  className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md shadow-cyan-500/20 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isConnectingDrive ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Connecting Google Drive...</span>
                    </>
                  ) : (
                    <>
                      <Cloud className="w-4 h-4" />
                      <span>Connect Owner Google Drive</span>
                    </>
                  )}
                </button>
                <button
                  id="connect-simulated-drive-btn"
                  type="button"
                  onClick={handleConnectSimulated}
                  disabled={isConnectingDrive}
                  className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-3.5 py-2.5 rounded-xl text-xs border border-slate-700 hover:border-emerald-500/50 transition-all cursor-pointer disabled:opacity-50"
                  title="Store data in server-side Excel (.xlsx) file without Google popup login"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <span>Use Local Excel Simulation (.xlsx)</span>
                </button>
              </>
            ) : (
              <>
                <button
                  id="sync-google-drive-btn"
                  type="button"
                  onClick={handleSyncNow}
                  disabled={isSyncingDrive}
                  className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold px-3.5 py-2 rounded-xl text-xs border border-slate-700 hover:border-cyan-500/40 transition-all cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isSyncingDrive ? 'animate-spin' : ''}`} />
                  <span>{isSyncingDrive ? 'Syncing...' : 'Sync Now'}</span>
                </button>
                {showDisconnectConfirm ? (
                  <div className="flex items-center gap-1.5 bg-rose-950/60 border border-rose-500/40 px-2.5 py-1.5 rounded-xl">
                    <span className="text-xs text-rose-300 font-medium">Disconnect Drive?</span>
                    <button
                      id="confirm-disconnect-google-drive-btn"
                      type="button"
                      onClick={handleDisconnectDrive}
                      disabled={isDisconnectingDrive}
                      className="bg-rose-600 hover:bg-rose-500 text-white font-bold px-2.5 py-1 rounded-lg text-xs transition-all cursor-pointer disabled:opacity-50"
                    >
                      {isDisconnectingDrive ? 'Disconnecting...' : 'Yes, Disconnect'}
                    </button>
                    <button
                      id="cancel-disconnect-google-drive-btn"
                      type="button"
                      onClick={() => setShowDisconnectConfirm(false)}
                      disabled={isDisconnectingDrive}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded-lg text-xs transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    id="disconnect-google-drive-btn"
                    type="button"
                    onClick={() => setShowDisconnectConfirm(true)}
                    disabled={isDisconnectingDrive}
                    className="flex items-center gap-1.5 bg-rose-950/30 hover:bg-rose-900/50 text-rose-400 hover:text-rose-300 font-semibold px-3.5 py-2 rounded-xl text-xs border border-rose-500/30 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <CloudOff className="w-3.5 h-3.5" />
                    <span>Disconnect Drive</span>
                  </button>
                )}
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              id="export-backup-json-btn"
              type="button"
              onClick={exportBackup}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-950 hover:bg-slate-800 text-slate-200 rounded-xl text-xs font-semibold border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer"
              title="Download full operational database as an Excel (.xlsx) workbook"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Download Excel (.xlsx)</span>
            </button>

            <label
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-950 hover:bg-slate-800 text-slate-200 rounded-xl text-xs font-semibold border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer"
              title="Restore database from an Excel (.xlsx) file"
            >
              <Upload className="w-3.5 h-3.5 text-emerald-400" />
              <span>Import Excel (.xlsx)</span>
              <input type="file" accept=".xlsx,.json" onChange={handleFileImport} className="hidden" />
            </label>
          </div>
        </div>

        {/* 2.1 Google OAuth & Origin Diagnostics Panel */}
        <div className="mt-2 border-t border-slate-800/80 pt-3">
          <button
            type="button"
            onClick={() => setShowOAuthConfig(!showOAuthConfig)}
            className="flex items-center justify-between w-full text-left py-1.5 px-3 rounded-xl bg-slate-950/40 hover:bg-slate-950/80 border border-slate-800 text-xs font-semibold text-slate-300 transition-colors"
          >
            <span className="flex items-center gap-2">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>Google OAuth & Origin Configuration Diagnostics</span>
            </span>
            {showOAuthConfig ? (
              <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            )}
          </button>

          {showOAuthConfig && (
            <div className="mt-3 p-4 rounded-xl bg-slate-950/90 border border-cyan-500/20 text-xs space-y-3">
              <div className="space-y-1">
                <span className="text-slate-400 font-medium">Current Deployed Origin (Requires Authorization):</span>
                <div className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 rounded-lg p-2 font-mono text-cyan-300 select-all">
                  <span className="flex-1 truncate text-[11px]">
                    {typeof window !== 'undefined' ? window.location.origin : 'N/A'}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (typeof window !== 'undefined') {
                        navigator.clipboard.writeText(window.location.origin);
                        setCopiedOrigin(true);
                        setTimeout(() => setCopiedOrigin(false), 2000);
                      }
                    }}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-cyan-950 text-cyan-400 hover:bg-cyan-900 font-sans text-[10px] font-bold cursor-pointer"
                  >
                    {copiedOrigin ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedOrigin ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              <div className="space-y-3 pt-1">
                <span className="text-slate-400 font-medium block">Google Drive OAuth Client Credentials (Offline Refresh Token Flow):</span>
                <div className="grid grid-cols-1 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400 mb-1 block">Google Cloud OAuth Client ID:</label>
                    <input
                      id="settings-custom-client-id-input"
                      type="text"
                      placeholder="e.g. 123456789-xxx.apps.googleusercontent.com"
                      value={customClientIdInput}
                      onChange={(e) => setCustomClientIdInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-[11px] text-cyan-300 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[10px] text-slate-400 block">Google Cloud OAuth Client Secret (Stored Securely in Tenant Vault):</label>
                      <button
                        type="button"
                        onClick={() => setShowSecretInput(!showSecretInput)}
                        className="text-[10px] text-cyan-400 hover:text-cyan-300 cursor-pointer"
                      >
                        {showSecretInput ? 'Hide' : 'Show'}
                      </button>
                    </div>
                    <input
                      id="settings-custom-client-secret-input"
                      type={showSecretInput ? 'text' : 'password'}
                      placeholder="e.g. GOCSPX-xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                      value={customClientSecretInput}
                      onChange={(e) => setCustomClientSecretInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-[11px] text-cyan-300 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    id="save-custom-client-id-btn"
                    type="button"
                    onClick={async () => {
                      driveService.setCustomClientId(customClientIdInput.trim() || null);
                      try {
                        const headers = await (driveService as any).getAuthHeaders();
                        await fetch('/api/tenant-vault-status', {
                          method: 'POST',
                          headers,
                          body: JSON.stringify({
                            action: 'update_oauth_credentials',
                            customClientId: customClientIdInput.trim() || null,
                            customClientSecret: customClientSecretInput.trim() || null,
                          }),
                        });
                      } catch (err) {
                        console.warn('[SettingsView] Error persisting custom OAuth credentials:', err);
                      }
                      setCustomClientIdSaved(true);
                      setTimeout(() => setCustomClientIdSaved(false), 2500);
                    }}
                    className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs transition-all cursor-pointer"
                  >
                    {customClientIdSaved ? 'Saved' : 'Save OAuth Credentials'}
                  </button>
                  {(customClientIdInput || customClientSecretInput) && (
                    <button
                      id="reset-custom-client-id-btn"
                      type="button"
                      onClick={async () => {
                        setCustomClientIdInput('');
                        setCustomClientSecretInput('');
                        driveService.setCustomClientId(null);
                        try {
                          const headers = await (driveService as any).getAuthHeaders();
                          await fetch('/api/tenant-vault-status', {
                            method: 'POST',
                            headers,
                            body: JSON.stringify({
                              action: 'update_oauth_credentials',
                              customClientId: null,
                              customClientSecret: null,
                            }),
                          });
                        } catch {}
                      }}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-lg text-xs transition-all cursor-pointer"
                      title="Reset to default environment OAuth client"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>

              {/* Direct Refresh Token Entry for 100% Permanent Connection */}
              <div className="border-t border-slate-800/80 pt-3 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                    <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Direct Google Drive Token (Permanent Connection)</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowDirectTokenInput(!showDirectTokenInput)}
                    className="text-[10px] text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                  >
                    {showDirectTokenInput ? 'Hide' : 'Enter Direct Token'}
                  </button>
                </div>

                {showDirectTokenInput && (
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-700/80 space-y-2.5">
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      If you have an offline Google Refresh Token or OAuth Access Token, paste it here to permanently connect Google Drive without needing popup login:
                    </p>
                    <div>
                      <label className="text-[10px] text-slate-400 mb-1 block">Google Account Email:</label>
                      <input
                        type="email"
                        placeholder="e.g. your-email@gmail.com"
                        value={directTokenEmailInput}
                        onChange={(e) => setDirectTokenEmailInput(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-[11px] text-slate-200 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 mb-1 block">Google Refresh Token or Access Token:</label>
                      <input
                        type="password"
                        placeholder="Paste 1//... or ya29... token here"
                        value={directTokenInput}
                        onChange={(e) => setDirectTokenInput(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-[11px] text-cyan-300 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <button
                      type="button"
                      disabled={isConnectingDirectToken || !directTokenInput.trim()}
                      onClick={async () => {
                        setIsConnectingDirectToken(true);
                        setDriveFeedbackMsg('');
                        try {
                          const res = await driveService.connectWithDirectToken({
                            token: directTokenInput.trim(),
                            userEmail: directTokenEmailInput.trim() || undefined,
                            clientId: customClientIdInput.trim() || undefined,
                            clientSecret: customClientSecretInput.trim() || undefined,
                          });
                          if (res.success) {
                            setDriveFeedbackMsg('Google Drive connected permanently with direct token!');
                            setDirectTokenInput('');
                            await triggerSync();
                          } else {
                            setDriveFeedbackMsg(res.error || 'Failed to connect with token.');
                          }
                        } catch (err: any) {
                          setDriveFeedbackMsg(err.message || 'Error connecting with token.');
                        } finally {
                          setIsConnectingDirectToken(false);
                        }
                      }}
                      className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-bold px-3.5 py-2 rounded-lg text-xs transition-all cursor-pointer disabled:opacity-50"
                    >
                      {isConnectingDirectToken ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Verifying & Connecting...</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Save & Connect Direct Token</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                <div>
                  <span className="text-slate-400 font-medium block">Active Drive OAuth Client ID:</span>
                  <span className="font-mono text-[10px] text-slate-300 break-all select-all block mt-0.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    {driveService.getOAuthClientId()}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 font-medium block">Identity & Auth Architecture:</span>
                  <span className="font-mono text-[11px] text-slate-300 block mt-0.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    Firebase Auth (Login) + Google Drive (Storage)
                  </span>
                </div>
              </div>

              <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-lg space-y-2 text-[11px] text-slate-300 leading-relaxed">
                <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>How to Authorize Deployed Origin in Google Cloud Console:</span>
                </div>
                <ol className="list-decimal pl-4 space-y-1 text-slate-400">
                  <li>
                    Open <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noreferrer" className="text-cyan-400 underline hover:text-cyan-300">Google Cloud Console &gt; APIs &amp; Services &gt; Credentials</a>.
                  </li>
                  <li>
                    Select project <strong className="text-slate-200">gen-lang-client-0942756484</strong>.
                  </li>
                  <li>
                    Under <strong className="text-slate-200">OAuth 2.0 Client IDs</strong>, click the Web Client matching ID <span className="font-mono text-cyan-300 text-[10px]">{driveService.getOAuthClientId()}</span>.
                  </li>
                  <li>
                    Under <strong className="text-slate-200">Authorized JavaScript origins</strong>, click <strong className="text-slate-200">+ ADD URI</strong> and paste your origin: <code className="text-cyan-300 font-mono text-[10px]">{typeof window !== 'undefined' ? window.location.origin : ''}</code>.
                  </li>
                  <li>
                    <strong className="text-slate-200">Note for GIS Popup Mode:</strong> Google Identity Services authorization-code flow with popup UX verifies the requesting origin against <strong className="text-slate-200">Authorized JavaScript origins</strong>. No separate redirect URI is required in Google Cloud Console for popup mode.
                  </li>
                  <li>
                    In <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline hover:text-cyan-300">Firebase Console</a> under <strong className="text-slate-200">Authentication &gt; Settings &gt; Authorized domains</strong>, ensure your domain (<code className="text-cyan-300 font-mono text-[10px]">{typeof window !== 'undefined' ? window.location.hostname : ''}</code>) is added.
                  </li>
                </ol>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. DANGER ZONE - Reset All Data */}
      <div className="bg-rose-950/20 border border-rose-500/30 rounded-2xl p-5 sm:p-6 shadow-lg shadow-black/20 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5 text-rose-400">
            <ShieldAlert className="w-5 h-5" />
            <h3 className="text-base font-bold">Danger Zone: Reset All Operational Data</h3>
          </div>
          <button
            id="restore-starter-catalog-btn"
            type="button"
            onClick={handleRestoreStarter}
            disabled={isRestoringStarter}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 hover:text-cyan-300 border border-slate-700 hover:border-cyan-500/40 rounded-xl text-xs font-semibold transition-all cursor-pointer disabled:opacity-50"
            title="Reload standard preset PCs, consoles, gear, and cafe items"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRestoringStarter ? 'animate-spin text-cyan-400' : ''}`} />
            <span>{isRestoringStarter ? 'Reloading...' : 'Restore Starter Templates'}</span>
          </button>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Resetting will permanently wipe all active & completed gaming sessions, customer records,
          cafeteria orders, rental checkouts, and payment earnings.
        </p>

        <div className="bg-slate-950/70 border border-rose-500/20 rounded-xl p-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <label className="flex items-center gap-3 p-3 bg-slate-900/80 rounded-xl border border-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={wipeStations}
                onChange={(e) => setWipeStations(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-rose-500 focus:ring-rose-500"
              />
              <span className="text-xs text-slate-300">Wipe Consoles/PCs</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-slate-900/80 rounded-xl border border-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={wipeRentalGear}
                onChange={(e) => setWipeRentalGear(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-rose-500 focus:ring-rose-500"
              />
              <span className="text-xs text-slate-300">Wipe Rental Gear</span>
            </label>
            <label className="flex items-center gap-3 p-3 bg-slate-900/80 rounded-xl border border-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={wipeCafeteriaItems}
                onChange={(e) => setWipeCafeteriaItems(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-rose-500 focus:ring-rose-500"
              />
              <span className="text-xs text-slate-300">Wipe Cafeteria</span>
            </label>
          </div>

          <div className="space-y-3">
            <label className="block text-xs font-semibold text-rose-300">
              To confirm, type <span className="text-white font-mono uppercase tracking-widest bg-rose-500/20 px-2 py-0.5 rounded">RESET</span> below:
            </label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={resetInput}
                onChange={(e) => setResetInput(e.target.value)}
                placeholder="Type RESET here..."
                className="flex-1 bg-slate-900 border border-rose-500/30 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-rose-500 transition-all font-mono"
              />
              <button
                type="button"
                onClick={handleResetButtonClick}
                disabled={resetInput.toUpperCase() !== 'RESET' || isResetting}
                className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:bg-slate-800 text-white font-bold rounded-xl text-sm transition-all disabled:opacity-50"
              >
                Reset Database
              </button>
            </div>
            {resetError && <p className="text-xs text-rose-400 font-medium">{resetError}</p>}
            {resetSuccess && (
              <p className="text-xs text-emerald-400 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                Database has been successfully reset!
              </p>
            )}
            {restoreSuccess && (
              <p className="text-xs text-cyan-400 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                Starter templates reloaded successfully!
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-6">
            <div className="flex items-center gap-3 text-rose-400">
              <ShieldAlert className="w-8 h-8" />
              <h3 className="text-xl font-bold">Final Confirmation</h3>
            </div>
            
            <p className="text-sm text-slate-300 leading-relaxed">
              You are about to perform a <strong className="text-white">permanent data wipe</strong>. 
              This action cannot be undone. Are you absolutely sure?
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setIsResetConfirmOpen(false)}
                className="flex-1 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-sm transition-all"
              >
                Cancel
              </button>
              <button
                onClick={executeReset}
                disabled={isResetting}
                className="flex-1 px-4 py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2"
              >
                {isResetting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Resetting...
                  </>
                ) : (
                  'Yes, Reset All'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
