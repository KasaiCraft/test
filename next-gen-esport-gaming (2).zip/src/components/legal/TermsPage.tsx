import React from 'react';
import { FileText, ArrowLeft, CheckCircle2, ShieldAlert, Gavel, Globe, UserCheck, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

export const TermsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans p-4 sm:p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-white uppercase tracking-tight">Terms of Service</h1>
              <p className="text-xs font-bold text-cyan-500 uppercase tracking-widest">Next Gen Esport Management Platform</p>
            </div>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-slate-300 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </Link>
        </div>

        <div className="bg-slate-900/40 border border-slate-800 rounded-[32px] p-8 md:p-12 space-y-12 text-sm text-slate-300 leading-relaxed shadow-2xl">
          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                <Globe className="w-4 h-4 text-cyan-400" />
              </div>
              1. Acceptance of Terms
            </h2>
            <p>
              By accessing and using <strong>NEXT GEN ESPORT</strong> (the "Platform"), you agree to be bound by these Terms of Service. These terms govern your use of our management tools, dashboards, and cloud synchronization features. If you do not agree to these terms, you must not use the Platform.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <UserCheck className="w-4 h-4 text-emerald-400" />
              </div>
              2. User Accounts & Security
            </h2>
            <p>
              To access certain features of the Platform, you must create an account using Firebase Authentication. You are responsible for maintaining the confidentiality of your login credentials and for all activities that occur under your account.
            </p>
            <ul className="list-disc list-inside space-y-2 pl-4">
              <li><strong>Admin Access:</strong> The primary account holder (Admin) has full control over the cafe's data and settings.</li>
              <li><strong>Staff Access:</strong> Staff accounts are restricted and monitored by the Admin.</li>
              <li><strong>Responsibility:</strong> You must immediately notify us of any unauthorized use of your account.</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Shield className="w-4 h-4 text-blue-400" />
              </div>
              3. Data Ownership & Cloud Integration
            </h2>
            <p>
              NEXT GEN ESPORT operates on a **Bring-Your-Own-Storage (BYOS)** model. We provide the interface, but you provide the storage.
            </p>
            <div className="p-6 bg-slate-950/50 border border-slate-800 rounded-2xl space-y-4">
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Ownership:</strong> You maintain 100% ownership and control of the data stored in your Google Drive.</li>
                <li><strong>Access Revocation:</strong> You can revoke the Platform's access to your Google Drive at any time via your Google Account settings.</li>
                <li><strong>Data Integrity:</strong> While the Platform facilitates data entry and retrieval, you are responsible for maintaining backups of your Google Drive files.</li>
              </ul>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
              </div>
              4. Service Availability & Performance
            </h2>
            <p>
              The Platform is provided on an "as-is" and "as-available" basis. We aim for high availability but do not guarantee that the Platform will be uninterrupted or error-free. Performance may vary based on your internet connection and Google Drive's API response times.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
              </div>
              5. Limitation of Liability
            </h2>
            <p>
              To the maximum extent permitted by law, NEXT GEN ESPORT and its developers shall not be liable for any indirect, incidental, special, or consequential damages resulting from the use or inability to use the Platform, including but not limited to loss of profits, data, or business reputation.
            </p>
          </section>

          <section className="space-y-4 border-t border-slate-800 pt-8">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-slate-500/10 flex items-center justify-center">
                <Gavel className="w-4 h-4 text-slate-400" />
              </div>
              6. Governing Law
            </h2>
            <p>
              These Terms shall be governed by and construed in accordance with the laws of your jurisdiction. Any disputes arising from these terms shall be resolved in the appropriate courts of said jurisdiction.
            </p>
            <div className="mt-6 p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <p className="text-xs text-slate-400 uppercase font-bold mb-2 tracking-widest text-center">Inquiries</p>
              <p className="text-sm text-center">For any questions regarding these Terms, please contact <a href="mailto:support@nextgencafe.com" className="text-cyan-400 hover:underline">support@nextgencafe.com</a></p>
            </div>
            <p className="text-xs text-slate-500 italic mt-8 text-center">
              Last updated: September 12, 2026
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
