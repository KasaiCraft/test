import React from 'react';
import { ShieldCheck, ArrowLeft, Lock, FileText, CheckCircle2, Cloud } from 'lucide-react';
import { Link } from 'react-router-dom';

export const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans p-4 sm:p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-white uppercase tracking-tight">Privacy Policy</h1>
              <p className="text-xs font-bold text-cyan-500 uppercase tracking-widest">Next Gen Esport Management Platform</p>
            </div>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-slate-300 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </Link>
        </div>

        <div className="bg-slate-900/40 border border-slate-800 rounded-[32px] p-8 md:p-12 space-y-12 text-sm text-slate-300 leading-relaxed shadow-2xl">
          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white tracking-tight">1. Introduction</h2>
            <p>
              Welcome to <strong>NEXT GEN ESPORT</strong>. We are committed to protecting your privacy and ensuring the security of your business and personal information. This Privacy Policy describes how we collect, use, and handle your data when you use our management platform. By accessing or using NEXT GEN ESPORT, you consent to the practices described in this policy.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white tracking-tight">2. About NEXT GEN ESPORT</h2>
            <p>
              NEXT GEN ESPORT is a professional high-performance management system designed for gaming cafes, eSports arenas, and console zones. Our platform provides tools for session tracking, customer management, inventory control, and financial reporting. We prioritize a decentralized data model where the business owner maintains physical ownership of their operational records through cloud integration.
            </p>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-white tracking-tight">3. Information We Collect</h2>
            
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">3.1 Account and Authentication Information</h3>
              <p>
                When you sign up or log in to NEXT GEN ESPORT, we collect information necessary to authenticate your identity. This includes your name, email address, and profile picture provided via Google Authentication or Firebase Authentication.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">3.2 Business Data</h3>
              <p>
                We process the business data you input into the system to provide our management services. This includes:
              </p>
              <ul className="list-disc list-inside space-y-2 pl-4">
                <li><strong>Customer Information:</strong> Names, contact details, and visit history.</li>
                <li><strong>Gaming Session Data:</strong> Start/end times, console/PC usage, and billing amounts.</li>
                <li><strong>Rental & Gear Data:</strong> Inventory lists, rental durations, and equipment status.</li>
                <li><strong>Repair Logs:</strong> Hardware maintenance history and associated costs.</li>
                <li><strong>Cafeteria and Transaction Data:</strong> Food and beverage orders, inventory levels, and sales records.</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">3.3 Google Account Information</h3>
              <p>
                To enable Google Drive integration, we access your Google Account's basic profile information (email and name) to verify the connection and ensure data is being stored in the correct account.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">3.4 Google Drive API Usage</h3>
              <p>
                Our application requests the <code>https://www.googleapis.com/auth/drive.file</code> scope. This permission is used <strong>exclusively</strong> to:
              </p>
              <ul className="list-disc list-inside space-y-2 pl-4">
                <li>Create a dedicated folder for your cafe data.</li>
                <li>Store your business records in an Excel (.xlsx) format.</li>
                <li>Retrieve and update these records during your active sessions.</li>
              </ul>
              <p className="bg-slate-950/50 p-4 rounded-xl border border-slate-800 text-xs">
                <strong>Important:</strong> This scope only allows the app to access files that were <strong>created by the app itself</strong>. We cannot see, read, or modify your personal photos, documents, or other unrelated files in your Google Drive.
              </p>
            </div>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-white tracking-tight">4. How We Use Information</h2>
            <p>
              We use the collected information solely to provide, maintain, and improve the NEXT GEN ESPORT platform. This includes processing gaming sessions, managing inventory, and generating reports for your business.
            </p>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">4.1 How Google User Data Is Used</h3>
              <p>
                Your Google user data is used strictly for authentication and to facilitate the Google Drive storage integration. We do <strong>not</strong> use your Google user data for advertising, marketing, or any purpose unrelated to the core functionality of the management system.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">4.2 Google Drive Data Access and Storage</h3>
              <p>
                The application writes and reads data directly to your authorized Google Drive. This decentralized model ensures that:
              </p>
              <ul className="list-disc list-inside space-y-2 pl-4">
                <li>You retain full physical ownership of your business records.</li>
                <li>Data is persisted securely in your own cloud environment.</li>
                <li>Access can be revoked by you at any time via Google Account settings.</li>
              </ul>
              <p>
                We do <strong>not</strong> sell your Google user data or any business records stored in your Google Drive to third parties.
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white tracking-tight">5. Data Storage and Security</h2>
            <p>
              We implement industry-standard security measures to protect your data. All communication between your browser and our servers is encrypted using TLS. Business data is never stored on our central servers; it is transmitted directly to your Google Drive or stored temporarily in-memory during an active session to provide real-time updates.
            </p>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-white tracking-tight">6. Data Sharing and Disclosure</h2>
            <p>
              We do <strong>not</strong> share your business or personal data with third parties, except as required by law or to provide our core services via trusted infrastructure providers (like Google Cloud).
            </p>
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">6.1 Third-Party Services</h3>
              <p>
                Our platform integrates with <strong>Google APIs / Google Drive</strong> to provide storage capabilities. These services have their own privacy policies, and we encourage you to review them. We do not provide your business data to any other third-party analytics or marketing services.
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white tracking-tight">7. Data Retention and Deletion</h2>
            <p>
              <strong>Data Retention:</strong> We do not retain your business data on our servers. Your records exist solely in your Google Drive. We retain your basic account identity (email) as long as your account is active.
            </p>
            <p>
              <strong>Data Deletion:</strong> You can delete your business records at any time by deleting the <code>NextGenGaming_Cafe_Data</code> folder in your Google Drive.
            </p>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-white tracking-tight">8. User Rights and Choices</h2>
            <p>
              You have the right to access, correct, or delete your personal and business information. You can manage your business data directly within the application or via your Google Drive.
            </p>
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400">8.1 Account and Data Deletion Requests</h3>
              <p>
                To request the deletion of your NEXT GEN ESPORT account and associated identity data, please contact us at the email provided below. To revoke the application's access to your Google Drive, visit your <a href="https://myaccount.google.com/permissions" className="text-cyan-400 hover:underline" target="_blank" rel="noopener noreferrer">Google Account Permissions</a> page.
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white tracking-tight">9. Cookies and Local Storage</h2>
            <p>
              We use essential cookies and session storage to maintain your login state and security. We do <strong>not</strong> use tracking cookies or persistent local storage for your sensitive business records, ensuring that your data remains decentralized and secure.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white tracking-tight">10. Children's Privacy</h2>
            <p>
              NEXT GEN ESPORT is intended for business owners and staff and is not directed at children under the age of 13. We do not knowingly collect personal information from children.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-white tracking-tight">11. Changes to This Privacy Policy</h2>
            <p>
              We may update this Privacy Policy periodically to reflect changes in our practices or for legal reasons. We will notify you of any significant changes by posting the updated policy on this page and updating the "Last Updated" date.
            </p>
          </section>

          <section className="space-y-4 border-t border-slate-800 pt-8">
            <h2 className="text-2xl font-bold text-white tracking-tight">12. Contact Information</h2>
            <p>
              If you have any questions or concerns about this Privacy Policy or our data practices, please contact us:
            </p>
            <div className="mt-6 p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <p className="text-xs text-slate-400 uppercase font-bold mb-2 tracking-widest text-center">Contact Terminal</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="text-center">
                  <p className="text-sm font-semibold text-white">Email Support</p>
                  <p className="text-sm"><a href="mailto:support@nextgencafe.com" className="text-cyan-400 hover:underline">support@nextgencafe.com</a></p>
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold text-white">Office Address</p>
                  <p className="text-sm text-slate-400">Esport Plaza, Terminal 1, Gaming District</p>
                </div>
              </div>
            </div>
            <p className="text-xs text-slate-500 italic mt-8 text-center">
              Last updated: September 12, 2026
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
