import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Gamepad2,
  TrendingUp,
  Package,
  AlertCircle,
  ChevronRight,
  CheckCircle2,
  Hourglass,
  ArrowUpRight,
  Users,
  Coffee,
  Coins,
  Clock,
  ArrowRight,
  Banknote,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { ConsoleDevice, GamingSession, RentalRecord } from '../../types';
import { SettlePendingPaymentModal, SettlePendingTarget } from '../modals/SettlePendingPaymentModal';

interface DashboardViewProps {
  onOpenStartSessionModal: (preselectedConsoleId?: string) => void;
  onOpenStopSessionModal: (session: GamingSession) => void;
  onOpenNewRentalModal: () => void;
  onOpenReturnRentalModal?: (record: RentalRecord) => void;
  onOpenCustomerModal?: () => void;
  onSelectConsole?: (console: ConsoleDevice) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenStartSessionModal,
  onOpenStopSessionModal,
  onSelectConsole,
}) => {
  const {
    consoles,
    sessions,
    activeSessions,
    rentalItems,
    rentalRecords,
    activeRentals,
    cafeteriaOrders,
    repairRecords,
    payments,
    customers,
    settings,
    calculateLiveSessionBill,
    isAdmin,
  } = useCafe();

  const navigate = useNavigate();

  // Settlement modal state
  const [settleTarget, setSettleTarget] = useState<SettlePendingTarget | null>(null);
  const [isSettleModalOpen, setIsSettleModalOpen] = useState(false);

  // Tick for live session timers
  const [, setTick] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  // Today's Date boundaries
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);

  // Month Date boundaries
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  // Actual recorded payments (Source of truth for revenue)
  const actualPayments = payments.filter((p) => (p.amount || 0) > 0);

  // 1. Today's Revenue
  const todayPayments = actualPayments.filter(
    (p) => p && p.timestamp && new Date(p.timestamp).getTime() >= startOfToday.getTime()
  );
  const totalRevenueToday = todayPayments.reduce((acc, p) => acc + (p.amount || 0), 0);

  // 2. This Month's Revenue
  const monthPayments = actualPayments.filter(
    (p) => p && p.timestamp && new Date(p.timestamp).getTime() >= startOfMonth.getTime()
  );
  const totalRevenueMonth = monthPayments.reduce((acc, p) => acc + (p.amount || 0), 0);

  // 3. Total Revenue (All-time recorded)
  const totalRevenueAllTime = actualPayments.reduce((acc, p) => acc + (p.amount || 0), 0);

  // 4. Gaming Revenue (All-time actual recorded payments)
  const gamingRevenueTotal = actualPayments
    .filter((p) => p && p.type === 'gaming_session')
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  // 5. Rental Revenue (All-time actual recorded payments - excludes refundable deposits)
  const rentalRevenueTotal = actualPayments
    .filter((p) => p && (p.type === 'rental_fee' || p.type === 'late_fee'))
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  // 6. Cafeteria Revenue (All-time actual recorded payments)
  const cafeteriaRevenueTotal = actualPayments
    .filter((p) => p && p.type === 'cafeteria_order')
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  // Today's category-wise earnings (strictly for staff today-only view)
  const todayGamingRevenue = todayPayments
    .filter((p) => p && p.type === 'gaming_session')
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  const todayRentalRevenue = todayPayments
    .filter((p) => p && (p.type === 'rental_fee' || p.type === 'late_fee'))
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  const todayCafeteriaRevenue = todayPayments
    .filter((p) => p && p.type === 'cafeteria_order')
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  // Pending Payments from Gaming, Rentals, and Cafeteria
  const pendingGamingList = sessions
    .filter((s) => s.status === 'completed' && (s.paymentStatus === 'pending' || s.paymentStatus === 'partial' || (s.paidAmount !== undefined && s.paidAmount < s.totalAmount)))
    .map((s) => {
      const paid = s.paidAmount || 0;
      const pending = Math.max(0, s.totalAmount - paid);
      return {
        id: s.id,
        type: 'session' as const,
        referenceId: s.id,
        referenceTitle: `${s.consoleCode} Gaming Session`,
        customerId: s.customerId,
        customerName: s.customerName,
        totalBill: s.totalAmount,
        previouslyPaid: paid,
        pendingAmount: pending,
        date: s.endTime || s.startTime,
        status: s.paymentStatus || 'pending',
      };
    })
    .filter((i) => i.pendingAmount > 0);

  const pendingRentalList = (rentalRecords || [])
    .filter((r) => r.paymentStatus === 'pending' || r.paymentStatus === 'partial' || (r.totalPaid !== undefined && r.totalPaid < (r.rentalFee + r.depositAmount + (r.lateFee || 0) + (r.damageDeduction || 0))))
    .map((r) => {
      const totalBill = r.rentalFee + r.depositAmount + (r.lateFee || 0) + (r.damageDeduction || 0);
      const paid = r.totalPaid || 0;
      const pending = Math.max(0, totalBill - paid);
      return {
        id: r.id,
        type: 'rental' as const,
        referenceId: r.id,
        referenceTitle: `${r.rentalItemName} Rental`,
        customerId: r.customerId,
        customerName: r.customerName,
        totalBill,
        previouslyPaid: paid,
        pendingAmount: pending,
        date: r.startTime,
        status: r.paymentStatus || 'pending',
      };
    })
    .filter((i) => i.pendingAmount > 0);

  const pendingCafeteriaList = (cafeteriaOrders || [])
    .filter((o) => o.status !== 'cancelled' && (o.paymentStatus === 'pending' || o.paymentStatus === 'partial' || (o.paidAmount !== undefined && o.paidAmount < o.totalAmount)))
    .map((o) => {
      const paid = o.paidAmount || 0;
      const pending = Math.max(0, o.totalAmount - paid);
      return {
        id: o.id,
        type: 'cafeteria' as const,
        referenceId: o.id,
        referenceTitle: `Cafeteria Order #${o.id.slice(-6)}`,
        customerId: o.customerId,
        customerName: o.customerName,
        totalBill: o.totalAmount,
        previouslyPaid: paid,
        pendingAmount: pending,
        date: o.createdAt,
        status: o.paymentStatus || 'pending',
      };
    })
    .filter((i) => i.pendingAmount > 0);

  const pendingRepairList = (repairRecords || [])
    .filter(
      (r) =>
        r.status !== 'Cancelled' &&
        (r.paymentStatus === 'pending' ||
          r.paymentStatus === 'partial' ||
          (r.paidAmount !== undefined && r.paidAmount < (r.finalCost || r.estimatedCost)))
    )
    .map((r) => {
      const totalBill = r.finalCost || r.estimatedCost;
      const paid = r.paidAmount || 0;
      const pending = Math.max(0, totalBill - paid);
      return {
        id: r.id,
        type: 'repair' as const,
        referenceId: r.id,
        referenceTitle: `Repair: ${r.deviceType} (${(r.faultDescription || '').slice(0, 20)})`,
        customerId: r.customerId,
        customerName: r.customerName,
        totalBill,
        previouslyPaid: paid,
        pendingAmount: pending,
        date: r.createdAt,
        status: r.paymentStatus || 'pending',
      };
    })
    .filter((i) => i.pendingAmount > 0);

  const allPendingItems = [
    ...pendingGamingList,
    ...pendingRentalList,
    ...pendingCafeteriaList,
    ...pendingRepairList,
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // 7. Pending Amount (Total across all 3 categories)
  const totalPendingAmount = allPendingItems.reduce((acc, item) => acc + item.pendingAmount, 0);

  // Station counts
  const totalConsoles = consoles.length;
  const occupiedConsoles = consoles.filter((c) => c.status === 'in_use').length;
  const availableConsoles = consoles.filter((c) => c.status === 'available').length;
  const maintenanceConsoles = consoles.filter((c) => c.status === 'maintenance' || c.status === 'disabled').length;

  // Rental counts
  const overdueRentals = activeRentals.filter((r) => r.status === 'overdue' || new Date(r.expectedReturnTime).getTime() < Date.now());

  // Format Timer (Countdown for scheduled, elapsed for open)
  const formatTimer = (session: GamingSession) => {
    const isPaused = session.status === 'paused';
    const pausedMinutes = (session.totalPausedMinutes || 0) + (isPaused && session.pausedAt ? Math.floor((Date.now() - new Date(session.pausedAt).getTime()) / 60000) : 0);
    const startMs = new Date(session.startTime).getTime();
    const nowMs = isPaused && session.pausedAt ? new Date(session.pausedAt).getTime() : Date.now();

    if (session.scheduledEndTime) {
      const endMs = new Date(session.scheduledEndTime).getTime();
      const referenceNow = isPaused && session.pausedAt ? new Date(session.pausedAt).getTime() : Date.now();
      const remainingSec = Math.max(0, Math.floor((endMs - referenceNow) / 1000));
      const mins = Math.floor(remainingSec / 60);
      const secs = remainingSec % 60;
      if (remainingSec === 0) return '00:00';
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    const elapsedSec = Math.max(0, Math.floor((nowMs - startMs) / 1000) - (session.totalPausedMinutes || 0) * 60);
    const hrs = Math.floor(elapsedSec / 3600);
    const mins = Math.floor((elapsedSec % 3600) / 60);
    const secs = elapsedSec % 60;
    if (hrs > 0) {
      return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div id="dashboard-view" className="space-y-6 pb-12">
      {/* Revenue Metrics Bento Grid */}
      {isAdmin ? (
        /* ADMIN VIEW: Full All-Time & Monthly Financial Overview */
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Metric 1: Today's Revenue */}
            <div
              id="metric-today-revenue-card"
              className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">Today's Revenue</span>
                <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <TrendingUp className="w-3 h-3" /> Live
                </span>
              </div>
              <div className="my-2 sm:my-3">
                <p className="text-2xl sm:text-3xl font-black text-emerald-400 tracking-tight truncate">
                  {settings.currencySymbol} {totalRevenueToday.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  {todayPayments.length} recorded payments today
                </p>
              </div>
            </div>

            {/* Metric 2: This Month's Revenue */}
            <div
              id="metric-month-revenue-card"
              className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">This Month's Revenue</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Monthly
                </span>
              </div>
              <div className="my-2 sm:my-3">
                <p className="text-2xl sm:text-3xl font-black text-cyan-300 tracking-tight truncate">
                  {settings.currencySymbol} {totalRevenueMonth.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Current calendar month receipts
                </p>
              </div>
            </div>

            {/* Metric 3: Total Revenue (All-time) */}
            <div
              id="metric-total-revenue-card"
              className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/40 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">Total Revenue</span>
                <Coins className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="my-2 sm:my-3">
                <p className="text-2xl sm:text-3xl font-black text-white tracking-tight truncate">
                  {settings.currencySymbol} {totalRevenueAllTime.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  All-time actual recorded payments
                </p>
              </div>
            </div>

            {/* Metric 4: Pending Amount */}
            <div
              id="metric-pending-amount-card"
              className={`bg-slate-900/90 border rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between transition-all ${
                totalPendingAmount > 0
                  ? 'border-amber-500/50 bg-amber-950/10 hover:border-amber-400'
                  : 'border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">Pending Amount</span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    totalPendingAmount > 0
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {allPendingItems.length} Tabs Unsettled
                </span>
              </div>
              <div className="my-2 sm:my-3">
                <p className={`text-2xl sm:text-3xl font-black tracking-tight truncate ${totalPendingAmount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                  {settings.currencySymbol} {totalPendingAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Unpaid balances across Gaming, Rentals, Cafe
                </p>
              </div>
            </div>
          </div>

          {/* Admin Category Breakdown (All-Time) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Metric 5: Gaming Revenue */}
            <div
              id="metric-gaming-revenue-card"
              className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between shadow-md hover:border-cyan-500/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <Gamepad2 className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Gaming Revenue</p>
                  <p className="text-xl font-extrabold text-white">
                    {settings.currencySymbol} {gamingRevenueTotal.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500">Actual session payments</p>
                </div>
              </div>
            </div>

            {/* Metric 6: Rental Revenue */}
            <div
              id="metric-rental-revenue-card"
              className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between shadow-md hover:border-amber-500/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Rental Revenue</p>
                  <p className="text-xl font-extrabold text-white">
                    {settings.currencySymbol} {rentalRevenueTotal.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500">Gear fees & deposits</p>
                </div>
              </div>
            </div>

            {/* Metric 7: Cafeteria Revenue */}
            <div
              id="metric-cafeteria-revenue-card"
              className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between shadow-md hover:border-rose-500/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                  <Coffee className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Cafeteria Revenue</p>
                  <p className="text-xl font-extrabold text-white">
                    {settings.currencySymbol} {cafeteriaRevenueTotal.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500">Snacks & drink orders</p>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        /* STAFF VIEW: Only Today's Earnings & Shift Operations (Total Revenue is completely hidden) */
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {/* Metric 1: Today's Earnings */}
            <div
              id="metric-today-revenue-card"
              className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">Today's Earnings</span>
                <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <TrendingUp className="w-3 h-3" /> Live
                </span>
              </div>
              <div className="my-2 sm:my-3">
                <p className="text-2xl sm:text-3xl font-black text-emerald-400 tracking-tight truncate">
                  {settings.currencySymbol} {totalRevenueToday.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  {todayPayments.length} recorded payments today
                </p>
              </div>
            </div>

            {/* Metric 2: Floor Status (Active Stations) */}
            <div
              id="metric-active-stations-card"
              className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">Active Stations</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  {consoles.length} Total
                </span>
              </div>
              <div className="my-2 sm:my-3">
                <p className="text-2xl sm:text-3xl font-black text-cyan-300 tracking-tight truncate">
                  {activeSessions.length} / {consoles.length}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  {activeSessions.length} active gaming sessions on floor
                </p>
              </div>
            </div>

            {/* Metric 3: Pending Amount to Collect */}
            <div
              id="metric-pending-amount-card"
              className={`bg-slate-900/90 border rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between transition-all ${
                totalPendingAmount > 0
                  ? 'border-amber-500/50 bg-amber-950/10 hover:border-amber-400'
                  : 'border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">Pending Due</span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    totalPendingAmount > 0
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {allPendingItems.length} Tabs
                </span>
              </div>
              <div className="my-2 sm:my-3">
                <p className={`text-2xl sm:text-3xl font-black tracking-tight truncate ${totalPendingAmount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                  {settings.currencySymbol} {totalPendingAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Unsettled customer tabs to collect today
                </p>
              </div>
            </div>
          </div>

          {/* Staff Category Breakdown: Today's Earnings Only */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div
              id="metric-today-gaming-card"
              className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between shadow-md hover:border-cyan-500/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <Gamepad2 className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Today's Gaming</p>
                  <p className="text-xl font-extrabold text-white">
                    {settings.currencySymbol} {todayGamingRevenue.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500">Collected today</p>
                </div>
              </div>
            </div>

            <div
              id="metric-today-rental-card"
              className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between shadow-md hover:border-amber-500/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Today's Rentals</p>
                  <p className="text-xl font-extrabold text-white">
                    {settings.currencySymbol} {todayRentalRevenue.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500">Collected today</p>
                </div>
              </div>
            </div>

            <div
              id="metric-today-cafeteria-card"
              className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between shadow-md hover:border-rose-500/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                  <Coffee className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Today's Cafeteria</p>
                  <p className="text-xl font-extrabold text-white">
                    {settings.currencySymbol} {todayCafeteriaRevenue.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500">Collected today</p>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Pending Payments Section on Dashboard */}
      {allPendingItems.length > 0 && (
        <div
          id="dashboard-pending-payments-panel"
          className="bg-slate-900/95 border border-amber-500/30 rounded-2xl p-5 shadow-xl"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  Pending Payments & Customer Tabs
                  <span className="px-2 py-0.5 text-[10px] font-extrabold bg-amber-500/20 text-amber-300 rounded-full border border-amber-500/30">
                    {allPendingItems.length} Unpaid
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Unsettled balances from Gaming, Equipment Rentals, and Cafeteria
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-400 mr-2">Total Pending:</span>
              <span className="text-base font-black text-amber-400">
                {settings.currencySymbol} {totalPendingAmount.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          <div className="space-y-2.5 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
            {allPendingItems.map((item) => {
              const typeColor =
                item.type === 'session'
                  ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                  : item.type === 'rental'
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  : item.type === 'repair'
                  ? 'bg-purple-500/10 text-purple-400 border-purple-500/30'
                  : 'bg-rose-500/10 text-rose-400 border-rose-500/30';

              return (
                <div
                  key={`${item.type}-${item.id}`}
                  className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 sm:p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-md border ${typeColor}`}
                    >
                      {item.type}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{item.customerName}</span>
                        <span className="text-xs text-slate-400">• {item.referenceTitle}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Total Bill: <span className="text-slate-200 font-semibold">{settings.currencySymbol}{item.totalBill}</span> | Paid: <span className="text-emerald-400 font-semibold">{settings.currencySymbol}{item.previouslyPaid}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                    <div className="text-right">
                      <p className="text-xs text-slate-400">Remaining Due</p>
                      <p className="text-sm font-black text-amber-400">
                        {settings.currencySymbol} {item.pendingAmount}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setSettleTarget({
                          type: item.type,
                          referenceId: item.referenceId,
                          referenceTitle: item.referenceTitle,
                          customerId: item.customerId,
                          customerName: item.customerName,
                          totalBill: item.totalBill,
                          previouslyPaid: item.previouslyPaid,
                          pendingAmount: item.pendingAmount,
                        });
                        setIsSettleModalOpen(true);
                      }}
                      className="bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-bold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
                    >
                      <Banknote className="w-3.5 h-3.5" />
                      <span>Collect & Settle</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Bento Grid Middle Section */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Bento 4: Console Status Grid (Col Span 2) */}
        <div
          id="bento-console-grid-card"
          className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col shadow-lg shadow-black/20"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4 pb-2 border-b border-slate-800/60">
            <div>
              <h4 className="font-extrabold text-white uppercase text-xs tracking-widest">
                Console Status Grid
              </h4>
              <p className="text-xs text-slate-400">Click station to start or stop session</p>
            </div>
            {/* Status Legend */}
            <div className="flex items-center gap-3 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-cyan-500 shadow-sm shadow-cyan-500/50"></span>
                In Use ({occupiedConsoles})
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-slate-700"></span>
                Available ({availableConsoles})
              </span>
              {maintenanceConsoles > 0 && (
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-amber-500"></span>
                  Maint. ({maintenanceConsoles})
                </span>
              )}
            </div>
          </div>

          {/* Grid of Console Stations */}
          {consoles.length === 0 ? (
            <div className="p-8 text-center bg-slate-950/60 rounded-xl border border-dashed border-slate-800 flex flex-col items-center justify-center">
              <Gamepad2 className="w-8 h-8 text-slate-600 mb-2" />
              <p className="text-sm font-semibold text-slate-400">No gaming consoles configured</p>
              <button
                onClick={() => navigate('/gaming')}
                className="mt-3 text-xs text-cyan-400 hover:text-cyan-300 font-semibold underline cursor-pointer"
              >
                + Add Stations in Gaming & Consoles
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2.5 max-h-[380px] overflow-y-auto custom-scrollbar pr-1">
              {consoles.map((consoleItem) => {
                const activeSession = sessions.find(
                  (s) => s.consoleId === consoleItem.id && (s.status === 'active' || s.status === 'paused')
                );
                const isInUse = !!activeSession;
                const isMaint = consoleItem.status === 'maintenance';
                const isDisabled = consoleItem.status === 'disabled';

                return (
                  <div
                    key={consoleItem.id}
                    id={`console-tile-${consoleItem.code}`}
                    onClick={() => {
                      if (isInUse && activeSession) {
                        onOpenStopSessionModal(activeSession);
                      } else if (consoleItem.status === 'available') {
                        onOpenStartSessionModal(consoleItem.id);
                      } else if (onSelectConsole) {
                        onSelectConsole(consoleItem);
                      } else {
                        navigate('/gaming');
                      }
                    }}
                    className={`aspect-square rounded-xl p-1.5 flex flex-col items-center justify-between text-center cursor-pointer transition-all relative overflow-hidden group border ${
                      isInUse
                        ? 'bg-cyan-500/15 border-cyan-500/40 hover:border-cyan-400 shadow-sm shadow-cyan-500/10'
                        : isMaint
                        ? 'bg-amber-500/10 border-amber-500/30 hover:border-amber-400'
                        : isDisabled
                        ? 'bg-rose-500/10 border-rose-500/30 hover:border-rose-400 opacity-60'
                        : 'bg-slate-800/80 border-slate-700/60 hover:bg-slate-800 hover:border-slate-500'
                    }`}
                    title={`${consoleItem.name} (${consoleItem.code}) - ${
                      isInUse ? `In use by ${activeSession?.customerName}` : consoleItem.status
                    }`}
                  >
                    {/* Console Code */}
                    <span
                      className={`text-[11px] font-black uppercase tracking-tight mt-1 ${
                        isInUse
                          ? 'text-cyan-300 font-mono'
                          : isMaint
                          ? 'text-amber-400'
                          : isDisabled
                          ? 'text-rose-400'
                          : 'text-slate-300'
                      }`}
                    >
                      {consoleItem.code}
                    </span>

                    {/* Center Content / Customer or Type */}
                    <div className="flex-1 flex flex-col items-center justify-center w-full px-1">
                      {isInUse && activeSession ? (
                        <p className="text-[9px] text-slate-200 font-medium truncate w-full flex items-center justify-center gap-0.5">
                          {String(activeSession.customerName || 'Player').split(' ')[0]}
                          {activeSession.playerCount && activeSession.playerCount > 1 && (
                            <span className="bg-cyan-500/40 px-0.5 rounded text-[7px] font-bold">{activeSession.playerCount}P</span>
                          )}
                        </p>
                      ) : (
                        <span className="text-[9px] text-slate-500 uppercase font-semibold">
                          {(consoleItem.type || '').replace(' Gaming', '').replace(' Station', '') || 'STATION'}
                        </span>
                      )}
                    </div>

                    {/* Bottom Running Timer or Status Badge */}
                    {isInUse && activeSession ? (
                      <span className={`text-[9px] text-white font-mono font-bold px-1 py-0.5 rounded w-full truncate ${activeSession.scheduledEndTime ? 'bg-amber-600' : 'bg-cyan-600'}`}>
                        {formatTimer(activeSession)}
                      </span>
                    ) : isMaint ? (
                      <span className="text-[8px] text-amber-300 font-bold uppercase bg-amber-500/20 px-1 rounded w-full">
                        Maint.
                      </span>
                    ) : isDisabled ? (
                      <span className="text-[8px] text-rose-300 font-bold uppercase bg-rose-500/20 px-1 rounded w-full">
                        Off
                      </span>
                    ) : (
                      <span className="text-[8px] text-emerald-400 font-bold uppercase opacity-80">
                        Free
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Bento 5: Recent Transactions & Live Feed (Col Span 2) */}
        <div
          id="bento-recent-transactions-card"
          className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col shadow-lg shadow-black/20"
        >
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800/60">
            <div>
              <h4 className="font-extrabold text-white uppercase text-xs tracking-widest">
                Recent Transactions
              </h4>
              <p className="text-xs text-slate-400">Live payment ledger and counter receipts</p>
            </div>
            <button
              id="view-all-payments-btn"
              onClick={() => navigate('/payments')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5 overflow-y-auto max-h-[380px] custom-scrollbar pr-1">
            {payments.slice(0, 6).map((tx) => {
              const isPositive = (tx.amount || 0) >= 0;
              const initials = tx.customerName
                ? String(tx.customerName)
                    .split(' ')
                    .filter(Boolean)
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join('')
                    .toUpperCase()
                : 'TX';

              return (
                <div
                  key={tx.id}
                  id={`tx-row-${tx.id}`}
                  className="flex items-center justify-between p-3 bg-slate-800/40 border border-slate-800/80 hover:border-slate-700 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-200 shrink-0">
                      {initials}
                    </div>
                    <div className="truncate">
                      <p className="text-sm text-white font-medium truncate">
                        {tx.customerName || 'Customer'}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate">
                        {tx.referenceTitle || 'Payment'}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 pl-3">
                    <p
                      className={`text-sm font-bold ${
                        isPositive ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isPositive ? '+' : ''}
                      {settings?.currencySymbol || '₹'} {Math.abs(tx.amount || 0).toLocaleString('en-IN')}
                    </p>
                    <p className="text-[10px] text-slate-400 uppercase font-mono">
                      {tx.method || 'cash'} • {tx.timestamp ? new Date(tx.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--:--'}
                    </p>
                  </div>
                </div>
              );
            })}

            {payments.length === 0 && (
              <div className="text-center py-8 text-slate-500 text-xs">
                No payment transactions recorded yet today.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Bento Row: Quick Metrics & Action Highlights */}
      <div className={`grid grid-cols-1 sm:grid-cols-2 ${isAdmin ? 'lg:grid-cols-4' : 'lg:grid-cols-3'} gap-4`}>
        {/* Quick Bento: Total Registered Customers */}
        <div
          id="bento-customers-count"
          onClick={() => navigate('/customers')}
          className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between hover:border-slate-700 cursor-pointer transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-semibold uppercase">Customers</p>
              <p className="text-xl font-bold text-white">{customers.length} Players</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </div>

        {/* Quick Bento: Pending Amounts */}
        <div
          id="bento-pending-payments"
          onClick={() => navigate('/payments')}
          className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between hover:border-slate-700 cursor-pointer transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Hourglass className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-semibold uppercase">Pending Tabs</p>
              <p className="text-xl font-bold text-white">
                {settings.currencySymbol} {totalPendingAmount.toLocaleString('en-IN')}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </div>

        {/* Quick Bento: Rental Inventory Status */}
        <div
          id="bento-rental-inventory-count"
          onClick={() => navigate('/rentals')}
          className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between hover:border-slate-700 cursor-pointer transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-semibold uppercase">Rental Gear</p>
              <p className="text-xl font-bold text-white">
                {rentalItems.reduce((acc, i) => acc + i.availableQuantity, 0)} In Stock
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </div>

        {/* Quick Bento: Reports & Audit - Admin Only */}
        {isAdmin && (
          <div
            id="bento-reports-shortcut"
            onClick={() => navigate('/reports')}
            className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between hover:border-slate-700 cursor-pointer transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-semibold uppercase">Full Reports</p>
                <p className="text-xl font-bold text-white">Financials</p>
              </div>
            </div>
            <ArrowUpRight className="w-4 h-4 text-slate-500" />
          </div>
        )}
      </div>

      {/* Settle Pending Payment Modal */}
      <SettlePendingPaymentModal
        isOpen={isSettleModalOpen}
        onClose={() => {
          setIsSettleModalOpen(false);
          setSettleTarget(null);
        }}
        target={settleTarget}
      />
    </div>
  );
};
