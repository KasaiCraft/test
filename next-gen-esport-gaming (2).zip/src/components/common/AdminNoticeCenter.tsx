import React, { useState, useEffect } from 'react';
import {
  Bell,
  X,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Pin,
  Clock,
  ShieldCheck,
  Send,
  Sparkles,
  Info,
  DollarSign,
  Gamepad2,
  Package,
  Coffee,
  Wrench,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { AdminNotice, NoticeCategory, NoticePriority } from '../../types';

interface AdminNoticeCenterProps {
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORY_ICONS: Record<NoticeCategory, React.ReactNode> = {
  general: <Info className="w-4 h-4 text-cyan-400" />,
  rates_pricing: <DollarSign className="w-4 h-4 text-purple-400" />,
  inventory_consoles: <Gamepad2 className="w-4 h-4 text-blue-400" />,
  rentals: <Package className="w-4 h-4 text-amber-400" />,
  cafeteria: <Coffee className="w-4 h-4 text-emerald-400" />,
  system_reset: <AlertTriangle className="w-4 h-4 text-rose-400" />,
  maintenance: <Wrench className="w-4 h-4 text-yellow-400" />,
  rules_policy: <ShieldCheck className="w-4 h-4 text-indigo-400" />,
};

const CATEGORY_LABELS: Record<NoticeCategory, string> = {
  general: 'General Notice',
  rates_pricing: 'Rates & Pricing',
  inventory_consoles: 'Stations & Consoles',
  rentals: 'Rental Gear',
  cafeteria: 'Cafeteria & Snacks',
  system_reset: 'System Reset',
  maintenance: 'Maintenance',
  rules_policy: 'Rules & Policies',
};

const CATEGORY_STYLES: Record<NoticeCategory, string> = {
  general: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/20',
  rates_pricing: 'bg-purple-500/10 text-purple-300 border-purple-500/20',
  inventory_consoles: 'bg-blue-500/10 text-blue-300 border-blue-500/20',
  rentals: 'bg-amber-500/10 text-amber-300 border-amber-500/20',
  cafeteria: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20',
  system_reset: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
  maintenance: 'bg-yellow-500/10 text-yellow-300 border-yellow-500/20',
  rules_policy: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20',
};

export const AdminNoticeCenter: React.FC<AdminNoticeCenterProps> = ({
  isOpen,
  onClose,
}) => {
  const { notices, currentUser, isAdmin, addAdminNotice, deleteAdminNotice, acknowledgeNotice } =
    useCafe();

  const [isComposing, setIsComposing] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [newCategory, setNewCategory] = useState<NoticeCategory>('general');
  const [newPriority, setNewPriority] = useState<NoticePriority>('info');
  const [newIsPinned, setNewIsPinned] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');

  // Auto-dismiss logic for urgent system notices (Reset notification)
  useEffect(() => {
    if (!isAdmin) return; // Only trigger for admin who initiated

    const urgentNotices = notices.filter(n => 
      (n.priority === 'urgent' || n.category === 'system_reset')
    );

    if (urgentNotices.length > 0) {
      const timers = urgentNotices.map(notice => {
        return setTimeout(() => {
          deleteAdminNotice(notice.id);
        }, 3000); // Exactly 3 seconds as requested
      });
      return () => timers.forEach(t => clearTimeout(t));
    }
  }, [notices, isAdmin, deleteAdminNotice]);

  if (!isOpen) return null;

  const currentUserId = currentUser?.id || 'staff';

  const filteredNotices = notices.filter((n) => {
    if (filterCategory === 'all') return true;
    return n.category === filterCategory;
  });

  const handlePostNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newMessage.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await addAdminNotice({
        title: newTitle.trim(),
        message: newMessage.trim(),
        category: newCategory,
        priority: newPriority,
        isPinned: newIsPinned,
      });
      if (res.success) {
        setNewTitle('');
        setNewMessage('');
        setNewCategory('general');
        setNewPriority('info');
        setNewIsPinned(false);
        setIsComposing(false);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="admin-notice-center-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white tracking-tight">
                  Admin Broadcast & Notice Board
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  {notices.length} {notices.length === 1 ? 'Notice' : 'Notices'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Live administrative notices, system changes, rate revisions & announcements
              </p>
            </div>
          </div>
          <button
            id="close-notice-center-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice Creation Bar for Admin */}
        {isAdmin && (
          <div className="px-6 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Admin Mode: Any changes you make or notices you post instantly reach staff terminals.</span>
            </div>
            <button
              id="toggle-compose-notice-btn"
              onClick={() => setIsComposing(!isComposing)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-bold transition-all shadow-sm shadow-cyan-500/20 cursor-pointer"
            >
              {isComposing ? <X className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
              <span>{isComposing ? 'Cancel Post' : '+ Broadcast Notice'}</span>
            </button>
          </div>
        )}

        {/* Compose Form */}
        {isAdmin && isComposing && (
          <form
            onSubmit={handlePostNotice}
            className="p-6 border-b border-slate-800 bg-slate-950/40 space-y-4 animate-in slide-in-from-top duration-200"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Create Broadcast Announcement
              </h4>
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={newIsPinned}
                  onChange={(e) => setNewIsPinned(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-cyan-500"
                />
                <Pin className="w-3 h-3 text-amber-400" />
                <span>Pin to top</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 relative z-10">
              <div className="relative">
                <label
                  htmlFor="notice-category-select"
                  className="block text-[11px] font-semibold text-slate-300 uppercase mb-1 tracking-wide"
                >
                  Category
                </label>
                <select
                  id="notice-category-select"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as NoticeCategory)}
                  style={{ colorScheme: 'dark', backgroundColor: '#0f172a', color: '#f8fafc' }}
                  className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 font-medium focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 hover:border-slate-600 transition-colors cursor-pointer shadow-sm"
                >
                  <option
                    value="general"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    General Announcement
                  </option>
                  <option
                    value="rates_pricing"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Rates & Pricing Update
                  </option>
                  <option
                    value="inventory_consoles"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Stations & Consoles
                  </option>
                  <option
                    value="rentals"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Rental Gear
                  </option>
                  <option
                    value="cafeteria"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Cafeteria & Stock
                  </option>
                  <option
                    value="maintenance"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Maintenance
                  </option>
                  <option
                    value="system_reset"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    System Reset Alert
                  </option>
                </select>
              </div>
              <div className="relative">
                <label
                  htmlFor="notice-priority-select"
                  className="block text-[11px] font-semibold text-slate-300 uppercase mb-1 tracking-wide"
                >
                  Priority
                </label>
                <select
                  id="notice-priority-select"
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as NoticePriority)}
                  style={{ colorScheme: 'dark', backgroundColor: '#0f172a', color: '#f8fafc' }}
                  className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 font-medium focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 hover:border-slate-600 transition-colors cursor-pointer shadow-sm"
                >
                  <option
                    value="info"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Info (Standard)
                  </option>
                  <option
                    value="important"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Important (Highlighted)
                  </option>
                  <option
                    value="urgent"
                    style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    className="bg-slate-900 text-slate-100 py-2 px-3"
                  >
                    Urgent (Red Alert Banner)
                  </option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">
                Notice Title
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Weekend Hourly Rate Revision or Maintenance Window"
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 placeholder:text-slate-500"
                required
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">
                Detailed Message
              </label>
              <textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                rows={3}
                placeholder="Write message details for staff..."
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 placeholder:text-slate-500 resize-none"
                required
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsComposing(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !newTitle.trim() || !newMessage.trim()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 disabled:opacity-50 text-slate-950 text-xs font-bold shadow-md shadow-cyan-500/20 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Posting...' : 'Broadcast to Staff'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Category Filters */}
        <div className="px-6 py-2.5 bg-slate-950/40 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-xs">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all cursor-pointer ${
              filterCategory === 'all'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            All ({notices.length})
          </button>
          {(Object.keys(CATEGORY_LABELS) as NoticeCategory[]).map((cat) => {
            const count = notices.filter((n) => n.category === cat).length;
            if (count === 0 && cat !== 'general' && cat !== 'rates_pricing' && cat !== 'system_reset') {
              return null;
            }
            return (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                  filterCategory === cat
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white bg-slate-800/60'
                }`}
              >
                <span>{CATEGORY_LABELS[cat]}</span>
                <span className="text-[10px] opacity-70">({count})</span>
              </button>
            );
          })}
        </div>

        {/* Notice List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {filteredNotices.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <Bell className="w-10 h-10 mx-auto mb-2 opacity-30 text-slate-400" />
              <p className="text-sm font-semibold text-slate-400">No active notices found</p>
              <p className="text-xs text-slate-500 mt-1">
                Any modifications to rates, inventory, resets, or announcements from Admin will appear here.
              </p>
            </div>
          ) : (
            filteredNotices.map((notice) => {
              const isAck = (notice.acknowledgedBy || []).includes(currentUserId);
              const isUrgent = notice.priority === 'urgent';
              const isImportant = notice.priority === 'important';

              return (
                <div
                  key={notice.id}
                  id={`notice-card-${notice.id}`}
                  className={`relative p-4 rounded-xl border transition-all ${
                    isUrgent
                      ? 'bg-rose-950/20 border-rose-500/40 shadow-sm shadow-rose-950/30'
                      : isImportant
                      ? 'bg-amber-950/15 border-amber-500/30'
                      : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Top line badges */}
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                          CATEGORY_STYLES[notice.category] || CATEGORY_STYLES.general
                        }`}
                      >
                        {CATEGORY_ICONS[notice.category] || CATEGORY_ICONS.general}
                        <span>{CATEGORY_LABELS[notice.category] || notice.category}</span>
                      </span>

                      {notice.isPinned && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                          <Pin className="w-2.5 h-2.5" /> Pinned
                        </span>
                      )}

                      {isUrgent && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-400" /> URGENT
                        </span>
                      )}
                      {isImportant && !isUrgent && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                          IMPORTANT
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                      <span className="flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {new Date(notice.createdAt).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                        })}{' '}
                        {new Date(notice.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>

                      {isAdmin && (
                        <button
                          onClick={() => deleteAdminNotice(notice.id)}
                          title="Delete Notice (Admin)"
                          className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer ml-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Title & Body */}
                  <h4 className="text-sm font-bold text-white mb-1.5">{notice.title}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                    {notice.message}
                  </p>

                  {/* Footer with Author & Acknowledge Button */}
                  <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                      Posted by <strong className="text-slate-300">{notice.authorName}</strong>
                    </span>

                    {!isAdmin && (
                      <div>
                        {isAck ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Acknowledged
                          </span>
                        ) : (
                          <button
                            onClick={() => acknowledgeNotice(notice.id)}
                            className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold transition-all cursor-pointer"
                          >
                            <CheckCircle2 className="w-3 h-3" /> Mark as Read
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <span>Synced across all terminals in real-time</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
