import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Banknote,
  QrCode,
  CreditCard,
  MoreHorizontal,
  Split,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { PaymentMethod, PaymentSplitItem, PaymentStatus } from '../../types';

export interface SplitPaymentState {
  isSplit: boolean;
  paymentMethod: PaymentMethod;
  totalPaid: number;
  remaining: number;
  paymentStatus: PaymentStatus;
  splitDetails?: PaymentSplitItem[];
}

interface SplitPaymentSectionProps {
  totalBill: number;
  currencySymbol: string;
  onChange: (state: SplitPaymentState) => void;
  defaultMethod?: PaymentMethod;
  initialPaidAmount?: number;
  allowPartial?: boolean;
}

export const SplitPaymentSection: React.FC<SplitPaymentSectionProps> = ({
  totalBill,
  currencySymbol,
  onChange,
  defaultMethod = 'upi',
  initialPaidAmount,
  allowPartial = true,
}) => {
  const [isSplit, setIsSplit] = useState<boolean>(defaultMethod === 'split');
  const [singleMethod, setSingleMethod] = useState<PaymentMethod>(
    defaultMethod === 'split' ? 'upi' : defaultMethod
  );
  const [singleAmount, setSingleAmount] = useState<string>(
    initialPaidAmount !== undefined ? String(initialPaidAmount) : String(totalBill)
  );

  // Split amounts
  const [cashAmount, setCashAmount] = useState<string>('');
  const [upiAmount, setUpiAmount] = useState<string>('');
  const [cardAmount, setCardAmount] = useState<string>('');
  const [otherAmount, setOtherAmount] = useState<string>('');

  // Update default single amount when totalBill changes if it matches previous total
  useEffect(() => {
    if (!isSplit && (singleAmount === '' || parseFloat(singleAmount) === totalBill)) {
      setSingleAmount(String(totalBill));
    }
  }, [totalBill, isSplit]);

  // Compute values for Single mode
  const singlePaidNum = useMemo(() => {
    if (singleAmount === '') return totalBill;
    const val = parseFloat(singleAmount);
    return isNaN(val) ? 0 : Math.max(0, val);
  }, [singleAmount, totalBill]);

  // Compute values for Split mode
  const parsedCash = parseFloat(cashAmount) || 0;
  const parsedUpi = parseFloat(upiAmount) || 0;
  const parsedCard = parseFloat(cardAmount) || 0;
  const parsedOther = parseFloat(otherAmount) || 0;

  const splitTotalPaid = useMemo(() => {
    return Math.round((parsedCash + parsedUpi + parsedCard + parsedOther) * 100) / 100;
  }, [parsedCash, parsedUpi, parsedCard, parsedOther]);

  // Active Total Paid
  const currentTotalPaid = isSplit ? splitTotalPaid : singlePaidNum;
  const remaining = Math.max(0, Math.round((totalBill - currentTotalPaid) * 100) / 100);
  const isOverpaid = currentTotalPaid > totalBill;

  // Derive Payment Status
  const paymentStatus: PaymentStatus = useMemo(() => {
    if (totalBill === 0) return 'paid';
    if (currentTotalPaid >= totalBill) return 'paid';
    if (currentTotalPaid > 0 && currentTotalPaid < totalBill) return 'partial';
    return 'pending';
  }, [totalBill, currentTotalPaid]);

  // Notify parent on changes safely
  const onChangeRef = useRef(onChange);
  useEffect(() => {
    onChangeRef.current = onChange;
  });

  const lastEmittedPayloadRef = useRef<string>('');

  const currentPayload = useMemo(() => {
    if (isSplit) {
      const splits: PaymentSplitItem[] = [];
      if (parsedCash > 0) splits.push({ method: 'cash', amount: parsedCash });
      if (parsedUpi > 0) splits.push({ method: 'upi', amount: parsedUpi });
      if (parsedCard > 0) splits.push({ method: 'card', amount: parsedCard });
      if (parsedOther > 0) splits.push({ method: 'other', amount: parsedOther });

      return {
        isSplit: true,
        paymentMethod: 'split' as PaymentMethod,
        totalPaid: splitTotalPaid,
        remaining,
        paymentStatus,
        splitDetails: splits.length > 0 ? splits : undefined,
      };
    } else {
      return {
        isSplit: false,
        paymentMethod: singleMethod,
        totalPaid: singlePaidNum,
        remaining: Math.max(0, totalBill - singlePaidNum),
        paymentStatus,
        splitDetails: undefined,
      };
    }
  }, [
    isSplit,
    parsedCash,
    parsedUpi,
    parsedCard,
    parsedOther,
    splitTotalPaid,
    remaining,
    paymentStatus,
    singleMethod,
    singlePaidNum,
    totalBill,
  ]);

  useEffect(() => {
    const serialized = JSON.stringify(currentPayload);
    if (lastEmittedPayloadRef.current !== serialized) {
      lastEmittedPayloadRef.current = serialized;
      onChangeRef.current(currentPayload);
    }
  }, [currentPayload]);

  // Helper functions for Split Mode
  const handleFillRemaining = (method: 'cash' | 'upi' | 'card' | 'other') => {
    const otherSum =
      (method !== 'cash' ? parsedCash : 0) +
      (method !== 'upi' ? parsedUpi : 0) +
      (method !== 'card' ? parsedCard : 0) +
      (method !== 'other' ? parsedOther : 0);

    const needed = Math.max(0, Math.round((totalBill - otherSum) * 100) / 100);
    const neededStr = needed > 0 ? String(needed) : '';

    if (method === 'cash') setCashAmount(neededStr);
    if (method === 'upi') setUpiAmount(neededStr);
    if (method === 'card') setCardAmount(neededStr);
    if (method === 'other') setOtherAmount(neededStr);
  };

  const handleSplit5050 = (m1: 'cash' | 'upi' | 'card', m2: 'cash' | 'upi' | 'card') => {
    const half = Math.round((totalBill / 2) * 100) / 100;
    const remainder = Math.round((totalBill - half) * 100) / 100;

    setCashAmount('');
    setUpiAmount('');
    setCardAmount('');
    setOtherAmount('');

    if (m1 === 'cash') setCashAmount(String(half));
    if (m1 === 'upi') setUpiAmount(String(half));
    if (m1 === 'card') setCardAmount(String(half));

    if (m2 === 'cash') setCashAmount(String(remainder));
    if (m2 === 'upi') setUpiAmount(String(remainder));
    if (m2 === 'card') setCardAmount(String(remainder));
  };

  const handleClearSplit = () => {
    setCashAmount('');
    setUpiAmount('');
    setCardAmount('');
    setOtherAmount('');
  };

  const handleSplitAmountChange = (
    method: 'cash' | 'upi' | 'card' | 'other',
    rawVal: string
  ) => {
    if (rawVal === '') {
      if (method === 'cash') setCashAmount('');
      if (method === 'upi') setUpiAmount('');
      if (method === 'card') setCardAmount('');
      if (method === 'other') setOtherAmount('');
      return;
    }

    const num = parseFloat(rawVal);
    if (isNaN(num) || num < 0) return;

    // Calculate maximum allowable for this field so total paid never exceeds total bill
    const otherSum =
      (method !== 'cash' ? parsedCash : 0) +
      (method !== 'upi' ? parsedUpi : 0) +
      (method !== 'card' ? parsedCard : 0) +
      (method !== 'other' ? parsedOther : 0);

    const maxAllowed = Math.max(0, Math.round((totalBill - otherSum) * 100) / 100);

    // If user enters more than allowable, cap it at maxAllowed
    if (num > maxAllowed) {
      const cappedStr = maxAllowed > 0 ? String(maxAllowed) : '';
      if (method === 'cash') setCashAmount(cappedStr);
      if (method === 'upi') setUpiAmount(cappedStr);
      if (method === 'card') setCardAmount(cappedStr);
      if (method === 'other') setOtherAmount(cappedStr);
      return;
    }

    if (method === 'cash') setCashAmount(rawVal);
    if (method === 'upi') setUpiAmount(rawVal);
    if (method === 'card') setCardAmount(rawVal);
    if (method === 'other') setOtherAmount(rawVal);
  };

  const methods = [
    { id: 'upi', label: 'UPI / QR', icon: QrCode, color: 'cyan' },
    { id: 'cash', label: 'Cash', icon: Banknote, color: 'emerald' },
    { id: 'card', label: 'Card / POS', icon: CreditCard, color: 'indigo' },
    { id: 'other', label: 'Other', icon: MoreHorizontal, color: 'slate' },
  ];

  return (
    <div id="split-payment-section" className="space-y-3.5">
      {/* Mode Switcher Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Payment Method
        </label>
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs w-full sm:w-auto">
          <button
            type="button"
            id="single-payment-mode-btn"
            onClick={() => setIsSplit(false)}
            className={`flex-1 sm:flex-initial text-center justify-center px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              !isSplit
                ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Single Method
          </button>
          <button
            type="button"
            id="split-payment-mode-btn"
            onClick={() => {
              setIsSplit(true);
              // If all split fields are empty, pre-fill UPI and Cash 50/50 or leave ready
              if (!cashAmount && !upiAmount && !cardAmount && !otherAmount) {
                const half = Math.round((totalBill / 2) * 100) / 100;
                const rem = Math.round((totalBill - half) * 100) / 100;
                setCashAmount(String(half));
                setUpiAmount(String(rem));
              }
            }}
            className={`flex-1 sm:flex-initial text-center justify-center flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              isSplit
                ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 shadow-sm shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Split className="w-3.5 h-3.5" />
            <span>Split Payment</span>
          </button>
        </div>
      </div>

      {/* SINGLE PAYMENT MODE */}
      {!isSplit ? (
        <div className="space-y-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {methods.map((m) => {
              const Icon = m.icon;
              const isSelected = singleMethod === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  id={`single-method-${m.id}`}
                  onClick={() => setSingleMethod(m.id as PaymentMethod)}
                  className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all text-xs font-bold ${
                    isSelected
                      ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-[11px] truncate w-full text-center">{m.label}</span>
                </button>
              );
            })}
          </div>

          {allowPartial && (
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Amount Received ({currencySymbol})
                </label>
                <input
                  id="single-received-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  placeholder={`Default: ${totalBill}`}
                  value={singleAmount}
                  onChange={(e) => {
                    const val = e.target.value;
                    const num = parseFloat(val);
                    if (!isNaN(num) && num > totalBill) {
                      setSingleAmount(String(totalBill));
                    } else {
                      setSingleAmount(val);
                    }
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Payment Status
                </label>
                <div className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs flex items-center justify-between">
                  <span
                    className={`font-extrabold uppercase ${
                      paymentStatus === 'paid'
                        ? 'text-emerald-400'
                        : paymentStatus === 'partial'
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {paymentStatus}
                  </span>
                  {remaining > 0 && (
                    <span className="text-[11px] text-amber-400 font-mono font-bold">
                      Pending: {currencySymbol} {remaining}
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* SPLIT PAYMENT MODE */
        <div className="space-y-3 bg-slate-950/90 border border-amber-500/30 rounded-2xl p-3.5 shadow-inner">
          {/* Preset Quick Actions */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
            <span className="text-[11px] text-slate-400 font-semibold flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              Quick Presets:
            </span>
            <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
              <button
                type="button"
                id="split-5050-upi-cash"
                onClick={() => handleSplit5050('cash', 'upi')}
                className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-2 py-1 rounded-lg border border-slate-700/80 transition-colors font-medium cursor-pointer"
              >
                Cash + UPI (50/50)
              </button>
              <button
                type="button"
                id="split-5050-card-upi"
                onClick={() => handleSplit5050('card', 'upi')}
                className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-2 py-1 rounded-lg border border-slate-700/80 transition-colors font-medium cursor-pointer"
              >
                Card + UPI (50/50)
              </button>
              <button
                type="button"
                onClick={handleClearSplit}
                className="text-slate-500 hover:text-rose-400 px-1.5 py-1 transition-colors flex items-center gap-1 cursor-pointer"
                title="Reset split inputs"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Clear</span>
              </button>
            </div>
          </div>

          {/* 4 Method Input Rows */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* Cash */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <Banknote className="w-3.5 h-3.5" />
                  <span>Cash</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleFillRemaining('cash')}
                  className="text-[10px] text-slate-400 hover:text-emerald-300 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                  {currencySymbol}
                </span>
                <input
                  id="split-cash-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={cashAmount}
                  onChange={(e) => handleSplitAmountChange('cash', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            {/* UPI / QR */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
                  <QrCode className="w-3.5 h-3.5" />
                  <span>UPI / QR</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleFillRemaining('upi')}
                  className="text-[10px] text-slate-400 hover:text-cyan-300 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                  {currencySymbol}
                </span>
                <input
                  id="split-upi-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={upiAmount}
                  onChange={(e) => handleSplitAmountChange('upi', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            {/* Card / POS */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-400">
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Card / POS</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleFillRemaining('card')}
                  className="text-[10px] text-slate-400 hover:text-indigo-300 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                  {currencySymbol}
                </span>
                <input
                  id="split-card-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={cardAmount}
                  onChange={(e) => handleSplitAmountChange('card', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-indigo-400"
                />
              </div>
            </div>

            {/* Other */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-slate-600 rounded-xl p-2.5 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
                  <MoreHorizontal className="w-3.5 h-3.5" />
                  <span>Other / Wallet</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleFillRemaining('other')}
                  className="text-[10px] text-slate-400 hover:text-slate-200 underline font-medium cursor-pointer"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                  {currencySymbol}
                </span>
                <input
                  id="split-other-input"
                  type="number"
                  min="0"
                  max={totalBill}
                  step="any"
                  placeholder="0.00"
                  value={otherAmount}
                  onChange={(e) => handleSplitAmountChange('other', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-slate-400"
                />
              </div>
            </div>
          </div>

          {/* Real-time Calculation Summary Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">Total Bill Amount:</span>
              <span className="font-mono font-bold text-white">
                {currencySymbol} {totalBill.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">Total Paid (Allocated):</span>
              <span
                className={`font-mono font-extrabold text-sm ${
                  splitTotalPaid === totalBill
                    ? 'text-emerald-400'
                    : splitTotalPaid > 0
                    ? 'text-amber-400'
                    : 'text-slate-400'
                }`}
              >
                {currencySymbol} {splitTotalPaid.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-semibold">Payment Status:</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wide ${
                    paymentStatus === 'paid'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : paymentStatus === 'partial'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  }`}
                >
                  {paymentStatus}
                </span>
              </div>

              {remaining > 0 ? (
                <div className="flex items-center gap-1 text-amber-400 font-bold font-mono">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Pending: {currencySymbol} {remaining.toLocaleString('en-IN')}</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Fully Balanced</span>
                </div>
              )}
            </div>

            {isOverpaid && (
              <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1 pt-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                Total payment amounts must never exceed the bill amount.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
