import React from 'react';
import { Bell, AlertTriangle, Pin, ArrowRight, CheckCircle2, X } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';

interface StaffNoticeBannerProps {
  onOpenNoticeCenter: () => void;
}

export const StaffNoticeBanner: React.FC<StaffNoticeBannerProps> = ({
  onOpenNoticeCenter,
}) => {
  const { notices, currentUser, isAdmin, acknowledgeNotice } = useCafe();

  const currentUserId = currentUser?.id || 'staff';

  // Find most critical unacknowledged notice
  const activeUnackNotice = [...notices]
    .sort((a, b) => {
      if (a.priority === 'urgent' && b.priority !== 'urgent') return -1;
      if (b.priority === 'urgent' && a.priority !== 'urgent') return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    })
    .find((n) => !(n.acknowledgedBy || []).includes(currentUserId));

  if (!activeUnackNotice) return null;

  const isAck = (activeUnackNotice.acknowledgedBy || []).includes(currentUserId);
  const isUrgent = activeUnackNotice.priority === 'urgent';
  const isImportant = activeUnackNotice.priority === 'important';

  return (
    <div
      id="staff-notice-banner"
      className={`mx-4 sm:mx-6 mt-3 px-4 py-2.5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md transition-all animate-in fade-in slide-in-from-top-2 duration-300 ${
        isUrgent
          ? 'bg-rose-950/40 border-rose-500/50 text-rose-200'
          : isImportant
          ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
          : 'bg-slate-900/95 border-cyan-500/30 text-slate-200'
      }`}
    >
      <div className="flex items-center gap-3 min-w-0">
        <div
          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
            isUrgent
              ? 'bg-rose-500/20 text-rose-400 animate-pulse'
              : isImportant
              ? 'bg-amber-500/20 text-amber-400'
              : 'bg-cyan-500/20 text-cyan-400'
          }`}
        >
          {isUrgent ? (
            <AlertTriangle className="w-4 h-4" />
          ) : activeUnackNotice.isPinned ? (
            <Pin className="w-4 h-4" />
          ) : (
            <Bell className="w-4 h-4" />
          )}
        </div>

        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-black/40 border border-white/10">
              Admin Notice
            </span>
            <span className="text-xs font-bold text-white truncate max-w-[300px] sm:max-w-md">
              {activeUnackNotice.title}
            </span>
          </div>
          <p className="text-xs opacity-90 truncate max-w-lg mt-0.5">
            {activeUnackNotice.message}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
        {!isAdmin && !isAck && (
          <button
            onClick={() => acknowledgeNotice(activeUnackNotice.id)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold cursor-pointer transition-colors"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Mark Read</span>
          </button>
        )}

        <button
          onClick={onOpenNoticeCenter}
          className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer transition-colors"
        >
          <span>View All ({notices.length})</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
