import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Banknote,
  QrCode,
  CreditCard,
  MoreHorizontal,
  Split,
  CheckCircle2,
  Clock,
  RotateCcw,
  AlertCircle,
  Sparkles,
  Check,
} from 'lucide-react';
import { PaymentMethod, PaymentSplitItem, PaymentStatus } from '../../types';

export interface PaymentInputData {
  paymentMode: 'single' | 'split';
  paymentMethod: PaymentMethod;
  paidAmount: number;
  remaining: number;
  paymentStatus: PaymentStatus;
  splitPayments?: PaymentSplitItem[];
  isValid: boolean;
  errorMessage?: string | null;
}

interface PaymentInputSectionProps {
  totalBill: number;
  currencySymbol: string;
  onChange: (data: PaymentInputData) => void;
  defaultMode?: 'single' | 'split';
  defaultMethod?: PaymentMethod;
  initialPaidAmount?: number;
}

export const PaymentInputSection: React.FC<PaymentInputSectionProps> = ({
  totalBill,
  currencySymbol,
  onChange,
  defaultMode = 'single',
  defaultMethod = 'cash',
  initialPaidAmount,
}) => {
  const [paymentMode, setPaymentMode] = useState<'single' | 'split'>(defaultMode);

  // Single Payment States
  const [singleMethod, setSingleMethod] = useState<PaymentMethod>(
    defaultMethod === 'split' ? 'cash' : defaultMethod
  );
  const [singleAmountPaidStr, setSingleAmountPaidStr] = useState<string>(
    initialPaidAmount !== undefined ? String(initialPaidAmount) : (totalBill > 0 ? String(totalBill) : '')
  );
  const [singleWasEdited, setSingleWasEdited] = useState<boolean>(false);

  // Split Payment States (string-backed for smooth typing, editing, decimal support & deleting 0)
  const [cashInput, setCashInput] = useState<string>('');
  const [upiInput, setUpiInput] = useState<string>('');
  const [cardInput, setCardInput] = useState<string>('');
  const [otherInput, setOtherInput] = useState<string>('');

  // Sync single amount when totalBill changes if user hasn't explicitly customized it
  const prevBillRef = useRef<number>(0); // Initialize to 0 to catch the first bill on mount
  const singleWasEditedRef = useRef(singleWasEdited);
  singleWasEditedRef.current = singleWasEdited;

  // Track if we already did the initial sync for the mount bill
  const initialSyncDone = useRef(false);

  useEffect(() => {
    // If bill changed OR it's the first time we have a non-zero bill and it wasn't edited
    if (prevBillRef.current !== totalBill || (!initialSyncDone.current && totalBill > 0)) {
      setSingleAmountPaidStr((prev) => {
        // If not edited, or if the current value matches the PREVIOUS bill (meaning it was auto-synced)
        if (!singleWasEditedRef.current || prev === String(prevBillRef.current) || prev === '') {
          return totalBill > 0 ? String(totalBill) : '';
        }
        // If edited but current value is now greater than total bill, cap it
        const currentVal = parseFloat(prev) || 0;
        if (currentVal > totalBill && totalBill > 0) {
          return String(totalBill);
        }
        return prev;
      });
      prevBillRef.current = totalBill;
      initialSyncDone.current = true;
    }
  }, [totalBill]);

  // ------------------------------------
  // SINGLE PAYMENT CALCULATIONS
  // ------------------------------------
  const numericSinglePaid = useMemo(() => {
    if (singleAmountPaidStr.trim() === '') return 0;
    const val = parseFloat(singleAmountPaidStr);
    if (isNaN(val) || val < 0) return 0;
    return Math.round(val * 100) / 100;
  }, [singleAmountPaidStr]);

  const isSingleExceeding = numericSinglePaid > totalBill;
  const singleExcess = isSingleExceeding ? Math.round((numericSinglePaid - totalBill) * 100) / 100 : 0;

  const singleRemaining = Math.max(
    0,
    Math.round((totalBill - numericSinglePaid) * 100) / 100
  );

  const singleStatus: PaymentStatus =
    numericSinglePaid >= totalBill && totalBill > 0
      ? 'paid'
      : numericSinglePaid > 0
      ? 'partial'
      : totalBill === 0
      ? 'paid'
      : 'pending';

  // ------------------------------------
  // SPLIT PAYMENT CALCULATIONS
  // ------------------------------------
  const numericCash = parseFloat(cashInput) || 0;
  const numericUpi = parseFloat(upiInput) || 0;
  const numericCard = parseFloat(cardInput) || 0;
  const numericOther = parseFloat(otherInput) || 0;

  // Total Paid = Sum of payment amounts
  const splitTotalPaid = useMemo(() => {
    const sum = numericCash + numericUpi + numericCard + numericOther;
    return Math.round(sum * 100) / 100;
  }, [numericCash, numericUpi, numericCard, numericOther]);

  // Remaining = Total Bill - Total Paid
  const splitRemaining = Math.max(
    0,
    Math.round((totalBill - splitTotalPaid) * 100) / 100
  );

  const isSplitExceeding = splitTotalPaid > totalBill;
  const splitExcess = isSplitExceeding ? Math.round((splitTotalPaid - totalBill) * 100) / 100 : 0;

  const splitStatus: PaymentStatus =
    splitTotalPaid >= totalBill && totalBill > 0
      ? 'paid'
      : splitTotalPaid > 0
      ? 'partial'
      : totalBill === 0
      ? 'paid'
      : 'pending';

  const splitItems = useMemo<PaymentSplitItem[]>(() => {
    const items: PaymentSplitItem[] = [];
    if (numericCash > 0) items.push({ method: 'cash', amount: numericCash });
    if (numericUpi > 0) items.push({ method: 'upi', amount: numericUpi });
    if (numericCard > 0) items.push({ method: 'card', amount: numericCard });
    if (numericOther > 0) items.push({ method: 'other', amount: numericOther });
    return items;
  }, [numericCash, numericUpi, numericCard, numericOther]);

  // ------------------------------------
  // EMIT TO PARENT VIA ONCHANGE SAFELY
  // ------------------------------------
  const onChangeRef = useRef(onChange);
  useEffect(() => {
    onChangeRef.current = onChange;
  });

  const lastEmittedPayloadRef = useRef<string>('');

  const currentPayload: PaymentInputData = useMemo(() => {
    if (paymentMode === 'single') {
      const isValid = !isSingleExceeding;
      return {
        paymentMode: 'single',
        paymentMethod: singleMethod,
        paidAmount: isSingleExceeding ? totalBill : numericSinglePaid,
        remaining: singleRemaining,
        paymentStatus: singleStatus,
        isValid,
        errorMessage: isSingleExceeding
          ? `Amount (${currencySymbol} ${numericSinglePaid}) exceeds total bill (${currencySymbol} ${totalBill}) by ${currencySymbol} ${singleExcess}`
          : null,
      };
    } else {
      const isValid = !isSplitExceeding;
      return {
        paymentMode: 'split',
        paymentMethod: 'split',
        paidAmount: isSplitExceeding ? totalBill : splitTotalPaid,
        remaining: splitRemaining,
        paymentStatus: splitStatus,
        splitPayments: splitItems.length > 0 ? splitItems : undefined,
        isValid,
        errorMessage: isSplitExceeding
          ? `Total split payments (${currencySymbol} ${splitTotalPaid}) exceed bill (${currencySymbol} ${totalBill}) by ${currencySymbol} ${splitExcess}`
          : null,
      };
    }
  }, [
    paymentMode,
    singleMethod,
    numericSinglePaid,
    isSingleExceeding,
    singleExcess,
    singleRemaining,
    singleStatus,
    splitTotalPaid,
    isSplitExceeding,
    splitExcess,
    splitRemaining,
    splitStatus,
    splitItems,
    totalBill,
    currencySymbol,
  ]);

  useEffect(() => {
    const serialized = JSON.stringify(currentPayload);
    if (lastEmittedPayloadRef.current !== serialized) {
      lastEmittedPayloadRef.current = serialized;
      onChangeRef.current(currentPayload);
    }
  }, [currentPayload]);

  // ------------------------------------
  // SINGLE PAYMENT HANDLERS
  // ------------------------------------
  const handleSingleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSingleWasEdited(true);
    const raw = e.target.value;

    // Allow clearing input so user can delete 0 or backspace cleanly
    if (raw === '') {
      setSingleAmountPaidStr('');
      return;
    }

    // Only allow valid decimal numbers (digits with at most one decimal point)
    if (!/^\d*\.?\d*$/.test(raw)) {
      return;
    }

    // Clean leading zero like "05" -> "5", while preserving "0" and "0."
    let clean = raw;
    if (clean.length > 1 && clean.startsWith('0') && !clean.startsWith('0.')) {
      clean = clean.replace(/^0+/, '');
      if (clean === '') clean = '0';
    }

    setSingleAmountPaidStr(clean);
  };

  const setSingleFullAmount = () => {
    setSingleWasEdited(true);
    setSingleAmountPaidStr(String(totalBill));
  };

  const setSingleZeroPending = () => {
    setSingleWasEdited(true);
    setSingleAmountPaidStr('0');
  };

  const capSingleToBill = () => {
    setSingleWasEdited(true);
    setSingleAmountPaidStr(String(totalBill));
  };

  // ------------------------------------
  // SPLIT PAYMENT HANDLERS
  // ------------------------------------
  const handleSplitInputChange = (
    channel: 'cash' | 'upi' | 'card' | 'other',
    rawVal: string
  ) => {
    // Allow deleting 0 and clearing field
    if (rawVal === '') {
      if (channel === 'cash') setCashInput('');
      if (channel === 'upi') setUpiInput('');
      if (channel === 'card') setCardInput('');
      if (channel === 'other') setOtherInput('');
      return;
    }

    // Only allow valid numeric / decimal strings
    if (!/^\d*\.?\d*$/.test(rawVal)) {
      return;
    }

    // Clean leading zeroes: e.g. typing 5 after 0 becomes 5 instead of 05
    let clean = rawVal;
    if (clean.length > 1 && clean.startsWith('0') && !clean.startsWith('0.')) {
      clean = clean.replace(/^0+/, '');
      if (clean === '') clean = '0';
    }

    if (channel === 'cash') setCashInput(clean);
    if (channel === 'upi') setUpiInput(clean);
    if (channel === 'card') setCardInput(clean);
    if (channel === 'other') setOtherInput(clean);
  };

  const fillRemainingToChannel = (channel: 'cash' | 'upi' | 'card' | 'other') => {
    const currentOtherSum =
      (channel !== 'cash' ? numericCash : 0) +
      (channel !== 'upi' ? numericUpi : 0) +
      (channel !== 'card' ? numericCard : 0) +
      (channel !== 'other' ? numericOther : 0);

    const needed = Math.max(0, Math.round((totalBill - currentOtherSum) * 100) / 100);
    const neededStr = needed > 0 ? String(needed) : '0';

    if (channel === 'cash') setCashInput(neededStr);
    if (channel === 'upi') setUpiInput(neededStr);
    if (channel === 'card') setCardInput(neededStr);
    if (channel === 'other') setOtherInput(neededStr);
  };

  const autoAdjustSplitToBill = () => {
    if (splitTotalPaid <= totalBill) return;
    let excess = Math.round((splitTotalPaid - totalBill) * 100) / 100;

    // Deduct excess from the highest channels
    const channels = [
      { name: 'other' as const, val: numericOther },
      { name: 'card' as const, val: numericCard },
      { name: 'upi' as const, val: numericUpi },
      { name: 'cash' as const, val: numericCash },
    ].sort((a, b) => b.val - a.val);

    for (const ch of channels) {
      if (ch.val <= 0 || excess <= 0) continue;
      const deduction = Math.min(ch.val, excess);
      const newVal = Math.round((ch.val - deduction) * 100) / 100;
      const strVal = newVal > 0 ? String(newVal) : '';

      if (ch.name === 'cash') setCashInput(strVal);
      if (ch.name === 'upi') setUpiInput(strVal);
      if (ch.name === 'card') setCardInput(strVal);
      if (ch.name === 'other') setOtherInput(strVal);

      excess = Math.round((excess - deduction) * 100) / 100;
    }
  };

  const splitHalfCashUpi = () => {
    const half = Math.round((totalBill / 2) * 100) / 100;
    const otherHalf = Math.round((totalBill - half) * 100) / 100;
    setCashInput(String(half));
    setUpiInput(String(otherHalf));
    setCardInput('');
    setOtherInput('');
  };

  const setFullCash = () => {
    setCashInput(String(totalBill));
    setUpiInput('');
    setCardInput('');
    setOtherInput('');
  };

  const setFullUpi = () => {
    setCashInput('');
    setUpiInput(String(totalBill));
    setCardInput('');
    setOtherInput('');
  };

  const clearSplitInputs = () => {
    setCashInput('');
    setUpiInput('');
    setCardInput('');
    setOtherInput('');
  };

  const methodsList: { id: PaymentMethod; label: string; icon: React.ReactNode }[] = [
    { id: 'cash', label: 'Cash', icon: <Banknote className="w-4 h-4" /> },
    { id: 'upi', label: 'UPI / QR', icon: <QrCode className="w-4 h-4" /> },
    { id: 'card', label: 'Card / POS', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'other', label: 'Other', icon: <MoreHorizontal className="w-4 h-4" /> },
  ];

  return (
    <div id="payment-input-section" className="space-y-3 pt-3 border-t border-slate-800">
      {/* Mode Selector Tabs: Single Payment vs Split Payment */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Payment Collection
        </label>
        <div className="flex items-center p-1 bg-slate-950 border border-slate-800 rounded-xl w-full sm:w-auto">
          <button
            type="button"
            id="tab-single-payment"
            onClick={() => setPaymentMode('single')}
            className={`flex-1 sm:flex-initial text-center justify-center px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              paymentMode === 'single'
                ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Single Payment
          </button>
          <button
            type="button"
            id="tab-split-payment"
            onClick={() => {
              setPaymentMode('split');
            }}
            className={`flex-1 sm:flex-initial text-center justify-center flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              paymentMode === 'split'
                ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Split className="w-3.5 h-3.5" />
            <span>Split Payment</span>
          </button>
        </div>
      </div>

      {/* SINGLE PAYMENT MODE */}
      {paymentMode === 'single' ? (
        <div className="space-y-3 bg-slate-950/70 border border-slate-800 rounded-xl p-4">
          {/* Method Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">
              Select Payment Method
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {methodsList.map((m) => {
                const isSelected = singleMethod === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    id={`single-method-${m.id}`}
                    onClick={() => setSingleMethod(m.id)}
                    className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/10'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    {m.icon}
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Warning Banner for Single Payment Overpayment */}
          {isSingleExceeding && (
            <div className="p-2.5 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center justify-between gap-2 text-xs text-rose-300">
              <div className="flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>
                  Amount exceeds total bill by <strong>{currencySymbol} {singleExcess}</strong>. Payment cannot exceed bill.
                </span>
              </div>
              <button
                type="button"
                onClick={capSingleToBill}
                className="shrink-0 px-2 py-1 bg-rose-500/30 hover:bg-rose-500/50 text-white rounded text-[11px] font-bold cursor-pointer"
              >
                Cap to {currencySymbol} {totalBill}
              </button>
            </div>
          )}

          {/* Amount Inputs and Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-300">
                  Amount Paid
                </label>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={setSingleFullAmount}
                    className="text-[10px] font-bold text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                  >
                    Full Bill
                  </button>
                  <span className="text-slate-600">•</span>
                  <button
                    type="button"
                    onClick={setSingleZeroPending}
                    className="text-[10px] font-bold text-amber-400 hover:text-amber-300 underline cursor-pointer"
                  >
                    ₹0 Pending
                  </button>
                </div>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500 pointer-events-none">
                  {currencySymbol}
                </span>
                <input
                  id="single-payment-amount-input"
                  type="text"
                  inputMode="decimal"
                  value={singleAmountPaidStr}
                  onChange={handleSingleAmountChange}
                  placeholder="0.00"
                  className={`w-full bg-slate-900 border rounded-xl pl-8 pr-3 py-2 text-sm font-bold text-white focus:outline-none transition-colors ${
                    isSingleExceeding
                      ? 'border-rose-500 focus:border-rose-400'
                      : 'border-slate-700 focus:border-cyan-500'
                  }`}
                  required
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                Type any amount normally (e.g. 100, 250, 500). Delete 0 freely.
              </p>
            </div>

            {/* Live Remaining & Status */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Total Bill:</span>
                <span className="font-bold text-white font-mono">
                  {currencySymbol} {totalBill.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs pt-1.5 border-t border-slate-800/80">
                <span className="text-slate-400">Remaining Due:</span>
                <span
                  className={`font-bold font-mono ${
                    singleRemaining > 0 ? 'text-amber-400' : 'text-slate-400'
                  }`}
                >
                  {currencySymbol} {singleRemaining.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-500">
                  Projected Status:
                </span>
                  {singleStatus === 'paid' ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase tracking-wider">
                      <CheckCircle2 className="w-3 h-3" /> Fully Paid
                    </span>
                  ) : singleStatus === 'partial' ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider">
                      <Clock className="w-3 h-3" /> Partial Due (₹{singleRemaining})
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500/20 text-rose-300 border border-rose-500/40 uppercase tracking-wider">
                      <Clock className="w-3 h-3" /> Unpaid (₹{totalBill})
                    </span>
                  )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* SPLIT PAYMENT MODE */
        <div className="space-y-3 bg-slate-950/70 border border-slate-800 rounded-xl p-4">
          {/* Split Quick Actions */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-semibold text-slate-400">
              Split across payment methods:
            </span>
            <div className="flex items-center gap-2 text-[10px]">
              <button
                type="button"
                onClick={setFullCash}
                className="font-bold text-emerald-400 hover:text-emerald-300 underline cursor-pointer"
              >
                Full Cash
              </button>
              <span className="text-slate-600">•</span>
              <button
                type="button"
                onClick={setFullUpi}
                className="font-bold text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                Full UPI
              </button>
              <span className="text-slate-600">•</span>
              <button
                type="button"
                onClick={splitHalfCashUpi}
                className="font-bold text-amber-400 hover:text-amber-300 underline cursor-pointer"
              >
                50/50 Split
              </button>
              <span className="text-slate-600">•</span>
              <button
                type="button"
                onClick={clearSplitInputs}
                className="font-bold text-slate-400 hover:text-slate-200 underline cursor-pointer"
              >
                Clear All
              </button>
            </div>
          </div>

          {/* Overpayment Alert for Split Payments */}
          {isSplitExceeding && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center justify-between gap-2 text-xs text-rose-300">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>
                  Total split payments (<strong>{currencySymbol} {splitTotalPaid}</strong>) exceed bill by{' '}
                  <strong>{currencySymbol} {splitExcess}</strong>. Payment cannot exceed bill amount.
                </span>
              </div>
              <button
                type="button"
                onClick={autoAdjustSplitToBill}
                className="shrink-0 px-2.5 py-1 bg-rose-500/30 hover:bg-rose-500/50 text-white rounded text-[11px] font-bold cursor-pointer transition-colors"
              >
                Adjust to Bill Limit
              </button>
            </div>
          )}

          {/* Grid of 4 split inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* Cash */}
            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between mb-1">
                <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <Banknote className="w-3.5 h-3.5" /> Cash Amount
                </span>
                <button
                  type="button"
                  onClick={() => fillRemainingToChannel('cash')}
                  className="text-[10px] text-cyan-400 hover:underline cursor-pointer font-semibold"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 pointer-events-none">
                  {currencySymbol}
                </span>
                <input
                  id="split-input-cash"
                  type="text"
                  inputMode="decimal"
                  placeholder="0.00"
                  value={cashInput}
                  onChange={(e) => handleSplitInputChange('cash', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-7 pr-2.5 py-1.5 text-xs font-bold text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* UPI */}
            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between mb-1">
                <span className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
                  <QrCode className="w-3.5 h-3.5" /> UPI / QR Amount
                </span>
                <button
                  type="button"
                  onClick={() => fillRemainingToChannel('upi')}
                  className="text-[10px] text-cyan-400 hover:underline cursor-pointer font-semibold"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 pointer-events-none">
                  {currencySymbol}
                </span>
                <input
                  id="split-input-upi"
                  type="text"
                  inputMode="decimal"
                  placeholder="0.00"
                  value={upiInput}
                  onChange={(e) => handleSplitInputChange('upi', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-7 pr-2.5 py-1.5 text-xs font-bold text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* Card */}
            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between mb-1">
                <span className="flex items-center gap-1.5 text-xs font-bold text-indigo-400">
                  <CreditCard className="w-3.5 h-3.5" /> Card / POS Amount
                </span>
                <button
                  type="button"
                  onClick={() => fillRemainingToChannel('card')}
                  className="text-[10px] text-cyan-400 hover:underline cursor-pointer font-semibold"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 pointer-events-none">
                  {currencySymbol}
                </span>
                <input
                  id="split-input-card"
                  type="text"
                  inputMode="decimal"
                  placeholder="0.00"
                  value={cardInput}
                  onChange={(e) => handleSplitInputChange('card', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-7 pr-2.5 py-1.5 text-xs font-bold text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* Other */}
            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between mb-1">
                <span className="flex items-center gap-1.5 text-xs font-bold text-slate-400">
                  <MoreHorizontal className="w-3.5 h-3.5" /> Other Amount
                </span>
                <button
                  type="button"
                  onClick={() => fillRemainingToChannel('other')}
                  className="text-[10px] text-cyan-400 hover:underline cursor-pointer font-semibold"
                >
                  Fill Balance
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 pointer-events-none">
                  {currencySymbol}
                </span>
                <input
                  id="split-input-other"
                  type="text"
                  inputMode="decimal"
                  placeholder="0.00"
                  value={otherInput}
                  onChange={(e) => handleSplitInputChange('other', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-7 pr-2.5 py-1.5 text-xs font-bold text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          </div>

          {/* Split Summary Footer */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total Bill:</span>
              <span className="font-bold text-white font-mono">
                {currencySymbol} {totalBill.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400 font-semibold">Total Paid (Sum):</span>
              <span className="font-bold text-emerald-400 text-sm font-mono">
                {currencySymbol} {splitTotalPaid.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="flex items-center justify-between border-t border-slate-800/80 pt-1.5">
              <span className="text-slate-400">Remaining Amount:</span>
              <span
                className={`font-bold font-mono ${
                  splitRemaining > 0 ? 'text-amber-400' : 'text-slate-400'
                }`}
              >
                {currencySymbol} {splitRemaining.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[10px] uppercase font-bold text-slate-500">
                Projected Status:
              </span>
              {splitStatus === 'paid' ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase">
                  <CheckCircle2 className="w-3 h-3" /> Fully Paid
                </span>
              ) : splitStatus === 'partial' ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
                  <Clock className="w-3 h-3" /> Partial Due (₹{splitRemaining})
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500/20 text-rose-300 border border-rose-500/40 uppercase">
                  <Clock className="w-3 h-3" /> Unpaid (₹{totalBill})
                </span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
