import React from 'react';
import { BellRing, Check, X, CreditCard, Clock, Gamepad2 } from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { GamingSession } from '../../types';

interface SessionAlertBannerProps {
  onOpenStopSession: (session: GamingSession) => void;
}

export const SessionAlertBanner: React.FC<SessionAlertBannerProps> = ({ onOpenStopSession }) => {
  const { sessionAlerts, dismissSessionAlert, clearAllSessionAlerts, sessions, settings } = useCafe();

  if (!sessionAlerts || sessionAlerts.length === 0) return null;

  return (
    <div
      id="session-alerts-container"
      aria-live="assertive"
      className="fixed bottom-5 right-5 z-50 flex flex-col gap-3 max-w-md w-full pointer-events-none sm:max-w-sm"
    >
      {sessionAlerts.slice(0, 3).map((alert) => {
        const targetSession = sessions.find((s) => s.id === alert.sessionId);

        return (
          <div
            key={alert.id}
            id={`session-alert-${alert.id}`}
            className="pointer-events-auto bg-slate-900/95 border-2 border-amber-500/80 rounded-2xl p-4 shadow-2xl shadow-black/80 backdrop-blur-md animate-in slide-in-from-bottom-5 duration-300 flex flex-col gap-3"
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0">
                  <BellRing className="w-4 h-4 animate-bounce" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Session Duration Ended
                  </h4>
                  <p className="text-sm font-extrabold text-white leading-tight">
                    Session Over — {alert.customerName}&apos;s session has ended.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => dismissSessionAlert(alert.id)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                title="Dismiss notification"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Details badge */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-300">
                <Gamepad2 className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-mono font-bold text-cyan-300">{alert.consoleCode}</span>
                <span className="text-slate-500">•</span>
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  {Math.floor(alert.durationMinutes / 60) > 0 ? `${Math.floor(alert.durationMinutes / 60)}h ` : ''}
                  {alert.durationMinutes % 60}m
                </span>
              </div>
              <span className="font-extrabold text-emerald-400">
                {settings.currencySymbol} {alert.totalAmount}
              </span>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 pt-1">
              {targetSession && (
                <button
                  type="button"
                  id={`checkout-alert-btn-${alert.sessionId}`}
                  onClick={() => {
                    dismissSessionAlert(alert.id);
                    onOpenStopSession(targetSession);
                  }}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold py-2 px-3 rounded-xl text-xs shadow-md shadow-amber-500/20 transition-all cursor-pointer"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Collect Payment & Bill</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => dismissSessionAlert(alert.id)}
                className="px-3 py-2 text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        );
      })}

      {sessionAlerts.length > 1 && (
        <button
          type="button"
          onClick={clearAllSessionAlerts}
          className="pointer-events-auto self-end text-[11px] text-slate-400 hover:text-slate-200 underline font-medium cursor-pointer"
        >
          Dismiss all ({sessionAlerts.length}) alerts
        </button>
      )}
    </div>
  );
};
