import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Gamepad2,
  Users,
  Package,
  Receipt,
  BarChart3,
  ShieldCheck,
  Settings,
  Cloud,
  RefreshCw,
  LogOut,
  X,
  Lock,
  Coffee,
  Database,
  Ticket,
  Wrench,
  Repeat,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { useAuth } from '../../context/AuthContext';
import { driveService } from '../../services/googleDriveService';

interface SidebarProps {
  mobileOpen?: boolean;
  setMobileOpen?: (open: boolean) => void;
  onOpenLoginModal?: () => void;
  onOpenSyncModal?: () => void;
  onOpenRoleSwitchModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  mobileOpen = false,
  setMobileOpen,
  onOpenLoginModal,
  onOpenSyncModal,
  onOpenRoleSwitchModal,
}) => {
  const {
    currentUser,
    isAdmin,
    authTenantRole,
    syncState,
    triggerSync,
    logoutUser,
    switchRole,
    database,
  } = useCafe();
  const { user: firebaseUser, logout: firebaseLogout, clearRoleVerification, verifiedRole } = useAuth();

  const location = useLocation();
  const navigate = useNavigate();

  // Authoritatively re-verify backend Drive connection on mount and every navigation
  React.useEffect(() => {
    driveService.checkVaultStatus().catch(() => {});
  }, [location.pathname]);

  const cafeName = database?.settings?.cafeName || 'NEXT GEN ESPORT';
  const cafeInitials = String(cafeName)
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join('') || 'NX';

  const navItems = [
    { id: 'dashboard', path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'gaming', path: '/gaming', label: 'Consoles & Gaming', icon: Gamepad2 },
    { id: 'vouchers', path: '/vouchers', label: 'Vouchers', icon: Ticket },
    { id: 'cafeteria', path: '/cafeteria', label: 'Cafeteria', icon: Coffee },
    { id: 'rentals', path: '/rentals', label: 'Rentals & Gear', icon: Package },
    { id: 'repairs', path: '/repairs', label: 'Repair Tracking', icon: Wrench },
    { id: 'buysell', path: '/buysell', label: 'Buy & Sell', icon: Repeat },
    { id: 'customers', path: '/customers', label: 'Customers', icon: Users },
    { id: 'payments', path: '/payments', label: 'Payments', icon: Receipt },
    { id: 'reports', path: '/reports', label: 'Reports', icon: BarChart3, adminOnly: true },
    { id: 'datacenter', path: '/datacenter', label: 'Data Center', icon: Database, adminOnly: true },
    { id: 'workers', path: '/workers', label: 'Staff Management', icon: ShieldCheck, adminOnly: true },
    { id: 'settings', path: '/settings', label: 'Settings & Cloud', icon: Settings, adminOnly: true },
  ];

  const handleNavigate = (path: string) => {
    navigate(path);
    if (setMobileOpen) {
      setMobileOpen(false);
    }
  };

  const isItemActive = (path: string) => {
    if (path === '/dashboard') {
      return location.pathname === '/dashboard' || location.pathname === '/';
    }
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          id="mobile-backdrop"
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={() => setMobileOpen && setMobileOpen(false)}
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed lg:static top-0 bottom-0 left-0 z-50 w-64 shrink-0 bg-slate-900/95 border-r border-slate-800 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 backdrop-blur-xl ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div
            onClick={() => handleNavigate('/dashboard')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 shrink-0 overflow-hidden rounded-lg bg-white/5 p-0.5 border border-slate-800 group-hover:scale-105 transition-transform">
              <img
                src="/app-logo.svg"
                alt="Next Gen Esports 2.0"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=Next+Gen+Esports&background=0ea5e9&color=fff&bold=true';
                }}
              />
            </div>
            <div className="overflow-hidden">
              <h1 className="text-sm font-extrabold tracking-tight text-white leading-tight truncate">
                {cafeName}
              </h1>
              <p className="text-cyan-400 text-[10px] uppercase font-bold tracking-widest leading-none truncate">
                GAMING LAUNCHER
              </p>
            </div>
          </div>
          {setMobileOpen && (
            <button
              id="close-sidebar-btn"
              onClick={() => setMobileOpen(false)}
              className="lg:hidden text-slate-400 hover:text-white p-1 rounded-md"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* User / Role Badge */}
        <div className="px-4 pt-4 pb-2">
          <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                  isAdmin
                    ? 'bg-gradient-to-tr from-cyan-600 to-cyan-400 text-slate-950 font-black'
                    : 'bg-gradient-to-tr from-emerald-600 to-emerald-400 text-slate-950 font-black'
                }`}
              >
                {isAdmin ? 'AD' : 'WK'}
              </div>
              <div className="truncate">
                <p className="text-xs font-semibold text-white truncate leading-tight">
                  {currentUser?.name || 'Staff Member'}
                </p>
                <span
                  className={`inline-block text-[9px] font-bold px-1.5 py-0.2 rounded uppercase tracking-wider ${
                    isAdmin
                      ? 'text-cyan-400 bg-cyan-500/10 border border-cyan-500/20'
                      : 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20'
                  }`}
                >
                  {isAdmin ? 'Administrator' : 'Worker'}
                </span>
              </div>
            </div>

            {/* Role Switch / Unlock Button */}
            <button
              id="role-switch-btn"
              type="button"
              onClick={() => {
                if (onOpenRoleSwitchModal) {
                  onOpenRoleSwitchModal();
                } else if (onOpenLoginModal) {
                  onOpenLoginModal();
                }
              }}
              title="Switch role mode or verify access code"
              className="text-[10px] font-semibold text-slate-300 hover:text-white bg-slate-700/80 hover:bg-slate-700 px-2 py-1 rounded-md transition-colors whitespace-nowrap border border-slate-600/40 shrink-0 cursor-pointer"
            >
              {isAdmin ? 'Staff Mode' : 'Admin Code'}
            </button>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto custom-scrollbar">
          {navItems.map((item) => {
            if (item.adminOnly && !isAdmin) {
              return null; // hide admin only menu items from workers
            }

            const Icon = item.icon;
            const active = isItemActive(item.path);

            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => handleNavigate(item.path)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all text-left group cursor-pointer ${
                  active
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-500/10 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    active ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'
                  }`}
                />
                <span className="flex-1 truncate">{item.label}</span>
                {item.adminOnly && (
                  <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700">
                    Admin
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Google Drive Live Status Widget */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-900/40">
          <div
            id="gdrive-status-card"
            onClick={() => {
              if (onOpenSyncModal) {
                onOpenSyncModal();
              } else if (isAdmin) {
                handleNavigate('/settings');
              } else {
                triggerSync();
              }
            }}
            className={`p-3 rounded-xl border border-slate-800 bg-slate-950/60 hover:border-slate-700 transition-all flex flex-col gap-2 group ${
              isAdmin || onOpenSyncModal ? 'cursor-pointer' : 'cursor-default'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[11px] font-bold text-slate-200 uppercase tracking-wider">
                  Owner's Drive
                </span>
              </div>
              <button
                id="refresh-sync-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerSync();
                }}
                title="Sync Now"
                className="text-slate-500 hover:text-cyan-400 p-1"
              >
                <RefreshCw
                  className={`w-3 h-3 ${syncState.status === 'syncing' ? 'animate-spin text-cyan-400' : ''}`}
                />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`w-2 h-2 rounded-full ${
                  syncState.isConnected || syncState.status === 'synced'
                    ? 'bg-emerald-500 shadow-sm shadow-emerald-500 animate-pulse'
                    : syncState.status === 'syncing'
                    ? 'bg-cyan-500 animate-ping'
                    : syncState.status === 'error'
                    ? 'bg-rose-500'
                    : 'bg-amber-500'
                }`}
              />
              <span className="text-[10px] text-slate-300 font-semibold truncate">
                {syncState.status === 'syncing'
                  ? 'Checking Google Drive...'
                  : syncState.isConnected || syncState.status === 'synced'
                  ? 'Google Drive Active'
                  : 'Google Drive Not Connected'}
              </span>
            </div>
          </div>

          {/* Quick Lock Terminal Role (returns to Role Selection) */}
          <button
            id="lock-terminal-btn"
            onClick={() => {
              clearRoleVerification();
              logoutUser();
            }}
            className="w-full mt-2 flex items-center justify-center gap-2 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors cursor-pointer"
            title="Lock terminal and return to Role Selection screen"
          >
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>Lock Role Terminal</span>
          </button>

          {/* Firebase Authentication Sign Out Button */}
          <button
            id="logout-btn"
            onClick={async () => {
              try {
                await firebaseLogout();
              } catch (err) {
                console.error('Logout error:', err);
              }
            }}
            className="w-full mt-1.5 flex items-center justify-center gap-2 px-3 py-1.5 text-xs text-rose-400/90 hover:text-rose-300 hover:bg-rose-500/10 border border-rose-500/20 rounded-lg transition-colors cursor-pointer font-medium"
            title={`Sign out of Firebase (${firebaseUser?.email || 'Authenticated Account'})`}
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};
