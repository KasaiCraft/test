import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import {
  Menu,
  Gamepad2,
  PackagePlus,
  Clock,
  ShieldCheck,
  User,
  LogOut,
  Bell,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { useAuth } from '../../context/AuthContext';

interface HeaderProps {
  onOpenMobileMenu?: () => void;
  onOpenStartSession?: () => void;
  onOpenNewRental?: () => void;
  onOpenNoticeCenter?: () => void;
  onOpenRoleSwitchModal?: () => void;
}

const ROUTE_META: Record<string, { title: string; subtitle: string }> = {
  '/dashboard': {
    title: 'Dashboard',
    subtitle: 'Real-time overview of gaming stations, rentals, revenue & active sessions',
  },
  '/gaming': {
    title: 'Gaming & Consoles',
    subtitle: 'Live station timers, station assignments, pricing & availability',
  },
  '/customers': {
    title: 'Customer Directory',
    subtitle: 'Player profiles, loyalty visits, gaming hours & outstanding tabs',
  },
  '/rentals': {
    title: 'Gear & Hardware Rentals',
    subtitle: 'Controllers, VR headsets, steering wheels, deposits & return processing',
  },
  '/payments': {
    title: 'Payments & Billing',
    subtitle: 'Cash, UPI, Card transactions, payment receipts and audit log',
  },
  '/reports': {
    title: 'Analytics & Financial Reports',
    subtitle: 'Daily & monthly revenue, gaming vs rental split, session history',
  },
  '/workers': {
    title: 'Staff & Worker Management',
    subtitle: 'Access controls, staff roster, quick PINs and permission roles',
  },
  '/settings': {
    title: 'Settings & Cloud Storage',
    subtitle: 'Cafe configuration, Google Drive integration, backup & danger zone',
  },
};

export const Header: React.FC<HeaderProps> = ({
  onOpenMobileMenu,
  onOpenStartSession,
  onOpenNewRental,
  onOpenNoticeCenter,
  onOpenRoleSwitchModal,
}) => {
  const { currentUser, isAdmin, activeSessions, notices } = useCafe();
  const { user: firebaseUser, logout: firebaseLogout, verifiedRole } = useAuth();
  const [time, setTime] = useState<string>('');
  const location = useLocation();

  const currentUserId = currentUser?.id || 'staff';
  const unreadNoticesCount = notices.filter(
    (n) => !(n.acknowledgedBy || []).includes(currentUserId)
  ).length;

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const meta = ROUTE_META[location.pathname] || (location.pathname === '/' ? ROUTE_META['/dashboard'] : {
    title: 'NEXT GEN ESPORT',
    subtitle: 'Management Terminal',
  });

  const isDashboard = location.pathname === '/dashboard' || location.pathname === '/';

  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 px-3 sm:px-6 py-3 sm:py-4 flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4"
    >
      {/* Left: Mobile Toggle & Page Info */}
      <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
        {onOpenMobileMenu && (
          <button
            id="mobile-menu-toggle-btn"
            onClick={onOpenMobileMenu}
            className="lg:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 cursor-pointer shrink-0"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        {/* Mobile Logo Branding */}
        <div className="lg:hidden w-8 h-8 shrink-0 overflow-hidden rounded-lg bg-white/5 border border-slate-800">
          <img
            src="/app-logo.svg"
            alt="Logo"
            className="w-full h-full object-contain"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=NGE&background=0ea5e9&color=fff&bold=true';
            }}
          />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-lg sm:text-2xl font-bold tracking-tight text-white truncate">
              {meta.title}
            </h2>
            {isDashboard && activeSessions.length > 0 && (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] sm:text-[11px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 animate-pulse whitespace-nowrap">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                {activeSessions.length} Live
              </span>
            )}
          </div>
          <p className="text-[11px] sm:text-sm text-slate-400 truncate mt-0.5">
            {meta.subtitle}
          </p>
        </div>
      </div>

      {/* Right: Real-time clock & Quick Action Buttons */}
      <div className="flex items-center flex-wrap gap-2 w-full justify-between sm:w-auto sm:justify-end md:self-auto">
        {/* Live Clock */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900/90 border border-slate-800 rounded-xl text-slate-300 text-xs font-mono">
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span>{time || '--:--:--'}</span>
        </div>

        {/* Quick Start Session Button */}
        {onOpenStartSession && (
          <button
            id="quick-start-session-btn"
            onClick={onOpenStartSession}
            className="flex items-center gap-1.5 sm:gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm shadow-md shadow-cyan-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
          >
            <Gamepad2 className="w-4 h-4 shrink-0" />
            <span>+ Start Session</span>
          </button>
        )}

        {/* Quick Rental Button */}
        {onOpenNewRental && (
          <button
            id="quick-new-rental-btn"
            onClick={onOpenNewRental}
            className="hidden sm:flex items-center gap-2 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 hover:border-slate-600 text-slate-200 font-semibold px-3.5 py-2 rounded-xl text-xs sm:text-sm transition-all cursor-pointer"
          >
            <PackagePlus className="w-4 h-4 text-amber-400 shrink-0" />
            <span>+ Rental</span>
          </button>
        )}

        {/* Admin Broadcast & Notice Board Button */}
        {onOpenNoticeCenter && (
          <button
            id="open-notice-center-btn"
            onClick={onOpenNoticeCenter}
            title={
              unreadNoticesCount > 0
                ? `${unreadNoticesCount} unread admin notice(s)`
                : 'Admin Broadcasts & Notice Board'
            }
            className="relative p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Bell className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="hidden md:inline text-xs font-semibold">Notices</span>
            {unreadNoticesCount > 0 && (
              <span className="inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-bold font-mono bg-rose-500 text-white shadow-sm shadow-rose-500/50 animate-pulse">
                {unreadNoticesCount}
              </span>
            )}
          </button>
        )}

        {/* User avatar / role switch indicator */}
        <button
          id="header-user-badge"
          type="button"
          onClick={onOpenRoleSwitchModal}
          className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 flex items-center gap-1.5 text-xs font-bold text-slate-300 relative group shrink-0 transition-all cursor-pointer shadow-sm"
          title={`Click to switch terminal role: ${verifiedRole === 'admin' ? 'Administrator' : 'Staff'}`}
        >
          {isAdmin ? (
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
          ) : (
            <User className="w-4 h-4 text-emerald-400" />
          )}
          <span className="hidden sm:inline text-xs font-semibold">
            {isAdmin ? 'Admin' : 'Staff'}
          </span>
          <span
            className={`w-2 h-2 rounded-full ring-2 ring-slate-950 ${
              isAdmin ? 'bg-cyan-400' : 'bg-emerald-400'
            }`}
          />
        </button>

        {/* Firebase Authentication Sign Out button */}
        {firebaseUser && (
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="hidden xl:flex flex-col text-right">
              <span
                className="text-[11px] font-semibold text-slate-300 truncate max-w-[130px]"
                title={firebaseUser.email || ''}
              >
                {firebaseUser.email}
              </span>
              <span className="text-[9px] text-cyan-400 font-mono flex items-center justify-end gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
                Auth Active
              </span>
            </div>
            <button
              id="header-logout-btn"
              onClick={async () => {
                try {
                  await firebaseLogout();
                } catch (err) {
                  console.error('Logout error:', err);
                }
              }}
              title={`Sign out of Firebase (${firebaseUser.email})`}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-500/10 border border-slate-800 hover:border-rose-500/30 text-slate-400 hover:text-rose-400 text-xs font-semibold transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
