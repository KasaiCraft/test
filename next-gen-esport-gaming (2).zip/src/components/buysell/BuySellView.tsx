import React, { useState, useMemo } from 'react';
import {
  Repeat,
  Plus,
  Search,
  CheckCircle2,
  TrendingUp,
  Package,
  ShoppingBag,
  ArrowDownLeft,
  ArrowUpRight,
  Printer,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import {
  BuySellItem,
  BuySellTransaction,
  BuySellCategory,
  BuySellCondition,
  PaymentMethod,
} from '../../types';

export const BuySellView: React.FC = () => {
  const {
    buySellItems,
    buySellTransactions,
    customers,
    buyItemFromCustomer,
    sellItemToCustomer,
    deleteBuySellItem,
    isAdmin,
  } = useCafe();

  const [activeTab, setActiveTab] = useState<'inventory' | 'sold' | 'transactions'>('inventory');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedCondition, setSelectedCondition] = useState<string>('all');

  // Modals
  const [isBuyModalOpen, setIsBuyModalOpen] = useState(false);
  const [isSellModalOpen, setIsSellModalOpen] = useState(false);
  const [selectedItemToSell, setSelectedItemToSell] = useState<BuySellItem | null>(null);
  const [printedTransaction, setPrintedTransaction] = useState<BuySellTransaction | null>(null);

  // Buy Form
  const [buyData, setBuyData] = useState({
    customerId: '',
    customerName: '',
    customerPhone: '',
    name: '',
    category: 'PS5' as BuySellCategory,
    condition: 'Used / Pre-owned' as BuySellCondition,
    serialNumber: '',
    purchasePrice: 15000,
    suggestedSellingPrice: 20000,
    paymentMethod: 'cash' as PaymentMethod,
    notes: '',
  });

  // Sell Form
  const [sellCustomerId, setSellCustomerId] = useState('');
  const [sellCustomerName, setSellCustomerName] = useState('');
  const [sellCustomerPhone, setSellCustomerPhone] = useState('');
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [sellPaymentMethod, setSellPaymentMethod] = useState<PaymentMethod>('cash');
  const [sellNotes, setSellNotes] = useState('');

  // Financial Metrics
  const metrics = useMemo(() => {
    const items = buySellItems || [];
    const inStock = items.filter((i) => i.status === 'in_inventory');
    const sold = items.filter((i) => i.status === 'sold');

    const totalStockValue = inStock.reduce((acc, i) => acc + i.purchasePrice, 0);
    const totalSalesRevenue = sold.reduce((acc, i) => acc + (i.soldPrice || 0), 0);
    const totalRealizedProfit = sold.reduce(
      (acc, i) => acc + ((i.soldPrice || 0) - i.purchasePrice),
      0
    );

    const marginPct =
      totalSalesRevenue > 0
        ? Math.round((totalRealizedProfit / totalSalesRevenue) * 100)
        : 0;

    return {
      inStockCount: inStock.length,
      soldCount: sold.length,
      totalStockValue,
      totalSalesRevenue,
      totalRealizedProfit,
      marginPct,
    };
  }, [buySellItems]);

  // Filtered Items
  const filteredItems = useMemo(() => {
    const items = buySellItems || [];
    const list =
      activeTab === 'inventory'
        ? items.filter((i) => i.status === 'in_inventory')
        : activeTab === 'sold'
        ? items.filter((i) => i.status === 'sold')
        : items;

    return list.filter((i) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        i.name.toLowerCase().includes(q) ||
        (i.serialNumber && i.serialNumber.toLowerCase().includes(q)) ||
        (i.sellerCustomerName && i.sellerCustomerName.toLowerCase().includes(q)) ||
        (i.buyerCustomerName && i.buyerCustomerName.toLowerCase().includes(q));

      const matchesCat =
        selectedCategory === 'all' || i.category === selectedCategory;
      const matchesCond =
        selectedCondition === 'all' || i.condition === selectedCondition;

      return matchesSearch && matchesCat && matchesCond;
    });
  }, [buySellItems, activeTab, searchQuery, selectedCategory, selectedCondition]);

  // Handle Buy Submit
  const handleBuySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyData.name.trim()) {
      alert('Please enter item name.');
      return;
    }

    let sellerName = buyData.customerName.trim();
    let sellerPhone = buyData.customerPhone.trim();

    if (buyData.customerId) {
      const c = customers.find((cust) => cust.id === buyData.customerId);
      if (c) {
        sellerName = c.name;
        sellerPhone = c.phone || sellerPhone;
      }
    }

    if (!sellerName) {
      alert('Please provide seller/customer name.');
      return;
    }

    const res = await buyItemFromCustomer({
      name: buyData.name.trim(),
      category: buyData.category,
      condition: buyData.condition,
      serialNumber: buyData.serialNumber.trim() || undefined,
      purchasePrice: Number(buyData.purchasePrice) || 0,
      suggestedSellingPrice: Number(buyData.suggestedSellingPrice) || 0,
      customerId: buyData.customerId || `cust_${Date.now()}`,
      customerName: sellerName,
      customerPhone: sellerPhone || undefined,
      paymentMethod: buyData.paymentMethod,
      notes: buyData.notes.trim() || undefined,
    });

    if (res.success) {
      setIsBuyModalOpen(false);
      setBuyData({
        customerId: '',
        customerName: '',
        customerPhone: '',
        name: '',
        category: 'PS5',
        condition: 'Used / Pre-owned',
        serialNumber: '',
        purchasePrice: 15000,
        suggestedSellingPrice: 20000,
        paymentMethod: 'cash',
        notes: '',
      });
    } else {
      alert(res.error || 'Failed to purchase item');
    }
  };

  // Open Sell Modal
  const handleOpenSell = (item: BuySellItem) => {
    setSelectedItemToSell(item);
    setSellingPrice(item.suggestedSellingPrice || item.purchasePrice);
    setSellCustomerId('');
    setSellCustomerName('');
    setSellCustomerPhone('');
    setSellPaymentMethod('cash');
    setSellNotes('');
    setIsSellModalOpen(true);
  };

  const handleSellSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItemToSell) return;

    let buyerName = sellCustomerName.trim();
    let buyerPhone = sellCustomerPhone.trim();

    if (sellCustomerId) {
      const c = customers.find((cust) => cust.id === sellCustomerId);
      if (c) {
        buyerName = c.name;
        buyerPhone = c.phone || buyerPhone;
      }
    }

    if (!buyerName) {
      alert('Please select or specify buyer name.');
      return;
    }

    const res = await sellItemToCustomer({
      itemId: selectedItemToSell.id,
      sellingPrice: Number(sellingPrice) || 0,
      customerId: sellCustomerId || `cust_${Date.now()}`,
      customerName: buyerName,
      customerPhone: buyerPhone || undefined,
      paymentMethod: sellPaymentMethod,
      notes: sellNotes.trim() || undefined,
    });

    if (res.success) {
      setIsSellModalOpen(false);
      setSelectedItemToSell(null);
      if (res.transaction) {
        setPrintedTransaction(res.transaction);
      }
    } else {
      alert(res.error || 'Failed to complete sale');
    }
  };

  const getConditionColor = (cond: BuySellCondition) => {
    switch (cond) {
      case 'New':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'Used / Pre-owned':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'Refurbished':
        return 'bg-violet-500/10 text-violet-400 border-violet-500/20';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  return (
    <div id="buysell-view" className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-600/20 text-teal-400 border border-teal-500/30">
              <Repeat className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Buy & Sell Management</h1>
              <p className="text-sm text-slate-400">
                Trade in consoles, games, controllers, and gear with instant profit margin tracking.
              </p>
            </div>
          </div>
        </div>

        <button
          id="open-buy-modal-btn"
          onClick={() => setIsBuyModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium text-sm transition shadow-lg shadow-teal-950/30"
        >
          <Plus className="w-4 h-4" />
          Buy Equipment from Customer
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-slate-400">In-Stock Gear</p>
          <p className="text-xl font-bold text-white mt-1">{metrics.inStockCount} items</p>
          <p className="text-[11px] text-slate-500 mt-0.5">₹{metrics.totalStockValue} inventory value</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-teal-400">Total Items Sold</p>
          <p className="text-xl font-bold text-teal-400 mt-1">{metrics.soldCount}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">₹{metrics.totalSalesRevenue} gross sales</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-emerald-400">Net Trade Profit</p>
          <p className="text-xl font-bold text-emerald-400 mt-1">₹{metrics.totalRealizedProfit}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Realized cash margin</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs text-indigo-400">Average Margin</p>
          <p className="text-xl font-bold text-indigo-400 mt-1">{metrics.marginPct}%</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Profit per sale</p>
        </div>
      </div>

      {/* Tabs & Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
          <button
            id="tab-buysell-inventory"
            onClick={() => setActiveTab('inventory')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
              activeTab === 'inventory'
                ? 'bg-teal-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            In Stock ({metrics.inStockCount})
          </button>
          <button
            id="tab-buysell-sold"
            onClick={() => setActiveTab('sold')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
              activeTab === 'sold'
                ? 'bg-teal-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            Sold Archive ({metrics.soldCount})
          </button>
          <button
            id="tab-buysell-transactions"
            onClick={() => setActiveTab('transactions')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
              activeTab === 'transactions'
                ? 'bg-teal-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            Transactions ({(buySellTransactions || []).length})
          </button>
        </div>

        {activeTab !== 'transactions' && (
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative min-w-[200px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                id="search-buysell-input"
                type="text"
                placeholder="Search gear, customer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-white text-sm focus:outline-none focus:border-teal-500"
              />
            </div>

            <select
              id="filter-buysell-category"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-sm focus:outline-none focus:border-teal-500"
            >
              <option value="all">All Categories</option>
              <option value="PS4">PS4</option>
              <option value="PS5">PS5</option>
              <option value="Controllers">Controllers</option>
              <option value="Games">Games</option>
              <option value="Accessories">Accessories</option>
              <option value="Other Equipment">Other Equipment</option>
            </select>

            <select
              id="filter-buysell-condition"
              value={selectedCondition}
              onChange={(e) => setSelectedCondition(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-sm focus:outline-none focus:border-teal-500"
            >
              <option value="all">All Conditions</option>
              <option value="New">New</option>
              <option value="Used / Pre-owned">Used / Pre-owned</option>
              <option value="Refurbished">Refurbished</option>
            </select>
          </div>
        )}
      </div>

      {/* Main Tab Content */}
      {activeTab !== 'transactions' ? (
        filteredItems.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-slate-900/30 border border-dashed border-slate-800">
            <Repeat className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 font-medium">No items found in this view</p>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Buy pre-owned games, consoles, or steering wheels from customers to stock your shop.
            </p>
            {activeTab === 'inventory' && (
              <button
                onClick={() => setIsBuyModalOpen(true)}
                className="mt-4 px-4 py-2 rounded-xl bg-teal-600 text-white text-sm font-medium hover:bg-teal-500 transition"
              >
                Buy First Item
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredItems.map((item) => {
              const isSold = item.status === 'sold';
              const projectedProfit = item.suggestedSellingPrice - item.purchasePrice;
              const actualProfit = (item.soldPrice || 0) - item.purchasePrice;

              return (
                <div
                  key={item.id}
                  id={`buysell-card-${item.id}`}
                  className="rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 p-5 transition flex flex-col justify-between"
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-300">
                        {item.category}
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getConditionColor(
                          item.condition
                        )}`}
                      >
                        {item.condition}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-white">{item.name}</h3>

                    {item.serialNumber && (
                      <p className="text-xs text-slate-500 font-mono mt-0.5">
                        SN: {item.serialNumber}
                      </p>
                    )}

                    {/* Price Breakdown */}
                    <div className="mt-4 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Purchase Cost:</span>
                        <span className="font-semibold text-rose-400">₹{item.purchasePrice}</span>
                      </div>

                      {isSold ? (
                        <>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Sold Price:</span>
                            <span className="font-semibold text-emerald-400">
                              ₹{item.soldPrice}
                            </span>
                          </div>
                          <div className="flex justify-between pt-1 border-t border-slate-800 font-bold">
                            <span className="text-slate-300">Realized Profit:</span>
                            <span
                              className={
                                actualProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                              }
                            >
                              ₹{actualProfit}
                            </span>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Target Selling Price:</span>
                            <span className="font-semibold text-teal-400">
                              ₹{item.suggestedSellingPrice}
                            </span>
                          </div>
                          <div className="flex justify-between pt-1 border-t border-slate-800 font-bold">
                            <span className="text-slate-300">Projected Margin:</span>
                            <span className="text-emerald-400">₹{projectedProfit}</span>
                          </div>
                        </>
                      )}
                    </div>

                    {/* Customer Information */}
                    <div className="mt-3 space-y-1 text-xs text-slate-400">
                      {item.sellerCustomerName && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Bought from:</span>
                          <span className="text-slate-300 font-medium truncate max-w-[150px]">
                            {item.sellerCustomerName}
                          </span>
                        </div>
                      )}
                      {isSold && item.buyerCustomerName && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Sold to:</span>
                          <span className="text-teal-300 font-medium truncate max-w-[150px]">
                            {item.buyerCustomerName}
                          </span>
                        </div>
                      )}
                      {item.notes && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Note:</span>
                          <span className="text-slate-300 truncate max-w-[150px]">{item.notes}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <span
                      className={`text-xs font-semibold ${
                        isSold ? 'text-slate-500' : 'text-emerald-400'
                      }`}
                    >
                      {isSold ? 'SOLD' : 'AVAILABLE IN STOCK'}
                    </span>

                    <div className="flex items-center gap-2">
                      {!isSold && (
                        <button
                          onClick={() => handleOpenSell(item)}
                          className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold transition shadow-lg shadow-teal-950/30 flex items-center gap-1"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          Sell Item
                        </button>
                      )}

                      {isAdmin && (
                        <button
                          onClick={() => {
                            if (confirm(`Remove item "${item.name}"?`)) {
                              deleteBuySellItem(item.id);
                            }
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 transition"
                          title="Delete Item"
                        >
                          &times;
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : (
        /* Transactions Tab */
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 overflow-hidden">
          {(buySellTransactions || []).length === 0 ? (
            <div className="p-12 text-center">
              <TrendingUp className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-slate-400 font-medium">No buy/sell transactions yet</p>
              <p className="text-xs text-slate-500 mt-1">
                Completed purchases and sales will automatically log detailed audit trails here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-900/90 text-slate-400 text-xs uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Item</th>
                    <th className="px-4 py-3">Party (Customer)</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">Method</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3 text-right">Receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {(buySellTransactions || []).map((t) => (
                    <tr key={t.id} className="hover:bg-slate-800/30">
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                            t.type === 'purchase'
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          }`}
                        >
                          {t.type === 'purchase' ? (
                            <>
                              <ArrowDownLeft className="w-3 h-3" /> Bought
                            </>
                          ) : (
                            <>
                              <ArrowUpRight className="w-3 h-3" /> Sold
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-semibold text-white">{t.itemName}</td>
                      <td className="px-4 py-3 text-slate-300">
                        {t.customerName}
                        {t.customerPhone && (
                          <span className="block text-xs text-slate-500">{t.customerPhone}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 font-bold text-white">
                        ₹{t.amount}
                        {t.profit !== undefined && t.profit > 0 && (
                          <span className="block text-[11px] text-emerald-400 font-normal">
                            Profit: ₹{t.profit}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400 uppercase">
                        {t.paymentMethod}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400">
                        {new Date(t.timestamp).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => setPrintedTransaction(t)}
                          title="Print Receipt"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* BUY MODAL */}
      {isBuyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Repeat className="w-5 h-5 text-teal-400" />
                <h2 className="text-lg font-bold text-white">Buy Equipment from Customer</h2>
              </div>
              <button
                onClick={() => setIsBuyModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleBuySubmit} className="space-y-4 mt-4">
              {/* Seller details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Select Customer
                  </label>
                  <select
                    value={buyData.customerId}
                    onChange={(e) => {
                      const c = customers.find((cust) => cust.id === e.target.value);
                      setBuyData({
                        ...buyData,
                        customerId: e.target.value,
                        customerName: c ? c.name : buyData.customerName,
                        customerPhone: c ? c.phone || '' : buyData.customerPhone,
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  >
                    <option value="">-- Walk-in / New Seller --</option>
                    {(customers || []).map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Seller Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Seller full name"
                    value={buyData.customerName}
                    onChange={(e) => setBuyData({ ...buyData, customerName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    placeholder="Contact number"
                    value={buyData.customerPhone}
                    onChange={(e) => setBuyData({ ...buyData, customerPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Equipment Category
                  </label>
                  <select
                    value={buyData.category}
                    onChange={(e) =>
                      setBuyData({ ...buyData, category: e.target.value as BuySellCategory })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  >
                    <option value="PS5">PS5</option>
                    <option value="PS4">PS4</option>
                    <option value="Controllers">Controllers</option>
                    <option value="Games">Games</option>
                    <option value="Accessories">Accessories</option>
                    <option value="Other Equipment">Other Equipment</option>
                  </select>
                </div>
              </div>

              {/* Item Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Item Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sony PS5 Digital Edition 825GB"
                    value={buyData.name}
                    onChange={(e) => setBuyData({ ...buyData, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Physical Condition
                  </label>
                  <select
                    value={buyData.condition}
                    onChange={(e) =>
                      setBuyData({ ...buyData, condition: e.target.value as BuySellCondition })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  >
                    <option value="New">New (Sealed)</option>
                    <option value="Used / Pre-owned">Used / Pre-owned</option>
                    <option value="Refurbished">Refurbished</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Serial # (Optional)
                </label>
                <input
                  type="text"
                  placeholder="Console or hardware serial"
                  value={buyData.serialNumber}
                  onChange={(e) => setBuyData({ ...buyData, serialNumber: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-teal-500 focus:outline-none"
                />
              </div>

              {/* Pricing */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Buy Price (₹) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={buyData.purchasePrice}
                    onChange={(e) =>
                      setBuyData({ ...buyData, purchasePrice: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-sm focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Target Sale Price (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={buyData.suggestedSellingPrice}
                    onChange={(e) =>
                      setBuyData({
                        ...buyData,
                        suggestedSellingPrice: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Paid Via
                  </label>
                  <select
                    value={buyData.paymentMethod}
                    onChange={(e) =>
                      setBuyData({ ...buyData, paymentMethod: e.target.value as any })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  >
                    <option value="cash">Cash</option>
                    <option value="upi">UPI / QR</option>
                    <option value="bank">Bank Transfer</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsBuyModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-sm font-semibold transition shadow-lg shadow-teal-950/30"
                >
                  Complete Purchase & Add to Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SELL MODAL */}
      {isSellModalOpen && selectedItemToSell && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-teal-400" />
                <h2 className="text-lg font-bold text-white">Sell Item to Customer</h2>
              </div>
              <button
                onClick={() => setIsSellModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <div className="p-3 my-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
              <div className="font-semibold text-white text-sm">{selectedItemToSell.name}</div>
              <div className="text-slate-400">Condition: {selectedItemToSell.condition}</div>
              <div className="flex justify-between pt-1 border-t border-slate-800">
                <span className="text-slate-400">Original Cost:</span>
                <span className="text-rose-400 font-semibold">
                  ₹{selectedItemToSell.purchasePrice}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Expected Profit:</span>
                <span className="text-emerald-400 font-bold">
                  ₹{sellingPrice - selectedItemToSell.purchasePrice}
                </span>
              </div>
            </div>

            <form onSubmit={handleSellSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Buyer Customer
                </label>
                <select
                  value={sellCustomerId}
                  onChange={(e) => {
                    const c = customers.find((cust) => cust.id === e.target.value);
                    setSellCustomerId(e.target.value);
                    if (c) {
                      setSellCustomerName(c.name);
                      setSellCustomerPhone(c.phone || '');
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                >
                  <option value="">-- Walk-in / Unregistered Buyer --</option>
                  {(customers || []).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>

              {!sellCustomerId && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                      Buyer Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Buyer full name"
                      value={sellCustomerName}
                      onChange={(e) => setSellCustomerName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      placeholder="Buyer phone"
                      value={sellCustomerPhone}
                      onChange={(e) => setSellCustomerPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Final Selling Price (₹) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-lg focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Payment Method
                  </label>
                  <select
                    value={sellPaymentMethod}
                    onChange={(e) => setSellPaymentMethod(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                  >
                    <option value="cash">Cash</option>
                    <option value="upi">UPI / QR</option>
                    <option value="card">Card</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. 15 Days Testing Warranty"
                  value={sellNotes}
                  onChange={(e) => setSellNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSellModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-sm font-semibold transition"
                >
                  Confirm Sale & Generate Bill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINT RECEIPT MODAL */}
      {printedTransaction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-white text-slate-900 p-6 shadow-2xl space-y-4">
            <div className="text-center border-b pb-3">
              <h3 className="text-lg font-black tracking-tight">NEXT GEN GAMING CAFE</h3>
              <p className="text-xs text-slate-500 uppercase tracking-widest">
                Trade & Sales Invoice
              </p>
              <div className="font-mono text-xs font-bold text-teal-600 mt-1">
                {printedTransaction.id}
              </div>
            </div>

            <div className="text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Transaction Type:</span>
                <span className="font-bold uppercase text-slate-800">
                  {printedTransaction.type === 'purchase' ? 'Equipment Buy-in' : 'Direct Sale'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date:</span>
                <span className="font-semibold">
                  {new Date(printedTransaction.timestamp).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Customer:</span>
                <span className="font-semibold">{printedTransaction.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Item:</span>
                <span className="font-semibold">{printedTransaction.itemName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Method:</span>
                <span className="uppercase font-medium">{printedTransaction.paymentMethod}</span>
              </div>
            </div>

            <div className="border-t pt-2 text-center">
              <span className="text-xs text-slate-500">Total Amount:</span>
              <div className="text-2xl font-black text-slate-900">
                ₹{printedTransaction.amount}
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t">
              <button
                onClick={() => setPrintedTransaction(null)}
                className="flex-1 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold flex items-center justify-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" />
                Print Bill
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
