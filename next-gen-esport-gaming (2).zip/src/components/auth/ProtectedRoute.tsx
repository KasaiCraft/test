import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen w-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="relative flex flex-col items-center">
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-black text-2xl tracking-tighter mb-4 animate-pulse">
            NX
          </div>
          <div className="flex items-center gap-2.5 text-cyan-400 text-sm font-semibold tracking-wide">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Authenticating Terminal Session...</span>
          </div>
          <p className="text-slate-500 text-xs mt-2">Next Gen Gaming Cafe Security</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

export const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen w-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="relative flex flex-col items-center">
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-black text-2xl tracking-tighter mb-4 animate-pulse">
            NX
          </div>
          <div className="flex items-center gap-2.5 text-cyan-400 text-sm font-semibold tracking-wide">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Checking Credentials...</span>
          </div>
        </div>
      </div>
    );
  }

  if (user) {
    const isWorker =
      user.providerId === 'nextgen-staff-terminal' ||
      Boolean(localStorage.getItem('NEXTGEN_TERMINAL_STAFF_SESSION_V1'));
    return <Navigate to={isWorker ? '/gaming' : '/dashboard'} replace />;
  }

  return <>{children}</>;
};
