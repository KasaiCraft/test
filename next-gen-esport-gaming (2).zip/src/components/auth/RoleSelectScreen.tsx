import React, { useState } from 'react';
import {
  ShieldCheck,
  User,
  KeyRound,
  Eye,
  EyeOff,
  ArrowRight,
  LogOut,
  AlertCircle,
  CheckCircle2,
  Lock,
  Sparkles,
  Gamepad2,
  Loader2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCafe } from '../../context/CafeContext';

export const RoleSelectScreen: React.FC = () => {
  const { user, verifyRoleCode, logout } = useAuth();
  const { database, settings, isLoading: isDatabaseLoading } = useCafe();

  // Selected tab: 'admin' or 'staff'
  const [selectedRole, setSelectedRole] = useState<'admin' | 'worker'>('admin');
  const [code, setCode] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [error, setError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  // If database is still loading, show a focused loading screen to prevent stale checks
  if (isDatabaseLoading) {
    return (
      <div className="min-h-screen w-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <div className="relative mb-8">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center animate-pulse">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          </div>
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 rounded-full border-2 border-slate-950 animate-ping" />
        </div>
        <h2 className="text-white text-lg font-bold mb-1">Loading Security Protocols...</h2>
        <p className="text-slate-500 text-xs font-mono tracking-widest uppercase">
          Synchronizing with cloud vault
        </p>
      </div>
    );
  }

  const handleRoleSelect = (role: 'admin' | 'worker') => {
    setSelectedRole(role);
    setCode('');
    setError('');
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsVerifying(true);

    try {
      const result = verifyRoleCode(
        selectedRole,
        code,
        settings || database?.settings,
        database?.users || []
      );

      if (!result.success) {
        setError(result.error || 'Invalid verification code.');
        setIsVerifying(false);
        return;
      }

      // Verification successful: AuthContext will update verifiedRole and transition screen
    } catch (err: any) {
      setError(err?.message || 'Verification failed. Please try again.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div
      id="role-selection-screen"
      className="min-h-screen w-screen bg-slate-950 flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden"
    >
      {/* Ambient background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[350px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-xl z-10">
        {/* Header Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 p-0.5 shadow-lg shadow-cyan-500/20 mb-4">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Gamepad2 className="w-8 h-8 text-cyan-400" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white uppercase">
            NEXT GEN ESPORT
          </h1>
          <p className="text-xs sm:text-sm font-semibold tracking-wider text-cyan-400 uppercase mt-1">
            GAMING LAUNCHER • TERMINAL ACCESS
          </p>
        </div>

        {/* Authenticated Firebase Account Badge */}
        <div className="mb-6 bg-slate-900/90 border border-slate-800/90 rounded-2xl p-3 sm:p-4 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-slate-300">Firebase Account Active</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
              </div>
              <p className="text-xs sm:text-sm font-mono text-slate-400 truncate">
                {user?.email || 'Logged In User'}
              </p>
            </div>
          </div>

          <button
            id="role-screen-logout-btn"
            onClick={logout}
            title="Sign out to use a different Firebase account"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-500/15 border border-slate-700 hover:border-rose-500/30 text-slate-300 hover:text-rose-400 text-xs font-semibold transition-all cursor-pointer shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>

        {/* Role Selection Container */}
        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/60">
          <div className="mb-6">
            <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-cyan-400" />
              Select Terminal Role & Verify Code
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Select your operational role and enter your security authorization code to unlock the terminal.
            </p>
          </div>

          {/* Two Role Options: Admin vs Staff */}
          <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6">
            {/* Admin Option */}
            <button
              id="role-option-admin-btn"
              type="button"
              onClick={() => handleRoleSelect('admin')}
              className={`p-4 rounded-2xl border transition-all text-left relative cursor-pointer ${
                selectedRole === 'admin'
                  ? 'bg-cyan-500/10 border-cyan-500 shadow-md shadow-cyan-500/15'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    selectedRole === 'admin'
                      ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <ShieldCheck className="w-5 h-5" />
                </div>
                {selectedRole === 'admin' && (
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400 animate-pulse" />
                )}
              </div>
              <h3
                className={`font-bold text-sm sm:text-base ${
                  selectedRole === 'admin' ? 'text-white' : 'text-slate-300'
                }`}
              >
                Administrator
              </h3>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Full Admin Panel: reports, data center, cloud sync & worker control
              </p>
            </button>

            {/* Staff Option */}
            <button
              id="role-option-staff-btn"
              type="button"
              onClick={() => handleRoleSelect('worker')}
              className={`p-4 rounded-2xl border transition-all text-left relative cursor-pointer ${
                selectedRole === 'worker'
                  ? 'bg-emerald-500/10 border-emerald-500 shadow-md shadow-emerald-500/15'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    selectedRole === 'worker'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <User className="w-5 h-5" />
                </div>
                {selectedRole === 'worker' && (
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400 animate-pulse" />
                )}
              </div>
              <h3
                className={`font-bold text-sm sm:text-base ${
                  selectedRole === 'worker' ? 'text-white' : 'text-slate-300'
                }`}
              >
                Staff Counter
              </h3>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Staff Panel: session management, rentals, cafeteria & customer billing
              </p>
            </button>
          </div>

          {/* Verification Code Form */}
          <form onSubmit={handleVerify} className="space-y-4">
            <div>
              <label
                htmlFor="access-code-input"
                className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2"
              >
                {selectedRole === 'admin' ? 'Administrator Security Code' : 'Staff Terminal Access Code'}
              </label>
              <div className="relative">
                <input
                  id="access-code-input"
                  type={showCode ? 'text' : 'password'}
                  value={code}
                  onChange={(e) => {
                    setCode(e.target.value);
                    setError('');
                  }}
                  autoFocus
                  placeholder={
                    selectedRole === 'admin'
                      ? 'Enter Admin Access Code'
                      : 'Enter Staff Access Code'
                  }
                  className={`w-full bg-slate-950/80 border rounded-xl px-4 py-3.5 text-base font-mono text-white placeholder-slate-500 focus:outline-none focus:ring-2 transition-all pr-12 ${
                    selectedRole === 'admin'
                      ? 'border-slate-700 focus:border-cyan-500 focus:ring-cyan-500/20'
                      : 'border-slate-700 focus:border-emerald-500 focus:ring-emerald-500/20'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowCode(!showCode)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 p-1 cursor-pointer"
                  tabIndex={-1}
                  aria-label={showCode ? 'Hide code' : 'Show code'}
                >
                  {showCode ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div
                id="role-code-error-banner"
                className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-2.5 text-rose-400 text-xs"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="font-medium leading-relaxed">{error}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              id="verify-role-code-btn"
              type="submit"
              disabled={isVerifying || !code.trim()}
              className={`w-full py-3.5 px-5 rounded-xl font-bold text-sm tracking-wide flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg disabled:opacity-50 disabled:cursor-not-allowed ${
                selectedRole === 'admin'
                  ? 'bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 shadow-cyan-500/20 hover:scale-[1.01] active:scale-[0.99]'
                  : 'bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 shadow-emerald-500/20 hover:scale-[1.01] active:scale-[0.99]'
              }`}
            >
              <Lock className="w-4 h-4" />
              <span>
                {selectedRole === 'admin'
                  ? 'Verify Admin Code & Unlock Admin Panel'
                  : 'Verify Staff Code & Unlock Staff Panel'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Terminal Security Guarantee */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-center gap-2 text-[11px] text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Strict Role Access Control • Terminal Encrypted</span>
          </div>
        </div>
      </div>
    </div>
  );
};
