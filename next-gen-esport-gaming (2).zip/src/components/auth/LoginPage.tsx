import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  LogIn,
  AlertCircle,
  Loader2,
  Gamepad2,
  ShieldCheck,
  UserPlus,
  Globe,
  CheckCircle2,
  Sparkles,
  KeyRound,
  Copy,
  Check,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { auth } from '../../services/firebase';

export const LoginPage: React.FC = () => {
  const { login, signup, loginWithGoogle, resetPassword, formatAuthError } = useAuth();
  const navigate = useNavigate();

  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [invalidCredState, setInvalidCredState] = useState<{ email: string; password: string } | null>(null);
  const [unauthorizedDomain, setUnauthorizedDomain] = useState<string | null>(null);
  const [domainCopied, setDomainCopied] = useState<boolean>(false);

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setError('');
    setSuccessMessage('');
    setInvalidCredState(null);
    setUnauthorizedDomain(null);
    setDomainCopied(false);
    try {
      await loginWithGoogle();
      navigate('/dashboard');
    } catch (err: any) {
      if (err?.code === 'auth/unauthorized-domain') {
        const host = typeof window !== 'undefined' ? window.location.hostname : '';
        setUnauthorizedDomain(host);
      }
      setError(formatAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickRegisterFromInvalidCred = async () => {
    if (!invalidCredState) return;
    const { email: targetEmail, password: targetPassword } = invalidCredState;
    if (targetPassword.length < 6) {
      setIsRegister(true);
      setError('Password must be at least 6 characters long to create an account.');
      return;
    }

    setIsLoading(true);
    setError('');
    setSuccessMessage('');
    try {
      await signup(targetEmail, targetPassword);
      navigate('/dashboard');
    } catch (err: any) {
      if (err?.code === 'auth/email-already-in-use') {
        setError(
          'An account with this email already exists with a different password. Please check your password, use Google Sign-In, or click "Forgot Password" below.'
        );
      } else {
        setError(formatAuthError(err));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      setError('Please enter your email address above to receive a password reset link.');
      return;
    }

    setIsLoading(true);
    setError('');
    setSuccessMessage('');
    try {
      await resetPassword(cleanEmail);
      setSuccessMessage(`Password reset link sent to ${cleanEmail}. Please check your email inbox.`);
      setInvalidCredState(null);
    } catch (err: any) {
      setError(formatAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setInvalidCredState(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      setError('Please enter your email address.');
      return;
    }
    if (!password) {
      setError('Please enter your password.');
      return;
    }

    if (isRegister) {
      if (password.length < 6) {
        setError('Password must be at least 6 characters long.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match. Please verify your password confirmation.');
        return;
      }
    }

    setIsLoading(true);
    try {
      if (isRegister) {
        await signup(cleanEmail, password);
      } else {
        await login(cleanEmail, password);
      }
      // After Firebase login/signup succeeds, user is authenticated in Firebase Auth.
      // Next step in the lifecycle is the Role Selection & Code screen.
      navigate('/dashboard');
    } catch (err: any) {
      const code = err?.code || '';
      const formattedError = formatAuthError(err);
      
      if ((code === 'auth/invalid-credential' || code === 'auth/invalid-login-credentials') && !isRegister) {
        setInvalidCredState({ email: cleanEmail, password });
        setError(formattedError);
      } else {
        setError(formattedError);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      id="login-page"
      className="min-h-screen w-screen bg-slate-950 flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden"
    >
      {/* Background cyber lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md z-10">
        {/* Branding Logo & Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 p-0.5 shadow-lg shadow-cyan-500/20 mb-3">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Gamepad2 className="w-8 h-8 text-cyan-400" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white uppercase">
            NEXT GEN ESPORT
          </h1>
          <p className="text-xs sm:text-sm font-semibold tracking-wider text-cyan-400 uppercase mt-0.5">
            GAMING LAUNCHER • CLOUD TERMINAL
          </p>
        </div>

        {/* Auth Box */}
        <div className="bg-slate-900/85 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/60">
          {/* Prominent Google Sign-in Option */}
          <div className="mb-5">
            <button
              id="login-google-btn"
              type="button"
              disabled={isLoading}
              onClick={handleGoogleSignIn}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-slate-900 to-slate-950 hover:from-slate-850 hover:to-slate-900 border border-cyan-500/40 hover:border-cyan-400/80 text-white font-semibold text-xs tracking-wide shadow-lg shadow-cyan-950/40 transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed group"
            >
              <div className="w-5 h-5 rounded-md bg-white/10 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <span>Continue with Google Account</span>
              <span className="ml-1 text-[10px] font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-500/30">
                1-Click
              </span>
            </button>
          </div>

          <div className="relative flex py-2 items-center mb-5">
            <div className="flex-grow border-t border-slate-800" />
            <span className="flex-shrink mx-4 text-[10px] font-semibold tracking-wider text-slate-500 uppercase">
              Or with email credentials
            </span>
            <div className="flex-grow border-t border-slate-800" />
          </div>

          {/* Mode Switch Tabs */}
          <div className="grid grid-cols-2 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 mb-5">
            <button
              id="tab-signin-btn"
              type="button"
              onClick={() => {
                setIsRegister(false);
                setError('');
                setSuccessMessage('');
                setInvalidCredState(null);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                !isRegister
                  ? 'bg-gradient-to-r from-cyan-600 to-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>

            <button
              id="tab-register-btn"
              type="button"
              onClick={() => {
                setIsRegister(true);
                setError('');
                setSuccessMessage('');
                setInvalidCredState(null);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                isRegister
                  ? 'bg-gradient-to-r from-cyan-600 to-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Create Account</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email Field */}
            <div>
              <label
                htmlFor="login-email-input"
                className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5"
              >
                Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  id="login-email-input"
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError('');
                    setSuccessMessage('');
                    setInvalidCredState(null);
                  }}
                  autoFocus
                  required
                  placeholder="name@nextgencafe.com"
                  className="w-full bg-slate-950/80 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all font-mono"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="login-password-input"
                  className="block text-xs font-semibold uppercase tracking-wider text-slate-300"
                >
                  Password
                </label>
                {!isRegister && (
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="login-password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError('');
                    setSuccessMessage('');
                    setInvalidCredState(null);
                  }}
                  required
                  placeholder="••••••••"
                  className="w-full bg-slate-950/80 border border-slate-700 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                  tabIndex={-1}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password (if registering) */}
            {isRegister && (
              <div>
                <label
                  htmlFor="login-confirm-password-input"
                  className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5"
                >
                  Confirm Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="login-confirm-password-input"
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      setError('');
                      setSuccessMessage('');
                    }}
                    required
                    placeholder="••••••••"
                    className="w-full bg-slate-950/80 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all font-mono"
                  />
                </div>
              </div>
            )}

            {/* Success Notification */}
            {successMessage && (
              <div
                id="login-success-banner"
                className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-2.5 text-emerald-300 text-xs"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="font-medium leading-relaxed">{successMessage}</span>
              </div>
            )}

            {/* Error Message Banner */}
            {error && (
              <div
                id="login-error-banner"
                className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 flex flex-col gap-2.5 text-rose-300 text-xs"
              >
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                  <span className="font-medium leading-relaxed">{error}</span>
                </div>

                {/* Instant Recovery Actions when unauthorized-domain occurs */}
                {unauthorizedDomain && (
                  <div className="pt-2 border-t border-rose-500/20 flex flex-col gap-2">
                    <p className="text-[11px] text-slate-300">
                      Copy your app domain below and paste it into <span className="text-white font-semibold">Firebase Console &gt; Authentication &gt; Settings &gt; Authorized domains</span>:
                    </p>
                    <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-lg border border-slate-700">
                      <span className="font-mono text-cyan-300 text-[11px] flex-1 truncate select-all">
                        {unauthorizedDomain}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          if (typeof navigator !== 'undefined' && navigator.clipboard) {
                            navigator.clipboard.writeText(unauthorizedDomain);
                            setDomainCopied(true);
                            setTimeout(() => setDomainCopied(false), 2500);
                          }
                        }}
                        className="py-1 px-2.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-[10px] flex items-center gap-1 shadow cursor-pointer transition-all"
                      >
                        {domainCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>{domainCopied ? 'Copied!' : 'Copy Domain'}</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Instant Recovery Actions when invalid-credential occurs */}
                {invalidCredState && (
                  <div className="pt-2 border-t border-rose-500/20 flex flex-col gap-2">
                    <p className="text-[11px] text-slate-300">
                      If this is a new account, you can create it right now with one click:
                    </p>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <button
                        id="quick-register-btn"
                        type="button"
                        disabled={isLoading}
                        onClick={handleQuickRegisterFromInvalidCred}
                        className="py-2 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow transition-all cursor-pointer disabled:opacity-50"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Create Account with this Password</span>
                      </button>

                      <button
                        id="quick-google-btn"
                        type="button"
                        disabled={isLoading}
                        onClick={handleGoogleSignIn}
                        className="py-2 px-3 rounded-lg bg-slate-950 hover:bg-slate-800 text-white font-medium text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-all cursor-pointer disabled:opacity-50"
                      >
                        <Globe className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Google Sign-In</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Submit Button */}
            <button
              id="login-submit-btn"
              type="submit"
              disabled={isLoading}
              className="w-full mt-1 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/20 transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authenticating...</span>
                </>
              ) : isRegister ? (
                <>
                  <UserPlus className="w-4 h-4" />
                  <span>Create Account & Continue</span>
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>Sign In & Continue</span>
                </>
              )}
            </button>
          </form>

          {/* Helpful Information Footer */}
          <div className="mt-5 pt-3 border-t border-slate-800 text-center">
            <p className="text-[11px] text-slate-400">
              Terminal Access requires an authorized Firebase account.
              <br />
              Admins and Staff verify security PINs on the next screen.
            </p>
            <div className="mt-2 flex flex-col gap-0.5">
              <p className="text-[9px] text-slate-600 font-mono">
                Build: {new Date().toISOString().split('T')[0]} • Project: {auth?.app?.options?.projectId || 'unknown'}
              </p>
              <p className="text-[9px] text-slate-700 font-mono">
                Instance: {window.location.hostname}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
