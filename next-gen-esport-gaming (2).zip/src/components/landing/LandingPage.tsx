import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Gamepad2, 
  Monitor, 
  Users, 
  Package, 
  Coffee, 
  Wrench, 
  ShoppingCart, 
  BarChart3, 
  ShieldCheck, 
  ArrowRight,
  ChevronRight,
  Database,
  Cloud
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans overflow-x-hidden">
      {/* Background cyber lighting */}
      <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] bg-cyan-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Navigation */}
      <nav className="relative z-50 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 p-0.5 shadow-lg shadow-cyan-500/20">
                <div className="w-full h-full bg-slate-950 rounded-[9px] flex items-center justify-center">
                  <Gamepad2 className="w-6 h-6 text-cyan-400" />
                </div>
              </div>
              <div>
                <span className="text-xl font-black tracking-tighter text-white uppercase">NEXT GEN ESPORT</span>
                <p className="text-[10px] font-bold tracking-[0.2em] text-cyan-500 uppercase leading-none">Management System</p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm font-medium text-slate-400 hover:text-cyan-400 transition-colors">Features</a>
              <a href="#storage" className="text-sm font-medium text-slate-400 hover:text-cyan-400 transition-colors">Storage Architecture</a>
              <Link to="/privacy" className="text-sm font-medium text-slate-400 hover:text-cyan-400 transition-colors">Privacy</Link>
            </div>
            <div>
              <Link 
                to="/login" 
                className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-sm font-bold text-white transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2"
              >
                <span>Terminal Login</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[10px] font-bold uppercase tracking-widest mb-8 animate-fade-in">
            <ShieldCheck className="w-3 h-3" />
            Professional Cafe Management
          </div>
          <h1 className="text-5xl md:text-7xl font-black tracking-tight text-white mb-6 leading-tight">
            The Ultimate Operating System for <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Gaming Cafes</span>
          </h1>
          <p className="text-lg text-slate-400 max-w-3xl mx-auto mb-10 leading-relaxed">
            NEXT GEN ESPORT is a high-performance management system designed specifically for modern gaming centers and eSports arenas. Streamline your operations with real-time session tracking, automated billing, and secure cloud-native architecture.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link 
              to="/login" 
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-lg shadow-xl shadow-cyan-500/20 transition-all hover:scale-[1.05] flex items-center justify-center gap-3"
            >
              <span>Access Terminal</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a 
              href="#features" 
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-slate-900 border border-slate-800 text-white font-bold text-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-3"
            >
              Explore Features
            </a>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section id="features" className="py-24 border-t border-slate-900 bg-slate-900/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-black text-white mb-4 uppercase tracking-tight">Full-Stack Operational Control</h2>
            <div className="w-20 h-1 bg-cyan-500 mx-auto" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard 
              icon={<Monitor className="w-6 h-6" />}
              title="Console Management"
              description="Real-time monitoring and control of gaming consoles and PC stations. Automated start/stop with precise duration tracking."
            />
            <FeatureCard 
              icon={<Users className="w-6 h-6" />}
              title="Customer Management"
              description="Detailed customer profiles, visit history, and credit management to build long-term loyalty."
            />
            <FeatureCard 
              icon={<Package className="w-6 h-6" />}
              title="Rental & Gear"
              description="Track high-value gaming peripherals, controllers, and accessories with clear rental records and status updates."
            />
            <FeatureCard 
              icon={<Coffee className="w-6 h-6" />}
              title="Cafeteria (F&B)"
              description="Integrated food and beverage ordering system with automated stock reduction and billing consolidation."
            />
            <FeatureCard 
              icon={<Wrench className="w-6 h-6" />}
              title="Repair Tracking"
              description="Manage maintenance logs for your hardware. Keep track of repairs, costs, and downtime for every device."
            />
            <FeatureCard 
              icon={<ShoppingCart className="w-6 h-6" />}
              title="Buy & Sell"
              description="Integrated marketplace for used gaming gear, consoles, and accessories within your cafe ecosystem."
            />
            <FeatureCard 
              icon={<BarChart3 className="w-6 h-6" />}
              title="Revenue Reports"
              description="Deep analytical insights into daily, weekly, and monthly performance. Export data to professional XLSX formats."
            />
            <FeatureCard 
              icon={<ShieldCheck className="w-6 h-6" />}
              title="Role-Based Access"
              description="Secure Admin and Staff management with unique access codes and permission tiers for operational safety."
            />
            <FeatureCard 
              icon={<Database className="w-6 h-6" />}
              title="Secure Vaulting"
              description="Your business data stays in your hands. High-security authentication combined with decentralized storage."
            />
          </div>
        </div>
      </section>

      {/* Storage Architecture Section */}
      <section id="storage" className="py-24 overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900/60 border border-slate-800 rounded-[32px] p-8 md:p-16 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-[50%] h-[100%] bg-cyan-500/5 blur-[100px] pointer-events-none" />
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-5xl font-black text-white mb-6 tracking-tight leading-tight uppercase">
                  Decentralized <br />
                  <span className="text-cyan-400">Business Storage</span>
                </h2>
                <p className="text-slate-400 text-lg mb-8 leading-relaxed">
                  Unlike traditional cloud apps that keep your data on their servers, NEXT GEN ESPORT uses a unique **Bring-Your-Own-Storage (BYOS)** architecture.
                </p>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 shrink-0 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-cyan-400 shadow-inner">
                      <Cloud className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-1">Your Google Drive, Your Data</h4>
                      <p className="text-sm text-slate-400">All business transactions and operational data are stored exclusively as encrypted Excel (XLSX) files inside your own private Google Drive.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-12 h-12 shrink-0 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-emerald-400 shadow-inner">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-1">Zero Local Persistence</h4>
                      <p className="text-sm text-slate-400">For maximum security, business data is never cached in your browser or local storage. Every session is real-time and server-validated.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 shadow-2xl relative">
                <div className="absolute -top-3 -right-3 px-4 py-1 bg-cyan-500 text-slate-950 text-[10px] font-black uppercase rounded-lg tracking-widest shadow-lg">Architecture</div>
                <div className="space-y-4 font-mono text-[11px]">
                  <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-500">Authentication</span>
                    <span className="text-cyan-400 italic">Firebase Auth (Identity only)</span>
                  </div>
                  <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-500">Business Data Storage</span>
                    <span className="text-amber-400 font-bold">Owner's Google Drive (Encrypted XLSX)</span>
                  </div>
                  <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-500">Local Cache</span>
                    <span className="text-rose-400">DISABLED (Strict Security)</span>
                  </div>
                  <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-500">Real-time Sync</span>
                    <span className="text-emerald-400">Server-Sent Events (SSE)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3 opacity-60 grayscale">
            <Gamepad2 className="w-5 h-5 text-white" />
            <span className="text-sm font-black tracking-tighter text-white uppercase">NEXT GEN ESPORT</span>
          </div>
          <div className="flex gap-8">
            <Link to="/privacy" className="text-xs font-medium text-slate-500 hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="text-xs font-medium text-slate-500 hover:text-white transition-colors">Terms of Service</Link>
            <a href="mailto:support@nextgencafe.com" className="text-xs font-medium text-slate-500 hover:text-white transition-colors">Support</a>
          </div>
          <p className="text-[10px] font-medium text-slate-600 uppercase tracking-widest">
            © {new Date().getFullYear()} Next Gen Esport Management System. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
  <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 hover:border-cyan-500/30 transition-all hover:translate-y-[-4px] group">
    <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center text-cyan-400 mb-6 shadow-inner group-hover:bg-cyan-500 group-hover:text-slate-950 transition-all duration-300">
      {icon}
    </div>
    <h3 className="text-xl font-bold text-white mb-3 tracking-tight">{title}</h3>
    <p className="text-sm text-slate-400 leading-relaxed">{description}</p>
  </div>
);
