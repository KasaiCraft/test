import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Plus,
  Search,
  Filter,
  Clock,
  Play,
  Pause,
  Square,
  AlertCircle,
  Edit2,
  Trash2,
  Wrench,
  CheckCircle2,
  DollarSign,
  Monitor,
  Zap,
  Tag,
  User,
  Phone,
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';
import { ConsoleDevice, ConsoleType, ConsoleStatus, GamingSession } from '../../types';

interface GamingConsolesViewProps {
  onOpenStartSession: (preselectedConsoleId?: string) => void;
  onOpenEndSession?: (session: GamingSession) => void;
  onOpenStopSession?: (session: GamingSession) => void;
  onOpenExtendSession?: (session: GamingSession) => void;
  onOpenConsoleModal: (consoleToEdit?: ConsoleDevice) => void;
}

export const GamingConsolesView: React.FC<GamingConsolesViewProps> = ({
  onOpenStartSession,
  onOpenEndSession,
  onOpenStopSession,
  onOpenExtendSession,
  onOpenConsoleModal,
}) => {
  const {
    consoles,
    sessions,
    isAdmin,
    settings,
    updateConsole,
    deleteConsole,
    calculateLiveSessionBill,
    pauseSession,
    resumeSession,
  } = useCafe();

  const handleEndSession = (session: GamingSession) => {
    if (onOpenEndSession) {
      onOpenEndSession(session);
    } else if (onOpenStopSession) {
      onOpenStopSession(session);
    }
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [, setTick] = useState(0);

  // Live timer tick
  useEffect(() => {
    const interval = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const consoleTypes: ConsoleType[] = [
    'PS5',
    'PS4',
    'Xbox Series X',
    'Xbox One',
    'PC Gaming',
    'VR Station',
    'Nintendo Switch',
    'Sim Racing',
  ];

  // Filtering
  const filteredConsoles = consoles.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.specifications && item.specifications.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesType = selectedType === 'all' || item.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || item.status === selectedStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  const formatTimer = (session: GamingSession) => {
    const isPaused = session.status === 'paused';
    const pausedMinutes = (session.totalPausedMinutes || 0) + (isPaused && session.pausedAt ? Math.floor((Date.now() - new Date(session.pausedAt).getTime()) / 60000) : 0);
    const startMs = new Date(session.startTime).getTime();
    const nowMs = isPaused && session.pausedAt ? new Date(session.pausedAt).getTime() : Date.now();

    if (session.scheduledEndTime) {
      const endMs = new Date(session.scheduledEndTime).getTime();
      const referenceNow = isPaused && session.pausedAt ? new Date(session.pausedAt).getTime() : Date.now();
      const remainingSec = Math.max(0, Math.floor((endMs - referenceNow) / 1000));
      
      const hrs = Math.floor(remainingSec / 3600);
      const mins = Math.floor((remainingSec % 3600) / 60);
      const secs = remainingSec % 60;
      if (isPaused) return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')} (Paused)`;
      if (remainingSec === 0) return '00:00:00 (Time Over)';
      if (hrs > 0) {
        return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')} left`;
      }
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')} left`;
    }

    const elapsedSec = Math.max(0, Math.floor((nowMs - startMs) / 1000) - (session.totalPausedMinutes || 0) * 60);
    const hrs = Math.floor(elapsedSec / 3600);
    const mins = Math.floor((elapsedSec % 3600) / 60);
    const secs = elapsedSec % 60;
    return `${isPaused ? '[PAUSED] ' : ''}${hrs > 0 ? `${hrs}h ` : ''}${mins}m ${secs.toString().padStart(2, '0')}s`;
  };

  const [consoleToDelete, setConsoleToDelete] = useState<ConsoleDevice | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const confirmDelete = async () => {
    if (!consoleToDelete || !isAdmin) return;
    if (consoleToDelete.status === 'in_use') {
      setDeleteError('Cannot delete a console while a gaming session is in progress. End the session first.');
      return;
    }
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteConsole(consoleToDelete.id);
      setConsoleToDelete(null);
    } catch (err: any) {
      setDeleteError(err?.message || 'Failed to delete gaming station.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleStatusToggle = async (consoleItem: ConsoleDevice, newStatus: ConsoleStatus) => {
    if (!isAdmin) return;
    if (consoleItem.status === 'in_use' && newStatus !== 'in_use') {
      return;
    }
    await updateConsole(consoleItem.id, { status: newStatus });
  };

  return (
    <div id="gaming-consoles-view" className="space-y-6 pb-12">
      {/* Action Header & Search Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4 bg-slate-900/80 p-3.5 sm:p-5 rounded-2xl border border-slate-800">
        <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 flex-1 w-full md:w-auto">
          {/* Search Box */}
          <div className="relative flex-1 sm:flex-initial sm:w-64 md:w-72 min-w-[160px] w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="console-search-input"
              type="text"
              placeholder="Search station (e.g. PS5-01, RTX, Booth)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Type Filter */}
          <select
            id="console-type-filter"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="w-full sm:w-auto bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="all">All Device Types</option>
            {consoleTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            id="console-status-filter"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full sm:w-auto bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="available">Available (Free)</option>
            <option value="in_use">In Use (Active)</option>
            <option value="maintenance">Maintenance</option>
            <option value="disabled">Disabled</option>
          </select>
        </div>

        {/* Add Console (Admin Only) */}
        {isAdmin && (
          <button
            id="add-new-console-btn"
            onClick={() => onOpenConsoleModal()}
            className="w-full md:w-auto flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-sm shadow-md shadow-cyan-500/20 transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Gaming Station</span>
          </button>
        )}
      </div>

      {/* Grid of Gaming Station Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredConsoles.map((consoleItem) => {
          const activeSession = sessions.find(
            (s) => s.consoleId === consoleItem.id && (s.status === 'active' || s.status === 'paused')
          );
          const isInUse = !!activeSession;
          const liveBill = activeSession ? calculateLiveSessionBill(activeSession) : null;

          return (
            <div
              key={consoleItem.id}
              id={`console-card-${consoleItem.code}`}
              className={`rounded-2xl border transition-all flex flex-col justify-between overflow-hidden relative shadow-lg ${
                isInUse
                  ? 'bg-slate-900 border-cyan-500/40 shadow-cyan-500/10'
                  : consoleItem.status === 'maintenance'
                  ? 'bg-slate-900 border-amber-500/30'
                  : consoleItem.status === 'disabled'
                  ? 'bg-slate-900/60 border-slate-800 opacity-70'
                  : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Card Header Banner */}
              <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm tracking-tight ${
                      isInUse
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                        : consoleItem.status === 'maintenance'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : consoleItem.status === 'disabled'
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {consoleItem.code}
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base leading-tight">
                      {consoleItem.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {consoleItem.type} • {consoleItem.location || 'Main Floor'}
                    </p>
                  </div>
                </div>

                {/* Status Badge */}
                <div>
                  {isInUse ? (
                    activeSession?.status === 'paused' ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                        Paused
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 animate-pulse">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                        In Session
                      </span>
                    )
                  ) : consoleItem.status === 'maintenance' ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                      <Wrench className="w-3 h-3" />
                      Maintenance
                    </span>
                  ) : consoleItem.status === 'disabled' ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30">
                      Disabled
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      <CheckCircle2 className="w-3 h-3" />
                      Available
                    </span>
                  )}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-4 sm:p-5 space-y-3 flex-1 flex flex-col justify-between">
                {/* Active Session Details Box */}
                {isInUse && activeSession && liveBill ? (
                  <div className="bg-slate-950/70 border border-cyan-500/20 rounded-xl p-3.5 space-y-2.5">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <div className="flex items-center gap-1.5 text-slate-200 font-medium">
                        <User className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="text-sm text-white font-bold">{activeSession.customerName}</span>
                        {activeSession.playerCount && activeSession.playerCount > 1 && (
                          <span className="text-[10px] font-bold text-cyan-400 bg-cyan-950/50 px-1.5 py-0.5 rounded border border-cyan-500/30 ml-1">
                            {activeSession.playerCount}P
                          </span>
                        )}
                      </div>
                      {activeSession.customerPhone && (
                        <span className="text-[11px] text-slate-400 font-mono">
                          {activeSession.customerPhone}
                        </span>
                      )}
                    </div>

                    {/* Live Clock & Running Bill */}
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <div className="flex items-center justify-between">
                          <p className="text-[10px] text-slate-400 uppercase font-semibold">
                            {activeSession.scheduledEndTime ? 'Time Remaining' : 'Running Time'}
                          </p>
                          {activeSession.presetDurationMinutes && (
                            <span className="text-[10px] font-medium text-cyan-400 bg-cyan-950/80 px-1 rounded">
                              {(() => {
                                const total = activeSession.presetDurationMinutes + (activeSession.usedCreditMinutes || 0);
                                return `${Math.floor(total / 60) > 0 ? `${Math.floor(total / 60)}h ` : ''}${total % 60 > 0 ? `${total % 60}m` : ''}`;
                              })()}
                            </span>
                          )}
                        </div>
                        <p className={`text-sm font-mono font-bold mt-0.5 ${activeSession.scheduledEndTime ? 'text-amber-300' : 'text-cyan-300'}`}>
                          {formatTimer(activeSession)}
                        </p>
                      </div>
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 flex items-center justify-center">
                        <p className="text-[10px] text-slate-500 uppercase font-bold text-center">Prepaid Fixed Pricing Applied</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2 text-xs text-slate-400">
                    <p className="line-clamp-2 text-slate-300">
                      {consoleItem.specifications || 'Standard gaming configuration.'}
                    </p>
                    {consoleItem.notes && (
                      <p className="text-amber-400/90 text-[11px] italic bg-amber-500/10 p-2 rounded-lg border border-amber-500/20">
                        Note: {consoleItem.notes}
                      </p>
                    )}
                  </div>
                )}

                {/* Pricing Info & Hourly Tiers */}
                <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-slate-400">
                      <Tag className="w-3 h-3 text-cyan-400" />
                      <span>Pricing Rates</span>
                    </span>
                    <span className="text-xs font-bold text-white">
                      {settings.currencySymbol} {consoleItem.price1Hour ?? consoleItem.hourlyRate} / 1h
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      1h: {settings.currencySymbol}{consoleItem.price1Hour ?? consoleItem.hourlyRate}
                    </span>
                    {consoleItem.price2Hour !== undefined && consoleItem.price2Hour !== null && consoleItem.price2Hour > 0 && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                        2h: {settings.currencySymbol}{consoleItem.price2Hour}
                      </span>
                    )}
                    {consoleItem.price3Hour !== undefined && consoleItem.price3Hour !== null && consoleItem.price3Hour > 0 && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                        3h: {settings.currencySymbol}{consoleItem.price3Hour}
                      </span>
                    )}
                    {Array.isArray(consoleItem.customPricing) &&
                      consoleItem.customPricing.map((cp) => (
                        <span
                          key={cp.hours}
                          className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20"
                        >
                          {cp.hours}h: {settings.currencySymbol}{cp.price}
                        </span>
                      ))}
                  </div>
                </div>
              </div>

              {/* Card Actions Footer */}
              <div className="p-4 sm:p-5 pt-0 flex items-center justify-between gap-2">
                {isInUse && activeSession ? (
                  <div className="w-full flex items-center gap-2">
                    {activeSession.status === 'paused' ? (
                      <button
                        id={`resume-session-btn-${consoleItem.code}`}
                        onClick={async () => {
                          await resumeSession(activeSession.id);
                        }}
                        className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-3 rounded-xl text-sm transition-all shadow-md shadow-emerald-600/20"
                        title="Resume Session Timer"
                      >
                        <Play className="w-4 h-4 fill-white" />
                        <span>Resume</span>
                      </button>
                    ) : (
                      <button
                        id={`pause-session-btn-${consoleItem.code}`}
                        onClick={async () => {
                          await pauseSession(activeSession.id);
                        }}
                        className="flex-1 flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold py-2.5 px-3 rounded-xl text-sm transition-all shadow-md shadow-amber-600/20"
                        title="Pause Session Timer"
                      >
                        <Pause className="w-4 h-4 fill-white" />
                        <span>Pause</span>
                      </button>
                    )}

                    {onOpenExtendSession && (
                      <button
                        id={`extend-session-btn-${consoleItem.code}`}
                        onClick={() => onOpenExtendSession(activeSession)}
                        className="flex-1 flex items-center justify-center gap-1.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-400 font-bold py-2.5 px-3 rounded-xl text-sm transition-all border border-cyan-500/30"
                        title="Extend Session Time"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Extend</span>
                      </button>
                    )}

                    <button
                      id={`stop-session-btn-${consoleItem.code}`}
                      onClick={() => handleEndSession(activeSession)}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold py-2.5 px-3 rounded-xl text-sm transition-all shadow-md shadow-rose-600/20"
                    >
                      <Square className="w-4 h-4 fill-white" />
                      <span>Checkout</span>
                    </button>
                  </div>
                ) : consoleItem.status === 'available' ? (
                  <button
                    id={`start-session-btn-${consoleItem.code}`}
                    onClick={() => onOpenStartSession(consoleItem.id)}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-sm transition-all shadow-md shadow-cyan-500/20"
                  >
                    <Play className="w-4 h-4 fill-slate-950" />
                    <span>Start New Session</span>
                  </button>
                ) : (
                  <div className="w-full flex items-center justify-between text-xs text-slate-500 py-2">
                    <span>Station unavailable for new sessions</span>
                    {isAdmin && (
                      <button
                        onClick={() => handleStatusToggle(consoleItem, 'available')}
                        className="text-cyan-400 hover:underline font-semibold"
                      >
                        Set Available
                      </button>
                    )}
                  </div>
                )}

                {/* Admin Quick Options (Edit / Delete / Toggle) */}
                {isAdmin && (
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      id={`edit-console-btn-${consoleItem.code}`}
                      onClick={() => onOpenConsoleModal(consoleItem)}
                      title="Edit Console"
                      className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      id={`delete-console-btn-${consoleItem.code}`}
                      onClick={() => {
                        setDeleteError(null);
                        setConsoleToDelete(consoleItem);
                      }}
                      title="Delete Console"
                      disabled={isInUse}
                      className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-40 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {filteredConsoles.length === 0 && (
          <div className="col-span-full py-16 text-center bg-slate-900/60 rounded-2xl border border-slate-800 text-slate-400 space-y-3">
            <Gamepad2 className="w-12 h-12 text-slate-600 mx-auto" />
            <div>
              <p className="text-base font-semibold text-slate-300">No Gaming Stations Found</p>
              <p className="text-xs text-slate-500 mt-1">
                {searchQuery || selectedType !== 'all' || selectedStatus !== 'all'
                  ? 'Try adjusting your search query or filters.'
                  : 'Your station directory is currently empty. Click below to add a station or restore starter templates in Settings.'}
              </p>
            </div>
            {isAdmin && !searchQuery && selectedType === 'all' && selectedStatus === 'all' && (
              <button
                type="button"
                onClick={() => onOpenConsoleModal()}
                className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add First Station</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* In-App Delete Confirmation Modal */}
      {consoleToDelete && (
        <div
          id="delete-console-modal-backdrop"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
        >
          <div
            id="delete-console-modal-card"
            className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete Gaming Station</h3>
                <p className="text-xs text-slate-400">This action cannot be undone.</p>
              </div>
            </div>

            {deleteError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-semibold flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Station Code:</span>
                <span className="font-mono font-bold text-cyan-400">{consoleToDelete.code}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Name:</span>
                <span className="font-semibold text-white">{consoleToDelete.name}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Type:</span>
                <span>{consoleToDelete.type}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Hourly Rate:</span>
                <span className="text-emerald-400 font-bold">
                  {settings.currencySymbol} {consoleToDelete.hourlyRate}/hr
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setConsoleToDelete(null);
                  setDeleteError(null);
                }}
                disabled={isDeleting}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="confirm-delete-console-btn"
                type="button"
                onClick={confirmDelete}
                disabled={isDeleting || consoleToDelete.status === 'in_use'}
                className="bg-rose-600 hover:bg-rose-500 text-white font-bold px-5 py-2 rounded-xl text-xs transition-all shadow-md shadow-rose-600/20 cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Delete Station'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
