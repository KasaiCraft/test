export interface StandardRentalPricing {
  base: {
    '1day': number;
    '3days': number;
    '7days': number;
    '30days': number;
  };
  extraController: {
    '1day': number;
    '3days': number;
    '7days': number;
    '30days': number;
  };
  extraGame: {
    '1day': number;
    '3days': number;
    '7days': number;
    '30days': number;
  };
}

export const RENTAL_PRICING: Record<'PS4' | 'PS5', StandardRentalPricing> = {
  PS4: {
    base: {
      '1day': 599,
      '3days': 1199,
      '7days': 2399,
      '30days': 3999,
    },
    extraController: {
      '1day': 199,
      '3days': 399,
      '7days': 799,
      '30days': 1199,
    },
    extraGame: {
      '1day': 99,
      '3days': 199,
      '7days': 399,
      '30days': 799,
    },
  },
  PS5: {
    base: {
      '1day': 899,
      '3days': 1799,
      '7days': 3499,
      '30days': 7999,
    },
    extraController: {
      '1day': 299,
      '3days': 599,
      '7days': 999,
      '30days': 1499,
    },
    extraGame: {
      '1day': 149,
      '3days': 299,
      '7days': 599,
      '30days': 999,
    },
  },
};

export type RentalDuration = '1day' | '3days' | '7days' | '30days';

export const DURATION_LABELS: Record<RentalDuration, string> = {
  '1day': '1 Day',
  '3days': '3 Days',
  '7days': '7 Days',
  '30days': '30 Days',
};

export const DURATION_UNITS: Record<RentalDuration, number> = {
  '1day': 1,
  '3days': 3,
  '7days': 7,
  '30days': 30,
};
