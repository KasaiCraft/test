import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  CafeDatabase,
  UserAccount,
  UserRole,
  ConsoleDevice,
  GamingSession,
  Customer,
  RentalItem,
  RentalRecord,
  RentalPeriodType,
  CafeteriaItem,
  CafeteriaOrder,
  CafeteriaCategory,
  CafeteriaOrderItem,
  CafeteriaStockLog,
  StockMovementType,
  Voucher,
  VoucherUsage,
  VoucherCategory,
  VoucherStatus,
  BuySellItem,
  BuySellTransaction,
  BuySellCategory,
  BuySellCondition,
  BuySellItemStatus,
  RepairRecord,
  RepairCategory,
  RepairStatus,
  PaymentTransaction,
  CafeSettings,
  NavigationTab,
  PaymentMethod,
  PaymentStatus,
  PaymentSplitItem,
  SessionAlert,
  NEXTGEN_CAFE_BUSINESS_ID,
  MAX_WORKERS_ALLOWED,
  ResetOptions,
  AdminNotice,
  NoticeCategory,
  NoticePriority,
  DriveSyncState,
} from '../types';
import { driveService } from '../services/googleDriveService';
import { CafeModulesService } from '../services/cafeModulesService';
import { INITIAL_DATABASE, INITIAL_ADMIN_USER, createIsolatedBusinessDatabase } from '../data/initialData';
import { playSessionEndChime } from '../utils/sound';
import { calculateStationPricing } from '../utils/pricing';
import { getGamingPrice, getFixedStationType } from '../data/gamingPricing';
import { useAuth } from './AuthContext';
import { tenantService } from '../services/tenantService';

// Helper to sanitize relational integrity and deduplicate records
export function sanitizeCafeDatabase(db: CafeDatabase): CafeDatabase {
  if (!db || typeof db !== 'object') {
    return INITIAL_DATABASE;
  }

  // 0. Resolve deleted console tombstones
  const deletedConsoleIds = new Set<string>([
    ...(Array.isArray(db.deletedConsoleIds) ? db.deletedConsoleIds : []),
    ...(Array.isArray((db.settings as any)?.deletedConsoleIds) ? (db.settings as any).deletedConsoleIds : []),
  ]);

  // Sanitize & Deduplicate Consoles (Unique ID & Stable Identification)
  const rawConsoles = Array.isArray(db.consoles) ? db.consoles : [];
  const canonicalConsoleMap = new Map<string, ConsoleDevice>();

  for (let i = 0; i < rawConsoles.length; i++) {
    const raw = rawConsoles[i];
    if (!raw || typeof raw !== 'object') continue;
    let cId = String(raw.id || '').trim();
    if (cId && deletedConsoleIds.has(cId)) continue;

    if (!cId) {
      cId = `c_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 6)}`;
    }

    const rawCode = String(raw.code || '').trim().toUpperCase();

    if (canonicalConsoleMap.has(cId)) {
      const existing = canonicalConsoleMap.get(cId)!;
      if (rawCode && existing.code && rawCode !== String(existing.code).trim().toUpperCase()) {
        cId = `${cId}_${rawCode.replace(/[^a-zA-Z0-9]/g, '') || Math.random().toString(36).substring(2, 6)}`;
      } else {
        continue;
      }
    }

    const rawHourly = typeof raw.hourlyRate === 'number' && !isNaN(raw.hourlyRate) && raw.hourlyRate > 0 ? raw.hourlyRate : 0;
    const p1 = typeof raw.price1Hour === 'number' && !isNaN(raw.price1Hour) && raw.price1Hour > 0 ? raw.price1Hour : (rawHourly || 100);

    const sanitizedConsole: ConsoleDevice = {
      ...raw,
      id: cId,
      code: rawCode || `STN-${i + 1}`,
      name: String(raw.name || rawCode || `Station ${i + 1}`).trim(),
      type: raw.type || 'PC Gaming',
      hourlyRate: p1,
      price1Hour: p1,
      price2Hour: typeof raw.price2Hour === 'number' && raw.price2Hour > 0 ? raw.price2Hour : undefined,
      price3Hour: typeof raw.price3Hour === 'number' && raw.price3Hour > 0 ? raw.price3Hour : undefined,
      customPricing: Array.isArray(raw.customPricing) ? raw.customPricing : [],
      playerPricing: raw.playerPricing && typeof raw.playerPricing === 'object' ? raw.playerPricing : undefined,
      status: raw.status || 'available',
      currentSessionId: raw.currentSessionId || null,
      createdAt: raw.createdAt || new Date().toISOString(),
    };

    canonicalConsoleMap.set(cId, sanitizedConsole);
  }

  const consoles = Array.from(canonicalConsoleMap.values());
  const existingConsoleMap = new Map<string, ConsoleDevice>();
  consoles.forEach((c) => existingConsoleMap.set(c.id, c));

  // 1. Sanitize & Deduplicate Customers (Unique ID & Unique Phone enforcement)
  const rawCustomers = Array.isArray(db.customers) ? db.customers : [];
  const canonicalCustomerMap = new Map<string, Customer>(); // canonicalId -> Customer
  const phoneToCanonicalIdMap = new Map<string, string>(); // cleanPhone -> canonicalId
  const idAliasMap = new Map<string, string>(); // duplicateId -> canonicalId

  for (const cust of rawCustomers) {
    if (!cust) continue;
    const custId = String(cust.id || '').trim();
    if (!custId) continue;

    const rawPhone = String(cust.phone || '').trim();
    const cleanPhone = rawPhone.replace(/[\s\-()]/g, '');

    // Case A: ID already seen -> merge into existing canonical record
    if (canonicalCustomerMap.has(custId)) {
      const existing = canonicalCustomerMap.get(custId)!;
      canonicalCustomerMap.set(custId, {
        ...existing,
        name: existing.name || cust.name,
        phone: existing.phone || cust.phone,
        email: existing.email || cust.email,
        membershipId: existing.membershipId || cust.membershipId,
        notes: existing.notes || cust.notes,
        totalVisits: Math.max(existing.totalVisits || 0, cust.totalVisits || 0),
        totalSpent: Math.max(existing.totalSpent || 0, cust.totalSpent || 0),
        totalOutstanding: Math.max(existing.totalOutstanding || 0, cust.totalOutstanding || 0),
      });
      continue;
    }

    // Case B: Same clean phone number exists -> alias this ID to existing canonical customer
    if (cleanPhone && phoneToCanonicalIdMap.has(cleanPhone)) {
      const canonicalId = phoneToCanonicalIdMap.get(cleanPhone)!;
      idAliasMap.set(custId, canonicalId);
      const existing = canonicalCustomerMap.get(canonicalId)!;
      canonicalCustomerMap.set(canonicalId, {
        ...existing,
        name: existing.name || cust.name,
        email: existing.email || cust.email,
        membershipId: existing.membershipId || cust.membershipId,
        notes: existing.notes || cust.notes,
        totalVisits: Math.max(existing.totalVisits || 0, cust.totalVisits || 0),
        totalSpent: Math.max(existing.totalSpent || 0, cust.totalSpent || 0),
        totalOutstanding: Math.max(existing.totalOutstanding || 0, cust.totalOutstanding || 0),
      });
      continue;
    }

    // Case C: New unique customer
    const sanitizedCust: Customer = {
      ...cust,
      id: custId,
      name: String(cust.name || 'Player').trim(),
      phone: rawPhone,
      email: cust.email ? String(cust.email).trim() : undefined,
      membershipId: cust.membershipId ? String(cust.membershipId).trim() : undefined,
      notes: cust.notes ? String(cust.notes).trim() : undefined,
      totalVisits: Number(cust.totalVisits) || 0,
      totalSpent: Number(cust.totalSpent) || 0,
      totalOutstanding: Number(cust.totalOutstanding) || 0,
      unusedMinutesBalance: Number(cust.unusedMinutesBalance) || 0,
      createdAt: cust.createdAt || new Date().toISOString(),
    };

    canonicalCustomerMap.set(custId, sanitizedCust);
    if (cleanPhone) {
      phoneToCanonicalIdMap.set(cleanPhone, custId);
    }
  }

  const sanitizedCustomers = Array.from(canonicalCustomerMap.values());

  // 2. Sanitize sessions: auto-close any active sessions whose preset duration expired or console was deleted
  const nowMs = Date.now();
    const rawSessions = Array.isArray(db.sessions) ? db.sessions : [];
    const sanitizedSessions = rawSessions.map((session) => {
      const remappedCustomerId = idAliasMap.get(session.customerId) || session.customerId;
      let s = { 
        ...session, 
        customerId: remappedCustomerId,
        paidAmount: Number(session.paidAmount) || 0,
        baseAmount: Number(session.baseAmount) || 0,
        totalAmount: Number(session.totalAmount) || 0,
      };

    if ((s.status === 'active' || s.status === 'paused') && !existingConsoleMap.has(s.consoleId)) {
      s = {
        ...s,
        status: 'completed' as const,
        endTime: s.endTime || new Date().toISOString(),
        notes: s.notes ? `${s.notes} (Auto-closed: station removed)` : '(Station removed)',
      };
    }
    return s;
  });

  const activeSessionByConsoleId = new Map<string, GamingSession>();
  sanitizedSessions.forEach((s) => {
    if ((s.status === 'active' || s.status === 'paused') && existingConsoleMap.has(s.consoleId)) {
      activeSessionByConsoleId.set(s.consoleId, s);
    }
  });

  // 3. Sanitize consoles: verify in_use / available state matches actual active session
  const sanitizedConsoles = consoles.map((c) => {
    const activeSession = activeSessionByConsoleId.get(c.id);
    if (activeSession) {
      return {
        ...c,
        status: 'in_use' as const,
        currentSessionId: activeSession.id,
      };
    } else if (c.status === 'in_use') {
      return {
        ...c,
        status: 'available' as const,
        currentSessionId: null,
      };
    }
    return c;
  });

  // 4. Remap customer IDs in rentals & payments if any aliasing occurred
  const rawRentals = Array.isArray(db.rentalRecords) ? db.rentalRecords : [];
  const sanitizedRentals = rawRentals.map((r) => ({
    ...r,
    customerId: idAliasMap.get(r.customerId) || r.customerId,
  }));

  const rawPayments = Array.isArray(db.payments) ? db.payments : [];
  const sanitizedPayments = rawPayments.map((p) => ({
    ...p,
    customerId: p.customerId ? idAliasMap.get(p.customerId) || p.customerId : p.customerId,
  }));

  const rawCafeteriaItems = Array.isArray(db.cafeteriaItems)
    ? db.cafeteriaItems
    : (db.lastResetAt ? [] : (INITIAL_DATABASE.cafeteriaItems || []));
  const rawCafeteriaOrders = Array.isArray(db.cafeteriaOrders)
    ? db.cafeteriaOrders
    : (db.lastResetAt ? [] : (INITIAL_DATABASE.cafeteriaOrders || []));
  const sanitizedCafeteriaOrders = rawCafeteriaOrders.map((o) => ({
    ...o,
    customerId: idAliasMap.get(o.customerId) || o.customerId,
  }));

  const rawCafeteriaStockLogs = Array.isArray(db.cafeteriaStockLogs) ? db.cafeteriaStockLogs : [];

  const deletedVoucherIds = new Set<string>([
    ...(Array.isArray(db.deletedVoucherIds) ? db.deletedVoucherIds : []),
    ...(Array.isArray((db.settings as any)?.deletedVoucherIds) ? (db.settings as any).deletedVoucherIds : []),
  ]);

  const deletedUserIds = new Set<string>([
    ...(Array.isArray(db.deletedUserIds) ? db.deletedUserIds : []),
    ...(Array.isArray((db.settings as any)?.deletedUserIds) ? (db.settings as any).deletedUserIds : []),
  ]);

  const rawVouchers = Array.isArray(db.vouchers) ? db.vouchers : [];
  const canonicalVoucherMap = new Map<string, Voucher>();
  rawVouchers.forEach((v) => {
    if (!v || typeof v !== 'object') return;
    const vId = String(v.id || '').trim();
    if (!vId || deletedVoucherIds.has(vId)) return;
    if (!canonicalVoucherMap.has(vId)) {
      canonicalVoucherMap.set(vId, {
        ...v,
        id: vId,
        assignedCustomerId: v.assignedCustomerId ? (idAliasMap.get(v.assignedCustomerId) || v.assignedCustomerId) : undefined,
      });
    }
  });
  const sanitizedVouchers = Array.from(canonicalVoucherMap.values());

  const rawVoucherUsages = Array.isArray(db.voucherUsages) ? db.voucherUsages : [];
  const sanitizedVoucherUsages = rawVoucherUsages.map((vu) => ({
    ...vu,
    customerId: idAliasMap.get(vu.customerId) || vu.customerId,
  }));

  const rawBuySellItems = Array.isArray(db.buySellItems) ? db.buySellItems : [];
  const sanitizedBuySellItems = rawBuySellItems.map((bi) => ({
    ...bi,
    sellerCustomerId: bi.sellerCustomerId ? (idAliasMap.get(bi.sellerCustomerId) || bi.sellerCustomerId) : undefined,
    buyerCustomerId: bi.buyerCustomerId ? (idAliasMap.get(bi.buyerCustomerId) || bi.buyerCustomerId) : undefined,
  }));

  const rawBuySellTransactions = Array.isArray(db.buySellTransactions) ? db.buySellTransactions : [];
  const sanitizedBuySellTransactions = rawBuySellTransactions.map((bt) => ({
    ...bt,
    customerId: idAliasMap.get(bt.customerId) || bt.customerId,
  }));

  const rawRepairRecords = Array.isArray(db.repairRecords) ? db.repairRecords : [];
  const sanitizedRepairRecords = rawRepairRecords.map((rr) => ({
    ...rr,
    customerId: idAliasMap.get(rr.customerId) || rr.customerId,
  }));

  return {
    version: db.version || 1,
    businessId: db.businessId || NEXTGEN_CAFE_BUSINESS_ID,
    ownerId: db.ownerId,
    ownerEmail: db.ownerEmail,
    lastModified: db.lastModified || new Date().toISOString(),
    lastResetAt: db.lastResetAt || db.settings?.lastResetAt,
    settings: {
      ...(db.settings || INITIAL_DATABASE.settings),
      lastResetAt: db.lastResetAt || db.settings?.lastResetAt,
      deletedConsoleIds: Array.from(deletedConsoleIds),
    },
    users: (() => {
      const userMap = new Map<string, UserAccount>();
      const emailToIdMap = new Map<string, string>();

      const addAccount = (u: UserAccount) => {
        if (!u || typeof u !== 'object') return;
        const uId = String(u.id || '').trim();
        const uEmail = String(u.email || '').trim().toLowerCase();
        if (uId && deletedUserIds.has(uId)) return;

        // If user already present by ID
        if (uId && userMap.has(uId)) {
          const existing = userMap.get(uId)!;
          userMap.set(uId, { ...existing, ...u, id: uId });
          if (uEmail) emailToIdMap.set(uEmail, uId);
          return;
        }

        // If user already present by Email
        if (uEmail && emailToIdMap.has(uEmail)) {
          const existingId = emailToIdMap.get(uEmail)!;
          const existing = userMap.get(existingId)!;
          userMap.set(existingId, { ...existing, ...u, id: existingId });
          return;
        }

        const finalId = uId || (uEmail ? `usr_${uEmail.replace(/[^a-z0-9]/g, '_')}` : `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`);
        if (deletedUserIds.has(finalId)) return;

        const sanitized: UserAccount = {
          ...u,
          id: finalId,
          name: String(u.name || (uEmail ? uEmail.split('@')[0] : 'Staff')).trim(),
          email: uEmail || undefined,
          role: u.role || 'worker',
          status: u.status || 'active',
          businessId: db.businessId || NEXTGEN_CAFE_BUSINESS_ID,
          createdAt: u.createdAt || new Date().toISOString(),
        };

        userMap.set(finalId, sanitized);
        if (uEmail) emailToIdMap.set(uEmail, finalId);
      };

      if (Array.isArray(db.users)) {
        db.users.forEach(addAccount);
      }
      try {
        const cachedStaff = tenantService.getStaffAccounts();
        if (Array.isArray(cachedStaff)) {
          cachedStaff.forEach(addAccount);
        }
      } catch (e) {
        // ignore
      }
      return Array.from(userMap.values());
    })(),
    consoles: sanitizedConsoles,
    sessions: sanitizedSessions,
    customers: sanitizedCustomers,
    rentalItems: Array.isArray(db.rentalItems) ? db.rentalItems : [],
    rentalRecords: sanitizedRentals,
    cafeteriaItems: rawCafeteriaItems,
    cafeteriaOrders: sanitizedCafeteriaOrders,
    cafeteriaStockLogs: rawCafeteriaStockLogs,
    vouchers: sanitizedVouchers,
    voucherUsages: sanitizedVoucherUsages,
    buySellItems: sanitizedBuySellItems,
    buySellTransactions: sanitizedBuySellTransactions,
    repairRecords: sanitizedRepairRecords,
    payments: sanitizedPayments,
    notices: Array.isArray(db.notices) ? db.notices : [],
    deletedConsoleIds: Array.from(deletedConsoleIds),
    deletedVoucherIds: Array.from(deletedVoucherIds),
    deletedUserIds: Array.from(deletedUserIds),
  };
}

interface CafeContextType {
  // Auth state
  currentUser: UserAccount | null;
  authTenantRole: UserRole;
  isAdmin: boolean;
  isWorker: boolean;
  loginUser: (user: UserAccount) => void;
  loginWithPin: (pin: string, workerId?: string) => Promise<{ success: boolean; error?: string; user?: UserAccount }>;
  logoutUser: () => void;
  switchRole: (role: UserRole) => void;
  switchUserRole: (role: UserRole) => void;

  // Navigation
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;

  // Database
  database: CafeDatabase;
  isLoading: boolean;
  syncState: DriveSyncState;
  triggerSync: () => Promise<void>;

  // Session Notifications & Alerts
  sessionAlerts: SessionAlert[];
  dismissSessionAlert: (alertId: string) => void;
  clearAllSessionAlerts: () => void;

  // Consoles & Sessions
  consoles: ConsoleDevice[];
  sessions: GamingSession[];
  activeSessions: GamingSession[];
  addConsole: (consoleData: Omit<ConsoleDevice, 'id' | 'createdAt'>) => Promise<void>;
  updateConsole: (id: string, updates: Partial<ConsoleDevice>) => Promise<void>;
  deleteConsole: (id: string) => Promise<void>;
  startSession: (params: {
    consoleId: string;
    customerId?: string;
    customerName: string;
    customerPhone?: string;
    presetMinutes?: number | null;
    customRate?: number;
    isRateOverride?: boolean;
    playerCount?: number;
    voucherId?: string;
    creditMinutesToApply?: number;
    startTime?: string;
  }) => Promise<{ success: boolean; session?: GamingSession; customerId?: string; error?: string }>;
  stopSession: (params: {
    sessionId: string;
    discountAmount?: number;
    extraCharges?: number;
    paymentMethod: PaymentMethod;
    paidAmount: number;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => Promise<{ success: boolean; session?: GamingSession; error?: string }>;
  pauseSession: (sessionId: string) => Promise<{ success: boolean; error?: string }>;
  resumeSession: (sessionId: string) => Promise<{ success: boolean; error?: string }>;
  extendSession: (params: {
    sessionId: string;
    extraMinutes: number;
    customExtensionPrice?: number;
    paidAmount: number;
    paymentMethod: PaymentMethod;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  calculateLiveSessionBill: (session: GamingSession) => {
    elapsedMinutes: number;
    totalAmount: number;
    baseAmount: number;
  };

  // Vouchers
  vouchers: Voucher[];
  voucherUsages: VoucherUsage[];
  addVoucher: (voucherData: Omit<Voucher, 'id' | 'createdAt' | 'usedCount'>) => Promise<{ success: boolean; voucher?: Voucher; error?: string }>;
  updateVoucher: (id: string, updates: Partial<Voucher>) => Promise<void>;
  deleteVoucher: (id: string) => Promise<void>;
  startVoucher: (id: string) => Promise<{ success: boolean; error?: string }>;
  pauseVoucher: (id: string) => Promise<{ success: boolean; error?: string }>;
  resumeVoucher: (id: string) => Promise<{ success: boolean; error?: string }>;
  redeemVoucher: (params: {
    code: string;
    customerId: string;
    customerName?: string;
    customerPhone?: string;
    sessionId?: string;
    consoleCode?: string;
    hoursToUse?: number;
    durationUsedMinutes?: number;
    notes?: string;
  }) => Promise<{ success: boolean; voucher?: Voucher; discountApplied?: number; error?: string }>;
  sellVoucher: (params: {
    voucherId: string;
    customerId: string;
    customerName: string;
    customerPhone?: string;
    paymentMethod: PaymentMethod;
    paidAmount?: number;
    notes?: string;
  }) => Promise<{ success: boolean; error?: string }>;

  // Buy & Sell Management
  buySellItems: BuySellItem[];
  buySellTransactions: BuySellTransaction[];
  buyItemFromCustomer: (params: {
    name: string;
    category: BuySellCategory;
    condition: BuySellCondition;
    serialNumber?: string;
    purchasePrice: number;
    suggestedSellingPrice: number;
    customerId: string;
    customerName: string;
    customerPhone?: string;
    paymentMethod: PaymentMethod;
    notes?: string;
  }) => Promise<{ success: boolean; item?: BuySellItem; error?: string }>;
  sellItemToCustomer: (params: {
    itemId: string;
    customerId: string;
    customerName: string;
    customerPhone?: string;
    sellingPrice: number;
    paymentMethod: PaymentMethod;
    notes?: string;
  }) => Promise<{ success: boolean; transaction?: BuySellTransaction; error?: string }>;
  updateBuySellItem: (id: string, updates: Partial<BuySellItem>) => Promise<void>;
  deleteBuySellItem: (id: string) => Promise<void>;

  // Repair Tracking
  repairRecords: RepairRecord[];
  createRepairRecord: (params: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    itemName: string;
    category: RepairCategory;
    serialNumber?: string;
    problemDescription: string;
    expectedCompletionDate?: string;
    technicianName?: string;
    repairCost?: number;
    customerCharge: number;
    advancePayment?: number;
    paymentMethod?: PaymentMethod;
    notes?: string;
  }) => Promise<{ success: boolean; repair?: RepairRecord; error?: string }>;
  updateRepairRecord: (id: string, updates: Partial<RepairRecord>) => Promise<void>;
  addRepairPayment: (repairId: string, amount: number, paymentMethod: PaymentMethod, notes?: string) => Promise<{ success: boolean; error?: string }>;
  deliverRepair: (repairId: string, finalPayment?: number, paymentMethod?: PaymentMethod, notes?: string) => Promise<{ success: boolean; error?: string }>;
  deleteRepairRecord: (id: string) => Promise<void>;

  // Cafeteria Stock Movement Logs
  cafeteriaStockLogs: CafeteriaStockLog[];
  recordCafeteriaStockMovement: (params: {
    itemId: string;
    type: StockMovementType;
    quantityChange: number;
    unitPrice?: number;
    supplier?: string;
    notes?: string;
  }) => Promise<{ success: boolean; error?: string }>;

  // Customers
  customers: Customer[];
  addCustomer: (customerData: Omit<Customer, 'id' | 'createdAt' | 'totalVisits' | 'totalSpent' | 'totalOutstanding'>) => Promise<Customer>;
  updateCustomer: (id: string, updates: Partial<Customer>) => Promise<void>;
  deleteCustomer: (id: string) => Promise<void>;
  getCustomerById: (id: string) => Customer | undefined;

  // Rentals
  rentalItems: RentalItem[];
  rentalRecords: RentalRecord[];
  activeRentals: RentalRecord[];
  addRentalItem: (itemData: Omit<RentalItem, 'id' | 'rentedQuantity' | 'availableQuantity'>) => Promise<void>;
  updateRentalItem: (id: string, updates: Partial<RentalItem>) => Promise<void>;
  deleteRentalItem: (id: string) => Promise<void>;
  createRental: (params: {
    rentalItemId: string;
    rentalItemName?: string;
    customerId: string;
    customerName: string;
    customerPhone: string;
    customerAadhaar?: string;
    aadhaarCollected?: boolean;
    customerAddress?: string;
    quantity: number;
    periodType: 'hourly' | 'daily';
    durationUnits: number; // e.g. 2 hours or 1 day
    depositAmount: number;
    paymentMethod: PaymentMethod;
    paidAmount?: number;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
    // Overrides for standard rental pricing
    totalFeeOverride?: number;
    totalDepositOverride?: number;
    isStandardRental?: boolean;
    standardConsole?: 'PS4' | 'PS5';
  }) => Promise<{ success: boolean; error?: string }>;
  extendRental: (params: {
    rentalId: string;
    extraUnits: number;
    periodType: RentalPeriodType;
    paidAmount: number;
    paymentMethod: PaymentMethod;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  returnRental: (params: {
    recordId: string;
    damageDeduction: number;
    lateFee: number;
    notes?: string;
  }) => Promise<{ success: boolean; error?: string }>;

  // Cafeteria Management
  cafeteriaItems: CafeteriaItem[];
  cafeteriaOrders: CafeteriaOrder[];
  addCafeteriaItem: (itemData: Omit<CafeteriaItem, 'id' | 'createdAt'>) => Promise<void>;
  updateCafeteriaItem: (id: string, updates: Partial<CafeteriaItem>) => Promise<void>;
  deleteCafeteriaItem: (id: string) => Promise<void>;
  toggleCafeteriaItemAvailability: (id: string) => Promise<void>;
  updateCafeteriaItemStock: (id: string, newStock: number) => Promise<void>;
  createCafeteriaOrder: (params: {
    customerId: string;
    customerName: string;
    customerPhone?: string;
    items: { itemId: string; quantity: number }[];
    discountAmount?: number;
    paymentMethod: PaymentMethod;
    paidAmount?: number;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => Promise<{ success: boolean; order?: CafeteriaOrder; error?: string }>;
  updateCafeteriaOrder: (orderId: string, updates: Partial<CafeteriaOrder>) => Promise<{ success: boolean; order?: CafeteriaOrder; error?: string }>;
  cancelCafeteriaOrder: (orderId: string, reason?: string) => Promise<{ success: boolean; error?: string }>;

  // Payments
  payments: PaymentTransaction[];
  recordPayment: (params: {
    type: PaymentTransaction['type'];
    referenceId: string;
    referenceTitle: string;
    customerId: string;
    customerName: string;
    amount: number;
    method: PaymentMethod;
    status: PaymentStatus;
    splitDetails?: PaymentSplitItem[];
    totalBill?: number;
    pendingAmount?: number;
    notes?: string;
  }) => Promise<void>;
  settlePendingPayment: (params: {
    type: 'session' | 'rental' | 'cafeteria' | 'payment' | 'repair' | 'buysell';
    referenceId: string;
    transactionId?: string;
    customerId?: string;
    customerName?: string;
    amountPaid: number;
    paymentMethod: PaymentMethod;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => Promise<{ success: boolean; error?: string }>;

  // Workers (Admin only)
  workers: UserAccount[];
  addWorker: (workerData: Omit<UserAccount, 'id' | 'createdAt' | 'role'>) => Promise<void>;
  updateWorker: (id: string, updates: Partial<UserAccount>) => Promise<void>;
  deleteWorker: (id: string) => Promise<void>;

  // Settings & Danger Zone
  settings: CafeSettings;
  updateSettings: (updates: Partial<CafeSettings>) => Promise<void>;
  deleteTransaction: (transactionId: string) => Promise<{ success: boolean; error?: string }>;
  resetAllData: (confirmationText: string, options?: ResetOptions) => Promise<{ success: boolean; error?: string }>;
  reloadStarterCatalog: () => Promise<{ success: boolean; error?: string }>;
  exportBackup: () => void;
  importBackup: (file: File) => Promise<void>;

  // Admin Broadcast & Notice Board
  notices: AdminNotice[];
  addAdminNotice: (notice: {
    title: string;
    message: string;
    category?: NoticeCategory;
    priority?: NoticePriority;
    isPinned?: boolean;
  }) => Promise<{ success: boolean; notice?: AdminNotice; error?: string }>;
  deleteAdminNotice: (id: string) => Promise<{ success: boolean; error?: string }>;
  acknowledgeNotice: (id: string) => Promise<{ success: boolean; error?: string }>;
}

const CafeContext = createContext<CafeContextType | undefined>(undefined);

export const CafeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user: authUser, verifiedRole } = useAuth();
  const [database, setDatabase] = useState<CafeDatabase>(INITIAL_DATABASE);
  const databaseRef = useRef<CafeDatabase>(INITIAL_DATABASE);
  const pendingSaveCount = useRef(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [authTenantRole, setAuthTenantRole] = useState<UserRole>('admin');
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [syncState, setSyncState] = useState<DriveSyncState>(driveService.getSyncState());
  const [sessionAlerts, setSessionAlerts] = useState<SessionAlert[]>([]);
  const notifiedSessionIds = useRef<Set<string>>(new Set());

  // Keep databaseRef always aligned with state
  useEffect(() => {
    databaseRef.current = database;
  }, [database]);

  // Sync to authoritative shared server database and update state for the active businessId
  const saveAndSync = useCallback(
    async (
      newDb: CafeDatabase,
      options?: {
        action?: 'save' | 'delete' | 'reset' | 'import';
        deleteInfo?: { collection: string; id: string };
        forceOverwrite?: boolean;
      }
    ) => {
      const bId = newDb.businessId || databaseRef.current?.businessId || (authUser?.uid ? `user_${authUser.uid}` : NEXTGEN_CAFE_BUSINESS_ID);
      newDb.businessId = bId;
      const sanitized = sanitizeCafeDatabase(newDb);
      sanitized.lastModified = new Date().toISOString(); // Update timestamp for optimistic consistency
      
      databaseRef.current = sanitized;
      setDatabase(sanitized);

      try {
        pendingSaveCount.current++;
        if (driveService.getSyncState().isConnected) {
          const authoritativeDb = await driveService.saveDatabase(sanitized, bId, options);
          if (authoritativeDb) {
            const sanitizedAuth = sanitizeCafeDatabase(authoritativeDb);
            databaseRef.current = sanitizedAuth;
            setDatabase(sanitizedAuth);
          }
        }
      } catch (err) {
        console.warn('[CafeContext] saveAndSync error:', err);
      } finally {
        pendingSaveCount.current = Math.max(0, pendingSaveCount.current - 1);
      }
    },
    [authUser?.uid]
  );

  const triggerSync = useCallback(async () => {
    const bId = databaseRef.current?.businessId || (authUser?.uid ? `user_${authUser.uid}` : NEXTGEN_CAFE_BUSINESS_ID);
    
    try {
      if (!driveService.getSyncState().isConnected) {
        await driveService.checkVaultStatus();
      }
      if (driveService.getSyncState().isConnected) {
        // Pushing current local state to Drive
        await driveService.saveDatabase(databaseRef.current, bId);
        
        // Refresh local state from the latest authoritative Drive database
        const data = await driveService.loadDatabase(bId);
        if (data) {
          const sanitized = sanitizeCafeDatabase(data);
          databaseRef.current = sanitized;
          setDatabase(sanitized);
        }
      }
    } catch (err) {
      console.error('Sync failed:', err);
    } finally {
      // Force refresh syncState to update the timestamp in the UI
      setSyncState(driveService.getSyncState());
    }
  }, [authUser?.uid]);

  const dismissSessionAlert = useCallback((alertId: string) => {
    setSessionAlerts((prev) => prev.filter((a) => a.id !== alertId));
  }, []);

  const clearAllSessionAlerts = useCallback(() => {
    setSessionAlerts([]);
  }, []);

  // Background auto-expiration ticker: checks for expired gaming sessions
  useEffect(() => {
    const timer = setInterval(() => {
      const nowMs = Date.now();
      const currentSessions = databaseRef.current.sessions;
      
      // Only alert for sessions that just expired and haven't been notified yet
      const newlyExpiredSessions = currentSessions.filter(
        (s) => 
          s.status === 'active' && 
          s.scheduledEndTime && 
          new Date(s.scheduledEndTime).getTime() <= nowMs &&
          !notifiedSessionIds.current.has(s.id)
      );

      if (newlyExpiredSessions.length > 0) {
        // Trigger notification sound and add to alerts
        const newAlerts: SessionAlert[] = newlyExpiredSessions.map((s) => {
          notifiedSessionIds.current.add(s.id);
          
          const durationMinutes = s.presetDurationMinutes || Math.max(1, Math.round((new Date(s.scheduledEndTime!).getTime() - new Date(s.startTime).getTime()) / 60000));
          const ratePerMinute = s.ratePerHour / 60;
          
          // Use locked price: initialBaseAmount + extensionCharges
          const lockedPrice = (Number(s.initialBaseAmount) || Number(s.baseAmount) || 0) + Number(s.extensionCharges || 0);
          const totalAmount = lockedPrice > 0 ? lockedPrice : Math.round(durationMinutes * ratePerMinute);
          
          return {
            id: `alert_${s.id}_${nowMs}_${Math.random().toString(36).substring(2, 6)}`,
            sessionId: s.id,
            consoleCode: s.consoleCode,
            customerName: s.customerName,
            endedAt: s.scheduledEndTime || new Date().toISOString(),
            durationMinutes,
            totalAmount,
          };
        });

        setSessionAlerts((prev) => [...newAlerts, ...prev]);
        playSessionEndChime();
        
        // We do NOT call saveAndSync or change session/console status here.
        // The session remains 'active' until manually checked out.
      }
    }, 1000);

    return () => clearInterval(timer);
  }, []); // removed saveAndSync dependency as it's no longer used inside

  // Subscribe to drive sync state
  useEffect(() => {
    const unsubscribe = driveService.subscribe((state) => {
      setSyncState(state);
    });
    return unsubscribe;
  }, []);

  // Initial data load synchronized with current authenticated tenant
  useEffect(() => {
    if (!authUser) {
      setIsLoading(false);
      const cleanDefault = createIsolatedBusinessDatabase({
        businessId: 'unauthenticated',
        ownerId: 'unauthenticated',
        ownerEmail: '',
        ownerName: 'Unauthenticated',
        cafeName: 'NEXT GEN ESPORT',
      });
      databaseRef.current = cleanDefault;
      setDatabase(cleanDefault);
      return;
    }
    
    let isCancelled = false;

    async function loadTenantData() {
      setIsLoading(true);
      try {
        const businessId = `user_${authUser?.uid}`;
        driveService.setBusinessId(businessId, authUser?.uid || null);
        
        // Ensure vault status is checked before attempting to load
        const isConnected = await driveService.checkVaultStatus();

        let data: CafeDatabase | null = null;
        if (isConnected) {
          data = await driveService.loadDatabase(businessId);
        }

        if (!data || !data.businessId || data.businessId !== businessId) {
          data = createIsolatedBusinessDatabase({
            businessId: businessId,
            ownerId: authUser?.uid || 'single_owner_id',
            ownerEmail: authUser?.email || 'owner@nextgencafe.com',
            ownerName: authUser?.displayName || 'Admin Owner',
            cafeName: 'NEXT GEN ESPORT',
          });
          if (driveService.getSyncState().isConnected) {
            try {
              await driveService.saveDatabase(data, businessId);
            } catch (saveErr) {
              console.warn('[CafeContext] Initial drive save warning:', saveErr);
            }
          }
        }

        if (isCancelled) return;
        const sanitized = sanitizeCafeDatabase(data);

        // Pre-populate notified set to avoid burst alerts on refresh
        const initialNow = Date.now();
        sanitized.sessions.forEach(s => {
          if (s.status === 'active' && s.scheduledEndTime && new Date(s.scheduledEndTime).getTime() <= initialNow) {
            notifiedSessionIds.current.add(s.id);
          }
        });

        databaseRef.current = sanitized;
        setDatabase(sanitized);
      } catch (err) {
        console.error('Failed to load local database:', err);
      } finally {
        if (!isCancelled) {
          setIsLoading(false);
        }
      }
    }

    loadTenantData();

    return () => {
      isCancelled = true;
    };
  }, [authUser?.uid]);

  // Real-time voucher consumption & auto-expiration background task
  useEffect(() => {
    let lastSyncTime = Date.now();
    const timer = setInterval(async () => {
      const curDb = databaseRef.current;
      if (!curDb || !curDb.vouchers) return;

      const hasRunningVouchers = curDb.vouchers.some(v => v.status === 'running');
      if (!hasRunningVouchers) return;

      const updatedDb = CafeModulesService.updateRunningVouchers(curDb);
      if (updatedDb !== curDb) {
        // Find if any vouchers just expired
        const justExpired = updatedDb.vouchers.filter((v, idx) => 
          v.status === 'expired' && curDb.vouchers[idx].status === 'running'
        );
        
        // Update local state
        databaseRef.current = updatedDb;
        setDatabase(updatedDb);
        
        const now = Date.now();
        // Sync to drive if: 
        // 1. A voucher just expired (critical event)
        // 2. It's been more than 1 minute since last sync (persistence check)
        if (justExpired.length > 0 || (now - lastSyncTime > 60000)) {
          lastSyncTime = now;
          await saveAndSync(updatedDb);
          
          if (justExpired.length > 0) {
            // Log/Alert
            justExpired.forEach(v => {
              console.log(`[Voucher] ${v.code} has expired.`);
              // We could also add an AdminNotice here if needed
            });
          }
        }
      }
    }, 5000); // Check every 5 seconds

    return () => clearInterval(timer);
  }, [saveAndSync]);

  // Real-time synchronization between Admin and Staff terminals (SSE + polling fallback)
  useEffect(() => {
    // 1. Subscribe to real-time Server-Sent Events (SSE) from the server
    const unsubscribeSse = driveService.subscribeToDatabaseUpdates((updatedDb) => {
      // Prevent background sync from overwriting local state if we have a pending save
      if (pendingSaveCount.current > 0) return;

      const currentSig = driveService.computeDatabaseSignature(databaseRef.current);
      const newSig = driveService.computeDatabaseSignature(updatedDb);
      if (currentSig !== newSig) {
        const sanitized = sanitizeCafeDatabase(updatedDb);
        databaseRef.current = sanitized;
        setDatabase(sanitized);
      }
    });

    // 2. Periodic fallback poll for background sync & window focus
    let isPolling = false;
    const checkRemoteSync = async () => {
      if (isPolling || pendingSaveCount.current > 0 || !driveService.getSyncState().isConnected) return;
      const bId = databaseRef.current?.businessId || (authUser?.uid ? `user_${authUser.uid}` : NEXTGEN_CAFE_BUSINESS_ID);
      isPolling = true;
      try {
        const driveData = await driveService.loadDatabase(bId, { quiet: true });
        if (driveData && pendingSaveCount.current === 0) {
          const currentSig = driveService.computeDatabaseSignature(databaseRef.current);
          const driveSig = driveService.computeDatabaseSignature(driveData);
          if (currentSig !== driveSig) {
            const sanitized = sanitizeCafeDatabase(driveData);
            databaseRef.current = sanitized;
            setDatabase(sanitized);
          }
        }
      } catch (pollErr) {
        // Ignore network blips during background check
      } finally {
        isPolling = false;
      }
    };

    // Scheduled live check every 3s and on window focus
    const pollTimer = setInterval(checkRemoteSync, 3000);
    window.addEventListener('focus', checkRemoteSync);

    return () => {
      unsubscribeSse();
      window.removeEventListener('focus', checkRemoteSync);
      clearInterval(pollTimer);
    };
  }, [authUser?.uid]);

  // Keep currentUser and authTenantRole synced with verifiedRole from AuthContext
  useEffect(() => {
    if (!verifiedRole) {
      setCurrentUser(null);
      setAuthTenantRole('worker');
      return;
    }

    if (verifiedRole === 'admin') {
      const adminAcc =
        database.users.find((u) => u.role === 'admin') || {
          id: 'admin_owner',
          name: 'Administrator',
          email: authUser?.email || 'admin@nextgencafe.com',
          role: 'admin',
          pin: '756569',
          accessCode: '756569',
          createdAt: new Date().toISOString(),
          status: 'active',
        };
      setCurrentUser(adminAcc);
      setAuthTenantRole('admin');
    } else {
      let matchedWorker: UserAccount | undefined;
      try {
        const storedSession = localStorage.getItem('NEXTGEN_VERIFIED_ROLE_SESSION');
        if (storedSession) {
          const parsed = JSON.parse(storedSession);
          if (parsed?.workerId) {
            matchedWorker = database.users.find((u) => u.id === parsed.workerId && u.role === 'worker');
          }
        }
      } catch (e) {
        // ignore
      }

      if (!matchedWorker) {
        matchedWorker = database.users.find((u) => u.role === 'worker');
      }

      const workerAcc =
        matchedWorker || {
          id: 'staff_operator',
          name: 'Staff Operator',
          email: authUser?.email || 'staff@nextgencafe.com',
          role: 'worker',
          pin: '',
          accessCode: '',
          createdAt: new Date().toISOString(),
          status: 'active',
        };
      setCurrentUser(workerAcc);
      setAuthTenantRole('worker');
    }
  }, [verifiedRole, authUser, database.users]);

  // Strict role checks directly derived from verifiedRole
  const isAdmin = useMemo(
    () => verifiedRole === 'admin' && currentUser?.role === 'admin',
    [verifiedRole, currentUser]
  );
  const isWorker = useMemo(
    () => verifiedRole === 'worker' || (verifiedRole === 'admin' && currentUser?.role === 'admin'),
    [verifiedRole, currentUser]
  );

  // Background check for product expiry alerts
  useEffect(() => {
    if (!isAdmin) return;

    const checkProductExpiry = async () => {
      const curDb = databaseRef.current;
      const cafeteriaItems = curDb.cafeteriaItems;
      const existingNotices = curDb.notices || [];
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const newNotices: AdminNotice[] = [];
      let databaseChanged = false;

      for (const item of cafeteriaItems) {
        if (!item.expiryDate) continue;

        const expiryDateObj = new Date(item.expiryDate);
        const warningDate = new Date(expiryDateObj);
        warningDate.setMonth(warningDate.getMonth() - 2);
        
        const isExpired = expiryDateObj.getTime() < today.getTime();
        const isExpiringSoon = !isExpired && today.getTime() >= warningDate.getTime();

        if (isExpired || isExpiringSoon) {
          // Use a unique ID based on item and date to prevent duplicates for the same expiry event
          const noticeId = `expiry_${item.id}_${item.expiryDate.replace(/\-/g, '')}`;
          
          const alreadyNotified = existingNotices.some(n => n.id === noticeId);
          
          if (!alreadyNotified) {
            const newNotice: AdminNotice = {
              id: noticeId,
              businessId: curDb.businessId || NEXTGEN_CAFE_BUSINESS_ID,
              title: isExpired ? `🔴 Product Expired: ${item.name}` : `⚠️ Product Expiring Soon: ${item.name}`,
              message: isExpired 
                ? `${item.name} expired on ${expiryDateObj.toLocaleDateString()}. Please remove from inventory.` 
                : `${item.name} will expire on ${expiryDateObj.toLocaleDateString()} (approx. ${Math.ceil((expiryDateObj.getTime() - today.getTime()) / (24*60*60*1000))} days remaining).`,
              category: 'cafeteria',
              priority: isExpired ? 'urgent' : 'important',
              authorName: 'System Monitor',
              authorRole: 'admin',
              createdAt: new Date().toISOString(),
              isPinned: isExpired,
              acknowledgedBy: [],
            };
            newNotices.push(newNotice);
            databaseChanged = true;
          }
        }
      }

      if (databaseChanged) {
        const updatedDb = {
          ...curDb,
          notices: [...newNotices, ...(curDb.notices || [])],
        };
        await saveAndSync(updatedDb);
      }
    };

    // Run on mount and then every hour
    checkProductExpiry();
    const interval = setInterval(checkProductExpiry, 3600000);
    return () => clearInterval(interval);
  }, [isAdmin, saveAndSync]);

  const loginUser = useCallback((user: UserAccount) => {
    setCurrentUser(user);
  }, []);

  const logoutUser = useCallback(() => {
    setCurrentUser(null);
    setAuthTenantRole('worker'); // Default back to worker for safety
    setActiveTab('dashboard');
  }, []);

  const switchRole = useCallback((role: UserRole) => {
    // Workers cannot escalate to Administrator role
    if (role === 'admin' && authTenantRole === 'worker') {
      console.warn('[SECURITY] Worker account is strictly prohibited from escalating to Administrator.');
      return;
    }
    if (role === 'admin') {
      const adminAcc = database.users.find((u) => u.role === 'admin') || INITIAL_ADMIN_USER;
      if (adminAcc) setCurrentUser(adminAcc);
    } else {
      const workerAcc = database.users.find((u) => u.role === 'worker');
      if (workerAcc) {
        setCurrentUser(workerAcc);
      } else {
        console.warn('[ROLE SWITCH] No worker account found to switch to.');
      }
    }
  }, [database.users, authTenantRole]);

  const switchUserRole = useCallback((role: UserRole) => {
    switchRole(role);
  }, [switchRole]);

  const loginWithPin = useCallback(async (pin: string, workerId?: string) => {
    const trimmedPin = pin.trim();
    if (workerId) {
      const foundUser = database.users.find((u) => u.id === workerId);
      if (!foundUser) {
        return { success: false, error: 'Staff member account not found.' };
      }
      if (foundUser.role === 'admin' && authTenantRole === 'worker') {
        return { success: false, error: 'Access denied: Worker terminal cannot elevate to Administrator.' };
      }
      if (foundUser.pin === trimmedPin) {
        loginUser(foundUser);
        return { success: true, user: foundUser };
      }
      return { success: false, error: 'Incorrect PIN for selected staff member.' };
    }

    const matchedUser = database.users.find((u) => u.pin === trimmedPin);
    if (matchedUser) {
      if (matchedUser.role === 'admin' && authTenantRole === 'worker') {
        return { success: false, error: 'Access denied: Worker terminal cannot elevate to Administrator.' };
      }
      loginUser(matchedUser);
      return { success: true, user: matchedUser };
    }
    return { success: false, error: 'Invalid PIN entered.' };
  }, [database.users, loginUser, authTenantRole]);

  // Consoles
  const consoles = database.consoles;
  const sessions = database.sessions;
  const activeSessions = useMemo(() => sessions.filter((s) => s.status === 'active' || s.status === 'paused'), [sessions]);

  const addConsole = useCallback(async (consoleData: Omit<ConsoleDevice, 'id' | 'createdAt'>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const curDb = databaseRef.current;
    
    // Generate unique, collision-resistant stable ID
    let uniqueId = `c_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    while (curDb.consoles?.some((c) => c.id === uniqueId)) {
      uniqueId = `c_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    }

    const newConsole: ConsoleDevice = {
      ...consoleData,
      id: uniqueId,
      createdAt: new Date().toISOString(),
      status: consoleData.status || 'available',
      currentSessionId: null,
    };
    const notice: AdminNotice = {
      id: `notice_c_${Date.now()}`,
      businessId: curDb.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '🎮 New Gaming Station Added',
      message: `Admin added station "${newConsole.code} - ${newConsole.name}" (${newConsole.type}, ₹${newConsole.hourlyRate}/hr). Available now for player bookings.`,
      category: 'inventory_consoles',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    // Ensure uniqueId is removed from deletedConsoleIds if it was previously present
    const updatedDeletedConsoleIds = (curDb.deletedConsoleIds || []).filter((dId) => dId !== uniqueId);

    const newDb: CafeDatabase = {
      ...curDb,
      consoles: [...(curDb.consoles || []).filter((c) => c.id !== uniqueId), newConsole],
      deletedConsoleIds: updatedDeletedConsoleIds,
      notices: [notice, ...(curDb.notices || [])],
    };
    await saveAndSync(newDb);
  }, [isAdmin, currentUser, saveAndSync]);

  const updateConsole = useCallback(async (id: string, updates: Partial<ConsoleDevice>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const curDb = databaseRef.current;
    const target = curDb.consoles?.find((c) => c.id === id);
    if (!target) return;
    const notice: AdminNotice = {
      id: `notice_c_upd_${Date.now()}`,
      businessId: curDb.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '🎮 Gaming Station Updated',
      message: `Admin updated station "${target?.code || target?.name || 'Station'}". Hourly rate or specifications revised.`,
      category: 'inventory_consoles',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb: CafeDatabase = {
      ...curDb,
      consoles: (curDb.consoles || []).map((c) => (c.id === id ? { ...c, ...updates, id } : c)),
      notices: [notice, ...(curDb.notices || [])],
    };
    await saveAndSync(newDb);
  }, [isAdmin, currentUser, saveAndSync]);

  const deleteConsole = useCallback(async (id: string) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const curDb = databaseRef.current;
    const target = curDb.consoles?.find((c) => c.id === id);
    if (!target) return;
    if (target.status === 'in_use') {
      throw new Error('Cannot delete a console currently in use. Stop the session first.');
    }
    const updatedConsoles = (curDb.consoles || []).filter((c) => c.id !== id);
    // Auto-clean any active sessions referencing this console
    const updatedSessions = (curDb.sessions || []).map((s) => {
      if (s.consoleId === id && (s.status === 'active' || s.status === 'paused')) {
        return {
          ...s,
          status: 'completed' as const,
          endTime: new Date().toISOString(),
          notes: s.notes ? `${s.notes} (Auto-closed: station removed)` : '(Station removed)',
        };
      }
      return s;
    });
    const notice: AdminNotice = {
      id: `notice_c_del_${Date.now()}`,
      businessId: curDb.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '🗑️ Gaming Station Removed',
      message: `Admin removed station "${target.code} - ${target.name}" from active cafe stations.`,
      category: 'inventory_consoles',
      priority: 'important',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const updatedDeletedConsoleIds = Array.from(new Set([...(curDb.deletedConsoleIds || []), id]));
    const newDb: CafeDatabase = {
      ...curDb,
      consoles: updatedConsoles,
      sessions: updatedSessions,
      deletedConsoleIds: updatedDeletedConsoleIds,
      notices: [notice, ...(curDb.notices || [])],
    };
    await saveAndSync(newDb, { action: 'delete', deleteInfo: { collection: 'consoles', id } });
  }, [isAdmin, currentUser, saveAndSync]);

  // Calculate live session bill based on locked rate
  const calculateLiveSessionBill = useCallback((session: GamingSession) => {
    const startMs = new Date(session.startTime).getTime();
    let endMs = session.endTime ? new Date(session.endTime).getTime() : Date.now();
    
    // If scheduled end time has passed, lock live calculations to scheduled end time
    if (session.scheduledEndTime) {
      const schedMs = new Date(session.scheduledEndTime).getTime();
      if (endMs > schedMs) {
        endMs = schedMs;
      }
    }

    let elapsedMs = Math.max(0, endMs - startMs);
    if (session.totalPausedMinutes) {
      elapsedMs -= session.totalPausedMinutes * 60000;
    }
    if (session.isPaused && session.pausedAt) {
      const activePausedMs = Math.max(0, Date.now() - new Date(session.pausedAt).getTime());
      elapsedMs -= activePausedMs;
    }
    elapsedMs = Math.max(0, elapsedMs);
    let elapsedMinutes = Math.max(1, Math.ceil(elapsedMs / 60000));
    
    const totalAllottedMinutes = (session.presetDurationMinutes || 0) + (session.usedCreditMinutes || 0);
    if (totalAllottedMinutes > 0 && elapsedMinutes > totalAllottedMinutes) {
      elapsedMinutes = totalAllottedMinutes;
    }

    // Tiered station pricing calculation with fallback
    const targetConsole = databaseRef.current?.consoles?.find((c) => c.id === session.consoleId);
    const initialBase = Number(session.initialBaseAmount) || Number(session.baseAmount) || 0;
    const extensionsTotal = Number(session.extensionCharges || 0);

    let baseAmount: number;

    // Use fixed billing if duration was preset (prepaid philosophy)
    if (session.presetDurationMinutes && session.presetDurationMinutes > 0) {
      baseAmount = initialBase;
    } else {
      if (session.isRateOverridden && session.ratePerHour > 0) {
        baseAmount = Math.round((elapsedMinutes / 60) * session.ratePerHour);
      } else if (targetConsole) {
        const pricing = calculateStationPricing(targetConsole, elapsedMinutes, session.ratePerHour, session.playerCount);
        baseAmount = pricing.baseAmount;
      } else {
        const ratePerMinute = session.ratePerHour / 60;
        baseAmount = Math.round(elapsedMinutes * ratePerMinute * 100) / 100;
      }
    }

    const totalGamingCharge = baseAmount + extensionsTotal;
    const totalAmount = Math.max(0, totalGamingCharge - (session.discountAmount || 0) + (session.extraCharges || 0));

    return {
      elapsedMinutes,
      baseAmount,
      initialBaseAmount: initialBase,
      extensionCharges: extensionsTotal,
      totalAmount: Math.round(totalAmount),
    };
  }, []);

  // Start a new gaming session (Double booking prevention & customer auto-registration)
  const startSession = useCallback(async (params: {
    consoleId: string;
    customerId?: string;
    customerName: string;
    customerPhone?: string;
    presetMinutes?: number | null;
    customRate?: number;
    isRateOverride?: boolean;
    playerCount?: number;
    voucherId?: string;
    creditMinutesToApply?: number;
    startTime?: string;
  }) => {
    const curDb = databaseRef.current;
    if (!params.consoleId) {
      return { success: false, error: 'Please select an available gaming station.' };
    }

    const targetConsole = curDb.consoles.find((c) => c.id === params.consoleId);
    if (!targetConsole) {
      return { success: false, error: 'Console not found. Please choose an existing station.' };
    }

    if (targetConsole.status === 'in_use' || targetConsole.currentSessionId) {
      return { success: false, error: `Double-booking prevented: ${targetConsole.code} is already in use!` };
    }

    if (targetConsole.status === 'maintenance' || targetConsole.status === 'disabled') {
      return { success: false, error: `${targetConsole.code} is currently in ${targetConsole.status} mode.` };
    }

    const cleanName = (params.customerName || '').trim();
    const cleanPhone = (params.customerPhone || '').trim();
    const normalizedPhone = cleanPhone.replace(/[\s\-()]/g, '');

    // Existing customer lookup:
    // 1. By params.customerId if it exists in curDb.customers
    // 2. By phone matching using normalized phone
    let matchedCustomer: Customer | undefined;
    if (params.customerId) {
      matchedCustomer = curDb.customers.find((c) => c.id === params.customerId);
    }
    if (!matchedCustomer && normalizedPhone) {
      matchedCustomer = curDb.customers.find((c) => {
        const cPhone = (c.phone || '').trim().replace(/[\s\-()]/g, '');
        return Boolean(cPhone && cPhone === normalizedPhone);
      });
    }

    const sessionId = `sess_${Date.now()}`;
    const hours = (params.presetMinutes || 60) / 60;
    
    // Calculate station pricing based on strict rules:
    // - 4 fixed stations (PS5, PS4, G29, VR) use fixed charts
    // - All other stations (PC Station, Custom, etc.) use Admin-configured price
    const pricing = calculateStationPricing(targetConsole, params.presetMinutes || 60, targetConsole.hourlyRate, params.playerCount || 1);

    const isOverrideActive = Boolean(params.isRateOverride && isAdmin && params.customRate && params.customRate > 0);

    const initialBase = isOverrideActive
      ? Math.round(((params.presetMinutes || 60) / 60) * params.customRate!)
      : ((params.presetMinutes && params.presetMinutes > 0) ? pricing.baseAmount : Math.round(pricing.effectiveRatePerHour * hours));

    let lockedRate = pricing.effectiveRatePerHour;
    if ((isOverrideActive || params.customRate !== undefined) && isAdmin && params.customRate && params.customRate > 0) {
      lockedRate = params.customRate;
    }
    
    const startTime = params.startTime || new Date().toISOString();
    const creditToUse = params.creditMinutesToApply || 0;
    const totalPlayMinutes = (params.presetMinutes || 0) + creditToUse;

    const scheduledEndTime = totalPlayMinutes > 0
      ? new Date(new Date(startTime).getTime() + totalPlayMinutes * 60000).toISOString()
      : null;

    let resolvedCustomerId: string;
    let resolvedCustomerName = cleanName;
    let resolvedCustomerPhone = cleanPhone;
    let updatedCustomers: Customer[];

    if (matchedCustomer) {
      // Reuse existing customer ID — never create a duplicate
      resolvedCustomerId = matchedCustomer.id;
      resolvedCustomerName = cleanName || matchedCustomer.name;
      resolvedCustomerPhone = cleanPhone || matchedCustomer.phone;

      const updatedExisting: Customer = {
        ...matchedCustomer,
        name: resolvedCustomerName,
        phone: resolvedCustomerPhone,
        totalVisits: (matchedCustomer.totalVisits || 0) + 1,
        unusedMinutesBalance: Math.max(0, (matchedCustomer.unusedMinutesBalance || 0) - creditToUse),
        lastVisited: startTime,
      };

      updatedCustomers = curDb.customers.map((c) =>
        c.id === matchedCustomer!.id ? updatedExisting : c
      );
    } else {
      // Auto-register new customer before creating session
      resolvedCustomerId = params.customerId || `cust_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const newCustomer: Customer = {
        id: resolvedCustomerId,
        name: cleanName || 'Guest Gamer',
        phone: cleanPhone,
        createdAt: startTime,
        totalVisits: 1,
        totalSpent: 0,
        totalOutstanding: 0,
        unusedMinutesBalance: 0,
        lastVisited: startTime,
      };

      updatedCustomers = [newCustomer, ...curDb.customers];
    }

    const newSession: GamingSession = {
      id: sessionId,
      consoleId: targetConsole.id,
      consoleCode: targetConsole.code,
      customerId: resolvedCustomerId,
      customerName: resolvedCustomerName,
      customerPhone: resolvedCustomerPhone,
      startTime,
      endTime: null,
      scheduledEndTime,
      presetDurationMinutes: params.presetMinutes || null,
      durationMinutes: 0,
      playerCount: params.playerCount,
      ratePerHour: lockedRate,
      isRateOverridden: isOverrideActive ? true : undefined,
      baseAmount: initialBase,
      initialBaseAmount: initialBase,
      extensionCharges: 0,
      discountAmount: 0,
      extraCharges: 0,
      totalAmount: initialBase,
      paidAmount: 0,
      usedCreditMinutes: creditToUse,
      paymentStatus: 'pending',
      status: 'active',
      workerId: currentUser?.id || 'usr_staff',
      workerName: currentUser?.name || 'Staff Member',
      createdAt: startTime,
      voucherId: params.voucherId,
    };

    // Update console status
    const updatedConsoles = curDb.consoles.map((c) =>
      c.id === targetConsole.id
        ? { ...c, status: 'in_use' as const, currentSessionId: sessionId }
        : c
    );

    const newDb: CafeDatabase = {
      ...curDb,
      consoles: updatedConsoles,
      sessions: [newSession, ...curDb.sessions],
      customers: updatedCustomers,
    };

    await saveAndSync(newDb);
    return { success: true, session: newSession, customerId: resolvedCustomerId };
  }, [isAdmin, currentUser, saveAndSync]);

  // Stop gaming session and process billing
  const stopSession = useCallback(async (params: {
    sessionId: string;
    discountAmount?: number;
    extraCharges?: number;
    paymentMethod: PaymentMethod;
    paidAmount: number;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => {
    const curDb = databaseRef.current;
    const targetSession = curDb.sessions.find((s) => s.id === params.sessionId);
    if (!targetSession || (targetSession.status !== 'active' && targetSession.status !== 'paused')) {
      return { success: false, error: 'Session is not active or paused.' };
    }

    // Clear notification state
    notifiedSessionIds.current.delete(params.sessionId);

    const startMs = new Date(targetSession.startTime).getTime();
    let endMs = targetSession.endTime ? new Date(targetSession.endTime).getTime() : Date.now();
    if (targetSession.scheduledEndTime && endMs > new Date(targetSession.scheduledEndTime).getTime()) {
      endMs = new Date(targetSession.scheduledEndTime).getTime();
    }
    const endTime = targetSession.endTime || new Date(endMs).toISOString();

    let durationMinutes = targetSession.durationMinutes;
    if (!durationMinutes || durationMinutes === 0) {
      // Correctly account for totalPausedMinutes and active pause time
      let elapsedMs = Math.max(0, endMs - startMs);
      if (targetSession.totalPausedMinutes) {
        elapsedMs -= targetSession.totalPausedMinutes * 60000;
      }
      if (targetSession.status === 'paused' && targetSession.pausedAt) {
        const activePausedMs = Math.max(0, Date.now() - new Date(targetSession.pausedAt).getTime());
        elapsedMs -= activePausedMs;
      }
      
      durationMinutes = Math.max(1, Math.ceil(elapsedMs / 60000));
      const totalAllotted = (targetSession.presetDurationMinutes || 0) + (targetSession.usedCreditMinutes || 0);
      if (totalAllotted > 0 && durationMinutes > totalAllotted) {
        durationMinutes = totalAllotted;
      }
    }

    const targetConsole = curDb.consoles?.find((c) => c.id === targetSession.consoleId);
    const initialBase = Number(targetSession.initialBaseAmount) || Number(targetSession.baseAmount) || 0;
    const extensionChargesTotal = Number(targetSession.extensionCharges || 0);

    let baseAmount = initialBase;
    if (!targetSession.presetDurationMinutes || targetSession.presetDurationMinutes <= 0) {
      if (targetSession.isRateOverridden && targetSession.ratePerHour > 0) {
        baseAmount = Math.round((durationMinutes / 60) * targetSession.ratePerHour);
      } else if (targetConsole) {
        const pricing = calculateStationPricing(targetConsole, durationMinutes, targetSession.ratePerHour, targetSession.playerCount);
        baseAmount = pricing.baseAmount;
      } else {
        const ratePerMinute = targetSession.ratePerHour / 60;
        baseAmount = Math.round(durationMinutes * ratePerMinute);
      }
    }

    const discount = params.discountAmount || 0;
    const extra = params.extraCharges || 0;
    const totalGamingBill = baseAmount + extensionChargesTotal;
    const totalAmount = Math.max(0, totalGamingBill - discount + extra);
    const paidAmount = params.paidAmount;

    const totalPaidCumulative = Number(targetSession.paidAmount || 0) + params.paidAmount;
    let paymentStatus: PaymentStatus = 'pending';
    if (totalPaidCumulative >= totalAmount && totalAmount > 0) {
      paymentStatus = 'paid';
    } else if (totalPaidCumulative > 0 && totalPaidCumulative < totalAmount) {
      paymentStatus = 'partial';
    } else if (totalAmount === 0) {
      paymentStatus = 'paid';
    }

    // Calculate unused credit
    let unusedMinutes = 0;
    const totalPlayableTime = (targetSession.presetDurationMinutes || 0) + (targetSession.usedCreditMinutes || 0);
    if (totalPlayableTime > 0) {
      // Unused minutes = (Purchased + Credit) - Actual played
      unusedMinutes = Math.max(0, totalPlayableTime - durationMinutes);
    }

    const completedSession: GamingSession = {
      ...targetSession,
      endTime,
      durationMinutes,
      initialBaseAmount: initialBase,
      extensionCharges: extensionChargesTotal,
      baseAmount,
      discountAmount: discount,
      extraCharges: extra,
      totalAmount,
      paidAmount: totalPaidCumulative,
      paymentStatus,
      paymentMethod: params.paymentMethod,
      splitPayments: params.splitPayments,
      status: 'completed',
      creditMinutesGenerated: unusedMinutes,
      notes: params.notes || targetSession.notes,
    };

    // Record voucher usage if applicable and update voucher remaining hours
    let updatedVouchers = curDb.vouchers || [];
    let updatedVoucherUsages = curDb.voucherUsages || [];
    if (completedSession.voucherId) {
      const targetVoucher = (curDb.vouchers || []).find(
        (v) => v.id === completedSession.voucherId || v.code === completedSession.voucherId
      );

      if (targetVoucher) {
        const totalPurchased =
          targetVoucher.totalPurchasedHours ??
          (targetVoucher.durationMinutes ? Math.round((targetVoucher.durationMinutes / 60) * 10) / 10 : 0);
        const playedHours = Math.round((durationMinutes / 60) * 10) / 10;
        const currentUsedHours = targetVoucher.usedHours ?? 0;
        const newUsedHours = Math.round((currentUsedHours + playedHours) * 10) / 10;
        const newRemainingHours = Math.max(
          0,
          Math.round((totalPurchased - newUsedHours) * 10) / 10
        );
        const newUsedMinutes = (targetVoucher.usedMinutes ?? 0) + durationMinutes;
        const newRemainingMinutes = Math.max(
          0,
          (targetVoucher.durationMinutes ?? Math.round(totalPurchased * 60)) - newUsedMinutes
        );
        const newUsedCount = (targetVoucher.usedCount || 0) + 1;
        const newStatus =
          newRemainingHours <= 0 || newUsedCount >= (targetVoucher.usageLimit || 999)
            ? 'used'
            : 'active';

        const updatedVoucher: Voucher = {
          ...targetVoucher,
          totalPurchasedHours: totalPurchased,
          usedHours: newUsedHours,
          remainingHours: newRemainingHours,
          usedMinutes: newUsedMinutes,
          remainingMinutes: newRemainingMinutes,
          usedCount: newUsedCount,
          status: newStatus,
        };

        updatedVouchers = (curDb.vouchers || []).map((v) =>
          v.id === targetVoucher.id ? updatedVoucher : v
        );

        const usageEntry: VoucherUsage = {
          id: `usage_${Date.now()}`,
          voucherId: targetVoucher.id,
          voucherCode: targetVoucher.code,
          voucherName: targetVoucher.name,
          customerId: completedSession.customerId,
          customerName: completedSession.customerName,
          customerPhone: completedSession.customerPhone,
          sessionId: completedSession.id,
          consoleCode: completedSession.consoleCode,
          durationUsedMinutes: durationMinutes,
          valueDiscountApplied: completedSession.discountAmount || 0,
          usedAt: endTime,
          recordedBy: currentUser?.name || 'Staff Member',
          notes: `Gaming session on ${completedSession.consoleCode}. Used: ${playedHours} hrs. Remaining: ${newRemainingHours} hrs.`,
        };
        updatedVoucherUsages = [usageEntry, ...updatedVoucherUsages];
      }
    }
    
    // Free console
    const updatedConsoles = curDb.consoles.map((c) =>
      c.id === targetSession.consoleId
        ? { ...c, status: 'available' as const, currentSessionId: null }
        : c
    );


    // Update customer stats
    const outstandingDifference = Math.max(0, totalAmount - totalPaidCumulative);
    const updatedCustomers = curDb.customers.map((cust) =>
      cust.id === targetSession.customerId
        ? {
            ...cust,
            totalSpent: (cust.totalSpent || 0) + params.paidAmount,
            totalOutstanding: Math.max(0, (cust.totalOutstanding || 0) + outstandingDifference),
            unusedMinutesBalance: (cust.unusedMinutesBalance || 0) + unusedMinutes,
          }
        : cust
    );

    // Create payment transaction at checkout ONLY if money was collected or if there is genuine pending balance.
    // Prevents creating redundant/duplicate transactions when the session and extensions were already fully paid.
    let updatedPayments = curDb.payments;
    if (params.paidAmount > 0 || outstandingDifference > 0) {
      const newPayment: PaymentTransaction = {
        id: `pay_${Date.now()}`,
        type: 'gaming_session',
        referenceId: completedSession.id,
        referenceTitle: `${completedSession.consoleCode} Gaming (${Math.floor(durationMinutes / 60)}h ${durationMinutes % 60}m)`,
        customerId: completedSession.customerId,
        customerName: completedSession.customerName,
        amount: params.paidAmount,
        method: params.paymentMethod,
        status: paymentStatus,
        splitDetails: params.splitPayments,
        totalBill: totalAmount,
        pendingAmount: outstandingDifference,
        notes: params.notes,
        timestamp: endTime,
        recordedBy: currentUser?.name || 'Staff Member',
      };
      updatedPayments = [newPayment, ...curDb.payments];
    }

    const newDb: CafeDatabase = {
      ...curDb,
      consoles: updatedConsoles,
      sessions: curDb.sessions.map((s) => (s.id === params.sessionId ? completedSession : s)),
      customers: updatedCustomers,
      payments: updatedPayments,
      vouchers: updatedVouchers,
      voucherUsages: updatedVoucherUsages,
    };

    await saveAndSync(newDb);
    return { success: true, session: completedSession };
  }, [currentUser, saveAndSync]);

  const extendSession = useCallback(async (params: {
    sessionId: string;
    extraMinutes: number;
    customExtensionPrice?: number;
    paidAmount: number;
    paymentMethod: PaymentMethod;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => {
    const curDb = databaseRef.current;
    const session = curDb.sessions.find((s) => s.id === params.sessionId);
    if (!session) return { success: false, error: 'Session not found' };
    if (session.status !== 'active') return { success: false, error: 'Only active sessions can be extended' };

    // Clear notification state so it can alert again when new time expires
    notifiedSessionIds.current.delete(params.sessionId);

    const now = new Date().toISOString();
    const currentEndTimeMs = session.scheduledEndTime ? new Date(session.scheduledEndTime).getTime() : Date.now();
    const newScheduledEndTime = new Date(currentEndTimeMs + params.extraMinutes * 60000).toISOString();

    const targetConsole = curDb.consoles.find(c => c.id === session.consoleId);
    
    // Determine the cost of this specific extension:
    // If a custom extension price was entered by admin/user, use it as authoritative!
    // Otherwise fallback to default station pricing calculation.
    let extensionCost = 0;
    if (params.customExtensionPrice !== undefined && !isNaN(Number(params.customExtensionPrice))) {
      extensionCost = Math.max(0, Number(params.customExtensionPrice));
    } else {
      const fixedType = getFixedStationType(targetConsole?.type);
      if (fixedType && targetConsole) {
        const currentMins = session.presetDurationMinutes || 60;
        const oldPricing = calculateStationPricing(targetConsole, currentMins, session.ratePerHour, session.playerCount);
        const newPricing = calculateStationPricing(targetConsole, currentMins + params.extraMinutes, session.ratePerHour, session.playerCount);
        extensionCost = Math.max(0, newPricing.baseAmount - oldPricing.baseAmount);
      } else if (targetConsole) {
        const adminRate = Number(targetConsole.hourlyRate ?? targetConsole.price1Hour ?? session.ratePerHour) || 0;
        extensionCost = Math.round((params.extraMinutes / 60) * adminRate);
      } else {
        extensionCost = Math.round((params.extraMinutes / 60) * session.ratePerHour);
      }
    }

    // Preserve original base gaming charge separately:
    // "Base Gaming Charge ko ₹800 mat karo."
    const currentInitialBase = Number(session.initialBaseAmount) || Number(session.baseAmount) || 0;
    const currentExtensionCharges = Number(session.extensionCharges || 0);
    const newExtensionCharges = currentExtensionCharges + extensionCost;

    const baseAmount = currentInitialBase; // Base Gaming Charge stays original (e.g. ₹700)!
    const discount = Number(session.discountAmount || 0);
    const extra = Number(session.extraCharges || 0);
    // Total Session Value = baseAmount + newExtensionCharges - discount + extra
    const newTotalAmount = Math.max(0, baseAmount + newExtensionCharges - discount + extra);

    const currentPaidAmount = Number(session.paidAmount || 0);
    const addedPaid = Number(params.paidAmount) || 0;
    const newPaidAmount = currentPaidAmount + addedPaid;

    let newPaymentStatus: PaymentStatus = 'pending';
    if (newPaidAmount >= newTotalAmount && newTotalAmount > 0) {
      newPaymentStatus = 'paid';
    } else if (newPaidAmount > 0 && newPaidAmount < newTotalAmount) {
      newPaymentStatus = 'partial';
    }

    const updatedSessions = curDb.sessions.map((s) =>
      s.id === params.sessionId
        ? {
            ...s,
            scheduledEndTime: newScheduledEndTime,
            presetDurationMinutes: (s.presetDurationMinutes || 0) + params.extraMinutes,
            initialBaseAmount: currentInitialBase,
            extensionCharges: newExtensionCharges,
            baseAmount: baseAmount,
            totalAmount: newTotalAmount,
            paidAmount: newPaidAmount,
            paymentStatus: newPaymentStatus,
            notes: params.notes ? `${s.notes}\n[Extension: +${params.extraMinutes}m - Charge: ₹${extensionCost}, Paid: ₹${addedPaid}]` : s.notes,
          }
        : s
    );

    // Record separate extension payment transaction ONLY if payment was collected now
    let updatedPayments = curDb.payments;
    if (addedPaid > 0) {
      const newPayment: PaymentTransaction = {
        id: `pay_${Date.now()}`,
        type: 'gaming_session',
        referenceId: session.id,
        referenceTitle: `${session.consoleCode} Extension (+${params.extraMinutes}m)`,
        customerId: session.customerId,
        customerName: session.customerName,
        amount: addedPaid,
        method: params.paymentMethod,
        status: 'paid',
        splitDetails: params.splitPayments,
        totalBill: extensionCost > 0 ? extensionCost : addedPaid,
        pendingAmount: 0,
        notes: params.notes || `Session extension for ${params.extraMinutes} minutes (Custom charge: ₹${extensionCost})`,
        timestamp: now,
        recordedBy: currentUser?.name || 'Staff Member',
      };
      updatedPayments = [newPayment, ...curDb.payments];
    }

    // Update customer spent only if payment was actually collected now
    let updatedCustomers = curDb.customers;
    if (addedPaid > 0) {
      updatedCustomers = curDb.customers.map((c) =>
        c.id === session.customerId
          ? { ...c, totalSpent: (c.totalSpent || 0) + addedPaid }
          : c
      );
    }

    await saveAndSync({
      ...curDb,
      sessions: updatedSessions,
      payments: updatedPayments,
      customers: updatedCustomers,
    });

    return { success: true };
  }, [currentUser, saveAndSync]);

  const pauseSession = useCallback(async (sessionId: string) => {
    const curDb = databaseRef.current;
    const target = curDb.sessions.find((s) => s.id === sessionId);
    if (!target) {
      return { success: false, error: 'Session not found' };
    }
    if (target.status !== 'active') {
      return { success: false, error: 'Only active sessions can be paused' };
    }
    const nowIso = new Date().toISOString();
    const updatedSessions = curDb.sessions.map((s) => {
      if (s.id === sessionId) {
        return {
          ...s,
          status: 'paused' as const,
          isPaused: true,
          pausedAt: nowIso,
          notes: s.notes ? `${s.notes} [Paused: ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}]` : `[Paused: ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}]`,
        };
      }
      return s;
    });
    await saveAndSync({ ...curDb, sessions: updatedSessions });
    return { success: true };
  }, [saveAndSync]);

  const resumeSession = useCallback(async (sessionId: string) => {
    const curDb = databaseRef.current;
    const target = curDb.sessions.find((s) => s.id === sessionId);
    if (!target) {
      return { success: false, error: 'Session not found' };
    }
    if (target.status !== 'paused' && !target.isPaused) {
      return { success: false, error: 'Session is not paused' };
    }
    const nowMs = Date.now();
    let pauseDurationMinutes = 0;
    if (target.pausedAt) {
      // Use exact duration in minutes (including fractional part) to preserve second-level accuracy
      pauseDurationMinutes = Math.max(0, (nowMs - new Date(target.pausedAt).getTime()) / 60000);
    }
    const newTotalPausedMinutes = (target.totalPausedMinutes || 0) + pauseDurationMinutes;

    let updatedScheduledEndTime = target.scheduledEndTime;
    if (target.scheduledEndTime && pauseDurationMinutes > 0) {
      const origSchedMs = new Date(target.scheduledEndTime).getTime();
      // Add exact pause duration to the scheduled end time
      updatedScheduledEndTime = new Date(origSchedMs + pauseDurationMinutes * 60000).toISOString();
    }

    const updatedSessions = curDb.sessions.map((s) => {
      if (s.id === sessionId) {
        return {
          ...s,
          status: 'active' as const,
          isPaused: false,
          pausedAt: null,
          totalPausedMinutes: newTotalPausedMinutes,
          scheduledEndTime: updatedScheduledEndTime,
        };
      }
      return s;
    });
    await saveAndSync({ ...curDb, sessions: updatedSessions });
    return { success: true };
  }, [saveAndSync]);

  // Customers
  const customers = database.customers;

  const addCustomer = useCallback(async (customerData: Omit<Customer, 'id' | 'createdAt' | 'totalVisits' | 'totalSpent' | 'totalOutstanding'>) => {
    const curDb = databaseRef.current;
    const cleanName = customerData.name.trim();
    const cleanPhone = customerData.phone.trim();
    const normalizedPhone = cleanPhone.replace(/[\s\-()]/g, '');

    // Check if customer already exists by phone or membershipId
    const existing = curDb.customers.find((c) => {
      const cPhone = (c.phone || '').trim().replace(/[\s\-()]/g, '');
      const phoneMatch = normalizedPhone && cPhone === normalizedPhone;
      const membershipMatch = customerData.membershipId && c.membershipId && c.membershipId.trim().toLowerCase() === customerData.membershipId.trim().toLowerCase();
      return phoneMatch || membershipMatch;
    });

    if (existing) {
      // Update existing record if new info provided
      const updatedExisting: Customer = {
        ...existing,
        name: cleanName || existing.name,
        phone: cleanPhone || existing.phone,
        email: customerData.email?.trim() || existing.email,
        membershipId: customerData.membershipId?.trim() || existing.membershipId,
        aadhaarNumber: customerData.aadhaarNumber?.trim() || existing.aadhaarNumber,
        aadhaarVerified: customerData.aadhaarVerified !== undefined ? customerData.aadhaarVerified : existing.aadhaarVerified,
        address: customerData.address?.trim() || existing.address,
        notes: customerData.notes?.trim() || existing.notes,
      };

      const newDb = {
        ...curDb,
        customers: curDb.customers.map((c) => (c.id === existing.id ? updatedExisting : c)),
      };
      await saveAndSync(newDb);
      return updatedExisting;
    }

    const newCustomer: Customer = {
      ...customerData,
      name: cleanName,
      phone: cleanPhone,
      email: customerData.email?.trim() || undefined,
      membershipId: customerData.membershipId?.trim() || undefined,
      aadhaarNumber: customerData.aadhaarNumber?.trim() || undefined,
      aadhaarVerified: customerData.aadhaarVerified,
      address: customerData.address?.trim() || undefined,
      notes: customerData.notes?.trim() || undefined,
      id: `cust_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      totalVisits: 0,
      totalSpent: 0,
      totalOutstanding: 0,
    };
    const newDb = {
      ...curDb,
      customers: [newCustomer, ...curDb.customers],
    };
    await saveAndSync(newDb);
    return newCustomer;
  }, [saveAndSync]);

  const updateCustomer = useCallback(async (id: string, updates: Partial<Customer>) => {
    const curDb = databaseRef.current;
    const newDb = {
      ...curDb,
      customers: curDb.customers.map((c) => (c.id === id ? { ...c, ...updates } : c)),
    };
    await saveAndSync(newDb);
  }, [saveAndSync]);

  const deleteCustomer = useCallback(async (id: string) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const curDb = databaseRef.current;
    const newDb = {
      ...curDb,
      customers: curDb.customers.filter((c) => c.id !== id),
    };
    await saveAndSync(newDb, { action: 'delete', deleteInfo: { collection: 'customers', id } });
  }, [isAdmin, saveAndSync]);

  const getCustomerById = useCallback((id: string) => {
    return databaseRef.current.customers.find((c) => c.id === id);
  }, []);

  // Rentals
  const rentalItems = database.rentalItems;
  const rentalRecords = database.rentalRecords;
  const activeRentals = useMemo(
    () => rentalRecords.filter((r) => r.status === 'active' || r.status === 'overdue'),
    [rentalRecords]
  );

  const addRentalItem = useCallback(async (itemData: Omit<RentalItem, 'id' | 'rentedQuantity' | 'availableQuantity'>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const newItem: RentalItem = {
      ...itemData,
      id: `rent_item_${Date.now()}`,
      rentedQuantity: 0,
      availableQuantity: itemData.totalQuantity,
    };
    const notice: AdminNotice = {
      id: `notice_rent_${Date.now()}`,
      businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '🎮 Rental Hardware Added',
      message: `Admin added new gear "${newItem.name}" (${newItem.category}, ₹${newItem.hourlyRate}/hr). Total available units: ${newItem.totalQuantity}.`,
      category: 'rentals',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb = {
      ...database,
      rentalItems: [...database.rentalItems, newItem],
      notices: [notice, ...(database.notices || [])],
    };
    await saveAndSync(newDb);
  }, [database, isAdmin, currentUser, saveAndSync]);

  const updateRentalItem = useCallback(async (id: string, updates: Partial<RentalItem>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const target = database.rentalItems.find((i) => i.id === id);
    const notice: AdminNotice = {
      id: `notice_rent_upd_${Date.now()}`,
      businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '🎮 Rental Inventory Updated',
      message: `Admin updated rental gear "${target?.name || 'Hardware'}". Pricing, deposits, or stock quantities changed.`,
      category: 'rentals',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb = {
      ...database,
      rentalItems: database.rentalItems.map((item) => {
        if (item.id !== id) return item;
        const total = updates.totalQuantity !== undefined ? updates.totalQuantity : item.totalQuantity;
        const rented = item.rentedQuantity;
        const available = Math.max(0, total - rented);
        return {
          ...item,
          ...updates,
          totalQuantity: total,
          availableQuantity: available,
        };
      }),
      notices: [notice, ...(database.notices || [])],
    };
    await saveAndSync(newDb);
  }, [database, isAdmin, currentUser, saveAndSync]);

  const deleteRentalItem = useCallback(async (id: string) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const item = database.rentalItems.find((i) => i.id === id);
    if (item && item.rentedQuantity > 0) {
      throw new Error('Cannot delete rental item with active rentals. Return items first.');
    }
    const notice: AdminNotice = {
      id: `notice_rent_del_${Date.now()}`,
      businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '🗑️ Rental Hardware Removed',
      message: `Admin retired "${item?.name || 'Hardware'}" from rental inventory.`,
      category: 'rentals',
      priority: 'important',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb = {
      ...database,
      rentalItems: database.rentalItems.filter((i) => i.id !== id),
      notices: [notice, ...(database.notices || [])],
    };
    await saveAndSync(newDb, { action: 'delete', deleteInfo: { collection: 'rentalItems', id } });
  }, [database, isAdmin, currentUser, saveAndSync]);

  const createRental = useCallback(async (params: {
    rentalItemId: string;
    rentalItemName?: string;
    customerId: string;
    customerName: string;
    customerPhone: string;
    customerAadhaar?: string;
    aadhaarCollected?: boolean;
    customerAddress?: string;
    quantity: number;
    periodType: 'hourly' | 'daily';
    durationUnits: number;
    depositAmount: number;
    paymentMethod: PaymentMethod;
    paidAmount?: number;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
    totalFeeOverride?: number;
    totalDepositOverride?: number;
    isStandardRental?: boolean;
    standardConsole?: 'PS4' | 'PS5';
  }) => {
    const item = database.rentalItems.find((i) => i.id === params.rentalItemId);
    if (!item && !params.totalFeeOverride && !params.rentalItemName) {
      return { success: false, error: 'Rental item not found' };
    }
    if (item && item.availableQuantity < params.quantity) {
      return { success: false, error: `Only ${item.availableQuantity} units available.` };
    }

    const rate = params.totalFeeOverride !== undefined
      ? params.totalFeeOverride
      : (item ? (params.periodType === 'daily' ? item.dailyRate : item.hourlyRate) : 0);
    const rentalFee = params.totalFeeOverride !== undefined ? params.totalFeeOverride : (rate * params.durationUnits * params.quantity);
    const totalDeposit = params.totalDepositOverride !== undefined ? params.totalDepositOverride : (params.depositAmount * params.quantity);
    const totalToPay = rentalFee + totalDeposit;
    const paidAmount = params.paidAmount !== undefined ? params.paidAmount : totalToPay;
    const itemName = item?.name || params.rentalItemName || 'Standard Rental Package';

    let paymentStatus: PaymentStatus = 'pending';
    if (paidAmount >= totalToPay && totalToPay > 0) {
      paymentStatus = 'paid';
    } else if (paidAmount > 0 && paidAmount < totalToPay) {
      paymentStatus = 'partial';
    } else if (totalToPay === 0) {
      paymentStatus = 'paid';
    }

    const startTime = new Date().toISOString();
    const durationMs = params.periodType === 'daily'
      ? params.durationUnits * 24 * 3600 * 1000
      : params.durationUnits * 3600 * 1000;
    const expectedReturnTime = new Date(Date.now() + durationMs).toISOString();

    const recordId = `rec_rent_${Date.now()}`;
    const newRecord: RentalRecord = {
      id: recordId,
      rentalItemId: item?.id || params.rentalItemId,
      rentalItemName: itemName,
      customerId: params.customerId,
      customerName: params.customerName,
      customerPhone: params.customerPhone,
      customerAadhaar: params.customerAadhaar,
      aadhaarCollected: params.aadhaarCollected,
      customerAddress: params.customerAddress,
      quantity: params.quantity,
      periodType: params.periodType,
      durationUnits: params.durationUnits,
      rateApplied: rate,
      totalBill: totalToPay,
      pendingAmount: Math.max(0, totalToPay - paidAmount),
      startTime,
      rentedAt: startTime,
      expectedReturnTime,
      actualReturnTime: null,
      rentalFee,
      depositAmount: totalDeposit,
      depositRefunded: 0,
      damageDeduction: 0,
      lateFee: 0,
      totalPaid: paidAmount,
      paidAmount: paidAmount,
      paymentStatus,
      paymentMethod: params.paymentMethod,
      splitPayments: params.splitPayments,
      status: 'active',
      notes: params.notes,
      isStandardRental: params.isStandardRental,
      standardConsole: params.standardConsole,
      workerId: currentUser?.id || 'usr_staff',
      workerName: currentUser?.name || 'Staff Member',
      createdAt: startTime,
    };

    // Update item stock only if tracked in inventory
    const updatedItems = item
      ? database.rentalItems.map((i) =>
          i.id === item.id
            ? {
                ...i,
                availableQuantity: i.availableQuantity - params.quantity,
                rentedQuantity: i.rentedQuantity + params.quantity,
              }
            : i
        )
      : database.rentalItems;

    // Record payment transactions separately:
    // Rental Fee is rental income. Security deposit is a separate refundable balance.
    const unpaidRental = Math.max(0, totalToPay - paidAmount);
    const newPayments: PaymentTransaction[] = [];
    const rentalFeePaid = Math.min(paidAmount, rentalFee);
    const depositPaid = Math.max(0, paidAmount - rentalFee);

    if (rentalFeePaid > 0 || totalDeposit === 0) {
      newPayments.push({
        id: `pay_${Date.now()}_fee`,
        type: 'rental_fee',
        referenceId: recordId,
        referenceTitle: `${itemName} Rental Fee`,
        customerId: params.customerId,
        customerName: params.customerName,
        amount: rentalFeePaid,
        method: params.paymentMethod,
        status: rentalFeePaid >= rentalFee ? 'paid' : 'partial',
        splitDetails: params.splitPayments,
        totalBill: rentalFee,
        pendingAmount: Math.max(0, rentalFee - rentalFeePaid),
        notes: params.notes || `Rental fee for ${itemName}`,
        timestamp: startTime,
        recordedBy: currentUser?.name || 'Staff Member',
      });
    }

    if (totalDeposit > 0 && depositPaid > 0) {
      newPayments.push({
        id: `pay_${Date.now()}_dep`,
        type: 'security_deposit',
        referenceId: recordId,
        referenceTitle: `${itemName} Security Deposit`,
        customerId: params.customerId,
        customerName: params.customerName,
        amount: depositPaid,
        method: params.paymentMethod,
        status: depositPaid >= totalDeposit ? 'paid' : 'partial',
        totalBill: totalDeposit,
        pendingAmount: Math.max(0, totalDeposit - depositPaid),
        notes: `Refundable Security Deposit: ₹${totalDeposit}`,
        timestamp: startTime,
        recordedBy: currentUser?.name || 'Staff Member',
      });
    }

    const updatedPayments = [...newPayments, ...database.payments];

    // Update customer stats and identity records
    const updatedCustomers = database.customers.map((c) =>
      c.id === params.customerId
        ? {
            ...c,
            totalSpent: (c.totalSpent || 0) + paidAmount,
            totalOutstanding: (c.totalOutstanding || 0) + unpaidRental,
            totalVisits: (c.totalVisits || 0) + 1,
            lastVisited: startTime,
            aadhaarNumber: params.customerAadhaar || c.aadhaarNumber,
            aadhaarVerified: params.aadhaarCollected !== undefined ? params.aadhaarCollected : c.aadhaarVerified,
            address: params.customerAddress || c.address,
          }
        : c
    );

    const newDb: CafeDatabase = {
      ...database,
      rentalItems: updatedItems,
      rentalRecords: [newRecord, ...database.rentalRecords],
      customers: updatedCustomers,
      payments: updatedPayments,
    };

    await saveAndSync(newDb);
    return { success: true };
  }, [database, currentUser, saveAndSync]);

  const extendRental = useCallback(async (params: {
    rentalId: string;
    extraUnits: number;
    periodType: 'hourly' | 'daily';
    paidAmount: number;
    paymentMethod: PaymentMethod;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => {
    const curDb = databaseRef.current;
    const record = curDb.rentalRecords.find((r) => r.id === params.rentalId);
    if (!record) return { success: false, error: 'Rental record not found' };
    if (record.status !== 'active') return { success: false, error: 'Only active rentals can be extended' };

    const now = new Date().toISOString();
    const currentEndTimeMs = new Date(record.expectedReturnTime).getTime();
    const durationMs = params.periodType === 'daily'
      ? params.extraUnits * 24 * 3600 * 1000
      : params.extraUnits * 3600 * 1000;
    const newExpectedReturnTime = new Date(currentEndTimeMs + durationMs).toISOString();

    const extLine = `[Extension: ${params.extraUnits} ${params.periodType} - ₹${params.paidAmount}]${params.notes ? ` - ${params.notes.trim()}` : ''}`;
    const updatedRecords = curDb.rentalRecords.map((r) =>
      r.id === params.rentalId
        ? {
            ...r,
            expectedReturnTime: newExpectedReturnTime,
            durationUnits: (r.durationUnits || 0) + params.extraUnits,
            rentalFee: (r.rentalFee || 0) + params.paidAmount,
            totalBill: (r.totalBill || 0) + params.paidAmount,
            totalPaid: (r.totalPaid || 0) + params.paidAmount,
            paidAmount: (r.paidAmount || 0) + params.paidAmount,
            notes: (r.notes ? r.notes + '\n' : '') + extLine,
          }
        : r
    );

    // Record payment
    const newPayment: PaymentTransaction = {
      id: `pay_${Date.now()}`,
      type: 'rental_fee',
      referenceId: record.id,
      referenceTitle: `${record.rentalItemName} Extension (+${params.extraUnits} ${params.periodType})`,
      customerId: record.customerId,
      customerName: record.customerName,
      amount: params.paidAmount,
      method: params.paymentMethod,
      status: 'paid',
      splitDetails: params.splitPayments,
      totalBill: params.paidAmount,
      pendingAmount: 0,
      notes: params.notes || `Rental extension for ${params.extraUnits} ${params.periodType}`,
      timestamp: now,
      recordedBy: currentUser?.name || 'Staff Member',
    };

    // Update customer spent
    const updatedCustomers = curDb.customers.map((c) =>
      c.id === record.customerId
        ? { ...c, totalSpent: (c.totalSpent || 0) + params.paidAmount }
        : c
    );

    await saveAndSync({
      ...curDb,
      rentalRecords: updatedRecords,
      payments: [newPayment, ...curDb.payments],
      customers: updatedCustomers,
    });

    return { success: true };
  }, [currentUser, saveAndSync]);


  const returnRental = useCallback(async (params: {
    recordId: string;
    damageDeduction: number;
    lateFee: number;
    notes?: string;
  }) => {
    const record = database.rentalRecords.find((r) => r.id === params.recordId);
    if (!record || (record.status !== 'active' && record.status !== 'overdue')) {
      return { success: false, error: 'Active rental record not found' };
    }

    const actualReturnTime = new Date().toISOString();
    const damage = params.damageDeduction || 0;
    const lateFee = params.lateFee || 0;
    
    // Calculate total settlement
    // Customer provided upfront: record.paidAmount (which can cover rental fee + deposit).
    // Upfront deposit actually collected:
    const depositPaid = Math.min(record.depositAmount, Math.max(0, (record.paidAmount || 0) - record.rentalFee));
    const unpaidRental = Math.max(0, record.rentalFee - (record.paidAmount || 0));
    const deductions = unpaidRental + damage + lateFee;

    const refundableDeposit = Math.max(0, depositPaid - deductions);
    const stillOwedAfterDeposit = Math.max(0, deductions - depositPaid);

    const updatedRecord: RentalRecord = {
      ...record,
      actualReturnTime,
      damageDeduction: damage,
      lateFee,
      depositRefunded: refundableDeposit,
      status: 'returned',
      notes: params.notes || record.notes,
      pendingAmount: stillOwedAfterDeposit,
      paymentStatus: stillOwedAfterDeposit === 0 ? 'paid' : 'partial',
    };

    // Restore stock
    const updatedItems = database.rentalItems.map((item) =>
      item.id === record.rentalItemId
        ? {
            ...item,
            availableQuantity: item.availableQuantity + record.quantity,
            rentedQuantity: Math.max(0, item.rentedQuantity - record.quantity),
          }
        : item
    );

    // Update customer stats
    const updatedCustomers = database.customers.map((c) => {
      if (c.id === record.customerId) {
        // Decrease outstanding by the amount that was settled from the deposit
        const amountSettledFromDeposit = Math.min(record.pendingAmount, record.depositAmount - damage - lateFee);
        const newOutstanding = Math.max(0, (c.totalOutstanding || 0) - Math.max(0, amountSettledFromDeposit));
        
        return {
          ...c,
          totalOutstanding: newOutstanding,
        };
      }
      return c;
    });

    // Record refund/deduction transactions
    const newPayments = [...database.payments];
    if (refundableDeposit > 0) {
      newPayments.unshift({
        id: `pay_ref_${Date.now()}`,
        type: 'deposit_refund',
        referenceId: record.id,
        referenceTitle: `Security Deposit Refund (${record.rentalItemName})`,
        customerId: record.customerId,
        customerName: record.customerName,
        amount: -refundableDeposit, // Negative indicates refund payout
        method: record.paymentMethod,
        status: 'paid',
        notes: `Refunded ₹${refundableDeposit} after settling fees/damages.`,
        timestamp: actualReturnTime,
        recordedBy: currentUser?.name || 'Staff Member',
      });
    }

    const newDb: CafeDatabase = {
      ...database,
      rentalItems: updatedItems,
      rentalRecords: database.rentalRecords.map((r) => (r.id === params.recordId ? updatedRecord : r)),
      customers: updatedCustomers,
      payments: newPayments,
    };

    await saveAndSync(newDb);
    return { success: true };
  }, [database, currentUser, saveAndSync]);

  // Cafeteria Management
  const cafeteriaItems = database.cafeteriaItems || [];
  const cafeteriaOrders = database.cafeteriaOrders || [];

  const addCafeteriaItem = useCallback(async (itemData: Omit<CafeteriaItem, 'id' | 'createdAt'>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const newItem: CafeteriaItem = {
      ...itemData,
      id: `food_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    const notice: AdminNotice = {
      id: `notice_food_${Date.now()}`,
      businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '☕ Cafeteria Menu Updated',
      message: `Admin added "${newItem.name}" (${newItem.category}, ₹${newItem.price}) to cafe menu. Stock: ${newItem.stockQuantity}.`,
      category: 'cafeteria',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb: CafeDatabase = {
      ...database,
      cafeteriaItems: [newItem, ...(database.cafeteriaItems || [])],
      notices: [notice, ...(database.notices || [])],
    };
    await saveAndSync(newDb);
  }, [database, isAdmin, currentUser, saveAndSync]);

  const updateCafeteriaItem = useCallback(async (id: string, updates: Partial<CafeteriaItem>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const target = (database.cafeteriaItems || []).find((i) => i.id === id);
    const notice: AdminNotice = {
      id: `notice_food_upd_${Date.now()}`,
      businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '☕ Cafeteria Item Updated',
      message: `Admin updated menu item "${target?.name || 'Snack'}". Pricing or item details revised.`,
      category: 'cafeteria',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb: CafeDatabase = {
      ...database,
      cafeteriaItems: (database.cafeteriaItems || []).map((item) =>
        item.id === id ? { ...item, ...updates } : item
      ),
      notices: [notice, ...(database.notices || [])],
    };
    await saveAndSync(newDb);
  }, [database, isAdmin, currentUser, saveAndSync]);

  const deleteCafeteriaItem = useCallback(async (id: string) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const target = (database.cafeteriaItems || []).find((i) => i.id === id);
    const notice: AdminNotice = {
      id: `notice_food_del_${Date.now()}`,
      businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '🗑️ Menu Item Removed',
      message: `Admin removed "${target?.name || 'Item'}" from cafeteria offerings.`,
      category: 'cafeteria',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb: CafeDatabase = {
      ...database,
      cafeteriaItems: (database.cafeteriaItems || []).filter((item) => item.id !== id),
      notices: [notice, ...(database.notices || [])],
    };
    await saveAndSync(newDb, { action: 'delete', deleteInfo: { collection: 'cafeteriaItems', id } });
  }, [database, isAdmin, currentUser, saveAndSync]);

  const toggleCafeteriaItemAvailability = useCallback(async (id: string) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const newDb: CafeDatabase = {
      ...database,
      cafeteriaItems: (database.cafeteriaItems || []).map((item) =>
        item.id === id ? { ...item, isAvailable: !item.isAvailable } : item
      ),
    };
    await saveAndSync(newDb);
  }, [database, isAdmin, saveAndSync]);

  const updateCafeteriaItemStock = useCallback(async (id: string, newStock: number) => {
    const stock = Math.max(0, newStock);
    const newDb: CafeDatabase = {
      ...database,
      cafeteriaItems: (database.cafeteriaItems || []).map((item) =>
        item.id === id ? { ...item, stockQuantity: stock } : item
      ),
    };
    await saveAndSync(newDb);
  }, [database, saveAndSync]);

  const createCafeteriaOrder = useCallback(async (params: {
    customerId: string;
    customerName: string;
    customerPhone?: string;
    items: { itemId: string; quantity: number }[];
    discountAmount?: number;
    paymentMethod: PaymentMethod;
    paidAmount?: number;
    paymentStatus?: PaymentStatus;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => {
    if (!params.customerName || !params.customerName.trim() || params.customerId === '') {
      return { success: false, error: 'Customer selection is required. Please select or enter a customer name.' };
    }

    if (!params.items || params.items.length === 0) {
      return { success: false, error: 'Order must contain at least one item' };
    }

    const currentItems = database.cafeteriaItems || [];
    const orderItems: CafeteriaOrderItem[] = [];
    let subtotal = 0;

    // Validate stock and build order items
    for (const reqItem of params.items) {
      const food = currentItems.find((i) => i.id === reqItem.itemId);
      if (!food) {
        return { success: false, error: `Item not found in menu` };
      }
      if (!food.isAvailable) {
        return { success: false, error: `Item "${food.name}" is currently disabled/unavailable` };
      }
      if (food.stockQuantity < reqItem.quantity) {
        return {
          success: false,
          error: `Insufficient stock for "${food.name}" (Only ${food.stockQuantity} remaining)`,
        };
      }
      const itemTotal = food.price * reqItem.quantity;
      subtotal += itemTotal;
      orderItems.push({
        itemId: food.id,
        name: food.name,
        category: food.category,
        unitPrice: food.price,
        quantity: reqItem.quantity,
        totalPrice: itemTotal,
      });
    }

    const discount = Math.max(0, params.discountAmount || 0);
    const totalAmount = Math.max(0, subtotal - discount);
    const paidAmount = params.paidAmount !== undefined ? params.paidAmount : totalAmount;

    let paymentStatus: PaymentStatus =
      params.paymentStatus || (paidAmount < totalAmount ? 'pending' : 'paid');

    const orderId = `ord_${Date.now()}`;
    const timestamp = new Date().toISOString();

    const newOrder: CafeteriaOrder = {
      id: orderId,
      customerId: params.customerId,
      customerName: params.customerName,
      customerPhone: params.customerPhone,
      items: orderItems,
      subtotal,
      discountAmount: discount,
      totalAmount,
      paidAmount,
      paymentStatus,
      paymentMethod: params.paymentMethod,
      splitPayments: params.splitPayments,
      status: 'completed',
      notes: params.notes,
      workerId: currentUser?.id || 'usr_staff',
      workerName: currentUser?.name || 'Staff Member',
      createdAt: timestamp,
    };

    // Deduct stock for ordered items
    const updatedCafeteriaItems = currentItems.map((item) => {
      const ordered = params.items.find((oi) => oi.itemId === item.id);
      if (ordered) {
        return {
          ...item,
          stockQuantity: Math.max(0, item.stockQuantity - ordered.quantity),
        };
      }
      return item;
    });

    // Record payment transaction (even if 0 paid, record as pending)
    const unpaidCafeteria = Math.max(0, totalAmount - paidAmount);
    const summaryItemsText = orderItems
      .map((i) => `${i.quantity}x ${i.name}`)
      .slice(0, 3)
      .join(', ');
    const referenceTitle = `Cafeteria Bill: ${summaryItemsText}${orderItems.length > 3 ? '...' : ''}`;

    const newPayment: PaymentTransaction = {
      id: `pay_${Date.now()}`,
      type: 'cafeteria_order',
      referenceId: orderId,
      referenceTitle,
      customerId: params.customerId,
      customerName: params.customerName,
      amount: paidAmount,
      method: params.paymentMethod,
      status: paymentStatus,
      splitDetails: params.splitPayments,
      totalBill: totalAmount,
      pendingAmount: unpaidCafeteria,
      notes: params.notes || `Cafeteria Order #${orderId}`,
      timestamp,
      recordedBy: currentUser?.name || 'Staff Member',
    };
    const updatedPayments = [newPayment, ...database.payments];

    // Update customer spending stats if customer exists
    let updatedCustomers = database.customers;
    const existingCust = database.customers.find((c) => c.id === params.customerId);
    if (existingCust) {
      const unpaidOutstanding = Math.max(0, totalAmount - paidAmount);
      updatedCustomers = database.customers.map((c) =>
        c.id === params.customerId
          ? {
              ...c,
              totalSpent: (c.totalSpent || 0) + paidAmount,
              totalOutstanding: (c.totalOutstanding || 0) + unpaidOutstanding,
              lastVisited: timestamp,
            }
          : c
      );
    }

    const newDb: CafeDatabase = {
      ...database,
      cafeteriaItems: updatedCafeteriaItems,
      cafeteriaOrders: [newOrder, ...(database.cafeteriaOrders || [])],
      customers: updatedCustomers,
      payments: updatedPayments,
    };

    await saveAndSync(newDb);
    return { success: true, order: newOrder };
  }, [database, currentUser, saveAndSync]);

  const cancelCafeteriaOrder = useCallback(async (orderId: string, reason?: string) => {
    const order = (database.cafeteriaOrders || []).find((o) => o.id === orderId);
    if (!order || order.status === 'cancelled') {
      return { success: false, error: 'Order not found or already cancelled' };
    }

    // Restore stock
    const updatedCafeteriaItems = (database.cafeteriaItems || []).map((item) => {
      const orderItem = order.items.find((oi) => oi.itemId === item.id);
      if (orderItem) {
        return {
          ...item,
          stockQuantity: item.stockQuantity + orderItem.quantity,
        };
      }
      return item;
    });

    const updatedOrders = (database.cafeteriaOrders || []).map((o) =>
      o.id === orderId
        ? {
            ...o,
            status: 'cancelled' as const,
            notes: reason ? `${o.notes ? o.notes + ' - ' : ''}Cancelled: ${reason}` : o.notes,
          }
        : o
    );

    const newDb: CafeDatabase = {
      ...database,
      cafeteriaItems: updatedCafeteriaItems,
      cafeteriaOrders: updatedOrders,
    };

    await saveAndSync(newDb);
    return { success: true };
  }, [database, saveAndSync]);

  const updateCafeteriaOrder = useCallback(async (orderId: string, updates: Partial<CafeteriaOrder>) => {
    const existingOrder = (database.cafeteriaOrders || []).find((o) => o.id === orderId);
    if (!existingOrder) {
      return { success: false, error: 'Order not found' };
    }

    const updatedOrder: CafeteriaOrder = {
      ...existingOrder,
      ...updates,
    };

    // If payment status or paidAmount changed, sync with payments
    let updatedPayments = database.payments;
    if (updates.paidAmount !== undefined || updates.paymentStatus !== undefined || updates.paymentMethod !== undefined) {
      const associatedPaymentIdx = database.payments.findIndex(
        (p) => p.referenceId === orderId && p.type === 'cafeteria_order'
      );
      if (associatedPaymentIdx >= 0) {
        updatedPayments = database.payments.map((p, idx) =>
          idx === associatedPaymentIdx
            ? {
                ...p,
                amount: updates.paidAmount !== undefined ? updates.paidAmount : p.amount,
                status: updates.paymentStatus !== undefined ? updates.paymentStatus : p.status,
                method: updates.paymentMethod !== undefined ? updates.paymentMethod : p.method,
                customerName: updates.customerName !== undefined ? updates.customerName : p.customerName,
              }
            : p
        );
      }
    }

    const updatedOrders = (database.cafeteriaOrders || []).map((o) =>
      o.id === orderId ? updatedOrder : o
    );

    const newDb: CafeDatabase = {
      ...database,
      cafeteriaOrders: updatedOrders,
      payments: updatedPayments,
    };

    await saveAndSync(newDb);
    return { success: true, order: updatedOrder };
  }, [database, saveAndSync]);

  // Vouchers
  const vouchers = database.vouchers || [];
  const voucherUsages = database.voucherUsages || [];

  const addVoucher = useCallback(async (voucherData: Omit<Voucher, 'id' | 'createdAt' | 'usedCount'>) => {
    try {
      const { updatedDb, voucher } = CafeModulesService.addVoucher(voucherData, database);
      await saveAndSync(updatedDb);
      return { success: true, voucher };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create voucher' };
    }
  }, [database, saveAndSync]);

  const updateVoucher = useCallback(async (id: string, updates: Partial<Voucher>) => {
    const updatedDb = CafeModulesService.updateVoucher(id, updates, database);
    await saveAndSync(updatedDb);
  }, [database, saveAndSync]);

  const startVoucher = useCallback(async (id: string) => {
    try {
      const updatedDb = CafeModulesService.startVoucher(id, database);
      await saveAndSync(updatedDb);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to start voucher' };
    }
  }, [database, saveAndSync]);

  const pauseVoucher = useCallback(async (id: string) => {
    try {
      const updatedDb = CafeModulesService.pauseVoucher(id, database);
      await saveAndSync(updatedDb);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to pause voucher' };
    }
  }, [database, saveAndSync]);

  const resumeVoucher = useCallback(async (id: string) => {
    try {
      const updatedDb = CafeModulesService.resumeVoucher(id, database);
      await saveAndSync(updatedDb);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to resume voucher' };
    }
  }, [database, saveAndSync]);

  const deleteVoucher = useCallback(async (id: string) => {
    const curDb = databaseRef.current;
    const updatedDb = CafeModulesService.deleteVoucher(id, curDb);
    await saveAndSync(updatedDb, { action: 'delete', deleteInfo: { collection: 'vouchers', id } });
  }, [saveAndSync]);

  const redeemVoucher = useCallback(async (params: {
    code: string;
    customerId: string;
    customerName?: string;
    customerPhone?: string;
    sessionId?: string;
    consoleCode?: string;
    notes?: string;
  }) => {
    try {
      const { updatedDb, voucher, usage } = CafeModulesService.redeemVoucher(params, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true, voucher, discountApplied: usage.valueDiscountApplied };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to redeem voucher' };
    }
  }, [database, currentUser, saveAndSync]);

  const sellVoucher = useCallback(async (params: {
    voucherId: string;
    customerId: string;
    customerName: string;
    customerPhone?: string;
    paymentMethod: PaymentMethod;
    paidAmount?: number;
    notes?: string;
  }) => {
    try {
      const updatedDb = CafeModulesService.sellVoucher(params, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to sell voucher' };
    }
  }, [database, currentUser, saveAndSync]);

  // Buy & Sell Management
  const buySellItems = database.buySellItems || [];
  const buySellTransactions = database.buySellTransactions || [];

  const buyItemFromCustomer = useCallback(async (params: {
    name: string;
    category: BuySellCategory;
    condition: BuySellCondition;
    serialNumber?: string;
    purchasePrice: number;
    suggestedSellingPrice: number;
    customerId: string;
    customerName: string;
    customerPhone?: string;
    paymentMethod: PaymentMethod;
    notes?: string;
  }) => {
    try {
      const { updatedDb, item } = CafeModulesService.buyItemFromCustomer(params, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true, item };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to buy item from customer' };
    }
  }, [database, currentUser, saveAndSync]);

  const sellItemToCustomer = useCallback(async (params: {
    itemId: string;
    customerId: string;
    customerName: string;
    customerPhone?: string;
    sellingPrice: number;
    paymentMethod: PaymentMethod;
    notes?: string;
  }) => {
    try {
      const { updatedDb, transaction } = CafeModulesService.sellItemToCustomer(params, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true, transaction };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to sell item to customer' };
    }
  }, [database, currentUser, saveAndSync]);

  const updateBuySellItem = useCallback(async (id: string, updates: Partial<BuySellItem>) => {
    const updatedDb = CafeModulesService.updateBuySellItem(id, updates, database);
    await saveAndSync(updatedDb);
  }, [database, saveAndSync]);

  const deleteBuySellItem = useCallback(async (id: string) => {
    const updatedDb = CafeModulesService.deleteBuySellItem(id, database);
    await saveAndSync(updatedDb, { action: 'delete', deleteInfo: { collection: 'buySellItems', id } });
  }, [database, saveAndSync]);

  // Repair Tracking
  const repairRecords = database.repairRecords || [];

  const createRepairRecord = useCallback(async (params: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    itemName: string;
    category: RepairCategory;
    repairId?: string;
    serialNumber?: string;
    problemDescription: string;
    expectedCompletionDate?: string;
    technicianName?: string;
    repairCost?: number;
    customerCharge: number;
    advancePayment?: number;
    paymentMethod?: PaymentMethod;
    notes?: string;
  }) => {
    try {
      const { updatedDb, repair } = CafeModulesService.createRepairRecord(params, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true, repair };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create repair ticket' };
    }
  }, [database, currentUser, saveAndSync]);

  const updateRepairRecord = useCallback(async (id: string, updates: Partial<RepairRecord>) => {
    const updatedDb = CafeModulesService.updateRepairRecord(id, updates, database);
    await saveAndSync(updatedDb);
  }, [database, saveAndSync]);

  const addRepairPayment = useCallback(async (repairId: string, amount: number, paymentMethod: PaymentMethod, notes?: string) => {
    try {
      const updatedDb = CafeModulesService.addRepairPayment(repairId, amount, paymentMethod, notes, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to process repair payment' };
    }
  }, [database, currentUser, saveAndSync]);

  const deliverRepair = useCallback(async (repairId: string, finalPayment?: number, paymentMethod?: PaymentMethod, notes?: string) => {
    try {
      const updatedDb = CafeModulesService.deliverRepair(repairId, finalPayment, paymentMethod, notes, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to deliver repair' };
    }
  }, [database, currentUser, saveAndSync]);

  const deleteRepairRecord = useCallback(async (id: string) => {
    const updatedDb = CafeModulesService.deleteRepairRecord(id, database);
    await saveAndSync(updatedDb, { action: 'delete', deleteInfo: { collection: 'repairRecords', id } });
  }, [database, saveAndSync]);

  // Cafeteria Stock Movement Logs
  const cafeteriaStockLogs = database.cafeteriaStockLogs || [];

  const recordCafeteriaStockMovement = useCallback(async (params: {
    itemId: string;
    type: StockMovementType;
    quantityChange: number;
    unitPrice?: number;
    supplier?: string;
    notes?: string;
  }) => {
    try {
      const updatedDb = CafeModulesService.recordCafeteriaStockMovement(params, database, currentUser);
      await saveAndSync(updatedDb);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to record stock movement' };
    }
  }, [database, currentUser, saveAndSync]);

  // Payments
  const payments = database.payments;

  const recordPayment = useCallback(async (params: {
    type: PaymentTransaction['type'];
    referenceId: string;
    referenceTitle: string;
    customerId: string;
    customerName: string;
    amount: number;
    method: PaymentMethod;
    status: PaymentStatus;
    splitDetails?: PaymentSplitItem[];
    totalBill?: number;
    pendingAmount?: number;
    notes?: string;
  }) => {
    const newPayment: PaymentTransaction = {
      id: `pay_${Date.now()}`,
      ...params,
      timestamp: new Date().toISOString(),
      recordedBy: currentUser?.name || 'Staff Member',
    };

    const newDb: CafeDatabase = {
      ...database,
      payments: [newPayment, ...database.payments],
    };

    await saveAndSync(newDb);
  }, [database, currentUser, saveAndSync]);

  const settlePendingPayment = useCallback(async (params: {
    type: 'session' | 'rental' | 'cafeteria' | 'payment' | 'repair' | 'buysell';
    referenceId: string;
    transactionId?: string;
    customerId?: string;
    customerName?: string;
    amountPaid: number;
    paymentMethod: PaymentMethod;
    splitPayments?: PaymentSplitItem[];
    notes?: string;
  }) => {
    if (params.amountPaid <= 0) {
      return { success: false, error: 'Payment amount must be greater than 0' };
    }

    const now = new Date().toISOString();
    let updatedSessions = database.sessions;
    let updatedRentals = database.rentalRecords;
    let updatedOrders = database.cafeteriaOrders;
    let updatedRepairs = database.repairRecords || [];
    let updatedCustomers = database.customers;
    let updatedPayments = database.payments;

    let customerId = params.customerId || '';
    let customerName = params.customerName || '';
    let referenceTitle = 'Pending Payment Settlement';
    let newStatus: PaymentStatus = 'paid';
    let totalBillAmount = params.amountPaid;
    let remainingPending = 0;

    if (params.type === 'session') {
      const sess = database.sessions.find((s) => s.id === params.referenceId);
      if (sess) {
        customerId = sess.customerId;
        customerName = sess.customerName;
        referenceTitle = `${sess.consoleCode} Gaming Session Balance Paid`;
        totalBillAmount = sess.totalAmount;
        const currentPaid = sess.paidAmount || 0;
        const newPaid = currentPaid + params.amountPaid;
        newStatus = newPaid >= sess.totalAmount ? 'paid' : 'partial';
        remainingPending = Math.max(0, sess.totalAmount - newPaid);

        updatedSessions = database.sessions.map((s) =>
          s.id === params.referenceId
            ? { ...s, paidAmount: newPaid, paymentStatus: newStatus }
            : s
        );
      }
    } else if (params.type === 'rental') {
      const rent = database.rentalRecords.find((r) => r.id === params.referenceId);
      if (rent) {
        customerId = rent.customerId;
        customerName = rent.customerName;
        referenceTitle = `${rent.rentalItemName} Rental Balance Paid`;
        const totalUpfront = rent.rentalFee + rent.depositAmount + (rent.lateFee || 0) + (rent.damageDeduction || 0);
        totalBillAmount = totalUpfront;
        const currentPaid = rent.totalPaid || 0;
        const newPaid = currentPaid + params.amountPaid;
        newStatus = newPaid >= totalUpfront ? 'paid' : 'partial';
        remainingPending = Math.max(0, totalUpfront - newPaid);

        updatedRentals = database.rentalRecords.map((r) =>
          r.id === params.referenceId
            ? { ...r, totalPaid: newPaid, paymentStatus: newStatus }
            : r
        );
      }
    } else if (params.type === 'cafeteria') {
      const order = database.cafeteriaOrders.find((o) => o.id === params.referenceId);
      if (order) {
        customerId = order.customerId;
        customerName = order.customerName;
        referenceTitle = `Cafeteria Order #${order.id} Balance Paid`;
        totalBillAmount = order.totalAmount;
        const currentPaid = order.paidAmount || 0;
        const newPaid = currentPaid + params.amountPaid;
        newStatus = newPaid >= order.totalAmount ? 'paid' : 'partial';
        remainingPending = Math.max(0, order.totalAmount - newPaid);

        updatedOrders = database.cafeteriaOrders.map((o) =>
          o.id === params.referenceId
            ? { ...o, paidAmount: newPaid, paymentStatus: newStatus }
            : o
        );
      }
    } else if (params.type === 'repair') {
      const rep = (database.repairRecords || []).find((r) => r.id === params.referenceId || r.repairNumber === params.referenceId);
      if (rep) {
        customerId = rep.customerId;
        customerName = rep.customerName;
        referenceTitle = `Repair #${rep.repairNumber} Balance Paid`;
        totalBillAmount = rep.customerCharge;
        const currentPaid = rep.paidAmount || 0;
        const newPaid = currentPaid + params.amountPaid;
        newStatus = newPaid >= rep.customerCharge ? 'paid' : 'partial';
        remainingPending = Math.max(0, rep.customerCharge - newPaid);

        updatedRepairs = (database.repairRecords || []).map((r) =>
          r.id === rep.id
            ? { ...r, paidAmount: newPaid, pendingAmount: remainingPending, paymentStatus: newStatus }
            : r
        );
      }
    }

    // Update customer stats
    if (customerId) {
      updatedCustomers = database.customers.map((c) =>
        c.id === customerId
          ? {
              ...c,
              totalSpent: (c.totalSpent || 0) + params.amountPaid,
              totalOutstanding: Math.max(0, (c.totalOutstanding || 0) - params.amountPaid),
            }
          : c
      );
    }

    // Update or mark existing payment transaction(s) for this reference if exists
    if (params.referenceId || params.transactionId) {
      updatedPayments = updatedPayments.map((p) => {
        if ((params.referenceId && p.referenceId === params.referenceId) || (params.transactionId && p.id === params.transactionId)) {
          return {
            ...p,
            status: newStatus,
            pendingAmount: remainingPending,
          };
        }
        return p;
      });
    }

    // Create a new transaction recording this actual payment collection
    const settlementTx: PaymentTransaction = {
      id: `pay_${Date.now()}`,
      type: params.type === 'session' ? 'gaming_session' : params.type === 'rental' ? 'rental_fee' : params.type === 'cafeteria' ? 'cafeteria_order' : params.type === 'repair' ? 'repair_charge' : 'direct_payment',
      referenceId: params.referenceId || params.transactionId || `settle_${Date.now()}`,
      referenceTitle,
      customerId,
      customerName: customerName || 'Valued Customer',
      amount: params.amountPaid,
      method: params.paymentMethod,
      status: newStatus,
      splitDetails: params.splitPayments,
      totalBill: totalBillAmount,
      pendingAmount: remainingPending,
      notes: params.notes || `Balance paid on ${new Date().toLocaleDateString()}`,
      timestamp: now,
      recordedBy: currentUser?.name || 'Staff Member',
    };

    updatedPayments = [settlementTx, ...updatedPayments];

    const newDb: CafeDatabase = {
      ...database,
      sessions: updatedSessions,
      rentalRecords: updatedRentals,
      cafeteriaOrders: updatedOrders,
      repairRecords: updatedRepairs,
      customers: updatedCustomers,
      payments: updatedPayments,
    };

    await saveAndSync(newDb);
    return { success: true };
  }, [database, currentUser, saveAndSync]);

  const deleteTransaction = useCallback(async (transactionId: string) => {
    if (!isAdmin) return { success: false, error: 'Admin access required' };
    const curDb = databaseRef.current;
    const tx = curDb.payments.find((p) => p.id === transactionId);
    if (!tx) return { success: false, error: 'Transaction not found' };

    const updatedPayments = curDb.payments.filter((p) => p.id !== transactionId);
    
    // Update customer totalSpent/totalOutstanding if we delete a transaction
    const updatedCustomers = curDb.customers.map((c) => {
      if (c.id === tx.customerId) {
        return {
          ...c,
          totalSpent: Math.max(0, (c.totalSpent || 0) - tx.amount),
          totalOutstanding: Math.max(0, (c.totalOutstanding || 0) + (tx.pendingAmount || 0)),
        };
      }
      return c;
    });

    await saveAndSync({
      ...curDb,
      payments: updatedPayments,
      customers: updatedCustomers,
    });
    return { success: true };
  }, [isAdmin, saveAndSync]);


  // Workers
  const workers = database.users;

  const addWorker = useCallback(async (workerData: Omit<UserAccount, 'id' | 'createdAt' | 'role'>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');

    const curDb = databaseRef.current;

    // Enforce maximum 5 workers rule for NEXT GEN GAMING CAFE
    const currentWorkerAccounts = curDb.users.filter((u) => u.role === 'worker');
    if (currentWorkerAccounts.length >= MAX_WORKERS_ALLOWED) {
      throw new Error(`Maximum staff limit reached: NEXT GEN GAMING CAFE supports a maximum of ${MAX_WORKERS_ALLOWED} worker accounts.`);
    }

    const businessId = curDb.businessId || (authUser?.uid ? `user_${authUser.uid}` : NEXTGEN_CAFE_BUSINESS_ID);
    const ownerId = curDb.ownerId || curDb.settings?.ownerId || authUser?.uid || '';
    const ownerEmail = curDb.ownerEmail || curDb.settings?.ownerEmail || authUser?.email || '';

    let workerUid = `usr_worker_${Date.now()}`;

    // Authoritative server-side worker provisioning:
    // Calls /api/provision-worker with verified owner token to set custom claims { businessId, role: 'worker' }
    if (authUser && workerData.email) {
      try {
        const staffPassword = workerData.password || (workerData.pin ? `Staff#${workerData.pin}` : (workerData.accessCode ? `Staff#${workerData.accessCode}` : 'NextGen#2024'));
        const res = await tenantService.provisionWorkerOnServer({
          workerEmail: workerData.email,
          workerName: workerData.name,
          temporaryPassword: staffPassword,
          ownerUser: authUser,
        });
        
        // Capture the real Firebase UID from the server response!
        if (res.success && (res as any).data?.workerUid) {
          workerUid = (res as any).data.workerUid;
        }
      } catch (provErr) {
        console.warn('Backend worker provisioning notice:', provErr);
      }
    }

    const cleanEmail = workerData.email ? workerData.email.trim().toLowerCase() : '';

    const newWorker: UserAccount = {
      ...workerData,
      id: workerUid,
      email: cleanEmail || undefined,
      businessId,
      ownerId,
      role: 'worker',
      status: workerData.status || 'active',
      createdAt: new Date().toISOString(),
    };

    // Register worker membership in offline cache
    if (cleanEmail) {
      tenantService.registerWorkerMembership({
        workerEmail: cleanEmail,
        businessId,
        ownerId,
        ownerEmail,
        workerId: newWorker.id,
        workerName: workerData.name,
        password: workerData.password,
        pin: workerData.pin,
        phone: workerData.phone,
      });
    }

    // Untombstone this ID / Email if re-added
    const deletedUserIds = (curDb.deletedUserIds || []).filter(
      (dId) => dId !== workerUid && (!cleanEmail || dId !== cleanEmail)
    );

    const newDb: CafeDatabase = {
      ...curDb,
      deletedUserIds,
      users: [...curDb.users.filter((u) => u.id !== workerUid && (!cleanEmail || u.email?.trim().toLowerCase() !== cleanEmail)), newWorker],
    };
    await saveAndSync(newDb);
  }, [isAdmin, authUser, saveAndSync]);

  const updateWorker = useCallback(async (id: string, updates: Partial<UserAccount>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const curDb = databaseRef.current;
    
    // If updating email or password, update on backend too
    const existing = curDb.users.find((u) => u.id === id);
    if (authUser && existing && (updates.password || updates.email || updates.name)) {
      try {
        await tenantService.provisionWorkerOnServer({
          workerEmail: updates.email || existing.email,
          workerName: updates.name || existing.name,
          temporaryPassword: updates.password,
          ownerUser: authUser,
        });
      } catch (err) {
        console.warn('Backend worker update notice:', err);
      }
    }

    if (existing) {
      const mergedWorker = { ...existing, ...updates };
      tenantService.registerWorkerMembership({
        workerEmail: mergedWorker.email,
        businessId: curDb.businessId || (authUser?.uid ? `user_${authUser.uid}` : NEXTGEN_CAFE_BUSINESS_ID),
        ownerId: mergedWorker.ownerId || authUser?.uid || '',
        ownerEmail: curDb.ownerEmail || authUser?.email || '',
        workerId: mergedWorker.id,
        workerName: mergedWorker.name,
        password: mergedWorker.password,
        pin: mergedWorker.pin,
        phone: mergedWorker.phone,
      });
    }

    const newDb: CafeDatabase = {
      ...curDb,
      users: curDb.users.map((u) => (u.id === id ? { ...u, ...updates } : u)),
    };
    await saveAndSync(newDb);
  }, [isAdmin, authUser, saveAndSync]);

  const deleteWorker = useCallback(async (id: string) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    if (id === currentUser?.id) {
      throw new Error('Cannot delete your own active account.');
    }
    const curDb = databaseRef.current;
    const cleanId = String(id || '').trim();
    const workerToDelete = curDb.users.find((u) => String(u.id || '').trim() === cleanId);
    const workerEmail = workerToDelete?.email ? String(workerToDelete.email).trim().toLowerCase() : '';
    
    // Call backend unbind to clear worker custom claims on the server
    if (authUser && (workerToDelete?.id || cleanId)) {
      try {
        await tenantService.unbindWorkerOnServer({
          workerUid: workerToDelete?.id || cleanId,
          ownerUser: authUser,
        });
      } catch (unbindErr) {
        console.warn('Backend worker unbind notice:', unbindErr);
      }
    }

    if (workerEmail) {
      tenantService.removeWorkerMembership(workerEmail, curDb.businessId);
    }

    const idsToTombstone = [cleanId];
    if (workerEmail) idsToTombstone.push(workerEmail);
    if (workerToDelete?.id && workerToDelete.id.trim() !== cleanId) {
      idsToTombstone.push(workerToDelete.id.trim());
    }

    const deletedUserIds = Array.from(new Set([
      ...(Array.isArray(curDb.deletedUserIds) ? curDb.deletedUserIds : []),
      ...idsToTombstone,
    ]));

    const newDb: CafeDatabase = {
      ...curDb,
      deletedUserIds,
      users: curDb.users.filter((u) => {
        const uId = String(u.id || '').trim();
        const uEmail = String(u.email || '').trim().toLowerCase();
        if (uId === cleanId) return false;
        if (workerEmail && uEmail === workerEmail) return false;
        return true;
      }),
    };
    await saveAndSync(newDb, { action: 'delete', deleteInfo: { collection: 'users', id: cleanId } });
  }, [isAdmin, currentUser, authUser, saveAndSync]);

  // Settings
  const settings = database.settings;

  const updateSettings = useCallback(async (updates: Partial<CafeSettings>) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const settingsNotice: AdminNotice = {
      id: `notice_settings_${Date.now()}`,
      businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
      title: '⚙️ Cafe Settings & Pricing Updated',
      message: `Admin ${currentUser?.name || 'Owner'} updated cafe policies / pricing rates. Please review station rules and rates.`,
      category: 'rates_pricing',
      priority: 'important',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const newDb = {
      ...database,
      settings: { ...database.settings, ...updates },
      notices: [settingsNotice, ...(database.notices || [])],
    };
    await saveAndSync(newDb);
  }, [database, isAdmin, currentUser, saveAndSync]);

  // Danger Zone - Reset All Data
  const resetAllData = useCallback(
    async (confirmationText: string, options?: ResetOptions) => {
      if (!isAdmin) return { success: false, error: 'Unauthorized: Admin only' };
      if (confirmationText.trim() !== 'RESET') {
        return { success: false, error: 'You must type "RESET" in capital letters to confirm.' };
      }

      // By default, wipe all PC/consoles, rental gear, and cafeteria items as requested by the user
      const wipeStations = options?.wipeStations ?? true;
      const wipeRentalGear = options?.wipeRentalGear ?? true;
      const wipeCafeteriaItems = options?.wipeCafeteriaItems ?? true;

      const resetTimestamp = new Date().toISOString();

      const cleanConsoles = wipeStations
        ? []
        : database.consoles.map((c) => ({
            ...c,
            status: 'available' as const,
            currentSessionId: null,
          }));

      const cleanRentals = wipeRentalGear
        ? []
        : database.rentalItems.map((r) => ({
            ...r,
            availableQuantity: r.totalQuantity,
            rentedQuantity: 0,
          }));

      const cleanCafeteriaItems = wipeCafeteriaItems
        ? []
        : database.cafeteriaItems || [];

      const resetNotice: AdminNotice = {
        id: `notice_reset_${Date.now()}`,
        businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
        title: '⚠️ System Reset Executed by Admin',
        message: `Admin ${currentUser?.name || 'Owner'} executed a system reset. Station sessions, earnings, and records have been wiped clean.`,
        category: 'system_reset',
        priority: 'urgent',
        authorName: currentUser?.name || 'Admin Owner',
        authorRole: 'admin',
        createdAt: resetTimestamp,
        isPinned: false,
        acknowledgedBy: [],
      };

      const resetDb: CafeDatabase = {
        version: (database.version || 1) + 1,
        businessId: database.businessId || NEXTGEN_CAFE_BUSINESS_ID,
        ownerId: database.ownerId,
        ownerEmail: database.ownerEmail,
        lastModified: resetTimestamp,
        lastResetAt: resetTimestamp,
        settings: {
          ...database.settings,
          lastResetAt: resetTimestamp,
        },
        users: [], // Wipe all users/workers during reset
        consoles: cleanConsoles,
        sessions: [],
        customers: [],
        rentalItems: cleanRentals,
        rentalRecords: [],
        cafeteriaItems: cleanCafeteriaItems,
        cafeteriaOrders: [],
        cafeteriaStockLogs: [],
        vouchers: [],
        voucherUsages: [],
        buySellItems: [],
        buySellTransactions: [],
        repairRecords: [],
        payments: [],
        notices: [resetNotice, ...(database.notices || []).filter((n) => n.category !== 'system_reset')],
      };

      await saveAndSync(resetDb, { action: 'reset', forceOverwrite: true });
      return { success: true };
    },
    [database, isAdmin, currentUser, saveAndSync]
  );

  const reloadStarterCatalog = useCallback(async () => {
    if (!isAdmin) return { success: false, error: 'Unauthorized: Admin only' };
    const targetBusinessId = database.businessId || NEXTGEN_CAFE_BUSINESS_ID;
    const catalogNotice: AdminNotice = {
      id: `notice_catalog_${Date.now()}`,
      businessId: targetBusinessId,
      title: '🎮 Default Stations & Catalog Reloaded',
      message: `Admin ${currentUser?.name || 'Owner'} reloaded the official default station & inventory catalog.`,
      category: 'inventory_consoles',
      priority: 'info',
      authorName: currentUser?.name || 'Admin Owner',
      authorRole: 'admin',
      createdAt: new Date().toISOString(),
      isPinned: false,
      acknowledgedBy: [],
    };
    const restoredDb: CafeDatabase = {
      ...database,
      consoles: INITIAL_DATABASE.consoles.map((c) => ({ ...c, businessId: targetBusinessId })),
      rentalItems: INITIAL_DATABASE.rentalItems.map((r) => ({ ...r, businessId: targetBusinessId })),
      cafeteriaItems: (INITIAL_DATABASE.cafeteriaItems || []).map((i) => ({ ...i, businessId: targetBusinessId })),
      notices: [catalogNotice, ...(database.notices || [])],
      lastModified: new Date().toISOString(),
    };
    await saveAndSync(restoredDb, { action: 'reset', forceOverwrite: true });
    return { success: true };
  }, [database, isAdmin, currentUser, saveAndSync]);

  // Admin Broadcast & Notice Board methods
  const notices = useMemo(() => database.notices || [], [database.notices]);

  const addAdminNotice = useCallback(
    async (noticeData: {
      title: string;
      message: string;
      category?: NoticeCategory;
      priority?: NoticePriority;
      isPinned?: boolean;
    }) => {
      if (!isAdmin) return { success: false, error: 'Unauthorized: Admin only' };
      if (!noticeData.title.trim() || !noticeData.message.trim()) {
        return { success: false, error: 'Title and message are required.' };
      }

      const newNotice: AdminNotice = {
        id: `notice_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        businessId: databaseRef.current.businessId || NEXTGEN_CAFE_BUSINESS_ID,
        title: noticeData.title.trim(),
        message: noticeData.message.trim(),
        category: noticeData.category || 'general',
        priority: noticeData.priority || 'info',
        authorName: currentUser?.name || 'Administrator',
        authorRole: 'admin',
        createdAt: new Date().toISOString(),
        isPinned: noticeData.isPinned ?? false,
        acknowledgedBy: [],
      };

      const newDb: CafeDatabase = {
        ...databaseRef.current,
        notices: [newNotice, ...(databaseRef.current.notices || [])],
      };

      await saveAndSync(newDb);
      return { success: true, notice: newNotice };
    },
    [isAdmin, currentUser, saveAndSync]
  );

  const deleteAdminNotice = useCallback(
    async (id: string) => {
      if (!isAdmin) return { success: false, error: 'Unauthorized: Admin only' };
      const newDb: CafeDatabase = {
        ...databaseRef.current,
        notices: (databaseRef.current.notices || []).filter((n) => n.id !== id),
      };
      await saveAndSync(newDb, { action: 'delete', deleteInfo: { collection: 'notices', id } });
      return { success: true };
    },
    [isAdmin, saveAndSync]
  );

  const acknowledgeNotice = useCallback(
    async (id: string) => {
      const currentUserId = currentUser?.id || 'staff';
      const updatedNotices = (databaseRef.current.notices || []).map((n) => {
        if (n.id === id) {
          const currentAcks = n.acknowledgedBy || [];
          if (!currentAcks.includes(currentUserId)) {
            return {
              ...n,
              acknowledgedBy: [...currentAcks, currentUserId],
            };
          }
        }
        return n;
      });

      const newDb: CafeDatabase = {
        ...databaseRef.current,
        notices: updatedNotices,
      };

      await saveAndSync(newDb);
      return { success: true };
    },
    [currentUser, saveAndSync]
  );

  const exportBackup = useCallback(() => {
    driveService.exportBackupXlsx(database);
  }, [database]);

  const importBackup = useCallback(async (file: File) => {
    if (!isAdmin) throw new Error('Unauthorized: Admin only');
    const imported = await driveService.importBackupXlsx(file);
    await saveAndSync(imported, { action: 'import', forceOverwrite: true });
  }, [isAdmin, saveAndSync]);

  const value = {
    currentUser,
    authTenantRole,
    isAdmin,
    isWorker,
    loginUser,
    loginWithPin,
    logoutUser,
    switchRole,
    switchUserRole,
    activeTab,
    setActiveTab,
    database,
    isLoading,
    syncState,
    triggerSync,
    sessionAlerts,
    dismissSessionAlert,
    clearAllSessionAlerts,
    consoles,
    sessions,
    activeSessions,
    addConsole,
    updateConsole,
    deleteConsole,
    startSession,
    stopSession,
    pauseSession,
    resumeSession,
    extendSession,
    calculateLiveSessionBill,
    // Vouchers
    vouchers,
    voucherUsages,
    addVoucher,
    updateVoucher,
    deleteVoucher,
    startVoucher,
    pauseVoucher,
    resumeVoucher,
    redeemVoucher,
    sellVoucher,
    // Buy & Sell
    buySellItems,
    buySellTransactions,
    buyItemFromCustomer,
    sellItemToCustomer,
    updateBuySellItem,
    deleteBuySellItem,
    // Repairs
    repairRecords,
    createRepairRecord,
    updateRepairRecord,
    addRepairPayment,
    deliverRepair,
    deleteRepairRecord,
    // Cafeteria Stock Movements
    cafeteriaStockLogs,
    recordCafeteriaStockMovement,
    customers,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    getCustomerById,
    rentalItems,
    rentalRecords,
    activeRentals,
    addRentalItem,
    updateRentalItem,
    deleteRentalItem,
    createRental,
    extendRental,
    returnRental,
    cafeteriaItems,
    cafeteriaOrders,
    addCafeteriaItem,
    updateCafeteriaItem,
    deleteCafeteriaItem,
    toggleCafeteriaItemAvailability,
    updateCafeteriaItemStock,
    createCafeteriaOrder,
    updateCafeteriaOrder,
    cancelCafeteriaOrder,
    payments,
    recordPayment,
    settlePendingPayment,
    workers,
    addWorker,
    updateWorker,
    deleteWorker,
    settings,
    updateSettings,
    deleteTransaction,
    resetAllData,
    reloadStarterCatalog,
    exportBackup,
    importBackup,
    notices,
    addAdminNotice,
    deleteAdminNotice,
    acknowledgeNotice,
  };

  return <CafeContext.Provider value={value}>{children}</CafeContext.Provider>;
};

export const useCafe = () => {
  const context = useContext(CafeContext);
  if (!context) {
    throw new Error('useCafe must be used within a CafeProvider');
  }
  return context;
};
