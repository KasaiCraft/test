import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  User,
  auth,
  initializeApp,
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  persistencePromise,
} from '../services/firebase';
import { NEXTGEN_CAFE_BUSINESS_ID, UserAccount, CafeSettings } from '../types';
import { driveService } from '../services/googleDriveService';
import { tenantService } from '../services/tenantService';

// Explicit re-exports of Firebase Auth APIs for direct access
export {
  initializeApp,
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  auth,
};
export type { User };

export const ROLE_SESSION_KEY = 'NEXTGEN_VERIFIED_ROLE_SESSION';

export interface RoleSessionData {
  role: 'admin' | 'worker';
  email: string;
  uid?: string;
  workerId?: string;
  workerName?: string;
  verifiedAt: number;
}

export interface AuthContextType {
  user: User | null;
  loading: boolean;
  verifiedRole: 'admin' | 'worker' | null;
  verifyRoleCode: (
    role: 'admin' | 'worker',
    code: string,
    settings?: CafeSettings,
    users?: UserAccount[]
  ) => { success: boolean; error?: string };
  switchRoleToStaff: () => void;
  clearRoleVerification: () => void;
  login: (email: string, password: string) => Promise<User>;
  signup: (email: string, password: string) => Promise<User>;
  loginWithGoogle: () => Promise<User>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  formatAuthError: (error: any) => string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function formatAuthError(error: any): string {
  if (!error) return 'An unknown error occurred.';
  const code = error.code || '';
  switch (code) {
    case 'auth/user-not-found':
      return 'No account found with this email. Please check your email or click "Create Account".';
    case 'auth/wrong-password':
      return 'Incorrect password. Please verify your password or use "Reset Password".';
    case 'auth/invalid-credential':
    case 'auth/invalid-login-credentials':
      const projectId = auth?.app?.options?.projectId || 'unknown';
      return `Invalid email or password. (Project: ${projectId}). If you signed up using Google, please use the "Continue with Google" button. If this is a new account, please click "Create Account".`;
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Please sign in, use Google Account (OAuth), or reset your password.';
    case 'auth/weak-password':
      return 'Password is too weak. Please use at least 6 characters.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address format.';
    case 'auth/network-request-failed':
      return 'Network connection error. Please verify your internet connection.';
    case 'auth/too-many-requests':
      return 'Access to this account has been temporarily disabled due to many failed attempts. Please try again later.';
    case 'auth/user-disabled':
      return 'This user account has been disabled by an administrator.';
    case 'auth/operation-not-allowed':
      return 'Email and password authentication is not enabled in Firebase Authentication.';
    case 'auth/popup-closed-by-user':
      return 'The Google sign-in window was closed before completing. Please try again.';
    case 'auth/popup-blocked':
      return 'Google sign-in popup was blocked by your browser. Please allow popups for this site.';
    case 'auth/cancelled-popup-request':
      return 'The sign-in request was cancelled. Please try again.';
    case 'auth/unauthorized-domain':
      const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'this domain';
      return `This domain ("${currentHost}") is not authorized for Firebase Google Sign-In. In Firebase Console > Authentication > Settings > Authorized domains, add "${currentHost}" and "asia-southeast1.run.app", or sign in with your email and password below.`;
    default:
      return error.message?.replace(/^Firebase:\s*/i, '') || `Authentication failed (${code || 'unknown'}). Please try again.`;
  }
}

export const FIXED_ADMIN_CODE = '756569';

const resolveStaffAccounts = (users?: UserAccount[]): UserAccount[] => {
  const staffMap = new Map<string, UserAccount>();

  // 1. Gather workers from provided users array
  if (Array.isArray(users)) {
    users.forEach((u) => {
      if (u && u.role === 'worker') {
        const key = u.id || u.email?.trim().toLowerCase();
        if (key) staffMap.set(key, u);
      }
    });
  }

  // 2. Gather from tenantService staff accounts (authoritative cache & registry)
  try {
    const cachedStaff = tenantService.getStaffAccounts();
    if (Array.isArray(cachedStaff)) {
      cachedStaff.forEach((w) => {
        if (w && w.role === 'worker') {
          const key = w.id || w.email?.trim().toLowerCase();
          if (key && !staffMap.has(key)) {
            staffMap.set(key, w);
          } else if (key && staffMap.has(key)) {
            const existing = staffMap.get(key)!;
            staffMap.set(key, { ...w, ...existing });
          }
        }
      });
    }
  } catch (e) {
    // ignore
  }

  // 3. Fallback check from persistent browser database keys
  try {
    if (typeof localStorage !== 'undefined') {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && (key.startsWith('NEXTGEN_CAFE_DB') || key === 'NEXTGEN_CAFE_DB_V1')) {
          const raw = localStorage.getItem(key);
          if (raw) {
            const parsed = JSON.parse(raw);
            if (parsed && Array.isArray(parsed.users)) {
              parsed.users.forEach((u: any) => {
                if (u && u.role === 'worker') {
                  const uKey = u.id || u.email?.trim().toLowerCase();
                  if (uKey && !staffMap.has(uKey)) {
                    staffMap.set(uKey, u);
                  }
                }
              });
            }
          }
        }
      }
    }
  } catch (e) {
    // ignore
  }

  return Array.from(staffMap.values());
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [verifiedRole, setVerifiedRole] = useState<'admin' | 'worker' | null>(null);
  const [centralUsers, setCentralUsers] = useState<UserAccount[]>([]);

  useEffect(() => {
    if (!user) {
      driveService.resetState();
      return;
    }

    const userBizId = `user_${user.uid}`;
    driveService.setBusinessId(userBizId, user.uid);
    driveService.initRealtimeStream(userBizId, user.uid);
    driveService.checkVaultStatus().catch(() => {});
    
    // Preload shared users from authoritative server database
    user.getIdToken().then(token => {
      fetch(`/api/cafe-database?businessId=${encodeURIComponent(userBizId)}&uid=${encodeURIComponent(user.uid)}`, { 
        cache: 'no-store',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
        .then((res) => res.json())
        .then((json) => {
          if (json.success && json.data && Array.isArray(json.data.users)) {
            setCentralUsers(json.data.users);
          }
        })
        .catch(() => {});
    });

    // Listen to real-time updates from server SSE stream
    const unsubscribeDb = driveService.subscribeToDatabaseUpdates((db) => {
      if (db && Array.isArray(db.users)) {
        setCentralUsers(db.users);
      }
    });

    return () => {
      unsubscribeDb();
      driveService.closeRealtimeStream();
    };
  }, [user]);

  // Listen to authoritative Firebase Auth state
  useEffect(() => {
    console.log('[AuthContext] Initializing onAuthStateChanged listener...');

    // Safety fallback: ensure initial loading resolves within 3s even if network is throttled
    const safetyTimer = setTimeout(() => {
      setLoading(false);
    }, 3000);

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      clearTimeout(safetyTimer);
      try {
        console.log('[AuthContext] Auth state changed. User:', firebaseUser?.email || 'null');
        setUser(firebaseUser);
        
        if (firebaseUser) {
          // Check if there is an active verified role session for this authenticated email
          try {
            const raw = localStorage.getItem(ROLE_SESSION_KEY);
            if (raw) {
              const session: RoleSessionData = JSON.parse(raw);
              if (
                session &&
                (session.role === 'admin' || session.role === 'worker') &&
                session.email?.toLowerCase() === firebaseUser.email?.toLowerCase()
              ) {
                console.log('[AuthContext] Restoring verified role from session:', session.role);
                setVerifiedRole(session.role);
              } else {
                setVerifiedRole(null);
              }
            } else {
              setVerifiedRole(null);
            }
          } catch (e) {
            console.warn('[AuthContext] Session restore error:', e);
            setVerifiedRole(null);
          }
        } else {
          setVerifiedRole(null);
          localStorage.removeItem(ROLE_SESSION_KEY);
          driveService.resetState();
        }
      } catch (err) {
        console.error('[AuthContext] Fatal error in onAuthStateChanged:', err);
      } finally {
        console.log('[AuthContext] Setting loading to false');
        setLoading(false);
      }
    });

    return () => {
      clearTimeout(safetyTimer);
      unsubscribe();
    };
  }, []);

  // Real email/password login via Firebase
  const login = useCallback(async (email: string, password: string): Promise<User> => {
    await persistencePromise;
    const normalizedEmail = (email || '').trim().toLowerCase();
    
    console.log('[AuthContext] Login attempt:', {
      normalizedEmail,
      passwordLength: (password || '').length,
      projectId: auth.app.options.projectId,
      authDomain: auth.app.options.authDomain,
      appId: auth.app.options.appId,
    });
    try {
      console.log('[AuthContext] Invoking signInWithEmailAndPassword...');
      const cred = await signInWithEmailAndPassword(auth, normalizedEmail, password);
      console.log('[AuthContext] signInWithEmailAndPassword success:', cred.user.email);
      // Update local state immediately for fast navigation
      setUser(cred.user);
      return cred.user;
    } catch (err: any) {
      console.error('[AuthContext] signInWithEmailAndPassword credential rejection:', {
        code: err?.code,
        message: err?.message,
        email: normalizedEmail,
      });

      // If credential rejection occurs, attempt server-side credential sync (for synchronized Firebase Auth accounts)
      const code = err?.code || '';
      if (code === 'auth/invalid-credential' || code === 'auth/invalid-login-credentials') {
        try {
          const syncRes = await fetch('/api/auth-credential-sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: normalizedEmail, password }),
          });
          if (syncRes.ok) {
            const syncJson = await syncRes.json();
            if (syncJson?.success && syncJson?.data?.synced) {
              console.log('[AuthContext] Credential sync succeeded on server, retrying signInWithEmailAndPassword...');
              const retryCred = await signInWithEmailAndPassword(auth, normalizedEmail, password);
              setUser(retryCred.user);
              return retryCred.user;
            }
          }
        } catch (syncErr) {
          console.warn('[AuthContext] Server credential sync notice:', syncErr);
        }
      }

      throw err;
    }
  }, []);

  // Real email/password registration via Firebase
  const signup = useCallback(async (email: string, password: string): Promise<User> => {
    await persistencePromise;
    const normalizedEmail = (email || '').trim().toLowerCase();
    console.log('[AuthContext] Signup attempt:', {
      normalizedEmail,
      passwordLength: (password || '').length,
      projectId: auth.app.options.projectId,
      appId: auth.app.options.appId,
      authInstanceName: auth.app.name,
    });
    try {
      const cred = await createUserWithEmailAndPassword(auth, normalizedEmail, password);
      console.log('[AuthContext] createUserWithEmailAndPassword success:', cred.user.email);
      // Update local state immediately
      setUser(cred.user);
      return cred.user;
    } catch (err: any) {
      console.error('[AuthContext] createUserWithEmailAndPassword validation rejection:', {
        code: err?.code,
        message: err?.message,
        email: normalizedEmail,
      });
      throw err;
    }
  }, []);

  // Real Google sign-in via Firebase popup (maintains separate provider identity)
  const loginWithGoogle = useCallback(async (): Promise<User> => {
    console.log('[AuthContext] loginWithGoogle called. Project:', auth.app.options.projectId);
    await persistencePromise;
    try {
      const { GoogleAuthProvider, signInWithPopup } = await import('firebase/auth');
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      
      console.log('[AuthContext] Opening Google Sign-In popup...');
      const cred = await signInWithPopup(auth, provider);
      console.log('[AuthContext] loginWithGoogle success:', cred.user.email);
      // Update local state immediately
      setUser(cred.user);
      return cred.user;
    } catch (err: any) {
      console.error('[AuthContext] loginWithGoogle error:', {
        code: err?.code,
        message: err?.message,
        domain: window.location.hostname
      });
      throw err;
    }
  }, []);

  // Send password reset email
  const resetPassword = useCallback(async (email: string): Promise<void> => {
    await persistencePromise;
    const normalizedEmail = (email || '').trim().toLowerCase();
    await sendPasswordResetEmail(auth, normalizedEmail);
  }, []);

  // Clear role session (requires fresh code verification)
  const clearRoleVerification = useCallback(() => {
    localStorage.removeItem(ROLE_SESSION_KEY);
    setVerifiedRole(null);
  }, []);

  // Full Firebase sign out + role session wipe + Drive state wipe
  const logout = useCallback(async () => {
    clearRoleVerification();
    driveService.resetState();
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.clear();
      }
    } catch {}
    await persistencePromise;
    await signOut(auth);
    setUser(null);
  }, [clearRoleVerification]);

  // If Admin wants to switch to Staff perspective
  const switchRoleToStaff = useCallback(() => {
    if (!user) return;
    const session: RoleSessionData = {
      role: 'worker',
      email: user.email || '',
      uid: user.uid,
      verifiedAt: Date.now(),
    };
    localStorage.setItem(ROLE_SESSION_KEY, JSON.stringify(session));
    setVerifiedRole('worker');
  }, [user]);

  // Strict Role Code Verification with Cross-Role Prevention
  const verifyRoleCode = useCallback(
    (
      role: 'admin' | 'worker',
      inputCode: string,
      settings?: CafeSettings,
      users?: UserAccount[]
    ): { success: boolean; error?: string } => {
      const code = (inputCode || '').trim();
      if (!code) {
        return {
          success: false,
          error: `Please enter the ${role === 'admin' ? 'Admin' : 'Staff'} Access Code.`,
        };
      }

      const configuredAdminCode = (settings?.adminAccessCode || FIXED_ADMIN_CODE).trim();

      // Aggregate all potential workers from both local database and preloaded central data
      const localWorkers = resolveStaffAccounts(users || []);
      const preloadedWorkers = resolveStaffAccounts(centralUsers || []);
      
      // Deduplicate by ID to prevent overlap
      const workersMap = new Map<string, UserAccount>();
      localWorkers.forEach(w => workersMap.set(w.id, w));
      preloadedWorkers.forEach(w => {
        if (!workersMap.has(w.id)) workersMap.set(w.id, w);
      });

      const activeStaff = Array.from(workersMap.values()).filter((w) => w.status !== 'inactive');
      
      // Also aggregate admin pins
      const adminUsers = [
        ...(users || []),
        ...(centralUsers || [])
      ].filter((u) => u.role === 'admin');
      
      const adminPins = Array.from(new Set(adminUsers
        .flatMap((u) => [u.accessCode, u.pin].filter(Boolean) as string[])
        .map((c) => c.trim())));

      const staffCodes = activeStaff
        .flatMap((w) => [w.accessCode, w.pin].filter(Boolean) as string[])
        .map((c) => c.trim());

      if (role === 'admin') {
        // Check if user entered a staff code in the admin field
        if (staffCodes.includes(code)) {
          return {
            success: false,
            error: 'Access Denied: Staff code cannot unlock Administrator Panel. Please enter the valid Admin Code.',
          };
        }

        // Verify admin code strictly: 756569 or configured Admin Code or Admin Pin
        const isAdminMatch =
          code === FIXED_ADMIN_CODE ||
          code === configuredAdminCode ||
          adminPins.includes(code);

        if (!isAdminMatch) {
          return {
            success: false,
            error: 'Invalid Admin Code. Please check your administrator security code and try again.',
          };
        }

        // Successfully verified as Admin
        setVerifiedRole('admin');
        const session: RoleSessionData = {
          role: 'admin',
          email: user?.email || '',
          uid: user?.uid,
          verifiedAt: Date.now(),
        };
        localStorage.setItem(ROLE_SESSION_KEY, JSON.stringify(session));
        return { success: true };
      } else {
        // role === 'worker' (Staff Panel)
        // Check if user entered admin code in the staff field
        const isAdminMatch =
          code === FIXED_ADMIN_CODE ||
          code === configuredAdminCode ||
          adminPins.includes(code);

        if (isAdminMatch) {
          return {
            success: false,
            error: 'Access Denied: Admin code cannot be used to unlock the Staff Panel. Please enter your valid Staff Code.',
          };
        }

        // Check if any staff member exists in Staff Management
        if (activeStaff.length === 0) {
          return {
            success: false,
            error: 'No active staff accounts configured. Please ask the Administrator to add staff in Staff Management and assign a Staff Code.',
          };
        }

        // Verify staff code: strictly match against code assigned to staff by Admin in Staff Management
        const matchingWorker = activeStaff.find((w) => {
          const wAccess = (w.accessCode || '').trim();
          const wPin = (w.pin || '').trim();
          return (wAccess && wAccess === code) || (wPin && wPin === code);
        });

        if (!matchingWorker) {
          return {
            success: false,
            error: 'Invalid Staff Code. Please enter the valid Staff Code set by Administrator in Staff Management.',
          };
        }

        // Successfully verified as Staff
        setVerifiedRole('worker');
        const session: RoleSessionData = {
          role: 'worker',
          email: matchingWorker.email || user?.email || '',
          uid: user?.uid,
          workerId: matchingWorker.id,
          workerName: matchingWorker.name,
          verifiedAt: Date.now(),
        };
        localStorage.setItem(ROLE_SESSION_KEY, JSON.stringify(session));
        return { success: true };
      }
    },
    [user, centralUsers]
  );

  const value: AuthContextType = {
    user,
    loading,
    verifiedRole,
    verifyRoleCode,
    switchRoleToStaff,
    clearRoleVerification,
    login,
    signup,
    loginWithGoogle,
    resetPassword,
    logout,
    formatAuthError,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

