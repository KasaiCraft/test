export type PlayerCount = 1 | 2 | 3 | 4 | 5;
export type DurationMinutes = 15 | 30 | 45 | 60 | 120 | 180;
export type FixedStationType = 'PS5' | 'PS4' | 'G29' | 'VR';

/**
 * EXACT FIXED PRICING CHARTS
 * ONLY these 4 station types follow fixed charts:
 * 1. PS5
 * 2. PS4
 * 3. Driving Simulator / G29
 * 4. PS VR
 */
export const GAMING_PRICING: Record<FixedStationType, Record<number, any>> = {
  PS5: {
    60: { 1: 100, 2: 170, 3: 240, 4: 310, 5: 380 },
    120: { 1: 170, 2: 290, 3: 410, 4: 530, 5: 650 },
    180: { 1: 230, 2: 390, 3: 550, 4: 710, 5: 870 },
  },
  PS4: {
    60: { 1: 80, 2: 140, 3: 200, 4: 260, 5: 320 },
    120: { 1: 130, 2: 230, 3: 330, 4: 430, 5: 530 },
    180: { 1: 170, 2: 300, 3: 430, 4: 560, 5: 690 },
  },
  G29: {
    30: 100,
    60: 150,
    120: 240,
    180: 315,
  },
  VR: {
    15: 100,
    30: 160,
    45: 220,
    60: 280,
  },
};

/**
 * Detects if a station belongs to one of the 4 fixed-pricing station categories:
 * - PS5
 * - PS4 (including PS4 Pro)
 * - Driving Simulator / G29 (including Sim Racing, Racing Simulator)
 * - PS VR (including VR Station)
 * 
 * Returns null for all other stations (PC Station, Custom Station, etc.)
 */
export function getFixedStationType(stationType?: string | null): FixedStationType | null {
  if (!stationType) return null;
  const raw = stationType.trim().toLowerCase();

  // 1. PS5
  if (raw === 'ps5') {
    return 'PS5';
  }

  // 2. PS4
  if (raw === 'ps4' || raw === 'ps4 pro') {
    return 'PS4';
  }

  // 3. Driving Simulator / G29
  if (
    raw === 'g29' ||
    raw === 'sim racing' ||
    raw === 'racing simulator' ||
    raw === 'driving simulator' ||
    raw === 'driving simulator / g29' ||
    raw.includes('simulator') ||
    raw.includes('g29')
  ) {
    return 'G29';
  }

  // 4. PS VR
  if (
    raw === 'vr' ||
    raw === 'ps vr' ||
    raw === 'vr station' ||
    raw === 'playstation vr'
  ) {
    return 'VR';
  }

  // All other stations (PC Station, Custom, etc.) are NOT fixed
  return null;
}

/**
 * Returns the exact fixed price for the 4 fixed stations.
 * Returns 0 for all other stations (NEVER fallback to fixed chart).
 */
export const getGamingPrice = (
  type: string,
  durationMinutes: number,
  players: number = 1
): number => {
  const fixedType = getFixedStationType(type);
  if (!fixedType) return 0;

  const stationPricing = GAMING_PRICING[fixedType];
  if (!stationPricing) return 0;

  // Direct tier match
  const durationPricing = stationPricing[durationMinutes];
  if (durationPricing !== undefined) {
    if (typeof durationPricing === 'object' && durationPricing !== null) {
      return durationPricing[players] ?? durationPricing[1] ?? 0;
    }
    return typeof durationPricing === 'number' ? durationPricing : 0;
  }

  // Interpolation between tiers or under/over tiers
  const tierMinutes = Object.keys(stationPricing)
    .map(Number)
    .sort((a, b) => a - b);

  if (tierMinutes.length === 0) return 0;

  const getTierPrice = (m: number): number => {
    const entry = stationPricing[m];
    if (typeof entry === 'object' && entry !== null) {
      return entry[players] ?? entry[1] ?? 0;
    }
    return typeof entry === 'number' ? entry : 0;
  };

  // Under lowest tier
  const lowest = tierMinutes[0];
  const lowestPrice = getTierPrice(lowest);
  if (durationMinutes < lowest) {
    return Math.max(1, Math.round((durationMinutes / lowest) * lowestPrice));
  }

  // Between tiers
  for (let i = 0; i < tierMinutes.length - 1; i++) {
    const low = tierMinutes[i];
    const high = tierMinutes[i + 1];
    if (durationMinutes >= low && durationMinutes <= high) {
      const lowPrice = getTierPrice(low);
      const highPrice = getTierPrice(high);
      const fraction = (durationMinutes - low) / (high - low);
      return Math.round(lowPrice + fraction * (highPrice - lowPrice));
    }
  }

  // Beyond highest tier
  const highest = tierMinutes[tierMinutes.length - 1];
  const highestPrice = getTierPrice(highest);
  const highestHourlyRate = highestPrice / (highest / 60);
  const excessHours = (durationMinutes - highest) / 60;
  return Math.round(highestPrice + excessHours * highestHourlyRate);
};

