import { Voucher } from '../types';

export const OFFICIAL_VOUCHERS = [
  { name: '7 Hours PS4 Pass', category: 'PS4', durationMinutes: 420, price: 479 },
  { name: '14 Hours PS4 Pass', category: 'PS4', durationMinutes: 840, price: 799 },
  { name: '30 Hours PS4 Pass', category: 'PS4', durationMinutes: 1800, price: 1599 },
  { name: '7 Hours PS5 Pass', category: 'PS5', durationMinutes: 420, price: 579 },
  { name: '14 Hours PS5 Pass', category: 'PS5', durationMinutes: 840, price: 899 },
  { name: '30 Hours PS5 Pass', category: 'PS5', durationMinutes: 1800, price: 1799 },
  { name: '7 Hours PC Pass', category: 'PC', durationMinutes: 420, price: 299 },
  { name: '14 Hours PC Pass', category: 'PC', durationMinutes: 840, price: 549 },
  { name: '30 Hours PC Pass', category: 'PC', durationMinutes: 1800, price: 1099 },
  { name: '7 Hours Driving Simulator', category: 'Driving Simulator', durationMinutes: 420, price: 799 },
  { name: '14 Hours Driving Simulator', category: 'Driving Simulator', durationMinutes: 840, price: 1499 },
  { name: '30 Hours Driving Simulator', category: 'Driving Simulator', durationMinutes: 1800, price: 2999 },
  { name: '7 Hours Streaming Room', category: 'Streaming Room', durationMinutes: 420, price: 799 },
  { name: '14 Hours Streaming Room', category: 'Streaming Room', durationMinutes: 840, price: 1499 },
  { name: '30 Hours Streaming Room', category: 'Streaming Room', durationMinutes: 1800, price: 2999 },
];
