import { CafeDatabase, UserAccount, NEXTGEN_CAFE_BUSINESS_ID } from '../types';

export const STARTER_DATA_TIMESTAMP = new Date().toISOString();

export const INITIAL_ADMIN_USER: UserAccount = {
  id: 'single_owner_id',
  name: 'Admin Owner',
  email: 'owner@nextgencafe.com',
  role: 'admin',
  businessId: NEXTGEN_CAFE_BUSINESS_ID,
  pin: '756569',
  accessCode: '756569',
  phone: '',
  createdAt: STARTER_DATA_TIMESTAMP,
  status: 'active',
};

export const INITIAL_DATABASE: CafeDatabase = {
  version: 1,
  businessId: NEXTGEN_CAFE_BUSINESS_ID,
  ownerId: 'single_owner_id',
  ownerEmail: 'owner@nextgencafe.com',
  lastModified: new Date().toISOString(),
  settings: {
    businessId: NEXTGEN_CAFE_BUSINESS_ID,
    ownerId: 'single_owner_id',
    ownerEmail: 'owner@nextgencafe.com',
    cafeName: 'NEXT GEN ESPORT',
    tagline: 'Gaming Cafe Management System',
    phone: '',
    email: 'owner@nextgencafe.com',
    address: '',
    currencySymbol: '₹',
    taxRatePercent: 0,
    minGamingTimeMinutes: 15,
    roundingIncrementMinutes: 5,
    autoSyncGoogleDrive: false,
    googleDriveSyncIntervalMinutes: 2,
    lastSyncedAt: null,
    adminAccessCode: '756569',
    staffAccessCode: '',
  },
  users: [INITIAL_ADMIN_USER],
  consoles: [],
  customers: [],
  sessions: [],
  rentalItems: [],
  rentalRecords: [],
  cafeteriaItems: [],
  cafeteriaOrders: [],
  cafeteriaStockLogs: [],
  vouchers: [],
  voucherUsages: [],
  buySellItems: [],
  buySellTransactions: [],
  repairRecords: [],
  payments: [],
  notices: [],
  deletedConsoleIds: [],
  deletedRepairIds: [],
  deletedVoucherIds: [],
  deletedUserIds: [],
};

/**
 * Factory to produce a fully isolated, clean CafeDatabase for a new business/owner
 */
export function createIsolatedBusinessDatabase(params: {
  businessId: string;
  ownerId: string;
  ownerEmail: string;
  ownerName?: string;
  cafeName?: string;
}): CafeDatabase {
  const { businessId, ownerId, ownerEmail, ownerName, cafeName } = params;
  const displayName = ownerName || ownerEmail.split('@')[0];
  const formattedCafeName =
    cafeName || `${displayName.toUpperCase()}'S GAMING CAFE`;

  const ownerUser: UserAccount = {
    id: ownerId,
    name: displayName,
    email: ownerEmail,
    role: 'admin',
    businessId,
    ownerId,
    pin: '756569',
    accessCode: '756569',
    createdAt: new Date().toISOString(),
    status: 'active',
  };

  return {
    version: 1,
    businessId,
    ownerId,
    ownerEmail,
    lastModified: new Date().toISOString(),
    settings: {
      businessId,
      ownerId,
      ownerEmail,
      cafeName: formattedCafeName,
      tagline: 'Gaming Cafe Management System',
      phone: '',
      email: ownerEmail,
      address: '',
      currencySymbol: '₹',
      taxRatePercent: 0,
      minGamingTimeMinutes: 15,
      roundingIncrementMinutes: 5,
      autoSyncGoogleDrive: false,
      googleDriveSyncIntervalMinutes: 2,
      lastSyncedAt: null,
      adminAccessCode: '756569',
      staffAccessCode: '',
    },
    users: [ownerUser],
    consoles: [],
    customers: [],
    sessions: [],
    rentalItems: [],
    rentalRecords: [],
    cafeteriaItems: [],
    cafeteriaOrders: [],
    cafeteriaStockLogs: [],
    vouchers: [],
    voucherUsages: [],
    buySellItems: [],
    buySellTransactions: [],
    repairRecords: [],
    payments: [],
    notices: [],
    deletedConsoleIds: [],
    deletedRepairIds: [],
    deletedVoucherIds: [],
    deletedUserIds: [],
  };
}
