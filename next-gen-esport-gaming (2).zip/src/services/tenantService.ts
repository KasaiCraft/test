import { User, updateProfile } from 'firebase/auth';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { TenantInfo, WorkerMembership, NEXTGEN_CAFE_BUSINESS_ID, MAX_WORKERS_ALLOWED, UserAccount } from '../types';
import { INITIAL_DATABASE } from '../data/initialData';

const WORKERS_REGISTRY_KEY = 'NEXTGEN_WORKERS_REGISTRY_V1';
const OWNER_STORAGE_KEY = 'NEXTGEN_CAFE_OWNER_V1';

export { NEXTGEN_CAFE_BUSINESS_ID, MAX_WORKERS_ALLOWED };

class TenantService {
  private workers: WorkerMembership[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const storedWorkers = localStorage.getItem(WORKERS_REGISTRY_KEY);
      if (storedWorkers) {
        this.workers = JSON.parse(storedWorkers);
      }
    } catch (e) {
      console.warn('Failed to load workers registry:', e);
      this.workers = [];
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem(WORKERS_REGISTRY_KEY, JSON.stringify(this.workers));
    } catch (e) {
      console.warn('Failed to save workers registry to storage:', e);
    }
  }

  /**
   * Always returns the user-isolated cafe business ID: user_${ownerUid}
   */
  public getBusinessId(ownerUid?: string): string {
    if (ownerUid) return `user_${ownerUid}`;
    return NEXTGEN_CAFE_BUSINESS_ID;
  }

  /**
   * Backward-compatible alias for business ID
   */
  public generateBusinessId(ownerUid?: string): string {
    if (ownerUid) return `user_${ownerUid}`;
    return NEXTGEN_CAFE_BUSINESS_ID;
  }

  /**
   * Look up if an email is a registered worker
   */
  public findWorkerMembership(email: string): WorkerMembership | null {
    this.loadFromStorage();
    const cleanEmail = email.trim().toLowerCase();
    return this.workers.find((w) => w.workerEmail.toLowerCase() === cleanEmail) || null;
  }

  public getWorkerMembership(email?: string | null, _uid?: string | null): WorkerMembership | null {
    if (!email) return null;
    return this.findWorkerMembership(email);
  }

  /**
   * Get all workers for the single cafe
   */
  public getWorkersForBusiness(_businessId?: string): WorkerMembership[] {
    this.loadFromStorage();
    return this.workers;
  }

  /**
   * Register a worker membership locally (cached)
   */
  public registerWorkerMembership(membership: {
    workerEmail: string;
    businessId?: string;
    workerId: string;
    workerName: string;
    ownerEmail: string;
    ownerId?: string;
    password?: string;
    pin?: string;
    phone?: string;
  }): WorkerMembership {
    this.loadFromStorage();
    const cleanEmail = membership.workerEmail.trim().toLowerCase();
    const existingIndex = this.workers.findIndex(
      (w) => w.workerEmail.toLowerCase() === cleanEmail
    );

    const newMembership: WorkerMembership = {
      workerEmail: cleanEmail,
      businessId: NEXTGEN_CAFE_BUSINESS_ID,
      workerId: membership.workerId,
      workerName: membership.workerName,
      role: 'worker',
      ownerEmail: membership.ownerEmail.toLowerCase(),
      ownerId: membership.ownerId,
      createdAt: existingIndex >= 0 ? this.workers[existingIndex].createdAt : new Date().toISOString(),
      password: membership.password || (existingIndex >= 0 ? this.workers[existingIndex].password : undefined),
      pin: membership.pin || (existingIndex >= 0 ? this.workers[existingIndex].pin : undefined),
      phone: membership.phone || (existingIndex >= 0 ? this.workers[existingIndex].phone : undefined),
    };

    if (existingIndex >= 0) {
      this.workers[existingIndex] = newMembership;
    } else {
      if (this.workers.length >= MAX_WORKERS_ALLOWED) {
        console.warn(`Worker count exceeds max of ${MAX_WORKERS_ALLOWED}`);
      }
      this.workers.push(newMembership);
    }

    this.saveToStorage();
    return newMembership;
  }

  /**
   * Retrieves all registered staff accounts across all local cafe databases and caches.
   */
  public getStaffAccounts(): UserAccount[] {
    const staffMap = new Map<string, UserAccount>();

    // 1. Check all local storage keys for NEXTGEN_CAFE_DB
    try {
      if (typeof localStorage !== 'undefined') {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && (key.startsWith('NEXTGEN_CAFE_DB') || key === 'NEXTGEN_CAFE_DB_V1')) {
            const raw = localStorage.getItem(key);
            if (raw) {
              const parsed = JSON.parse(raw);
              if (parsed && Array.isArray(parsed.users)) {
                for (const u of parsed.users) {
                  if (u && u.role === 'worker' && u.email) {
                    const cleanEmail = u.email.trim().toLowerCase();
                    const existing = staffMap.get(cleanEmail);
                    staffMap.set(cleanEmail, { ...(existing || {}), ...u });
                  }
                }
              }
            }
          }
        }
      }
    } catch (e) {
      console.warn('Error reading staff accounts from localStorage:', e);
    }

    // 2. Cross-reference with workers registry
    this.loadFromStorage();
    for (const w of this.workers) {
      const cleanEmail = w.workerEmail.trim().toLowerCase();
      const existing = staffMap.get(cleanEmail);
      if (!existing) {
        staffMap.set(cleanEmail, {
          id: w.workerId || `usr_${cleanEmail.replace(/[^a-z0-9]/g, '_')}`,
          name: w.workerName || String(cleanEmail || '').split('@')[0],
          email: cleanEmail,
          role: 'worker',
          pin: w.accessCode || w.pin || '',
          accessCode: w.accessCode || w.pin || '',
          password: w.password,
          phone: w.phone,
          businessId: NEXTGEN_CAFE_BUSINESS_ID,
          createdAt: w.createdAt || new Date().toISOString(),
          status: 'active',
        });
      } else {
        // Supplement missing password/pin from registry if needed
        if (!existing.password && w.password) existing.password = w.password;
        if (!existing.pin && (w.accessCode || w.pin)) existing.pin = w.accessCode || w.pin;
        if (!existing.accessCode && (w.accessCode || w.pin)) existing.accessCode = w.accessCode || w.pin;
      }
    }

    // 3. Fallback to INITIAL_DATABASE workers if still empty
    if (staffMap.size === 0) {
      for (const u of INITIAL_DATABASE.users) {
        if (u.role === 'worker' && u.email) {
          staffMap.set(u.email.trim().toLowerCase(), u);
        }
      }
    }

    return Array.from(staffMap.values());
  }

  /**
   * Disconnects staff authentication from Firebase Auth!
   * Directly validates staff credentials (email/phone/name + password or PIN).
   */
  public verifyStaffCredentials(
    identifier: string,
    secret: string
  ): { success: boolean; worker?: UserAccount; error?: string } {
    const cleanId = identifier.trim().toLowerCase();
    const cleanSecret = secret.trim();

    if (!cleanId || !cleanSecret) {
      return { success: false, error: 'Please enter both your identifier and password or PIN.' };
    }

    const allStaff = this.getStaffAccounts();
    const worker = allStaff.find((w) => {
      const wEmail = (w.email || '').trim().toLowerCase();
      const wName = (w.name || '').trim().toLowerCase();
      const wPhone = (w.phone || '').replace(/\D/g, '');
      const inputPhone = cleanId.replace(/\D/g, '');

      return (
        wEmail === cleanId ||
        wName === cleanId ||
        (inputPhone.length >= 7 && wPhone === inputPhone)
      );
    });

    if (!worker) {
      return {
        success: false,
        error: 'No staff account found for this email or phone. Please ask the Cafe Owner to add you in Staff Management.',
      };
    }

    const isPasswordMatch = Boolean(worker.password && worker.password === cleanSecret);
    const isPinMatch = Boolean(worker.pin && worker.pin === cleanSecret);

    if (isPasswordMatch || isPinMatch) {
      return { success: true, worker };
    }

    return {
      success: false,
      error: 'Incorrect staff password or quick PIN. Please try again or check with the Cafe Owner.',
    };
  }

  /**
   * Verifies a staff member using their 4-digit PIN for quick counter unlock.
   */
  public verifyStaffPin(
    pin: string,
    workerId?: string
  ): { success: boolean; worker?: UserAccount; error?: string } {
    const cleanPin = pin.trim();
    if (!cleanPin) {
      return { success: false, error: 'Please enter your 4-digit terminal PIN.' };
    }

    const allStaff = this.getStaffAccounts();

    if (workerId) {
      const worker = allStaff.find(
        (w) => w.id === workerId || w.email.trim().toLowerCase() === workerId.trim().toLowerCase()
      );
      if (!worker) {
        return { success: false, error: 'Selected staff profile not found.' };
      }
      const pinMatch = worker.pin === cleanPin;
      const passMatch = Boolean(worker.password && worker.password === cleanPin);
      if (pinMatch || passMatch) {
        return { success: true, worker };
      }
      return { success: false, error: 'Incorrect PIN for selected staff member.' };
    }

    // Direct PIN without selecting staff
    const matched = allStaff.find((w) => w.pin === cleanPin || (w.password && w.password === cleanPin));
    if (matched) {
      return { success: true, worker: matched };
    }

    return { success: false, error: 'Invalid PIN entered. No staff profile matches this PIN.' };
  }

  /**
   * Remove a worker membership
   */
  public removeWorkerMembership(email: string, _businessId?: string) {
    this.loadFromStorage();
    const cleanEmail = email.trim().toLowerCase();
    this.workers = this.workers.filter(
      (w) => w.workerEmail.toLowerCase() !== cleanEmail
    );
    this.saveToStorage();
  }

  /**
   * Resolves the authoritative role and tenant info for NEXT GEN GAMING CAFE.
   * All accounts share the SAME NEXTGEN_CAFE_BUSINESS_ID.
   */
  public async resolveUserTenant(user: User): Promise<TenantInfo> {
    const userEmail = (user.email || '').trim().toLowerCase();
    const userName = user.displayName || String(userEmail || '').split('@')[0] || 'User';

    // 1. Inspect cryptographically signed Firebase Custom Claims directly on the user's ID token
    try {
      const idTokenResult = await user.getIdTokenResult(false);
      const claims = idTokenResult.claims;

      if (claims.role) {
        const role = claims.role === 'worker' ? 'worker' : 'admin';
        return {
          businessId: NEXTGEN_CAFE_BUSINESS_ID,
          role,
          name: userName,
          email: userEmail,
          ownerId: claims.ownerUid ? String(claims.ownerUid) : undefined,
          businessName: 'NEXT GEN GAMING CAFE',
        };
      }
    } catch (claimErr) {
      console.warn('Could not read existing custom claims from token:', claimErr);
    }

    // Direct check: If this user is in the staff roster, return worker role immediately
    const staffMatch = this.getStaffAccounts().find(
      (s) => s.email && s.email.trim().toLowerCase() === userEmail
    );
    if (staffMatch) {
      return {
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        role: 'worker',
        name: staffMatch.name || userName,
        email: userEmail,
        businessName: 'NEXT GEN GAMING CAFE',
      };
    }

    // 2. Claims not present on token: Call backend to authoritatively establish/assign claims
    try {
      const idToken = await user.getIdToken();
      const response = await fetch('/api/tenant-claim', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
      });

      if (response.ok) {
        const payload = await response.json();
        if (payload.success && payload.data) {
          // Force refresh Firebase ID token after claims are set
          await user.getIdToken(true);

          const refreshedTokenResult = await user.getIdTokenResult(false);
          const refClaims = refreshedTokenResult.claims;

          const authoritativeRole = (refClaims.role || payload.data.role) === 'worker' ? 'worker' : 'admin';

          return {
            businessId: NEXTGEN_CAFE_BUSINESS_ID,
            role: authoritativeRole,
            name: userName,
            email: userEmail,
            ownerId: payload.data.ownerUid,
            businessName: 'NEXT GEN GAMING CAFE',
          };
        }
      }
    } catch (apiErr) {
      console.warn('Backend tenant-claim API unavailable or offline:', apiErr);
    }

    // 3. Fallback: Check local worker registry cache
    this.loadFromStorage();
    const workerMembership = this.findWorkerMembership(userEmail);
    if (workerMembership) {
      return {
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        role: 'worker',
        name: workerMembership.workerName || userName,
        email: userEmail,
        ownerEmail: workerMembership.ownerEmail,
        ownerId: workerMembership.ownerId,
        businessName: 'NEXT GEN GAMING CAFE',
      };
    }

    // 4. Security Check: Determine if this user is the authentic cafe owner
    const ownerStatus = await this.checkOwnerExists();
    const knownOwnerEmail = (ownerStatus.ownerEmail || '').toLowerCase();
    const isAuthenticOwner =
      (ownerStatus.exists && knownOwnerEmail && userEmail === knownOwnerEmail);

    if (ownerStatus.exists && !isAuthenticOwner) {
      // Owner is already established and this user is NOT the owner.
      // Strictly restrict to worker role. Non-owners CANNOT access admin panel or delete data.
      console.warn(`[SECURITY] Non-owner ${userEmail} resolved to Worker role to prevent admin escalation.`);
      return {
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        role: 'worker',
        name: userName,
        email: userEmail,
        ownerEmail: ownerStatus.ownerEmail,
        businessName: 'NEXT GEN GAMING CAFE',
      };
    }

    // Initial Owner setup (or verified authentic owner)
    return {
      businessId: NEXTGEN_CAFE_BUSINESS_ID,
      role: 'admin',
      name: userName,
      email: userEmail,
      businessName: 'NEXT GEN GAMING CAFE',
    };
  }

  /**
   * Checks if an Owner account has already been registered for NEXT GEN GAMING CAFE.
   * Authoritatively queries the live server endpoint /api/system-status first.
   * If all emails were deleted from Firebase, it immediately cleans local cache and returns exists: false.
   */
  public async checkOwnerExists(forceRefresh: boolean = false): Promise<{ exists: boolean; ownerEmail?: string; firebaseHasUsers?: boolean }> {
    // Check session cache first for instant UI response (unless force refresh)
    if (!forceRefresh) {
      try {
        const sessionCached = sessionStorage.getItem(OWNER_STORAGE_KEY);
        if (sessionCached) {
          const data = JSON.parse(sessionCached);
          if (data.configured) return { exists: true, ownerEmail: data.ownerEmail };
        }
      } catch {}
    }

    // 1. Primary: Query authoritative server endpoint /api/system-status with cache busting
    try {
      const res = await fetch(`/api/system-status?t=${Date.now()}`);
      if (res.ok) {
        const payload = await res.json();
        if (payload && payload.success && payload.data) {
          const exists = Boolean(payload.data.ownerExists);
          const ownerEmail = payload.data.ownerEmail;
          const firebaseHasUsers = payload.data.firebaseHasUsers;

          if (exists && ownerEmail) {
            try {
              const cacheData = {
                ownerEmail,
                configured: true,
                cachedAt: new Date().toISOString(),
              };
              localStorage.setItem(OWNER_STORAGE_KEY, JSON.stringify(cacheData));
              sessionStorage.setItem(OWNER_STORAGE_KEY, JSON.stringify(cacheData));
            } catch {
              // ignore
            }
            return { exists: true, ownerEmail, firebaseHasUsers };
          } else {
            // Server confirmed NO owner exists or all Firebase accounts were deleted!
            try {
              localStorage.removeItem(OWNER_STORAGE_KEY);
              sessionStorage.removeItem(OWNER_STORAGE_KEY);
            } catch {
              // ignore
            }
            return { exists: false, firebaseHasUsers: false };
          }
        }
      }
    } catch (e) {
      console.warn('Live owner status check from /api/system-status failed, falling back to local verification:', e);
    }

    // 2. Fallback only if offline and not force-refreshing
    if (!forceRefresh) {
      try {
        const stored = localStorage.getItem(OWNER_STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (parsed.ownerEmail) return { exists: true, ownerEmail: parsed.ownerEmail };
        }
      } catch {
        // ignore
      }
    }

    return { exists: false };
  }

  /**
   * Explicitly clears local owner cache and requests the server to sync with Firebase Auth.
   */
  public async resetOwnerStatus(): Promise<{ success: boolean; ownerExists: boolean }> {
    try {
      localStorage.removeItem(OWNER_STORAGE_KEY);
    } catch {
      // ignore
    }

    try {
      const res = await fetch('/api/system-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'sync_firebase' }),
      });
      if (res.ok) {
        const payload = await res.json();
        const exists = Boolean(payload?.data?.ownerExists);
        if (!exists) {
          localStorage.removeItem(OWNER_STORAGE_KEY);
        }
        return { success: true, ownerExists: exists };
      }
    } catch (e) {
      console.warn('Error resetting owner status via API:', e);
    }

    return { success: true, ownerExists: false };
  }

  /**
   * Authoritatively provisions a worker via the serverless backend.
   * Maximum 5 worker accounts allowed for NEXT GEN GAMING CAFE.
   */
  public async provisionWorkerOnServer(params: {
    workerUid?: string;
    workerEmail: string;
    workerName: string;
    temporaryPassword?: string;
    ownerUser: User;
  }): Promise<{ success: boolean; data?: any; error?: string }> {
    try {
      const idToken = await params.ownerUser.getIdToken();
      const res = await fetch('/api/provision-worker', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({
          workerUid: params.workerUid,
          workerEmail: params.workerEmail,
          workerName: params.workerName,
          temporaryPassword: params.temporaryPassword,
        }),
      });

      const payload = await res.json();
      if (!res.ok || !payload.success) {
        return {
          success: false,
          error: payload.error || `Server responded with status ${res.status}`,
        };
      }

      // Also cache locally
      this.registerWorkerMembership({
        workerEmail: params.workerEmail,
        workerId: params.workerUid || `worker_${Date.now()}`,
        workerName: params.workerName,
        ownerEmail: params.ownerUser.email || '',
        ownerId: params.ownerUser.uid,
      });

      return { success: true, data: payload.data };
    } catch (err: any) {
      console.warn('Worker server provisioning warning (offline or fallback):', err);
      return {
        success: false,
        error: err?.message || 'Failed to communicate with provisioning backend',
      };
    }
  }

  /**
   * Unbinds a worker and clears their custom claims on the server.
   */
  public async unbindWorkerOnServer(params: {
    workerUid: string;
    ownerUser: User;
  }): Promise<{ success: boolean; error?: string }> {
    try {
      const idToken = await params.ownerUser.getIdToken();
      const res = await fetch('/api/provision-worker', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({
          action: 'unbind',
          workerUid: params.workerUid,
        }),
      });

      const payload = await res.json();
      if (!res.ok || !payload.success) {
        return {
          success: false,
          error: payload.error || `Server responded with status ${res.status}`,
        };
      }
      return { success: true };
    } catch (err: any) {
      console.warn('Worker unbind backend warning:', err);
      return { success: false, error: err?.message || 'Failed to unbind worker' };
    }
  }

  /**
   * Helper for creating a Firebase Auth worker account without signing out the current admin.
   * Securely calls the backend to assign worker custom claims.
   * Enforces the maximum 5 worker accounts limit.
   */
  public async createWorkerAuthAccount(
    email: string,
    password: string,
    name: string,
    _businessId?: string,
    ownerUser?: User | null
  ): Promise<{ success: boolean; workerUid?: string; error?: string }> {
    // Check worker count limit before creating Firebase Auth account
    this.loadFromStorage();
    if (this.workers.length >= MAX_WORKERS_ALLOWED) {
      return {
        success: false,
        error: `Maximum ${MAX_WORKERS_ALLOWED} Worker accounts allowed for NEXT GEN GAMING CAFE. You already have ${this.workers.length} active workers.`,
      };
    }

    const secondaryAppName = `SecondaryAuth_${Date.now()}`;
    let secondaryApp;
    try {
      secondaryApp = initializeApp(firebaseConfig, secondaryAppName);
      const secondaryAuth = getAuth(secondaryApp);
      const userCredential = await createUserWithEmailAndPassword(secondaryAuth, email, password);
      const workerUid = userCredential.user.uid;

      // Update profile with worker name
      await updateProfile(userCredential.user, {
        displayName: name,
      });

      // Sign out from secondary auth immediately
      await signOut(secondaryAuth);

      // If active owner user is available, provision claims server-side
      if (ownerUser) {
        const provisionResult = await this.provisionWorkerOnServer({
          workerUid,
          workerEmail: email,
          workerName: name,
          ownerUser,
        });

        if (!provisionResult.success) {
          console.warn('Server claim assignment warning:', provisionResult.error);
        }
      }

      return { success: true, workerUid };
    } catch (err: any) {
      console.warn('Worker auth creation warning:', err);
      return {
        success: false,
        error: err?.message || 'Failed to create worker auth credentials in Firebase',
      };
    }
  }
}

export const tenantService = new TenantService();
