import {
  CafeDatabase,
  Voucher,
  VoucherStatus,
  VoucherUsage,
  BuySellItem,
  BuySellTransaction,
  BuySellCategory,
  BuySellCondition,
  RepairRecord,
  RepairCategory,
  RepairStatus,
  CafeteriaItem,
  CafeteriaStockLog,
  StockMovementType,
  PaymentTransaction,
  PaymentMethod,
  PaymentStatus,
  UserAccount,
  Customer,
} from '../types';

export class CafeModulesService {
  /**
   * Generates a clean, unique Voucher Code
   */
  static generateVoucherCode(prefix: string = 'VOUCH'): string {
    const randomHex = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${randomHex}`;
  }

  /**
   * Generates next sequential repair number (e.g. REP-101, REP-102)
   */
  static generateRepairNumber(existingRepairs: RepairRecord[] = []): string {
    const count = existingRepairs.length + 101;
    return `REP-${count}`;
  }

  /**
   * VOUCHER OPERATIONS
   */
  static addVoucher(
    voucherData: Omit<Voucher, 'id' | 'createdAt' | 'usedCount' | 'updatedAt'>,
    db: CafeDatabase
  ): { updatedDb: CafeDatabase; voucher: Voucher } {
    const rawCode = (voucherData.code || this.generateVoucherCode()).trim().toUpperCase();
    const existing = (db.vouchers || []).find(
      (v) => v.code.toUpperCase() === rawCode
    );
    if (existing) {
      throw new Error(`A voucher with code "${rawCode}" already exists.`);
    }

    const totalPurchasedHours =
      voucherData.totalPurchasedHours ??
      (voucherData.durationMinutes ? Math.round((voucherData.durationMinutes / 60) * 10) / 10 : 0);
    const durationMinutes =
      voucherData.durationMinutes ?? Math.round(totalPurchasedHours * 60);
    const usedHours = voucherData.usedHours ?? 0;
    const remainingHours =
      voucherData.remainingHours ??
      Math.max(0, Math.round((totalPurchasedHours - usedHours) * 10) / 10);
    const usedMinutes = voucherData.usedMinutes ?? Math.round(usedHours * 60);
    const remainingMinutes =
      voucherData.remainingMinutes ?? Math.max(0, durationMinutes - usedMinutes);

    const newVoucher: Voucher = {
      ...voucherData,
      id: `vouch_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      code: rawCode,
      durationMinutes,
      totalPurchasedHours,
      usedHours,
      remainingHours,
      usedMinutes,
      remainingMinutes,
      
      // Initialize real-time fields
      startedAt: null,
      pausedAt: null,
      resumedAt: null,
      lastCalculatedAt: null,
      totalVoucherDuration: durationMinutes,
      consumedDuration: usedMinutes,
      remainingDuration: remainingMinutes,
      
      purchaseDate: voucherData.purchaseDate || new Date().toISOString(),
      usedCount: 0,
      status: voucherData.status || (remainingHours <= 0 && totalPurchasedHours > 0 ? 'used' : 'active'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updatedDb: CafeDatabase = {
      ...db,
      vouchers: [newVoucher, ...(db.vouchers || [])],
    };

    return { updatedDb, voucher: newVoucher };
  }

  static updateVoucher(
    id: string,
    updates: Partial<Voucher>,
    db: CafeDatabase
  ): CafeDatabase {
    const timestamp = new Date().toISOString();
    const updatedVouchers = (db.vouchers || []).map((v) => {
      if (v.id === id) {
        return { ...v, ...updates, updatedAt: timestamp };
      }
      return v;
    });

    return { ...db, vouchers: updatedVouchers };
  }

  static startVoucher(id: string, db: CafeDatabase): CafeDatabase {
    const timestamp = new Date().toISOString();
    const updatedVouchers = (db.vouchers || []).map((v) => {
      if (v.id === id) {
        if (v.status !== 'active') {
          throw new Error(`Cannot start voucher in "${v.status}" status.`);
        }
        return {
          ...v,
          status: 'running' as const,
          startedAt: timestamp,
          resumedAt: timestamp,
          lastCalculatedAt: timestamp,
          updatedAt: timestamp,
        };
      }
      return v;
    });
    return { ...db, vouchers: updatedVouchers };
  }

  static pauseVoucher(id: string, db: CafeDatabase): CafeDatabase {
    const timestamp = new Date().toISOString();
    const updatedVouchers = (db.vouchers || []).map((v) => {
      if (v.id === id) {
        if (v.status !== 'running') {
          throw new Error('Voucher is not running.');
        }
        
        // Calculate consumed time up to now
        const lastCalc = v.lastCalculatedAt ? new Date(v.lastCalculatedAt).getTime() : new Date(v.resumedAt || v.startedAt || timestamp).getTime();
        const now = new Date(timestamp).getTime();
        const elapsedMinutes = Math.max(0, (now - lastCalc) / (1000 * 60));
        
        const newConsumed = (v.consumedDuration || 0) + elapsedMinutes;
        const newRemaining = Math.max(0, (v.totalVoucherDuration || v.durationMinutes) - newConsumed);
        
        // Convert to hours for legacy fields
        const newUsedHours = Math.round((newConsumed / 60) * 10) / 10;
        const newRemainingHours = Math.round((newRemaining / 60) * 10) / 10;

        return {
          ...v,
          status: 'paused' as const,
          pausedAt: timestamp,
          lastCalculatedAt: timestamp,
          updatedAt: timestamp,
          consumedDuration: newConsumed,
          remainingDuration: newRemaining,
          usedMinutes: Math.round(newConsumed),
          remainingMinutes: Math.round(newRemaining),
          usedHours: newUsedHours,
          remainingHours: newRemainingHours,
        };
      }
      return v;
    });
    return { ...db, vouchers: updatedVouchers };
  }

  static resumeVoucher(id: string, db: CafeDatabase): CafeDatabase {
    const timestamp = new Date().toISOString();
    const updatedVouchers = (db.vouchers || []).map((v) => {
      if (v.id === id) {
        if (v.status !== 'paused') {
          throw new Error('Voucher is not paused.');
        }
        return {
          ...v,
          status: 'running' as const,
          resumedAt: timestamp,
          lastCalculatedAt: timestamp,
          updatedAt: timestamp,
        };
      }
      return v;
    });
    return { ...db, vouchers: updatedVouchers };
  }

  static updateRunningVouchers(db: CafeDatabase): CafeDatabase {
    const now = Date.now();
    const timestamp = new Date(now).toISOString();
    let changed = false;

    const updatedVouchers = (db.vouchers || []).map((v) => {
      if (v.status === 'running') {
        const lastCalc = v.lastCalculatedAt ? new Date(v.lastCalculatedAt).getTime() : new Date(v.resumedAt || v.startedAt || timestamp).getTime();
        const elapsedMinutes = Math.max(0, (now - lastCalc) / (1000 * 60));
        
        if (elapsedMinutes >= 0.01) { // Only update if significant time passed (e.g. 0.01 mins)
          changed = true;
          const newConsumed = (v.consumedDuration || 0) + elapsedMinutes;
          const totalDur = v.totalVoucherDuration || v.durationMinutes;
          let newRemaining = Math.max(0, totalDur - newConsumed);
          
          let status: VoucherStatus = v.status;
          if (newRemaining <= 0) {
            newRemaining = 0;
            status = 'expired';
          }

          // Convert to hours for legacy fields
          const newUsedHours = Math.round((newConsumed / 60) * 10) / 10;
          const newRemainingHours = Math.round((newRemaining / 60) * 10) / 10;

          return {
            ...v,
            status,
            consumedDuration: newConsumed,
            remainingDuration: newRemaining,
            lastCalculatedAt: timestamp,
            usedMinutes: Math.round(newConsumed),
            remainingMinutes: Math.round(newRemaining),
            usedHours: newUsedHours,
            remainingHours: newRemainingHours,
            updatedAt: timestamp,
          };
        }
      }
      return v;
    });

    if (!changed) return db;
    return { ...db, vouchers: updatedVouchers };
  }

  static deleteVoucher(id: string, db: CafeDatabase): CafeDatabase {
    const deletedVoucherIds = Array.from(new Set([
      ...(Array.isArray(db.deletedVoucherIds) ? db.deletedVoucherIds : []),
      id,
    ]));
    return {
      ...db,
      deletedVoucherIds,
      vouchers: (db.vouchers || []).filter((v) => v.id !== id),
    };
  }

  static redeemVoucher(
    params: {
      code: string;
      customerId: string;
      customerName?: string;
      customerPhone?: string;
      sessionId?: string;
      consoleCode?: string;
      hoursToUse?: number;
      durationUsedMinutes?: number;
      notes?: string;
    },
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): { updatedDb: CafeDatabase; voucher: Voucher; usage: VoucherUsage } {
    const cleanCode = params.code.trim().toUpperCase();
    const voucher = (db.vouchers || []).find(
      (v) => v.code.toUpperCase() === cleanCode
    );

    if (!voucher) {
      throw new Error(`Voucher code "${cleanCode}" was not found.`);
    }

    if (voucher.status === 'disabled') {
      throw new Error(`Voucher "${cleanCode}" has been disabled.`);
    }

    if (voucher.status === 'used' || voucher.usedCount >= voucher.usageLimit || (voucher.remainingHours !== undefined && voucher.remainingHours <= 0)) {
      throw new Error(`Voucher "${cleanCode}" has already reached its maximum usage limit (0 hours remaining).`);
    }

    if (voucher.expiryDate && voucher.expiryDate !== 'never') {
      const expDate = new Date(voucher.expiryDate).getTime();
      if (expDate < Date.now()) {
        throw new Error(`Voucher "${cleanCode}" expired on ${new Date(voucher.expiryDate).toLocaleDateString()}.`);
      }
    }

    const totalPurchased =
      voucher.totalPurchasedHours ??
      (voucher.durationMinutes ? Math.round((voucher.durationMinutes / 60) * 10) / 10 : 0);
    const minutesToUse =
      params.durationUsedMinutes ??
      (params.hoursToUse
        ? Math.round(params.hoursToUse * 60)
        : voucher.remainingMinutes ?? voucher.durationMinutes);
    const playedHours =
      params.hoursToUse ?? Math.round((minutesToUse / 60) * 10) / 10;

    const currentUsedHours = voucher.usedHours ?? 0;
    const newUsedHours = Math.round((currentUsedHours + playedHours) * 10) / 10;
    const newRemainingHours = Math.max(
      0,
      Math.round((totalPurchased - newUsedHours) * 10) / 10
    );
    const newUsedMinutes = (voucher.usedMinutes ?? 0) + minutesToUse;
    const newRemainingMinutes = Math.max(
      0,
      (voucher.durationMinutes ?? Math.round(totalPurchased * 60)) - newUsedMinutes
    );

    const newUsedCount = voucher.usedCount + 1;
    const newStatus =
      newRemainingHours <= 0 || newUsedCount >= voucher.usageLimit
        ? 'used'
        : 'active';

    const updatedVoucher: Voucher = {
      ...voucher,
      totalPurchasedHours: totalPurchased,
      usedHours: newUsedHours,
      remainingHours: newRemainingHours,
      usedMinutes: newUsedMinutes,
      remainingMinutes: newRemainingMinutes,
      usedCount: newUsedCount,
      status: newStatus,
      updatedAt: new Date().toISOString(),
    };

    const resolvedCustomer =
      (db.customers || []).find((c) => c.id === params.customerId) ||
      (db.customers || []).find((c) => c.phone === params.customerPhone);

    const usageRecord: VoucherUsage = {
      id: `vuse_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      voucherId: voucher.id,
      voucherCode: voucher.code,
      voucherName: voucher.name,
      customerId: params.customerId,
      customerName: params.customerName || resolvedCustomer?.name || 'Customer',
      customerPhone: params.customerPhone || resolvedCustomer?.phone,
      sessionId: params.sessionId,
      consoleCode: params.consoleCode,
      durationUsedMinutes: minutesToUse,
      valueDiscountApplied: voucher.valueAmount || voucher.price,
      usedAt: new Date().toISOString(),
      recordedBy: currentUser?.name || 'Staff Member',
      notes: params.notes || `Used ${playedHours} hrs. Remaining: ${newRemainingHours} hrs.`,
    };

    const updatedVouchers = (db.vouchers || []).map((v) =>
      v.id === voucher.id ? updatedVoucher : v
    );

    const updatedDb: CafeDatabase = {
      ...db,
      vouchers: updatedVouchers,
      voucherUsages: [usageRecord, ...(db.voucherUsages || [])],
    };

    return { updatedDb, voucher: updatedVoucher, usage: usageRecord };
  }

  static sellVoucher(
    params: {
      voucherId: string;
      customerId: string;
      customerName: string;
      customerPhone?: string;
      paymentMethod: PaymentMethod;
      paidAmount?: number;
      notes?: string;
    },
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): CafeDatabase {
    const voucher = (db.vouchers || []).find((v) => v.id === params.voucherId);
    if (!voucher) {
      throw new Error('Voucher not found.');
    }

    const price = voucher.price;
    const paid = params.paidAmount !== undefined ? params.paidAmount : price;
    const status: PaymentStatus = paid >= price ? 'paid' : 'pending';
    const pendingAmount = Math.max(0, price - paid);

    const paymentTx: PaymentTransaction = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'voucher_sale',
      referenceId: voucher.id,
      referenceTitle: `Voucher Purchase: ${voucher.name} (${voucher.code})`,
      customerId: params.customerId,
      customerName: params.customerName,
      amount: paid,
      method: params.paymentMethod,
      status,
      totalBill: price,
      pendingAmount,
      notes: params.notes || `Sold voucher ${voucher.code}`,
      timestamp: new Date().toISOString(),
      recordedBy: currentUser?.name || 'Staff Member',
    };

    const updatedVouchers = (db.vouchers || []).map((v) =>
      v.id === voucher.id
        ? {
            ...v,
            assignedCustomerId: params.customerId,
            assignedCustomerName: params.customerName,
            assignedCustomerPhone: params.customerPhone,
            purchaseDate: new Date().toISOString(),
          }
        : v
    );

    const updatedCustomers = (db.customers || []).map((c) => {
      if (c.id === params.customerId) {
        return {
          ...c,
          totalSpent: (c.totalSpent || 0) + paid,
          totalOutstanding: (c.totalOutstanding || 0) + pendingAmount,
        };
      }
      return c;
    });

    return {
      ...db,
      vouchers: updatedVouchers,
      payments: [paymentTx, ...(db.payments || [])],
      customers: updatedCustomers,
    };
  }

  /**
   * BUY & SELL MANAGEMENT
   */
  static buyItemFromCustomer(
    params: {
      name: string;
      category: BuySellCategory;
      condition: BuySellCondition;
      serialNumber?: string;
      purchasePrice: number;
      suggestedSellingPrice: number;
      customerId: string;
      customerName: string;
      customerPhone?: string;
      paymentMethod: PaymentMethod;
      notes?: string;
    },
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): { updatedDb: CafeDatabase; item: BuySellItem } {
    const itemId = `bs_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const timestamp = new Date().toISOString();

    const newItem: BuySellItem = {
      id: itemId,
      name: params.name.trim(),
      category: params.category,
      condition: params.condition,
      serialNumber: params.serialNumber?.trim() || undefined,
      purchasePrice: params.purchasePrice,
      suggestedSellingPrice: params.suggestedSellingPrice,
      sellerCustomerId: params.customerId,
      sellerCustomerName: params.customerName,
      sellerPhone: params.customerPhone,
      purchaseDate: timestamp,
      status: 'in_inventory',
      notes: params.notes,
      createdAt: timestamp,
    };

    // Record trade transaction
    const transaction: BuySellTransaction = {
      id: `bstx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'purchase',
      itemId,
      itemName: params.name.trim(),
      category: params.category,
      condition: params.condition,
      serialNumber: params.serialNumber?.trim() || undefined,
      customerId: params.customerId,
      customerName: params.customerName,
      customerPhone: params.customerPhone,
      amount: params.purchasePrice,
      purchaseCost: params.purchasePrice,
      profit: 0,
      paymentMethod: params.paymentMethod,
      paymentStatus: 'paid',
      notes: params.notes || `Purchased from customer: ${params.name}`,
      timestamp,
      recordedBy: currentUser?.name || 'Staff Member',
    };

    // Record payment payout (money going out to customer for purchase)
    const paymentTx: PaymentTransaction = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'buy_sell_purchase',
      referenceId: itemId,
      referenceTitle: `Buy Item: ${params.name} (${params.condition})`,
      customerId: params.customerId,
      customerName: params.customerName,
      amount: params.purchasePrice,
      method: params.paymentMethod,
      status: 'paid',
      notes: `Payout to customer for selling ${params.name}`,
      timestamp,
      recordedBy: currentUser?.name || 'Staff Member',
    };

    const updatedDb: CafeDatabase = {
      ...db,
      buySellItems: [newItem, ...(db.buySellItems || [])],
      buySellTransactions: [transaction, ...(db.buySellTransactions || [])],
      payments: [paymentTx, ...(db.payments || [])],
    };

    return { updatedDb, item: newItem };
  }

  static sellItemToCustomer(
    params: {
      itemId: string;
      customerId: string;
      customerName: string;
      customerPhone?: string;
      sellingPrice: number;
      paymentMethod: PaymentMethod;
      notes?: string;
    },
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): { updatedDb: CafeDatabase; transaction: BuySellTransaction } {
    const item = (db.buySellItems || []).find((i) => i.id === params.itemId);
    if (!item) {
      throw new Error('Item not found in inventory.');
    }
    if (item.status === 'sold') {
      throw new Error(`Item "${item.name}" is already sold.`);
    }

    const profit = Math.round(params.sellingPrice - item.purchasePrice);
    const timestamp = new Date().toISOString();
    const invoiceNumber = `INV-BS-${Date.now().toString().slice(-6)}`;

    const updatedItem: BuySellItem = {
      ...item,
      status: 'sold',
      soldAt: timestamp,
      soldPrice: params.sellingPrice,
      buyerCustomerId: params.customerId,
      buyerCustomerName: params.customerName,
      buyerPhone: params.customerPhone,
      profit,
      invoiceNumber,
      paymentMethod: params.paymentMethod,
      notes: params.notes ? `${item.notes ? item.notes + ' | ' : ''}${params.notes}` : item.notes,
    };

    const transaction: BuySellTransaction = {
      id: `bstx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'sale',
      itemId: item.id,
      itemName: item.name,
      category: item.category,
      condition: item.condition,
      serialNumber: item.serialNumber,
      customerId: params.customerId,
      customerName: params.customerName,
      customerPhone: params.customerPhone,
      amount: params.sellingPrice,
      purchaseCost: item.purchasePrice,
      profit,
      paymentMethod: params.paymentMethod,
      paymentStatus: 'paid',
      notes: params.notes || `Sold to customer. Profit: ₹${profit}`,
      timestamp,
      recordedBy: currentUser?.name || 'Staff Member',
    };

    const paymentTx: PaymentTransaction = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'buy_sell_sale',
      referenceId: item.id,
      referenceTitle: `Sold Item: ${item.name} (${item.category})`,
      customerId: params.customerId,
      customerName: params.customerName,
      amount: params.sellingPrice,
      method: params.paymentMethod,
      status: 'paid',
      notes: `Revenue from selling ${item.name}. Net Profit: ₹${profit}`,
      timestamp,
      recordedBy: currentUser?.name || 'Staff Member',
    };

    const updatedItems = (db.buySellItems || []).map((i) =>
      i.id === item.id ? updatedItem : i
    );

    const updatedCustomers = (db.customers || []).map((c) => {
      if (c.id === params.customerId) {
        return {
          ...c,
          totalSpent: (c.totalSpent || 0) + params.sellingPrice,
        };
      }
      return c;
    });

    const updatedDb: CafeDatabase = {
      ...db,
      buySellItems: updatedItems,
      buySellTransactions: [transaction, ...(db.buySellTransactions || [])],
      payments: [paymentTx, ...(db.payments || [])],
      customers: updatedCustomers,
    };

    return { updatedDb, transaction };
  }

  static updateBuySellItem(
    id: string,
    updates: Partial<BuySellItem>,
    db: CafeDatabase
  ): CafeDatabase {
    const updatedItems = (db.buySellItems || []).map((i) => {
      if (i.id === id) {
        return { ...i, ...updates };
      }
      return i;
    });
    return { ...db, buySellItems: updatedItems };
  }

  static deleteBuySellItem(id: string, db: CafeDatabase): CafeDatabase {
    return {
      ...db,
      buySellItems: (db.buySellItems || []).filter((i) => i.id !== id),
    };
  }

  /**
   * REPAIR TRACKING
   */
  static createRepairRecord(
    params: {
      customerId: string;
      customerName: string;
      customerPhone: string;
      itemName: string;
      category: RepairCategory;
      repairId?: string;
      serialNumber?: string;
      problemDescription: string;
      expectedCompletionDate?: string;
      technicianName?: string;
      repairCost?: number;
      customerCharge: number;
      advancePayment?: number;
      paymentMethod?: PaymentMethod;
      notes?: string;
    },
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): { updatedDb: CafeDatabase; repair: RepairRecord } {
    const repairNumber = this.generateRepairNumber(db.repairRecords || []);
    const repairId = params.repairId || `rep_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const timestamp = new Date().toISOString();

    const advance = Math.max(0, params.advancePayment || 0);
    const charge = Math.max(0, params.customerCharge || 0);
    const pendingAmount = Math.max(0, charge - advance);
    const paymentStatus: PaymentStatus =
      advance >= charge && charge > 0
        ? 'paid'
        : advance > 0
        ? 'partial'
        : 'pending';

    const newRepair: RepairRecord = {
      id: repairId,
      repairId: params.repairId || repairId,
      repairNumber,
      customerId: params.customerId,
      customerName: params.customerName.trim(),
      customerPhone: params.customerPhone.trim(),
      itemName: params.itemName.trim(),
      category: params.category,
      serialNumber: params.serialNumber?.trim() || undefined,
      problemDescription: params.problemDescription.trim(),
      dateReceived: timestamp,
      expectedCompletionDate: params.expectedCompletionDate,
      technicianName: params.technicianName?.trim() || currentUser?.name || 'Lead Technician',
      repairCost: params.repairCost || 0,
      customerCharge: charge,
      advancePayment: advance,
      paidAmount: advance,
      pendingAmount,
      paymentStatus,
      paymentMethod: params.paymentMethod || 'cash',
      status: 'Received',
      notes: params.notes,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    let updatedPayments = db.payments || [];
    if (advance > 0) {
      const advancePaymentTx: PaymentTransaction = {
        id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: 'repair_advance',
        referenceId: repairId,
        referenceTitle: `Repair Advance: [${repairNumber}] ${params.itemName}`,
        customerId: params.customerId,
        customerName: params.customerName,
        amount: advance,
        method: params.paymentMethod || 'cash',
        status: paymentStatus,
        totalBill: charge,
        pendingAmount,
        notes: `Advance payment collected at intake for Repair #${repairNumber}`,
        timestamp,
        recordedBy: currentUser?.name || 'Staff Member',
      };
      updatedPayments = [advancePaymentTx, ...updatedPayments];
    }

    const updatedCustomers = (db.customers || []).map((c) => {
      if (c.id === params.customerId) {
        return {
          ...c,
          totalSpent: (c.totalSpent || 0) + advance,
          totalOutstanding: (c.totalOutstanding || 0) + pendingAmount,
        };
      }
      return c;
    });

    const updatedDb: CafeDatabase = {
      ...db,
      repairRecords: [newRepair, ...(db.repairRecords || [])],
      payments: updatedPayments,
      customers: updatedCustomers,
    };

    return { updatedDb, repair: newRepair };
  }

  static updateRepairRecord(
    id: string,
    updates: Partial<RepairRecord>,
    db: CafeDatabase
  ): CafeDatabase {
    const updatedRepairs = (db.repairRecords || []).map((r) => {
      if (r.id === id) {
        const updated = { ...r, ...updates, updatedAt: new Date().toISOString() };
        if (updates.customerCharge !== undefined || updates.paidAmount !== undefined) {
          const charge = updates.customerCharge !== undefined ? updates.customerCharge : r.customerCharge;
          const paid = updates.paidAmount !== undefined ? updates.paidAmount : r.paidAmount;
          updated.pendingAmount = Math.max(0, charge - paid);
          updated.paymentStatus = paid >= charge && charge > 0 ? 'paid' : paid > 0 ? 'partial' : 'pending';
        }
        return updated;
      }
      return r;
    });
    return { ...db, repairRecords: updatedRepairs };
  }

  static addRepairPayment(
    repairId: string,
    amount: number,
    paymentMethod: PaymentMethod,
    notes: string | undefined,
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): CafeDatabase {
    const repair = (db.repairRecords || []).find((r) => r.id === repairId);
    if (!repair) throw new Error('Repair record not found.');

    const newPaid = (repair.paidAmount || 0) + amount;
    const newPending = Math.max(0, repair.customerCharge - newPaid);
    const newStatus: PaymentStatus = newPaid >= repair.customerCharge ? 'paid' : 'partial';
    const timestamp = new Date().toISOString();

    const paymentTx: PaymentTransaction = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'repair_charge',
      referenceId: repair.id,
      referenceTitle: `Repair Payment: [${repair.repairNumber}] ${repair.itemName}`,
      customerId: repair.customerId,
      customerName: repair.customerName,
      amount,
      method: paymentMethod,
      status: newStatus,
      totalBill: repair.customerCharge,
      pendingAmount: newPending,
      notes: notes || `Payment for repair #${repair.repairNumber}`,
      timestamp,
      recordedBy: currentUser?.name || 'Staff Member',
    };

    const updatedRepairs = (db.repairRecords || []).map((r) =>
      r.id === repairId
        ? {
            ...r,
            paidAmount: newPaid,
            pendingAmount: newPending,
            paymentStatus: newStatus,
            updatedAt: timestamp,
          }
        : r
    );

    const updatedCustomers = (db.customers || []).map((c) => {
      if (c.id === repair.customerId) {
        return {
          ...c,
          totalSpent: (c.totalSpent || 0) + amount,
          totalOutstanding: Math.max(0, (c.totalOutstanding || 0) - amount),
        };
      }
      return c;
    });

    return {
      ...db,
      repairRecords: updatedRepairs,
      payments: [paymentTx, ...(db.payments || [])],
      customers: updatedCustomers,
    };
  }

  static deliverRepair(
    repairId: string,
    finalPayment: number | undefined,
    paymentMethod: PaymentMethod | undefined,
    notes: string | undefined,
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): CafeDatabase {
    let currentDb = db;
    if (finalPayment && finalPayment > 0 && paymentMethod) {
      currentDb = this.addRepairPayment(
        repairId,
        finalPayment,
        paymentMethod,
        `Final delivery settlement: ${notes || ''}`,
        currentDb,
        currentUser
      );
    }

    const timestamp = new Date().toISOString();
    const updatedRepairs = (currentDb.repairRecords || []).map((r) =>
      r.id === repairId
        ? {
            ...r,
            status: 'Delivered' as RepairStatus,
            deliveredAt: timestamp,
            actualCompletionDate: r.actualCompletionDate || timestamp,
            notes: notes ? `${r.notes ? r.notes + ' | ' : ''}Delivered: ${notes}` : r.notes,
            updatedAt: timestamp,
          }
        : r
    );

    return { ...currentDb, repairRecords: updatedRepairs };
  }

  static deleteRepairRecord(id: string, db: CafeDatabase): CafeDatabase {
    return {
      ...db,
      repairRecords: (db.repairRecords || []).filter((r) => r.id !== id),
    };
  }

  /**
   * CAFETERIA INVENTORY STOCK MOVEMENTS
   */
  static recordCafeteriaStockMovement(
    params: {
      itemId: string;
      type: StockMovementType;
      quantityChange: number;
      unitPrice?: number;
      supplier?: string;
      notes?: string;
    },
    db: CafeDatabase,
    currentUser: UserAccount | null
  ): CafeDatabase {
    const item = (db.cafeteriaItems || []).find((i) => i.id === params.itemId);
    if (!item) throw new Error('Cafeteria item not found.');

    const previousStock = item.stockQuantity;
    const newStock = Math.max(0, previousStock + params.quantityChange);
    const timestamp = new Date().toISOString();

    const log: CafeteriaStockLog = {
      id: `stk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      itemId: item.id,
      itemName: item.name,
      type: params.type,
      quantityChange: params.quantityChange,
      previousStock,
      newStock,
      unitPrice: params.unitPrice,
      supplier: params.supplier,
      notes: params.notes,
      recordedBy: currentUser?.name || 'Staff Member',
      timestamp,
    };

    const updatedItems = (db.cafeteriaItems || []).map((i) =>
      i.id === item.id
        ? {
            ...i,
            stockQuantity: newStock,
          }
        : i
    );

    return {
      ...db,
      cafeteriaItems: updatedItems,
      cafeteriaStockLogs: [log, ...(db.cafeteriaStockLogs || [])],
    };
  }
}
