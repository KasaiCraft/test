export const NEXTGEN_CAFE_BUSINESS_ID = 'nextgen_gaming_cafe';
export const MAX_WORKERS_ALLOWED = 5;

export type UserRole = 'admin' | 'worker';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  businessId?: string;
  ownerId?: string;
  pin: string; // 4-digit PIN / staff code
  accessCode?: string; // Explicit staff access code set by Admin
  password?: string; // Terminal login password set by Owner/Admin
  phone?: string;
  createdAt: string;
  lastLogin?: string;
  status: 'active' | 'inactive';
}

export interface TenantInfo {
  businessId: string;
  role: UserRole;
  name: string;
  email: string;
  ownerEmail?: string;
  ownerId?: string;
  businessName?: string;
}

export interface WorkerMembership {
  workerEmail: string;
  businessId: string;
  workerId: string;
  workerName: string;
  role: 'worker';
  ownerEmail: string;
  ownerId?: string;
  createdAt: string;
  password?: string;
  pin?: string;
  accessCode?: string;
  phone?: string;
}

export type ConsoleType =
  | 'PS5'
  | 'PS4'
  | 'PS4 Pro'
  | 'Xbox Series X'
  | 'Xbox Series S'
  | 'Xbox One'
  | 'PC Gaming'
  | 'Gaming PC Ultra'
  | 'VR Station'
  | 'Nintendo Switch'
  | 'Sim Racing'
  | 'Racing Simulator'
  | 'Retro Arcade'
  | 'Other';

export type ConsoleStatus = 'available' | 'in_use' | 'occupied' | 'maintenance' | 'disabled';

export interface CustomPricingTier {
  hours: number;
  price: number;
  playerPrices?: { [playerCount: number]: number }; // Optional: price override per player count
}

export interface ConsoleDevice {
  id: string;
  businessId?: string;
  code: string; // e.g. "PS5-01", "PC-04"
  name: string;
  type: ConsoleType;
  hourlyRate: number; // 1-hr base rate (retained for backward compatibility)
  price1Hour?: number; // 1-hour custom price (usually same as hourlyRate)
  price2Hour?: number; // 2-hour custom package price
  price3Hour?: number; // 3-hour custom package price
  customPricing?: CustomPricingTier[]; // Custom hours & custom value tiers
  
  // Player-based pricing configuration (1-4 players)
  playerPricing?: {
    [hours: number]: { [playerCount: number]: number };
  };
  
  status: ConsoleStatus;
  currentSessionId?: string | null;
  specifications?: string;
  specs?: string;
  location?: string;
  notes?: string;
  createdAt: string;
}

export type GamingConsole = ConsoleDevice;

export type PaymentStatus = 'paid' | 'partial' | 'pending';
export type PaymentMethod = 'cash' | 'upi' | 'card' | 'other' | 'split';

export interface PaymentSplitItem {
  method: 'cash' | 'upi' | 'card' | 'other';
  amount: number;
  notes?: string;
}

export interface GamingSession {
  id: string;
  businessId?: string;
  consoleId: string;
  consoleCode: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  startTime: string; // ISO timestamp
  endTime: string | null; // ISO timestamp when finished
  scheduledEndTime?: string | null; // ISO timestamp when preset duration finishes
  presetDurationMinutes?: number | null; // e.g. 30, 60, 90, 120, or custom minutes
  durationMinutes: number; // calculated on stop or live
  playerCount?: number; // Added for PS4/PS5 player-based pricing
  ratePerHour: number; // Locked rate at session start
  isRateOverridden?: boolean; // True when special rate override was entered by admin
  baseAmount: number;
  initialBaseAmount?: number; // Base amount before extensions for tracking breakdown
  extensionCharges?: number; // Cumulative extension cost added across all extensions
  discountAmount: number;
  extraCharges: number;
  totalAmount: number;
  paidAmount: number;
  paymentStatus: PaymentStatus;
  paymentMethod?: PaymentMethod | null;
  splitPayments?: PaymentSplitItem[];
  status: 'active' | 'paused' | 'completed' | 'cancelled';
  isPaused?: boolean;
  pausedAt?: string | null;
  totalPausedMinutes?: number;
  usedCreditMinutes?: number; // Minutes consumed from customer's unused credit balance
  creditMinutesGenerated?: number; // Unused prepaid minutes converted to credit
  notes?: string;
  voucherId?: string; // Track voucher used for this session
  workerId: string;
  workerName: string;
  createdAt: string;
}

export interface SessionAlert {
  id: string;
  sessionId: string;
  consoleCode: string;
  customerName: string;
  endedAt: string;
  durationMinutes: number;
  totalAmount: number;
}

export interface Customer {
  id: string;
  businessId?: string;
  name: string;
  phone: string;
  email?: string;
  membershipId?: string;
  aadhaarNumber?: string;
  aadhaarVerified?: boolean;
  address?: string;
  notes?: string;
  createdAt: string;
  totalVisits: number;
  totalSpent: number;
  totalOutstanding: number;
  unusedMinutesBalance?: number; // Total accumulated unused time in minutes
  lastVisited?: string;
}

export type RentalCategory =
  | 'PS5'
  | 'PS4'
  | 'Controllers'
  | 'Games'
  | 'Controller'
  | 'VR Headset'
  | 'Headphones'
  | 'Racing Wheel'
  | 'Accessory'
  | 'Console'
  | 'Game Disc'
  | 'Other';

export type RentalItemStatus =
  | 'available'
  | 'rented'
  | 'returned'
  | 'maintenance'
  | 'lost'
  | 'damaged'
  | 'low_stock'
  | 'out_of_stock';

export type EquipmentCondition = 'New' | 'Mint' | 'Good' | 'Fair' | 'Needs Maintenance' | 'Damaged';

export interface RentalItem {
  id: string;
  businessId?: string;
  name: string;
  category: RentalCategory;
  serialNumber?: string; // Unique ID / serial number for physical tracking
  condition?: EquipmentCondition;
  totalQuantity: number;
  availableQuantity: number;
  rentedQuantity: number;
  hourlyRate: number;
  dailyRate: number;
  securityDeposit: number;
  description?: string;
  image?: string;
  status: RentalItemStatus;
  notes?: string;
  createdAt?: string;
}

export type RentalStatus = 'active' | 'returned' | 'overdue' | 'cancelled';
export type RentalPeriodType = 'hourly' | 'daily';

export interface RentalRecord {
  id: string;
  businessId?: string;
  rentalItemId: string;
  rentalItemName: string;
  serialNumber?: string;
  conditionAtRental?: string;
  conditionAtReturn?: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAadhaar?: string;
  aadhaarCollected?: boolean;
  customerAddress?: string;
  quantity: number;
  periodType: RentalPeriodType;
  startTime: string; // ISO
  expectedReturnTime: string; // ISO
  actualReturnTime?: string | null;
  rentalFee: number;
  depositAmount: number;
  depositRefunded: number;
  damageDeduction: number;
  lateFee: number;
  additionalCharges?: number;
  totalPaid: number;
  paidAmount?: number;
  durationUnits?: number;
  rateApplied?: number;
  totalBill?: number;
  pendingAmount?: number;
  rentedAt?: string;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  splitPayments?: PaymentSplitItem[];
  status: RentalStatus;
  notes?: string;
  workerId: string;
  workerName: string;
  createdAt: string;
  isStandardRental?: boolean;
  standardConsole?: 'PS4' | 'PS5';
}

export type CafeteriaCategory =
  | 'Snacks'
  | 'Beverages'
  | 'Fast Food'
  | 'Energy Drinks'
  | 'Desserts'
  | 'Combos'
  | 'Other';

export interface CafeteriaItem {
  id: string;
  businessId?: string;
  name: string;
  category: CafeteriaCategory;
  sku?: string;
  costPrice?: number; // Purchase / wholesale price
  price: number; // Selling price
  stockQuantity: number;
  minStockLevel?: number; // Low stock alert threshold (default 5)
  supplier?: string;
  unit?: string; // e.g. "Can", "Bottle", "Packet", "Plate", "Pc"
  expiryDate?: string;
  isAvailable: boolean;
  description?: string;
  image?: string;
  createdAt: string;
}

export type StockMovementType = 'stock_in' | 'stock_out' | 'sale' | 'wastage' | 'adjustment';

export interface CafeteriaStockLog {
  id: string;
  businessId?: string;
  itemId: string;
  itemName: string;
  type: StockMovementType;
  quantityChange: number; // e.g. +10 or -2
  previousStock: number;
  newStock: number;
  unitPrice?: number;
  supplier?: string;
  notes?: string;
  recordedBy: string;
  timestamp: string; // ISO
}

export interface CafeteriaOrderItem {
  itemId: string;
  name: string;
  itemName?: string; // Legacy field
  category: CafeteriaCategory;
  unitPrice: number;
  price?: number; // Legacy field
  quantity: number;
  totalPrice: number;
}

export interface CafeteriaOrder {
  id: string;
  businessId?: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  items: CafeteriaOrderItem[];
  subtotal: number;
  discountAmount: number;
  totalAmount: number;
  finalAmount?: number; // Legacy field
  paidAmount: number;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  splitPayments?: PaymentSplitItem[];
  status: 'completed' | 'cancelled';
  notes?: string;
  workerId: string;
  workerName: string;
  createdAt: string; // ISO
}

// ==========================================
// MODULE 2: VOUCHER MANAGEMENT
// ==========================================
export type VoucherCategory = 'All' | 'all' | 'PS4' | 'PS5' | 'PC' | 'Driving Simulator' | 'Streaming Room';
export type VoucherStatus = 'active' | 'used' | 'expired' | 'disabled' | 'running' | 'paused';

export interface Voucher {
  id: string;
  businessId?: string;
  code?: string; // e.g. "VOUCH-PS5-2H" or custom code
  name: string; // e.g. "2-Hour PS5 Gaming Pass"
  category: VoucherCategory;
  type?: 'time' | 'value' | 'discount_percentage';
  durationMinutes: number; // Duration grant in minutes (e.g. 60, 120, 180, 420)
  totalPurchasedHours?: number; // Total Purchased Hours (e.g. 7)
  usedHours?: number; // Total Used Hours (e.g. 5)
  remainingHours?: number; // Total Remaining Hours (e.g. 2)
  usedMinutes?: number; // Duration in minutes used
  remainingMinutes?: number; // Duration in minutes remaining
  
  // Real-time tracking fields
  startedAt?: string | null;   // ISO timestamp when first started
  pausedAt?: string | null;    // ISO timestamp when last paused
  resumedAt?: string | null;   // ISO timestamp when last resumed
  lastCalculatedAt?: string | null; // ISO timestamp of last consumption check
  totalVoucherDuration?: number; // Minutes
  consumedDuration?: number;    // Minutes consumed so far
  remainingDuration?: number;   // Minutes remaining
  
  purchaseDate?: string; // Purchase date (ISO or YYYY-MM-DD)
  price: number; // Selling price to customer
  valueAmount?: number; // Face value / discount if applicable
  expiryDate: string; // ISO string date or 'never'
  status: VoucherStatus;
  usageLimit: number; // Max times voucher can be redeemed (default 1)
  usedCount: number; // Number of times used
  notes?: string;
  assignedCustomerId?: string; // Optional: customer who purchased/holds it
  assignedCustomerName?: string;
  assignedCustomerPhone?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface VoucherUsage {
  id: string;
  businessId?: string;
  voucherId: string;
  voucherCode: string;
  voucherName: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  sessionId?: string; // If redeemed during a session
  consoleCode?: string;
  durationUsedMinutes: number;
  valueDiscountApplied: number;
  usedAt: string; // ISO
  recordedBy: string;
  notes?: string;
}

// ==========================================
// MODULE 4: BUY & SELL MANAGEMENT
// ==========================================
export type BuySellCategory =
  | 'PS4'
  | 'PS5'
  | 'Controllers'
  | 'Games'
  | 'Accessories'
  | 'Other Equipment';

export type BuySellCondition = 'New' | 'Used / Pre-owned' | 'Refurbished';
export type BuySellItemStatus = 'in_inventory' | 'sold' | 'reserved';

export interface BuySellItem {
  id: string;
  businessId?: string;
  name: string;
  category: BuySellCategory;
  condition: BuySellCondition;
  serialNumber?: string;
  purchasePrice: number; // Business purchase cost
  suggestedSellingPrice: number;
  sellerCustomerId?: string; // Customer who sold it to the business
  sellerCustomerName?: string;
  sellerPhone?: string;
  purchaseDate: string; // ISO
  status: BuySellItemStatus;
  notes?: string;
  createdAt: string;

  // Populated when sold to customer
  soldAt?: string;
  soldPrice?: number;
  buyerCustomerId?: string;
  buyerCustomerName?: string;
  buyerPhone?: string;
  profit?: number; // soldPrice - purchasePrice
  invoiceNumber?: string;
  paymentMethod?: PaymentMethod;
}

export interface BuySellTransaction {
  id: string;
  businessId?: string;
  type: 'purchase' | 'sale'; // 'purchase' = bought from customer, 'sale' = sold to customer
  itemId: string;
  itemName: string;
  category: BuySellCategory;
  condition: BuySellCondition;
  serialNumber?: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  amount: number; // Billed selling price or purchase payout
  purchaseCost?: number; // Base purchase cost
  profit?: number; // Automatically calculated (amount - purchaseCost)
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  notes?: string;
  timestamp: string; // ISO
  recordedBy: string;
}

// ==========================================
// MODULE 5: REPAIR TRACKING
// ==========================================
export type RepairCategory =
  | 'PS4'
  | 'PS5'
  | 'Controllers'
  | 'Games'
  | 'Other Equipment';

export type RepairStatus =
  | 'Received'
  | 'Diagnosing'
  | 'Waiting for Parts'
  | 'Under Repair'
  | 'Ready'
  | 'Delivered'
  | 'Cancelled';

export interface RepairRecord {
  id: string;
  businessId?: string;
  repairNumber: string; // e.g. "REP-101"
  repairId: string; // New: Unique ID for the repair
  customerId: string;
  customerName: string;
  customerPhone: string;
  itemName: string;
  deviceType?: string; // Legacy
  category: RepairCategory;
  serialNumber?: string;
  problemDescription: string;
  faultDescription?: string; // Legacy
  dateReceived: string; // ISO
  expectedCompletionDate?: string; // ISO
  actualCompletionDate?: string;
  technicianName?: string;
  technician?: string; // Legacy
  repairCost: number; // Internal business / parts cost
  estimatedCost?: number; // Legacy
  finalCost?: number; // Legacy
  customerCharge: number; // Total billed charge to customer
  advancePayment: number; // Advance collected at intake
  paidAmount: number; // Total paid so far (advance + subsequent)
  pendingAmount: number; // customerCharge - paidAmount
  paymentStatus: PaymentStatus;
  paymentMethod?: PaymentMethod;
  status: RepairStatus;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
  deliveredAt?: string;
}

export type TransactionType =
  | 'gaming_session'
  | 'rental_fee'
  | 'cafeteria_order'
  | 'security_deposit'
  | 'deposit_refund'
  | 'late_fee'
  | 'direct_payment'
  | 'voucher_sale'
  | 'buy_sell_sale'
  | 'buy_sell_purchase'
  | 'repair_advance'
  | 'repair_charge';

export interface PaymentTransaction {
  id: string;
  businessId?: string;
  type: TransactionType;
  referenceId: string; // Session ID, Rental ID, Cafeteria Order ID, or custom
  referenceTitle: string; // e.g. "Console PS5-01 Session" or "DualSense Edge Rental"
  customerId: string;
  customerName: string;
  amount: number; // Actual amount collected
  method: PaymentMethod;
  status: PaymentStatus;
  notes?: string;
  timestamp: string; // ISO
  recordedBy: string; // Worker name / Admin
  splitDetails?: PaymentSplitItem[];
  totalBill?: number; // Total billed amount
  pendingAmount?: number; // Remaining unpaid amount
}

export interface SettlePaymentParams {
  type: 'gaming_session' | 'rental_fee' | 'cafeteria_order' | 'direct_payment' | 'session' | 'rental' | 'cafeteria';
  referenceId: string;
  transactionId?: string;
  customerId: string;
  customerName: string;
  amountPaid: number;
  paymentMethod: PaymentMethod;
  splitPayments?: PaymentSplitItem[];
  notes?: string;
}

export interface ResetOptions {
  wipeStations?: boolean;
  wipeRentalGear?: boolean;
  wipeCafeteriaItems?: boolean;
}

export interface CafeSettings {
  businessId?: string;
  ownerId?: string;
  ownerEmail?: string;
  cafeName: string;
  tagline: string;
  phone: string;
  email: string;
  address: string;
  currencySymbol: string;
  taxRatePercent: number;
  minGamingTimeMinutes: number;
  roundingIncrementMinutes: number; // e.g. 15 mins rounding
  autoSyncGoogleDrive: boolean;
  googleDriveSyncIntervalMinutes: number;
  googleDriveFolderId?: string;
  googleDriveFileId?: string;
  lastSyncedAt?: string;
  lastResetAt?: string;
  adminAccessCode?: string; // Access code for Administrator Panel (fixed: "756569")
  staffAccessCode?: string; // Legacy fallback; active staff codes are assigned per worker in Staff Management
  deletedConsoleIds?: string[];
}

export type NoticePriority = 'info' | 'important' | 'urgent';

export type NoticeCategory =
  | 'general'
  | 'rates_pricing'
  | 'inventory_consoles'
  | 'system_reset'
  | 'rules_policy'
  | 'cafeteria'
  | 'rentals'
  | 'maintenance';

export interface AdminNotice {
  id: string;
  businessId: string;
  title: string;
  message: string;
  category: NoticeCategory;
  priority: NoticePriority;
  authorName: string;
  authorRole: 'admin';
  createdAt: string;
  isPinned?: boolean;
  acknowledgedBy?: string[]; // user IDs of staff who have read/acknowledged
}

export interface CafeDatabase {
  version: number;
  businessId?: string;
  ownerId?: string;
  ownerEmail?: string;
  lastModified: string;
  lastResetAt?: string;
  settings: CafeSettings;
  users: UserAccount[];
  consoles: ConsoleDevice[];
  sessions: GamingSession[];
  customers: Customer[];
  rentalItems: RentalItem[];
  rentalRecords: RentalRecord[];
  cafeteriaItems: CafeteriaItem[];
  cafeteriaOrders: CafeteriaOrder[];
  cafeteriaStockLogs?: CafeteriaStockLog[];
  vouchers: Voucher[];
  voucherUsages: VoucherUsage[];
  buySellItems: BuySellItem[];
  buySellTransactions: BuySellTransaction[];
  repairRecords: RepairRecord[];
  payments: PaymentTransaction[];
  notices?: AdminNotice[];
  deletedConsoleIds?: string[];
  deletedRepairIds?: string[];
  deletedVoucherIds?: string[];
  deletedUserIds?: string[];
}

export interface DriveSyncState {
  status: 'synced' | 'syncing' | 'error' | 'local_only' | 'no_connection';
  lastSyncedAt: string | null;
  errorMessage: string | null;
  isConnected: boolean;
  userEmail: string | null;
  userName: string | null;
  userPhoto: string | null;
  folderId: string | null;
  fileId: string | null;
}

export type NavigationTab =
  | 'dashboard'
  | 'worker-panel'
  | 'consoles'
  | 'vouchers'
  | 'rentals'
  | 'buysell'
  | 'repairs'
  | 'cafeteria'
  | 'customers'
  | 'payments'
  | 'reports'
  | 'datacenter'
  | 'workers'
  | 'settings';

export type ActiveView = NavigationTab;
