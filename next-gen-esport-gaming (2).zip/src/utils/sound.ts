/**
 * Web Audio Synthesizer for Gaming Cafe Alerts & Chimes
 * Plays crisp, pleasant harmonic chimes without needing external MP3/WAV files.
 */

let sharedAudioContext: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!sharedAudioContext) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        sharedAudioContext = new AudioCtx();
      }
    }
    if (sharedAudioContext && sharedAudioContext.state === 'suspended') {
      sharedAudioContext.resume().catch(() => {});
    }
    return sharedAudioContext;
  } catch {
    return null;
  }
}

/**
 * Play a bright, friendly multi-tone chime when a gaming session completes
 */
export function playSessionEndChime(): void {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    // Harmonic arpeggio: C5 (523.25), E5 (659.25), G5 (783.99), C6 (1046.50)
    const tones = [523.25, 659.25, 783.99, 1046.50];
    const startTime = ctx.currentTime + 0.05;

    tones.forEach((freq, i) => {
      const noteStart = startTime + i * 0.12;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteStart);

      // Smooth attack and exponential decay
      gain.gain.setValueAtTime(0.0001, noteStart);
      gain.gain.linearRampToValueAtTime(0.25, noteStart + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + 0.5);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(noteStart);
      osc.stop(noteStart + 0.55);
    });

    // Add a secondary soft sub-harmonic bell
    const finalBellOsc = ctx.createOscillator();
    const finalBellGain = ctx.createGain();
    const finalStart = startTime + 0.36;

    finalBellOsc.type = 'triangle';
    finalBellOsc.frequency.setValueAtTime(1046.50, finalStart);

    finalBellGain.gain.setValueAtTime(0.0001, finalStart);
    finalBellGain.gain.linearRampToValueAtTime(0.18, finalStart + 0.03);
    finalBellGain.gain.exponentialRampToValueAtTime(0.0001, finalStart + 0.8);

    finalBellOsc.connect(finalBellGain);
    finalBellGain.connect(ctx.destination);

    finalBellOsc.start(finalStart);
    finalBellOsc.stop(finalStart + 0.85);
  } catch (err) {
    console.warn('Session end chime audio unavailable:', err);
  }
}
