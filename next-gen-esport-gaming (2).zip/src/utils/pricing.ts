import { ConsoleDevice } from '../types';
import { getGamingPrice, getFixedStationType, GAMING_PRICING, FixedStationType } from '../data/gamingPricing';

export interface PricingTierInfo {
  hours: number;
  minutes: number;
  price: number;
  isCustom: boolean;
  label: string;
}

/**
 * Returns all configured pricing tiers for a station, sorted by minutes ascending.
 * - For PS5, PS4, Driving Simulator/G29, and PS VR: uses fixed pricing charts.
 * - For all other stations (PC Station, Custom, etc.): ADMIN CONFIGURED PRICE IS THE SOURCE OF TRUTH.
 */
export function getConsolePricingTiers(consoleItem?: Partial<ConsoleDevice> | null, playerCount: number = 1): PricingTierInfo[] {
  if (!consoleItem) return [];

  const fixedType = getFixedStationType(consoleItem.type);

  // CASE 1: FIXED CHART STATIONS (PS5, PS4, G29, VR)
  if (fixedType) {
    // 1. Check custom player-based pricing override if explicitly defined
    if (consoleItem.playerPricing && Object.keys(consoleItem.playerPricing).length > 0) {
      const tiers: PricingTierInfo[] = [];
      [1, 2, 3].forEach((h) => {
        const p = consoleItem.playerPricing?.[h]?.[playerCount] ?? getGamingPrice(fixedType, h * 60, playerCount);
        if (p > 0) {
          tiers.push({
            hours: h,
            minutes: h * 60,
            price: p,
            isCustom: false,
            label: `${h} Hr`,
          });
        }
      });
      return tiers.sort((a, b) => a.minutes - b.minutes);
    }

    const chart = GAMING_PRICING[fixedType];
    const tiers: PricingTierInfo[] = [];

    if (fixedType === 'PS5' || fixedType === 'PS4') {
      [1, 2, 3].forEach((h) => {
        const mins = h * 60;
        const p = getGamingPrice(fixedType, mins, playerCount);
        if (p > 0) {
          tiers.push({
            hours: h,
            minutes: mins,
            price: p,
            isCustom: false,
            label: `${h} Hr`,
          });
        }
      });
    } else if (fixedType === 'G29') {
      [30, 60, 120, 180].forEach((mins) => {
        const p = chart[mins];
        if (typeof p === 'number' && p > 0) {
          tiers.push({
            hours: mins / 60,
            minutes: mins,
            price: p,
            isCustom: false,
            label: mins >= 60 ? `${mins / 60} Hr` : `${mins} Min`,
          });
        }
      });
    } else if (fixedType === 'VR') {
      [15, 30, 45, 60].forEach((mins) => {
        const p = chart[mins];
        if (typeof p === 'number' && p > 0) {
          tiers.push({
            hours: mins / 60,
            minutes: mins,
            price: p,
            isCustom: false,
            label: mins >= 60 ? `${mins / 60} Hr` : `${mins} Min`,
          });
        }
      });
    }

    return tiers.sort((a, b) => a.minutes - b.minutes);
  }

  // CASE 2: ALL OTHER STATIONS (PC Station, Custom Station, etc.)
  // ADMIN CONFIGURED PRICE = FINAL PRICE SOURCE OF TRUTH
  const adminHourlyRate = Number(consoleItem.hourlyRate ?? consoleItem.price1Hour) || 0;
  const tiers: PricingTierInfo[] = [];

  const getPriceForHour = (h: number): number => {
    // 1. Admin configured playerPricing on station
    if (consoleItem.playerPricing?.[h]?.[playerCount]) {
      return consoleItem.playerPricing[h][playerCount];
    }
    // 2. Specific hour pricing configured by Admin
    if (h === 1) return Number(consoleItem.price1Hour ?? adminHourlyRate) || adminHourlyRate;
    if (h === 2) return Number(consoleItem.price2Hour ?? (adminHourlyRate * 2)) || (adminHourlyRate * 2);
    if (h === 3) return Number(consoleItem.price3Hour ?? (adminHourlyRate * 3)) || (adminHourlyRate * 3);
    return Math.round(adminHourlyRate * h);
  };

  [1, 2, 3].forEach((h) => {
    const p = getPriceForHour(h);
    if (p > 0) {
      tiers.push({
        hours: h,
        minutes: h * 60,
        price: p,
        isCustom: false,
        label: `${h} Hr`,
      });
    }
  });

  // Custom tiers configured by Admin on this station (e.g. 4h, 5h, etc.)
  if (Array.isArray(consoleItem.customPricing)) {
    for (const cp of consoleItem.customPricing) {
      if (cp && cp.hours > 0 && cp.price > 0) {
        if (!tiers.some((t) => t.hours === cp.hours)) {
          tiers.push({
            hours: cp.hours,
            minutes: Math.round(cp.hours * 60),
            price: cp.price,
            isCustom: true,
            label: `${cp.hours} Hr`,
          });
        }
      }
    }
  }

  return tiers.sort((a, b) => a.minutes - b.minutes);
}

export interface CalculatedPricingResult {
  baseAmount: number;
  effectiveRatePerHour: number;
  appliedTierLabel: string;
}

/**
 * Calculates session pricing:
 * - For PS5, PS4, Driving Simulator / G29, and PS VR: uses exact fixed chart pricing.
 * - For ALL other stations (PC Station, Custom, etc.): ADMIN CONFIGURED PRICE = FINAL PRICE SOURCE.
 *   Never falls back to PS4/PS5/VR/G29 or hardcoded ₹50/₹100/₹150.
 */
export function calculateStationPricing(
  consoleItem: Partial<ConsoleDevice> | null | undefined,
  durationMinutes: number,
  fallbackRatePerHour?: number,
  playerCount: number = 1
): CalculatedPricingResult {
  const safeMins = Math.max(1, durationMinutes);
  const hours = safeMins / 60;

  const fixedType = getFixedStationType(consoleItem?.type);

  // 1. FIXED CHART STATIONS (PS5, PS4, G29, VR)
  if (fixedType) {
    // If Admin set an explicit custom playerPricing override on this specific station, check it
    if (consoleItem?.playerPricing?.[hours]?.[playerCount]) {
      const overridePrice = consoleItem.playerPricing[hours][playerCount];
      return {
        baseAmount: overridePrice,
        effectiveRatePerHour: Math.round(overridePrice / hours),
        appliedTierLabel: `${consoleItem.type || fixedType} - ${safeMins}m (${playerCount}P)`,
      };
    }

    const price = getGamingPrice(fixedType, safeMins, playerCount);
    const effectiveRate = Math.round(price / hours);
    return {
      baseAmount: price,
      effectiveRatePerHour: effectiveRate,
      appliedTierLabel: `${consoleItem?.type || fixedType} - ${safeMins}m (${playerCount}P)`,
    };
  }

  // 2. ALL OTHER STATIONS (PC Station, Custom Station, etc.)
  // ADMIN CONFIGURED PRICE IS THE SOLE SOURCE OF TRUTH
  const adminHourlyRate = Number(consoleItem?.hourlyRate ?? consoleItem?.price1Hour ?? fallbackRatePerHour) || 0;

  // Check custom player pricing if configured by Admin
  if (consoleItem?.playerPricing?.[hours]?.[playerCount]) {
    const pPrice = consoleItem.playerPricing[hours][playerCount];
    return {
      baseAmount: pPrice,
      effectiveRatePerHour: Math.round(pPrice / hours),
      appliedTierLabel: `${consoleItem?.code || 'Station'} - ${safeMins}m (${playerCount}P)`,
    };
  }

  const tiers = getConsolePricingTiers(consoleItem, playerCount);

  // Exact tier match (e.g. 1h, 2h, 3h, custom package)
  const exactTier = tiers.find((t) => t.minutes === safeMins);
  if (exactTier) {
    return {
      baseAmount: exactTier.price,
      effectiveRatePerHour: Math.round(exactTier.price / (exactTier.minutes / 60)),
      appliedTierLabel: `${exactTier.label} Package`,
    };
  }

  // Under 1 Hour
  if (safeMins < 60) {
    const p1 = tiers.find((t) => t.hours === 1)?.price ?? adminHourlyRate;
    const base = Math.max(1, Math.round((safeMins / 60) * p1));
    return {
      baseAmount: base,
      effectiveRatePerHour: p1,
      appliedTierLabel: `${safeMins}m @ ₹${p1}/hr`,
    };
  }

  // Between tiers interpolation
  for (let i = 0; i < tiers.length - 1; i++) {
    const lower = tiers[i];
    const upper = tiers[i + 1];

    if (safeMins >= lower.minutes && safeMins <= upper.minutes) {
      const fraction = (safeMins - lower.minutes) / (upper.minutes - lower.minutes);
      const interpolatedPrice = lower.price + fraction * (upper.price - lower.price);
      return {
        baseAmount: Math.round(interpolatedPrice),
        effectiveRatePerHour: Math.round((interpolatedPrice / safeMins) * 60),
        appliedTierLabel: `${lower.label} - ${upper.label} Tier`,
      };
    }
  }

  // Beyond highest tier
  if (tiers.length > 0) {
    const highest = tiers[tiers.length - 1];
    if (safeMins > highest.minutes) {
      const excessMinutes = safeMins - highest.minutes;
      const highestHourly = highest.price / (highest.minutes / 60);
      const extraPrice = (excessMinutes / 60) * highestHourly;
      const total = Math.round(highest.price + extraPrice);
      return {
        baseAmount: total,
        effectiveRatePerHour: Math.round(highestHourly),
        appliedTierLabel: `${highest.label} + ${excessMinutes}m extra`,
      };
    }
  }

  // Direct calculation from Admin Hourly Rate
  const total = Math.max(1, Math.round((safeMins / 60) * adminHourlyRate));
  return {
    baseAmount: total,
    effectiveRatePerHour: adminHourlyRate,
    appliedTierLabel: `${safeMins}m @ ₹${adminHourlyRate}/hr`,
  };
}

