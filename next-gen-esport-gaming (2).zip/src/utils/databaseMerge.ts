import { CafeDatabase, CafeSettings, ConsoleDevice, GamingSession, Customer, RentalItem, RentalRecord, CafeteriaItem, CafeteriaOrder, PaymentTransaction, UserAccount, AdminNotice, Voucher } from '../types';

/**
 * Robust, deterministic merger for two versions of CafeDatabase.
 * Designed to handle concurrent edits safely so that neither Worker 1,
 * Worker 2, nor the Owner accidentally overwrites another's changes.
 */
export function mergeCafeDatabases(
  existingDb: CafeDatabase,
  incomingDb: CafeDatabase
): CafeDatabase {
  if (!existingDb) return incomingDb;
  if (!incomingDb) return existingDb;

  const businessId = incomingDb.businessId || existingDb.businessId || 'nextgen_gaming_cafe';

  const existingResetMs = (existingDb.lastResetAt || existingDb.settings?.lastResetAt)
    ? new Date(existingDb.lastResetAt || existingDb.settings?.lastResetAt!).getTime()
    : 0;
  const incomingResetMs = (incomingDb.lastResetAt || incomingDb.settings?.lastResetAt)
    ? new Date(incomingDb.lastResetAt || incomingDb.settings?.lastResetAt!).getTime()
    : 0;

  // Identify whether an authoritative reset has occurred on one side
  const incomingIsNewerReset = incomingResetMs > existingResetMs;
  const existingIsNewerReset = existingResetMs > incomingResetMs;
  const activeResetMs = Math.max(incomingResetMs, existingResetMs);

  // If one database performed a newer explicit reset/wipe, purge pre-reset items from the older database
  if (incomingIsNewerReset) {
    existingDb = {
      ...existingDb,
      consoles: (existingDb.consoles || []).filter((c) => c?.createdAt && new Date(c.createdAt).getTime() > incomingResetMs),
      rentalItems: (existingDb.rentalItems || []).filter((r) => r?.createdAt && new Date(r.createdAt).getTime() > incomingResetMs),
      cafeteriaItems: (existingDb.cafeteriaItems || []).filter((i) => i?.createdAt && new Date(i.createdAt).getTime() > incomingResetMs),
      sessions: (existingDb.sessions || []).filter((s) => s?.startTime && new Date(s.startTime).getTime() > incomingResetMs),
      customers: (existingDb.customers || []).filter((c) => c?.createdAt && new Date(c.createdAt).getTime() > incomingResetMs),
      rentalRecords: (existingDb.rentalRecords || []).filter((r) => r?.createdAt && new Date(r.createdAt).getTime() > incomingResetMs),
      cafeteriaOrders: (existingDb.cafeteriaOrders || []).filter((o) => o?.createdAt && new Date(o.createdAt).getTime() > incomingResetMs),
      payments: (existingDb.payments || []).filter((p) => p?.timestamp && new Date(p.timestamp).getTime() > incomingResetMs),
    };
  } else if (existingIsNewerReset) {
    incomingDb = {
      ...incomingDb,
      consoles: (incomingDb.consoles || []).filter((c) => c?.createdAt && new Date(c.createdAt).getTime() > existingResetMs),
      rentalItems: (incomingDb.rentalItems || []).filter((r) => r?.createdAt && new Date(r.createdAt).getTime() > existingResetMs),
      cafeteriaItems: (incomingDb.cafeteriaItems || []).filter((i) => i?.createdAt && new Date(i.createdAt).getTime() > existingResetMs),
      sessions: (incomingDb.sessions || []).filter((s) => s?.startTime && new Date(s.startTime).getTime() > existingResetMs),
      customers: (incomingDb.customers || []).filter((c) => c?.createdAt && new Date(c.createdAt).getTime() > existingResetMs),
      rentalRecords: (incomingDb.rentalRecords || []).filter((r) => r?.createdAt && new Date(r.createdAt).getTime() > existingResetMs),
      cafeteriaOrders: (incomingDb.cafeteriaOrders || []).filter((o) => o?.createdAt && new Date(o.createdAt).getTime() > existingResetMs),
      payments: (incomingDb.payments || []).filter((p) => p?.timestamp && new Date(p.timestamp).getTime() > existingResetMs),
    };
  }

  // 1. Merge Consoles & respect deleted station tombstones
  const deletedConsoleIds = new Set<string>([
    ...(Array.isArray(existingDb.deletedConsoleIds) ? existingDb.deletedConsoleIds : []),
    ...(Array.isArray(incomingDb.deletedConsoleIds) ? incomingDb.deletedConsoleIds : []),
    ...(Array.isArray((existingDb.settings as any)?.deletedConsoleIds) ? (existingDb.settings as any).deletedConsoleIds : []),
    ...(Array.isArray((incomingDb.settings as any)?.deletedConsoleIds) ? (incomingDb.settings as any).deletedConsoleIds : []),
  ]);

  const deletedVoucherIds = new Set<string>([
    ...(Array.isArray(existingDb.deletedVoucherIds) ? existingDb.deletedVoucherIds : []),
    ...(Array.isArray(incomingDb.deletedVoucherIds) ? incomingDb.deletedVoucherIds : []),
    ...(Array.isArray((existingDb.settings as any)?.deletedVoucherIds) ? (existingDb.settings as any).deletedVoucherIds : []),
    ...(Array.isArray((incomingDb.settings as any)?.deletedVoucherIds) ? (incomingDb.settings as any).deletedVoucherIds : []),
  ]);

  const deletedUserIds = new Set<string>([
    ...(Array.isArray(existingDb.deletedUserIds) ? existingDb.deletedUserIds : []),
    ...(Array.isArray(incomingDb.deletedUserIds) ? incomingDb.deletedUserIds : []),
    ...(Array.isArray((existingDb.settings as any)?.deletedUserIds) ? (existingDb.settings as any).deletedUserIds : []),
    ...(Array.isArray((incomingDb.settings as any)?.deletedUserIds) ? (incomingDb.settings as any).deletedUserIds : []),
  ]);

  const voucherMap = new Map<string, Voucher>();
  const baseVouchers = incomingIsNewerReset
    ? (incomingDb.vouchers || [])
    : (existingDb.vouchers || []);
  const secondaryVouchers = incomingIsNewerReset
    ? (existingDb.vouchers || [])
    : (incomingDb.vouchers || []);

  for (const v of baseVouchers) {
    if (v?.id && !deletedVoucherIds.has(v.id)) {
      voucherMap.set(v.id, { ...v, businessId });
    }
  }
  for (const v of secondaryVouchers) {
    if (!v?.id || deletedVoucherIds.has(v.id)) continue;
    if (!voucherMap.has(v.id)) {
      voucherMap.set(v.id, { ...v, businessId });
    }
  }

  const consoleMap = new Map<string, ConsoleDevice>();
  const baseConsoles = incomingIsNewerReset
    ? (incomingDb.consoles || [])
    : (existingDb.consoles || []);
  const secondaryConsoles = incomingIsNewerReset
    ? (existingDb.consoles || [])
    : (incomingDb.consoles || []);

  for (const c of baseConsoles) {
    if (c?.id && !deletedConsoleIds.has(c.id)) {
      consoleMap.set(c.id, { ...c, businessId });
    }
  }
  for (const c of secondaryConsoles) {
    if (!c?.id || deletedConsoleIds.has(c.id)) continue;
    const existing = consoleMap.get(c.id);
    if (!existing) {
      if (!activeResetMs || (c.createdAt && new Date(c.createdAt).getTime() > activeResetMs)) {
        consoleMap.set(c.id, { ...c, businessId });
      }
    } else {
      // If stations have different non-empty codes, they are distinct stations with a duplicate ID collision
      if (c.code && existing.code && c.code.trim().toUpperCase() !== existing.code.trim().toUpperCase()) {
        const remappedId = `${c.id}_${c.code.replace(/[^a-zA-Z0-9]/g, '')}`;
        if (!consoleMap.has(remappedId) && !deletedConsoleIds.has(remappedId)) {
          consoleMap.set(remappedId, { ...c, id: remappedId, businessId });
        }
      } else {
        consoleMap.set(c.id, {
          ...existing,
          ...c,
          businessId,
          hourlyRate: c.hourlyRate || existing.hourlyRate,
          price1Hour: c.price1Hour || existing.price1Hour || c.hourlyRate || existing.hourlyRate,
          price2Hour: c.price2Hour !== undefined ? c.price2Hour : existing.price2Hour,
          price3Hour: c.price3Hour !== undefined ? c.price3Hour : existing.price3Hour,
          customPricing: Array.isArray(c.customPricing) && c.customPricing.length > 0 ? c.customPricing : existing.customPricing,
          playerPricing: c.playerPricing || existing.playerPricing,
          status: c.status === 'in_use' ? 'in_use' : existing.status === 'in_use' && !c.currentSessionId ? existing.status : c.status,
          currentSessionId: c.status === 'in_use' ? c.currentSessionId : (existing.status === 'in_use' && !c.currentSessionId ? existing.currentSessionId : c.currentSessionId),
        });
      }
    }
  }

  // 2. Merge Sessions
  const sessionMap = new Map<string, GamingSession>();
  for (const s of existingDb.sessions || []) {
    if (s?.id) sessionMap.set(s.id, { ...s, businessId });
  }
  for (const s of incomingDb.sessions || []) {
    if (!s?.id) continue;
    const existing = sessionMap.get(s.id);
    if (!existing) {
      sessionMap.set(s.id, { ...s, businessId });
    } else {
      const isCompleted = s.status === 'completed' || existing.status === 'completed';
      const endTime = s.endTime || existing.endTime;
      sessionMap.set(s.id, {
        ...existing,
        ...s,
        businessId,
        status: isCompleted ? 'completed' : s.status,
        endTime: isCompleted ? (endTime || new Date().toISOString()) : null,
        totalAmount: s.totalAmount !== undefined ? s.totalAmount : existing.totalAmount,
        discountAmount: s.discountAmount !== undefined ? s.discountAmount : existing.discountAmount,
        extraCharges: s.extraCharges !== undefined ? s.extraCharges : existing.extraCharges,
      });
    }
  }

  // 3. Merge Customers
  const customerMap = new Map<string, Customer>();
  for (const cust of existingDb.customers || []) {
    if (cust?.id) customerMap.set(cust.id, { ...cust, businessId });
  }
  for (const cust of incomingDb.customers || []) {
    if (!cust?.id) continue;
    const existing = customerMap.get(cust.id);
    if (!existing) {
      customerMap.set(cust.id, { ...cust, businessId });
    } else {
      customerMap.set(cust.id, {
        ...existing,
        ...cust,
        businessId,
        totalVisits: Math.max(existing.totalVisits || 0, cust.totalVisits || 0),
        totalSpent: Math.max(existing.totalSpent || 0, cust.totalSpent || 0),
        totalOutstanding: cust.totalOutstanding !== undefined ? cust.totalOutstanding : existing.totalOutstanding,
      });
    }
  }

  // 4. Merge Rental Items
  const rentalItemMap = new Map<string, RentalItem>();
  const baseRentals = incomingIsNewerReset
    ? (incomingDb.rentalItems || [])
    : (existingDb.rentalItems || []);
  const secondaryRentals = incomingIsNewerReset
    ? (existingDb.rentalItems || [])
    : (incomingDb.rentalItems || []);

  for (const r of baseRentals) {
    if (r?.id) rentalItemMap.set(r.id, { ...r, businessId });
  }
  for (const r of secondaryRentals) {
    if (!r?.id) continue;
    if (!rentalItemMap.has(r.id)) {
      if (!activeResetMs || (r.createdAt && new Date(r.createdAt).getTime() > activeResetMs)) {
        rentalItemMap.set(r.id, { ...r, businessId });
      }
    } else {
      rentalItemMap.set(r.id, { ...(rentalItemMap.get(r.id) || {}), ...r, businessId });
    }
  }

  // 5. Merge Rental Records
  const rentalRecordMap = new Map<string, RentalRecord>();
  for (const rr of existingDb.rentalRecords || []) {
    if (rr?.id) rentalRecordMap.set(rr.id, { ...rr, businessId });
  }
  for (const rr of incomingDb.rentalRecords || []) {
    if (!rr?.id) continue;
    const existing = rentalRecordMap.get(rr.id);
    if (!existing) {
      rentalRecordMap.set(rr.id, { ...rr, businessId });
    } else {
      const isReturned = rr.status === 'returned' || existing.status === 'returned';
      rentalRecordMap.set(rr.id, {
        ...existing,
        ...rr,
        businessId,
        status: isReturned ? 'returned' : rr.status,
      });
    }
  }

  // 6. Merge Cafeteria Items
  const cafeteriaItemMap = new Map<string, CafeteriaItem>();
  const baseCafeteria = incomingIsNewerReset
    ? (incomingDb.cafeteriaItems || [])
    : (existingDb.cafeteriaItems || []);
  const secondaryCafeteria = incomingIsNewerReset
    ? (existingDb.cafeteriaItems || [])
    : (incomingDb.cafeteriaItems || []);

  for (const ci of baseCafeteria) {
    if (ci?.id) cafeteriaItemMap.set(ci.id, { ...ci, businessId });
  }
  for (const ci of secondaryCafeteria) {
    if (!ci?.id) continue;
    if (!cafeteriaItemMap.has(ci.id)) {
      if (!activeResetMs || (ci.createdAt && new Date(ci.createdAt).getTime() > activeResetMs)) {
        cafeteriaItemMap.set(ci.id, { ...ci, businessId });
      }
    } else {
      cafeteriaItemMap.set(ci.id, { ...(cafeteriaItemMap.get(ci.id) || {}), ...ci, businessId });
    }
  }

  // 7. Merge Cafeteria Orders
  const cafeteriaOrderMap = new Map<string, CafeteriaOrder>();
  for (const order of existingDb.cafeteriaOrders || []) {
    if (order?.id) cafeteriaOrderMap.set(order.id, { ...order, businessId });
  }
  for (const order of incomingDb.cafeteriaOrders || []) {
    if (!order?.id) continue;
    cafeteriaOrderMap.set(order.id, { ...(cafeteriaOrderMap.get(order.id) || {}), ...order, businessId });
  }

  // 8. Merge Payments
  const paymentMap = new Map<string, PaymentTransaction>();
  for (const p of existingDb.payments || []) {
    if (p?.id) paymentMap.set(p.id, { ...p, businessId });
  }
  for (const p of incomingDb.payments || []) {
    if (!p?.id) continue;
    paymentMap.set(p.id, { ...(paymentMap.get(p.id) || {}), ...p, businessId });
  }

  // 9. Merge Users
  const userMap = new Map<string, UserAccount>();
  for (const u of existingDb.users || []) {
    if (u?.id && !deletedUserIds.has(u.id.trim())) {
      userMap.set(u.id.trim(), { ...u, businessId });
    }
  }
  for (const u of incomingDb.users || []) {
    if (!u?.id || deletedUserIds.has(u.id.trim())) continue;
    userMap.set(u.id.trim(), { ...(userMap.get(u.id.trim()) || {}), ...u, businessId });
  }

  // 10. Merge Admin Notices
  const noticeMap = new Map<string, AdminNotice>();
  for (const n of existingDb.notices || []) {
    if (n?.id) noticeMap.set(n.id, { ...n, businessId });
  }
  for (const n of incomingDb.notices || []) {
    if (!n?.id) continue;
    const existing = noticeMap.get(n.id);
    if (!existing) {
      noticeMap.set(n.id, { ...n, businessId });
    } else {
      const combinedAck = Array.from(
        new Set([...(existing.acknowledgedBy || []), ...(n.acknowledgedBy || [])])
      );
      noticeMap.set(n.id, {
        ...existing,
        ...n,
        businessId,
        acknowledgedBy: combinedAck,
      });
    }
  }

  // Sort sessions with most recent first
  const mergedSessions = Array.from(sessionMap.values()).sort(
    (a, b) => new Date(b.startTime || 0).getTime() - new Date(a.startTime || 0).getTime()
  );

  // Sort payments with most recent first
  const mergedPayments = Array.from(paymentMap.values()).sort(
    (a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime()
  );

  // Sort cafeteria orders with most recent first
  const mergedOrders = Array.from(cafeteriaOrderMap.values()).sort(
    (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
  );

  // Sort notices: Pinned first, then newest first
  const mergedNotices = Array.from(noticeMap.values()).sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
  });

  const mergedSettings: CafeSettings = {
    tagline: 'High-End Esports & Next-Gen Console Arena',
    phone: '+91 98765 43210',
    email: 'contact@nextgencafe.com',
    address: 'Shop 104, Cyber Hub, Tech District',
    currencySymbol: '₹',
    taxRatePercent: 0,
    minGamingTimeMinutes: 15,
    roundingIncrementMinutes: 5,
    autoSyncGoogleDrive: true,
    googleDriveSyncIntervalMinutes: 2,
    ...(existingDb.settings || {}),
    ...(incomingDb.settings || {}),
    businessId,
    cafeName: 'NEXT GEN GAMING CAFE',
  };

  const finalResetAt = incomingDb.lastResetAt || existingDb.lastResetAt;

  return {
    version: Math.max(existingDb.version || 1, incomingDb.version || 1),
    businessId,
    ownerId: incomingDb.ownerId || existingDb.ownerId,
    ownerEmail: incomingDb.ownerEmail || existingDb.ownerEmail,
    lastModified: new Date().toISOString(),
    lastResetAt: finalResetAt,
    settings: {
      ...mergedSettings,
      lastResetAt: incomingDb.settings?.lastResetAt || existingDb.settings?.lastResetAt || finalResetAt,
    },
    users: Array.from(userMap.values()),
    consoles: Array.from(consoleMap.values()),
    sessions: mergedSessions,
    customers: Array.from(customerMap.values()),
    rentalItems: Array.from(rentalItemMap.values()),
    rentalRecords: Array.from(rentalRecordMap.values()),
    cafeteriaItems: Array.from(cafeteriaItemMap.values()),
    cafeteriaOrders: mergedOrders,
    cafeteriaStockLogs: Array.isArray(incomingDb.cafeteriaStockLogs) ? incomingDb.cafeteriaStockLogs : (existingDb.cafeteriaStockLogs || []),
    vouchers: Array.from(voucherMap.values()),
    voucherUsages: Array.isArray(incomingDb.voucherUsages) ? incomingDb.voucherUsages : (existingDb.voucherUsages || []),
    buySellItems: Array.isArray(incomingDb.buySellItems) ? incomingDb.buySellItems : (existingDb.buySellItems || []),
    buySellTransactions: Array.isArray(incomingDb.buySellTransactions) ? incomingDb.buySellTransactions : (existingDb.buySellTransactions || []),
    repairRecords: Array.isArray(incomingDb.repairRecords) ? incomingDb.repairRecords : (existingDb.repairRecords || []),
    payments: mergedPayments,
    notices: mergedNotices,
    deletedConsoleIds: Array.from(deletedConsoleIds),
    deletedVoucherIds: Array.from(deletedVoucherIds),
    deletedUserIds: Array.from(deletedUserIds),
  };
}
