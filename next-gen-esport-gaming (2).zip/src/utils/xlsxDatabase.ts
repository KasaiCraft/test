import * as XLSX from 'xlsx';
import { CafeDatabase, CafeSettings } from '../types/index.ts';
import { INITIAL_DATABASE } from '../data/initialData.ts';

function safeJsonStringify(val: any): string {
  if (val === undefined || val === null) return '';
  if (typeof val === 'string') return val;
  try {
    return JSON.stringify(val);
  } catch {
    return '';
  }
}

function safeJsonParse<T = any>(val: any, fallback: T): T {
  if (!val || typeof val !== 'string') return fallback;
  const trimmed = val.trim();
  if ((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'))) {
    try {
      return JSON.parse(trimmed) as T;
    } catch {
      return fallback;
    }
  }
  return fallback;
}

function toNum(val: any, fallback = 0): number {
  if (val === undefined || val === null || val === '') return fallback;
  const n = Number(val);
  return isNaN(n) ? fallback : n;
}

function toBool(val: any, fallback = false): boolean {
  if (val === undefined || val === null || val === '') return fallback;
  if (typeof val === 'boolean') return val;
  if (val === 1 || val === '1' || String(val).toLowerCase() === 'true') return true;
  if (val === 0 || val === '0' || String(val).toLowerCase() === 'false') return false;
  return fallback;
}

function toStr(val: any, fallback = ''): string {
  if (val === undefined || val === null) return fallback;
  return String(val);
}

/**
 * Converts a CafeDatabase into an Excel XLSX Workbook with dedicated sheets:
 * Settings, Devices, Sessions, Customers, Payments, Invoices, Cafeteria,
 * Cafeteria_Orders, Inventory, Rentals, Users, Notices, Expenses, Memberships, Reservations.
 */
export function cafeDatabaseToXlsxWorkbook(db: CafeDatabase): XLSX.WorkBook {
  const wb = XLSX.utils.book_new();

  const businessId = db.businessId || 'NEXTGEN_CAFE_BUSINESS_ID';
  const settings = db.settings || ({} as CafeSettings);

  // Helper to create sheet with fallback headers and auto-fit column widths
  const addSheetWithHeaders = (sheetName: string, data: any[], defaultHeaders: string[]) => {
    let ws: XLSX.WorkSheet;
    if (data && data.length > 0) {
      ws = XLSX.utils.json_to_sheet(data, { header: defaultHeaders });
    } else {
      // Create empty sheet with header row
      ws = XLSX.utils.aoa_to_sheet([defaultHeaders]);
    }

    // Auto-fit column widths so text is organized and never cramped into narrow paragraphs
    const colWidths = defaultHeaders.map((header) => {
      let maxLen = header.length;
      if (data && data.length > 0) {
        for (const row of data) {
          if (!row) continue;
          const val = row[header];
          if (val !== undefined && val !== null) {
            const str = String(val);
            const lineLen = str.includes('\n')
              ? Math.max(...str.split('\n').map((l) => l.length))
              : str.length;
            if (lineLen > maxLen) {
              maxLen = lineLen;
            }
          }
        }
      }
      return { wch: Math.min(Math.max(maxLen + 3, 12), 48) };
    });
    ws['!cols'] = colWidths;

    XLSX.utils.book_append_sheet(wb, ws, sheetName);
  };

  // 1. Summary / Overview Sheet (The first sheet visible when opening Excel)
  const totalRevenue = (db.payments || []).reduce((acc, p) => acc + (p.amount || 0), 0);
  const activeSessionsCount = (db.sessions || []).filter((s) => s.status === 'active' || s.status === 'paused').length;
  const availableConsolesCount = (db.consoles || []).filter((c) => c.status === 'available').length;
  const inUseConsolesCount = (db.consoles || []).filter((c) => c.status === 'in_use').length;
  const activeRentalsCount = (db.rentalRecords || []).filter((r) => r.status === 'active').length;
  const totalOutstanding = (db.customers || []).reduce((acc, c) => acc + (c.totalOutstanding || 0), 0);

  const summaryRows = [
    { 'Category / Metric': '=== BUSINESS PROFILE ===', 'Details / Value': '', 'Status / Info': '' },
    { 'Category / Metric': 'Cafe Name', 'Details / Value': settings.cafeName || 'NEXT GEN GAMING CAFE', 'Status / Info': 'Active Business' },
    { 'Category / Metric': 'Tagline', 'Details / Value': settings.tagline || 'High-End Esports & Next-Gen Console Arena', 'Status / Info': '' },
    { 'Category / Metric': 'Business ID', 'Details / Value': businessId, 'Status / Info': 'Tenant ID' },
    { 'Category / Metric': 'Contact Phone', 'Details / Value': settings.phone || 'N/A', 'Status / Info': '' },
    { 'Category / Metric': 'Contact Email', 'Details / Value': settings.email || 'N/A', 'Status / Info': '' },
    { 'Category / Metric': 'Address', 'Details / Value': settings.address || 'N/A', 'Status / Info': '' },
    { 'Category / Metric': 'Currency', 'Details / Value': settings.currencySymbol || '₹', 'Status / Info': 'Default' },
    { 'Category / Metric': 'Last Database Sync', 'Details / Value': db.lastModified || new Date().toISOString(), 'Status / Info': 'Google Drive / Local' },
    { 'Category / Metric': '=== OPERATIONAL METRICS ===', 'Details / Value': '', 'Status / Info': '' },
    { 'Category / Metric': 'Total Gaming Consoles/PCs', 'Details / Value': (db.consoles || []).length, 'Status / Info': `${availableConsolesCount} Available, ${inUseConsolesCount} In-Use` },
    { 'Category / Metric': 'Active Gaming Sessions', 'Details / Value': activeSessionsCount, 'Status / Info': 'Currently Playing' },
    { 'Category / Metric': 'Total Sessions Recorded', 'Details / Value': (db.sessions || []).length, 'Status / Info': 'Historical Total' },
    { 'Category / Metric': 'Registered Customers', 'Details / Value': (db.customers || []).length, 'Status / Info': 'Total Players' },
    { 'Category / Metric': 'Total Net Revenue Collected', 'Details / Value': `${settings.currencySymbol || '₹'} ${totalRevenue.toLocaleString('en-IN')}`, 'Status / Info': 'Paid Receipts' },
    { 'Category / Metric': 'Total Pending Balance', 'Details / Value': `${settings.currencySymbol || '₹'} ${totalOutstanding.toLocaleString('en-IN')}`, 'Status / Info': 'Customer Dues' },
    { 'Category / Metric': 'Cafeteria Menu Items', 'Details / Value': (db.cafeteriaItems || []).length, 'Status / Info': 'F&B Inventory' },
    { 'Category / Metric': 'Cafeteria Orders Served', 'Details / Value': (db.cafeteriaOrders || []).length, 'Status / Info': 'Completed Orders' },
    { 'Category / Metric': 'Rental Inventory Items', 'Details / Value': (db.rentalItems || []).length, 'Status / Info': `${activeRentalsCount} Currently Rented` },
    { 'Category / Metric': 'Registered Staff / Workers', 'Details / Value': (db.users || []).length, 'Status / Info': 'Staff Accounts' },
    { 'Category / Metric': '=== WORKBOOK SHEETS GUIDE ===', 'Details / Value': '', 'Status / Info': 'Navigate tabs at the bottom' },
    { 'Category / Metric': 'Devices', 'Details / Value': 'List of consoles & PCs with specs and hourly rates', 'Status / Info': 'Tab 2' },
    { 'Category / Metric': 'Sessions', 'Details / Value': 'All gaming sessions, duration, billing & payment status', 'Status / Info': 'Tab 3' },
    { 'Category / Metric': 'Customers', 'Details / Value': 'Player directory, visit history & outstanding dues', 'Status / Info': 'Tab 4' },
    { 'Category / Metric': 'Payments', 'Details / Value': 'Financial transaction records, Cash/UPI splits & timestamps', 'Status / Info': 'Tab 5' },
    { 'Category / Metric': 'Invoices', 'Details / Value': 'Customer invoices and payment status', 'Status / Info': 'Tab 6' },
    { 'Category / Metric': 'Cafeteria & Orders', 'Details / Value': 'Food/drinks menu and itemized order history', 'Status / Info': 'Tabs 7 & 8' },
    { 'Category / Metric': 'Inventory & Rentals', 'Details / Value': 'Rental accessories and customer return tracking', 'Status / Info': 'Tabs 9 & 10' },
    { 'Category / Metric': 'Settings', 'Details / Value': 'Cafe configuration & synchronization parameters', 'Status / Info': 'Tab 11' },
  ];
  addSheetWithHeaders('Summary', summaryRows, ['Category / Metric', 'Details / Value', 'Status / Info']);

  // 2. Settings Sheet
  const settingsRows = [
    {
      version: db.version || 1,
      businessId,
      ownerId: db.ownerId || '',
      ownerEmail: db.ownerEmail || '',
      lastModified: db.lastModified || new Date().toISOString(),
      lastResetAt: db.lastResetAt || '',
      cafeName: settings.cafeName || 'NEXT GEN GAMING CAFE',
      tagline: settings.tagline || '',
      phone: settings.phone || '',
      email: settings.email || '',
      address: settings.address || '',
      currencySymbol: settings.currencySymbol || '₹',
      taxRatePercent: settings.taxRatePercent ?? 0,
      minGamingTimeMinutes: settings.minGamingTimeMinutes ?? 15,
      roundingIncrementMinutes: settings.roundingIncrementMinutes ?? 5,
      autoSyncGoogleDrive: settings.autoSyncGoogleDrive ?? true,
      googleDriveSyncIntervalMinutes: settings.googleDriveSyncIntervalMinutes ?? 2,
      googleDriveFolderId: settings.googleDriveFolderId || '',
      googleDriveFileId: settings.googleDriveFileId || '',
      lastSyncedAt: settings.lastSyncedAt || '',
      deletedConsoleIds: Array.isArray(db.deletedConsoleIds) && db.deletedConsoleIds.length > 0 ? safeJsonStringify(db.deletedConsoleIds) : '',
    },
  ];
  const settingsHeaders = [
    'version', 'businessId', 'ownerId', 'ownerEmail', 'lastModified', 'lastResetAt', 'cafeName', 'tagline', 'phone', 'email', 'address', 'currencySymbol', 'taxRatePercent', 'minGamingTimeMinutes', 'roundingIncrementMinutes', 'autoSyncGoogleDrive', 'googleDriveSyncIntervalMinutes', 'googleDriveFolderId', 'googleDriveFileId', 'lastSyncedAt', 'deletedConsoleIds'
  ];
  addSheetWithHeaders('Settings', settingsRows, settingsHeaders);

  // 2. Devices (consoles) Sheet
  const devicesRows = (db.consoles || []).map((c) => ({
    id: c.id,
    businessId: c.businessId || businessId,
    code: c.code || '',
    name: c.name || '',
    type: c.type || 'PC',
    hourlyRate: toNum(c.hourlyRate, 0),
    price1Hour: toNum(c.price1Hour ?? c.hourlyRate, 0),
    price2Hour: c.price2Hour !== undefined && c.price2Hour !== null && c.price2Hour > 0 ? toNum(c.price2Hour, 0) : '',
    price3Hour: c.price3Hour !== undefined && c.price3Hour !== null && c.price3Hour > 0 ? toNum(c.price3Hour, 0) : '',
    customPricing: Array.isArray(c.customPricing) && c.customPricing.length > 0 ? safeJsonStringify(c.customPricing) : '',
    playerPricing: c.playerPricing && typeof c.playerPricing === 'object' && Object.keys(c.playerPricing).length > 0 ? safeJsonStringify(c.playerPricing) : '',
    status: c.status || 'available',
    currentSessionId: c.currentSessionId || '',
    specs: c.specs || c.specifications || '',
    serialNumber: (c as any).serialNumber || '',
    ipAddress: (c as any).ipAddress || '',
    createdAt: c.createdAt || '',
  }));
  addSheetWithHeaders('Devices', devicesRows, [
    'id', 'businessId', 'code', 'name', 'type', 'hourlyRate', 'price1Hour', 'price2Hour', 'price3Hour', 'customPricing', 'playerPricing', 'status', 'currentSessionId', 'specs', 'serialNumber', 'ipAddress', 'createdAt'
  ]);

  // 3. Sessions Sheet
  const sessionsRows = (db.sessions || []).map((s) => {
    const splitSummary = Array.isArray(s.splitPayments) && s.splitPayments.length > 0
      ? s.splitPayments.map((sp: any) => `${String(sp.method || 'payment').toUpperCase()}: ${settings.currencySymbol || '₹'}${sp.amount}`).join(' | ')
      : (s.paymentMethod || 'cash');

    return {
      id: s.id,
      businessId: s.businessId || businessId,
      consoleId: s.consoleId || '',
      consoleCode: s.consoleCode || (s as any).consoleName || '',
      consoleName: (s as any).consoleName || s.consoleCode || '',
      customerId: s.customerId || '',
      customerName: s.customerName || '',
      customerPhone: s.customerPhone || '',
      startTime: s.startTime || '',
      endTime: s.endTime || '',
      scheduledEndTime: s.scheduledEndTime || '',
      presetDurationMinutes: toNum(s.presetDurationMinutes, 0),
      durationMinutes: toNum(s.durationMinutes, 0),
      ratePerHour: toNum(s.ratePerHour, 0),
      baseAmount: toNum(s.baseAmount, 0),
      discountAmount: toNum(s.discountAmount, 0),
      extraCharges: toNum(s.extraCharges, 0),
      totalAmount: toNum(s.totalAmount, 0),
      paidAmount: toNum(s.paidAmount, 0),
      paymentStatus: s.paymentStatus || 'pending',
      paymentMethod: s.paymentMethod || 'cash',
      splitSummary,
      status: s.status || 'active',
      workerId: s.workerId || '',
      workerName: s.workerName || '',
      notes: s.notes || '',
      allocatedConsoles: (s as any).allocatedConsoles ? safeJsonStringify((s as any).allocatedConsoles) : '',
      splitPayments: s.splitPayments ? safeJsonStringify(s.splitPayments) : '',
      createdAt: s.createdAt || s.startTime || '',
    };
  });
  addSheetWithHeaders('Sessions', sessionsRows, [
    'id', 'businessId', 'consoleId', 'consoleCode', 'consoleName', 'customerId', 'customerName', 'customerPhone', 'startTime', 'endTime', 'scheduledEndTime', 'presetDurationMinutes', 'durationMinutes', 'ratePerHour', 'baseAmount', 'discountAmount', 'extraCharges', 'totalAmount', 'paidAmount', 'paymentStatus', 'paymentMethod', 'splitSummary', 'status', 'workerId', 'workerName', 'notes', 'allocatedConsoles', 'splitPayments', 'createdAt'
  ]);

  // 4. Customers Sheet
  const customersRows = (db.customers || []).map((c) => ({
    id: c.id,
    businessId: c.businessId || businessId,
    name: c.name || '',
    phone: c.phone || '',
    email: c.email || '',
    totalVisits: toNum(c.totalVisits, 0),
    totalSpent: toNum(c.totalSpent, 0),
    totalOutstanding: toNum(c.totalOutstanding, 0),
    notes: c.notes || '',
    createdAt: c.createdAt || '',
  }));
  addSheetWithHeaders('Customers', customersRows, [
    'id', 'businessId', 'name', 'phone', 'email', 'totalVisits', 'totalSpent', 'totalOutstanding', 'notes', 'createdAt'
  ]);

  // 5. Payments Sheet
  const paymentsRows = (db.payments || []).map((p) => {
    const splitSummary = Array.isArray(p.splitDetails) && p.splitDetails.length > 0
      ? p.splitDetails.map((sd: any) => `${String(sd.method || 'payment').toUpperCase()}: ${settings.currencySymbol || '₹'}${sd.amount}`).join(' | ')
      : (p.method || 'cash');

    return {
      id: p.id,
      businessId: p.businessId || businessId,
      customerId: p.customerId || '',
      customerName: p.customerName || '',
      type: p.type || 'session',
      referenceId: p.referenceId || '',
      amount: toNum(p.amount, 0),
      method: p.method || 'cash',
      splitSummary,
      status: p.status || 'completed',
      timestamp: p.timestamp || '',
      recordedBy: p.recordedBy || '',
      totalBill: toNum(p.totalBill, 0),
      pendingAmount: toNum(p.pendingAmount, 0),
      notes: p.notes || '',
      splitDetails: p.splitDetails ? safeJsonStringify(p.splitDetails) : '',
    };
  });
  addSheetWithHeaders('Payments', paymentsRows, [
    'id', 'businessId', 'customerId', 'customerName', 'type', 'referenceId', 'amount', 'method', 'splitSummary', 'status', 'timestamp', 'recordedBy', 'totalBill', 'pendingAmount', 'notes', 'splitDetails'
  ]);

  // 6. Invoices Sheet (derived from payments and invoices)
  const invoicesRows = (db.payments || []).map((p, idx) => ({
    id: `inv_${p.id}`,
    businessId: p.businessId || businessId,
    invoiceNumber: `INV-${new Date(p.timestamp || Date.now()).getFullYear()}-${String(idx + 1).padStart(4, '0')}`,
    customerId: p.customerId || '',
    customerName: p.customerName || '',
    referenceId: p.referenceId || '',
    type: p.type || 'session',
    totalAmount: toNum(p.totalBill || p.amount, 0),
    paidAmount: toNum(p.amount, 0),
    pendingAmount: toNum(p.pendingAmount, 0),
    status: p.status || 'completed',
    paymentMethod: p.method || 'cash',
    createdAt: p.timestamp || '',
    notes: p.notes || '',
  }));
  addSheetWithHeaders('Invoices', invoicesRows, [
    'id', 'businessId', 'invoiceNumber', 'customerId', 'customerName', 'referenceId', 'type', 'totalAmount', 'paidAmount', 'pendingAmount', 'status', 'paymentMethod', 'createdAt', 'notes'
  ]);

  // 7. Cafeteria Sheet (cafeteriaItems)
  const cafeteriaRows = (db.cafeteriaItems || []).map((i) => ({
    id: i.id,
    businessId: i.businessId || businessId,
    name: i.name || '',
    category: i.category || 'Snacks',
    price: toNum(i.price, 0),
    stockQuantity: toNum(i.stockQuantity, 0),
    isAvailable: toBool(i.isAvailable, true),
    description: i.description || '',
    image: i.image || '',
    createdAt: i.createdAt || '',
  }));
  addSheetWithHeaders('Cafeteria', cafeteriaRows, [
    'id', 'businessId', 'name', 'category', 'price', 'stockQuantity', 'isAvailable', 'description', 'image', 'createdAt'
  ]);

  // 8. Cafeteria_Orders Sheet
  const orderRows = (db.cafeteriaOrders || []).map((o) => {
    const itemsSummary = Array.isArray(o.items) && o.items.length > 0
      ? o.items.map((i: any) => `${i.quantity}x ${i.name} (${settings.currencySymbol || '₹'}${i.totalPrice ?? (i.price ? i.price * i.quantity : 0)})`).join('; ')
      : 'No items';

    return {
      id: o.id,
      businessId: o.businessId || businessId,
      customerId: o.customerId || '',
      customerName: o.customerName || '',
      customerPhone: o.customerPhone || '',
      itemsSummary,
      items: o.items ? safeJsonStringify(o.items) : '[]',
      subtotal: toNum(o.subtotal, 0),
      discountAmount: toNum(o.discountAmount, 0),
      totalAmount: toNum(o.totalAmount, 0),
      paidAmount: toNum(o.paidAmount, 0),
      paymentStatus: o.paymentStatus || 'unpaid',
      paymentMethod: o.paymentMethod || 'cash',
      notes: o.notes || '',
      status: o.status || 'completed',
      createdAt: o.createdAt || (o as any).orderTime || '',
      workerId: o.workerId || '',
      workerName: o.workerName || '',
    };
  });
  addSheetWithHeaders('Cafeteria_Orders', orderRows, [
    'id', 'businessId', 'customerId', 'customerName', 'customerPhone', 'itemsSummary', 'items', 'subtotal', 'discountAmount', 'totalAmount', 'paidAmount', 'paymentStatus', 'paymentMethod', 'notes', 'status', 'createdAt', 'workerId', 'workerName'
  ]);

  // 9. Inventory Sheet (rentalItems)
  const inventoryRows = (db.rentalItems || []).map((r) => ({
    id: r.id,
    businessId: r.businessId || businessId,
    name: r.name || '',
    category: r.category || 'Controller',
    totalQuantity: toNum(r.totalQuantity, 0),
    availableQuantity: toNum(r.availableQuantity, 0),
    rentedQuantity: toNum(r.rentedQuantity, 0),
    hourlyRate: toNum(r.hourlyRate, 0),
    dailyRate: toNum(r.dailyRate, 0),
    securityDeposit: toNum(r.securityDeposit, 0),
    status: r.status || 'available',
    description: r.description || '',
    image: r.image || '',
    createdAt: r.createdAt || '',
  }));
  addSheetWithHeaders('Inventory', inventoryRows, [
    'id', 'businessId', 'name', 'category', 'totalQuantity', 'availableQuantity', 'rentedQuantity', 'hourlyRate', 'dailyRate', 'securityDeposit', 'status', 'description', 'image', 'createdAt'
  ]);

  // 10. Rentals Sheet (rentalRecords)
  const rentalsRows = (db.rentalRecords || []).map((rec) => {
    const splitSummary = Array.isArray(rec.splitPayments) && rec.splitPayments.length > 0
      ? rec.splitPayments.map((sp: any) => `${String(sp.method || 'payment').toUpperCase()}: ${settings.currencySymbol || '₹'}${sp.amount}`).join(' | ')
      : (rec.paymentMethod || 'cash');

    return {
      id: rec.id,
      businessId: rec.businessId || businessId,
      rentalItemId: rec.rentalItemId || '',
      rentalItemName: rec.rentalItemName || '',
      customerId: rec.customerId || '',
      customerName: rec.customerName || '',
      customerPhone: rec.customerPhone || '',
      quantity: toNum(rec.quantity, 1),
      periodType: rec.periodType || 'hourly',
      startTime: rec.startTime || '',
      expectedReturnTime: rec.expectedReturnTime || '',
      actualReturnTime: rec.actualReturnTime || '',
      rentalFee: toNum(rec.rentalFee, 0),
      depositAmount: toNum(rec.depositAmount, 0),
      depositRefunded: toNum(rec.depositRefunded, 0),
      damageDeduction: toNum(rec.damageDeduction, 0),
      lateFee: toNum(rec.lateFee, 0),
      totalPaid: toNum(rec.totalPaid, 0),
      paidAmount: toNum(rec.paidAmount, 0),
      durationUnits: toNum(rec.durationUnits, 0),
      rateApplied: toNum(rec.rateApplied, 0),
      totalBill: toNum(rec.totalBill, 0),
      pendingAmount: toNum(rec.pendingAmount, 0),
      rentedAt: rec.rentedAt || '',
      paymentStatus: rec.paymentStatus || 'unpaid',
      paymentMethod: rec.paymentMethod || 'cash',
      splitSummary,
      status: rec.status || 'active',
      notes: rec.notes || '',
      workerId: rec.workerId || '',
      workerName: rec.workerName || '',
      createdAt: rec.createdAt || '',
      splitPayments: rec.splitPayments ? safeJsonStringify(rec.splitPayments) : '',
    };
  });
  addSheetWithHeaders('Rentals', rentalsRows, [
    'id', 'businessId', 'rentalItemId', 'rentalItemName', 'customerId', 'customerName', 'customerPhone', 'quantity', 'periodType', 'startTime', 'expectedReturnTime', 'actualReturnTime', 'rentalFee', 'depositAmount', 'depositRefunded', 'damageDeduction', 'lateFee', 'totalPaid', 'paidAmount', 'durationUnits', 'rateApplied', 'totalBill', 'pendingAmount', 'rentedAt', 'paymentStatus', 'paymentMethod', 'splitSummary', 'status', 'notes', 'workerId', 'workerName', 'createdAt', 'splitPayments'
  ]);

  // 11. Users Sheet
  const usersRows = (db.users || []).map((u) => ({
    id: u.id,
    businessId: u.businessId || businessId,
    name: u.name || '',
    email: u.email || '',
    pin: u.pin || '',
    role: u.role || 'worker',
    status: u.status || 'active',
    phone: u.phone || '',
    createdAt: u.createdAt || '',
    lastLogin: u.lastLogin || '',
  }));
  addSheetWithHeaders('Users', usersRows, [
    'id', 'businessId', 'name', 'email', 'pin', 'role', 'status', 'phone', 'createdAt', 'lastLogin'
  ]);

  // 12. Notices Sheet
  const noticesRows = (db.notices || []).map((n) => ({
    id: n.id,
    businessId: n.businessId || businessId,
    title: n.title || '',
    message: n.message || '',
    category: n.category || 'general',
    priority: n.priority || 'info',
    authorName: n.authorName || '',
    authorRole: n.authorRole || 'admin',
    createdAt: n.createdAt || '',
    isPinned: toBool(n.isPinned, false),
    acknowledgedBy: n.acknowledgedBy ? safeJsonStringify(n.acknowledgedBy) : '[]',
  }));
  addSheetWithHeaders('Notices', noticesRows, [
    'id', 'businessId', 'title', 'message', 'category', 'priority', 'authorName', 'authorRole', 'createdAt', 'isPinned', 'acknowledgedBy'
  ]);

  // 13. Expenses Sheet (Future expansion & financial tracking)
  const expensesRows = ((db as any).expenses || []).map((exp: any) => ({
    id: exp.id || '',
    businessId: exp.businessId || businessId,
    title: exp.title || '',
    category: exp.category || 'Maintenance',
    amount: toNum(exp.amount, 0),
    date: exp.date || '',
    recordedBy: exp.recordedBy || '',
    notes: exp.notes || '',
  }));
  addSheetWithHeaders('Expenses', expensesRows, [
    'id', 'businessId', 'title', 'category', 'amount', 'date', 'recordedBy', 'notes'
  ]);

  // 14. Memberships Sheet
  const membershipsRows = ((db as any).memberships || []).map((m: any) => ({
    id: m.id || '',
    businessId: m.businessId || businessId,
    customerId: m.customerId || '',
    customerName: m.customerName || '',
    planName: m.planName || 'VIP',
    startDate: m.startDate || '',
    endDate: m.endDate || '',
    status: m.status || 'active',
    price: toNum(m.price, 0),
  }));
  addSheetWithHeaders('Memberships', membershipsRows, [
    'id', 'businessId', 'customerId', 'customerName', 'planName', 'startDate', 'endDate', 'status', 'price'
  ]);

  // 15. Reservations Sheet
  const reservationsRows = ((db as any).reservations || []).map((res: any) => ({
    id: res.id || '',
    businessId: res.businessId || businessId,
    customerId: res.customerId || '',
    customerName: res.customerName || '',
    consoleId: res.consoleId || '',
    consoleName: res.consoleName || '',
    reservationTime: res.reservationTime || '',
    durationHours: toNum(res.durationHours, 1),
    status: res.status || 'confirmed',
    notes: res.notes || '',
  }));
  addSheetWithHeaders('Reservations', reservationsRows, [
    'id', 'businessId', 'customerId', 'customerName', 'consoleId', 'consoleName', 'reservationTime', 'durationHours', 'status', 'notes'
  ]);

  // 16. Vouchers Sheet
  const vouchersRows = (db.vouchers || []).map((v: any) => ({
    id: v.id || '',
    businessId: v.businessId || businessId,
    code: v.code || '',
    name: v.name || v.code || '',
    category: v.category || 'All',
    durationMinutes: toNum(v.durationMinutes, 60),
    totalPurchasedHours: toNum(v.totalPurchasedHours, 0),
    usedHours: toNum(v.usedHours, 0),
    remainingHours: toNum(v.remainingHours, 0),
    price: toNum(v.price, 0),
    valueAmount: toNum(v.valueAmount, 0),
    expiryDate: v.expiryDate || 'never',
    status: v.status || 'active',
    usageLimit: toNum(v.usageLimit, 1),
    usedCount: toNum(v.usedCount, 0),
    notes: v.notes || '',
    assignedCustomerId: v.assignedCustomerId || '',
    assignedCustomerName: v.assignedCustomerName || '',
    assignedCustomerPhone: v.assignedCustomerPhone || '',
    createdAt: v.createdAt || '',
  }));
  addSheetWithHeaders('Vouchers', vouchersRows, [
    'id', 'businessId', 'code', 'name', 'category', 'durationMinutes', 'totalPurchasedHours', 'usedHours', 'remainingHours', 'price', 'valueAmount', 'expiryDate', 'status', 'usageLimit', 'usedCount', 'notes', 'assignedCustomerId', 'assignedCustomerName', 'assignedCustomerPhone', 'createdAt'
  ]);

  // 17. Voucher Usages Sheet
  const voucherUsagesRows = (db.voucherUsages || []).map((vu: any) => ({
    id: vu.id || '',
    businessId: vu.businessId || businessId,
    voucherId: vu.voucherId || '',
    voucherCode: vu.voucherCode || '',
    voucherName: vu.voucherName || '',
    customerId: vu.customerId || '',
    customerName: vu.customerName || '',
    customerPhone: vu.customerPhone || '',
    sessionId: vu.sessionId || '',
    consoleCode: vu.consoleCode || '',
    durationUsedMinutes: toNum(vu.durationUsedMinutes, 0),
    valueDiscountApplied: toNum(vu.valueDiscountApplied, 0),
    usedAt: vu.usedAt || '',
    recordedBy: vu.recordedBy || 'Staff',
    notes: vu.notes || '',
  }));
  addSheetWithHeaders('Voucher_Usages', voucherUsagesRows, [
    'id', 'businessId', 'voucherId', 'voucherCode', 'voucherName', 'customerId', 'customerName', 'customerPhone', 'sessionId', 'consoleCode', 'durationUsedMinutes', 'valueDiscountApplied', 'usedAt', 'recordedBy', 'notes'
  ]);

  // 18. Buy & Sell Items Sheet
  const buySellItemsRows = (db.buySellItems || []).map((bs: any) => ({
    id: bs.id || '',
    businessId: bs.businessId || businessId,
    name: bs.name || '',
    category: bs.category || 'Accessories',
    condition: bs.condition || 'Used / Pre-owned',
    serialNumber: bs.serialNumber || '',
    purchasePrice: toNum(bs.purchasePrice, 0),
    suggestedSellingPrice: toNum(bs.suggestedSellingPrice, 0),
    sellerCustomerId: bs.sellerCustomerId || '',
    sellerCustomerName: bs.sellerCustomerName || '',
    sellerPhone: bs.sellerPhone || '',
    purchaseDate: bs.purchaseDate || '',
    status: bs.status || 'in_inventory',
    notes: bs.notes || '',
    createdAt: bs.createdAt || '',
    soldAt: bs.soldAt || '',
    soldPrice: toNum(bs.soldPrice, 0),
    buyerCustomerId: bs.buyerCustomerId || '',
    buyerCustomerName: bs.buyerCustomerName || '',
    buyerPhone: bs.buyerPhone || '',
    profit: toNum(bs.profit, 0),
    invoiceNumber: bs.invoiceNumber || '',
    paymentMethod: bs.paymentMethod || 'cash',
  }));
  addSheetWithHeaders('Buy_Sell_Items', buySellItemsRows, [
    'id', 'businessId', 'name', 'category', 'condition', 'serialNumber', 'purchasePrice', 'suggestedSellingPrice', 'sellerCustomerId', 'sellerCustomerName', 'sellerPhone', 'purchaseDate', 'status', 'notes', 'createdAt', 'soldAt', 'soldPrice', 'buyerCustomerId', 'buyerCustomerName', 'buyerPhone', 'profit', 'invoiceNumber', 'paymentMethod'
  ]);

  // 19. Buy & Sell Transactions Sheet
  const buySellTxRows = (db.buySellTransactions || []).map((tx: any) => ({
    id: tx.id || '',
    businessId: tx.businessId || businessId,
    type: tx.type || 'sale',
    itemId: tx.itemId || '',
    itemName: tx.itemName || '',
    category: tx.category || 'Accessories',
    condition: tx.condition || 'Used / Pre-owned',
    serialNumber: tx.serialNumber || '',
    customerId: tx.customerId || '',
    customerName: tx.customerName || '',
    customerPhone: tx.customerPhone || '',
    amount: toNum(tx.amount, 0),
    purchaseCost: toNum(tx.purchaseCost, 0),
    profit: toNum(tx.profit, 0),
    paymentMethod: tx.paymentMethod || 'cash',
    paymentStatus: tx.paymentStatus || 'completed',
    notes: tx.notes || '',
    timestamp: tx.timestamp || '',
    recordedBy: tx.recordedBy || 'Staff',
  }));
  addSheetWithHeaders('Buy_Sell_Transactions', buySellTxRows, [
    'id', 'businessId', 'type', 'itemId', 'itemName', 'category', 'condition', 'serialNumber', 'customerId', 'customerName', 'customerPhone', 'amount', 'purchaseCost', 'profit', 'paymentMethod', 'paymentStatus', 'notes', 'timestamp', 'recordedBy'
  ]);

  // 20. Repair Records Sheet
  const repairRows = (db.repairRecords || []).map((rep: any) => ({
    id: rep.id || '',
    businessId: rep.businessId || businessId,
    repairNumber: rep.repairNumber || '',
    repairId: rep.repairId || rep.id || '',
    customerId: rep.customerId || '',
    customerName: rep.customerName || '',
    customerPhone: rep.customerPhone || '',
    itemName: rep.itemName || rep.deviceName || '',
    category: rep.category || 'Controllers',
    serialNumber: rep.serialNumber || '',
    problemDescription: rep.problemDescription || rep.issueDescription || '',
    dateReceived: rep.dateReceived || rep.receivedDate || '',
    expectedCompletionDate: rep.expectedCompletionDate || '',
    actualCompletionDate: rep.actualCompletionDate || rep.completedDate || '',
    technicianName: rep.technicianName || '',
    repairCost: toNum(rep.repairCost, 0),
    customerCharge: toNum(rep.customerCharge || rep.finalCost || rep.estimatedCost, 0),
    advancePayment: toNum(rep.advancePayment || rep.advancePaid, 0),
    paidAmount: toNum(rep.paidAmount, 0),
    pendingAmount: toNum(rep.pendingAmount, 0),
    paymentStatus: rep.paymentStatus || 'pending',
    paymentMethod: rep.paymentMethod || 'cash',
    status: rep.status || 'Received',
    notes: rep.notes || rep.technicianNotes || '',
    createdAt: rep.createdAt || '',
    updatedAt: rep.updatedAt || '',
    deliveredAt: rep.deliveredAt || '',
  }));
  addSheetWithHeaders('Repairs', repairRows, [
    'id', 'businessId', 'repairNumber', 'repairId', 'customerId', 'customerName', 'customerPhone', 'itemName', 'category', 'serialNumber', 'problemDescription', 'dateReceived', 'expectedCompletionDate', 'actualCompletionDate', 'technicianName', 'repairCost', 'customerCharge', 'advancePayment', 'paidAmount', 'pendingAmount', 'paymentStatus', 'paymentMethod', 'status', 'notes', 'createdAt', 'updatedAt', 'deliveredAt'
  ]);

  // 21. Cafeteria Stock Logs Sheet
  const stockLogRows = (db.cafeteriaStockLogs || []).map((sl: any) => ({
    id: sl.id || '',
    businessId: sl.businessId || businessId,
    itemId: sl.itemId || '',
    itemName: sl.itemName || '',
    type: sl.type || sl.changeType || 'stock_in',
    quantityChange: toNum(sl.quantityChange || sl.quantityChanged, 0),
    previousStock: toNum(sl.previousStock, 0),
    newStock: toNum(sl.newStock, 0),
    unitPrice: toNum(sl.unitPrice, 0),
    supplier: sl.supplier || '',
    notes: sl.notes || sl.reason || '',
    recordedBy: sl.recordedBy || 'Staff',
    timestamp: sl.timestamp || sl.date || '',
  }));
  addSheetWithHeaders('Stock_Logs', stockLogRows, [
    'id', 'businessId', 'itemId', 'itemName', 'type', 'quantityChange', 'previousStock', 'newStock', 'unitPrice', 'supplier', 'notes', 'recordedBy', 'timestamp'
  ]);

  return wb;
}

/**
 * Converts a CafeDatabase into a binary Uint8Array representation of an XLSX file.
 */
export function cafeDatabaseToXlsxBuffer(db: CafeDatabase): Uint8Array {
  const wb = cafeDatabaseToXlsxWorkbook(db);
  const out = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  return new Uint8Array(out);
}

/**
 * Converts a CafeDatabase into a Base64 string of an XLSX file.
 */
export function cafeDatabaseToXlsxBase64(db: CafeDatabase): string {
  const wb = cafeDatabaseToXlsxWorkbook(db);
  return XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
}

/**
 * Converts an XLSX Workbook back into the application's CafeDatabase structure.
 */
export function xlsxWorkbookToCafeDatabase(wb: XLSX.WorkBook, defaultBusinessId = 'NEXTGEN_CAFE_BUSINESS_ID'): CafeDatabase {
  const getSheetRows = (name: string): any[] => {
    const sheet = wb.Sheets[name];
    if (!sheet) return [];
    return XLSX.utils.sheet_to_json(sheet, { defval: '' });
  };

  // 1. Settings Sheet
  const settingsRows = getSheetRows('Settings');
  const s0 = settingsRows[0] || {};
  const businessId = s0.businessId || defaultBusinessId;

  const settings: CafeSettings = {
    businessId,
    ownerId: s0.ownerId || undefined,
    ownerEmail: s0.ownerEmail || undefined,
    cafeName: s0.cafeName || 'NEXT GEN GAMING CAFE',
    tagline: s0.tagline || 'High-End Esports & Next-Gen Console Arena',
    phone: s0.phone || '',
    email: s0.email || '',
    address: s0.address || '',
    currencySymbol: s0.currencySymbol || '₹',
    taxRatePercent: toNum(s0.taxRatePercent, 0),
    minGamingTimeMinutes: toNum(s0.minGamingTimeMinutes, 15),
    roundingIncrementMinutes: toNum(s0.roundingIncrementMinutes, 5),
    autoSyncGoogleDrive: toBool(s0.autoSyncGoogleDrive, true),
    googleDriveSyncIntervalMinutes: toNum(s0.googleDriveSyncIntervalMinutes, 2),
    googleDriveFolderId: s0.googleDriveFolderId || undefined,
    googleDriveFileId: s0.googleDriveFileId || undefined,
    lastSyncedAt: s0.lastSyncedAt || undefined,
    lastResetAt: s0.lastResetAt || undefined,
    deletedConsoleIds: s0.deletedConsoleIds ? safeJsonParse(toStr(s0.deletedConsoleIds), []) : [],
  };

  // 2. Devices (consoles) Sheet
  const devicesRows = getSheetRows('Devices');
  const consoles = devicesRows.map((r) => {
    const rawHourly = toNum(r.hourlyRate, 0);
    const p1 = r.price1Hour !== undefined && r.price1Hour !== '' ? toNum(r.price1Hour, rawHourly) : rawHourly;
    const p2 = r.price2Hour !== undefined && r.price2Hour !== '' && toNum(r.price2Hour, 0) > 0 ? toNum(r.price2Hour, 0) : undefined;
    const p3 = r.price3Hour !== undefined && r.price3Hour !== '' && toNum(r.price3Hour, 0) > 0 ? toNum(r.price3Hour, 0) : undefined;
    const customPricingRaw = r.customPricing ? safeJsonParse(toStr(r.customPricing), []) : [];
    const playerPricingRaw = r.playerPricing ? safeJsonParse(toStr(r.playerPricing), undefined) : undefined;

    return {
      id: toStr(r.id),
      businessId: toStr(r.businessId || businessId),
      code: toStr(r.code),
      name: toStr(r.name),
      type: (toStr(r.type) || 'PC') as any,
      hourlyRate: p1 || rawHourly,
      price1Hour: p1 || rawHourly,
      price2Hour: p2,
      price3Hour: p3,
      customPricing: Array.isArray(customPricingRaw) ? customPricingRaw : [],
      playerPricing: playerPricingRaw && typeof playerPricingRaw === 'object' ? playerPricingRaw : undefined,
      status: (toStr(r.status) || 'available') as any,
      currentSessionId: r.currentSessionId ? toStr(r.currentSessionId) : null,
      specs: r.specs ? toStr(r.specs) : undefined,
      serialNumber: r.serialNumber ? toStr(r.serialNumber) : undefined,
      ipAddress: r.ipAddress ? toStr(r.ipAddress) : undefined,
      createdAt: toStr(r.createdAt || new Date().toISOString()),
    };
  }).filter((c) => c.id && c.name);

  // 3. Sessions Sheet
  const sessionsRows = getSheetRows('Sessions');
  const sessions = sessionsRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    consoleId: toStr(r.consoleId),
    consoleCode: toStr(r.consoleCode || r.consoleName || 'C-1'),
    customerId: toStr(r.customerId),
    customerName: toStr(r.customerName),
    customerPhone: r.customerPhone ? toStr(r.customerPhone) : undefined,
    startTime: toStr(r.startTime),
    endTime: r.endTime ? toStr(r.endTime) : null,
    scheduledEndTime: r.scheduledEndTime ? toStr(r.scheduledEndTime) : null,
    presetDurationMinutes: r.presetDurationMinutes ? toNum(r.presetDurationMinutes, 0) : null,
    durationMinutes: toNum(r.durationMinutes, 0),
    ratePerHour: toNum(r.ratePerHour, 0),
    baseAmount: toNum(r.baseAmount, 0),
    discountAmount: toNum(r.discountAmount, 0),
    extraCharges: toNum(r.extraCharges, 0),
    totalAmount: toNum(r.totalAmount, 0),
    paidAmount: toNum(r.paidAmount, 0),
    paymentStatus: (toStr(r.paymentStatus) || 'pending') as any,
    paymentMethod: (r.paymentMethod ? toStr(r.paymentMethod) : null) as any,
    splitPayments: safeJsonParse(r.splitPayments, undefined),
    status: (toStr(r.status) || 'active') as any,
    notes: r.notes ? toStr(r.notes) : undefined,
    workerId: toStr(r.workerId || 'admin'),
    workerName: toStr(r.workerName || 'Admin'),
    createdAt: toStr(r.createdAt || r.startTime || new Date().toISOString()),
  })).filter((s) => s.id);

  // 4. Customers Sheet
  const customersRows = getSheetRows('Customers');
  const customers = customersRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    name: toStr(r.name),
    phone: toStr(r.phone),
    email: r.email ? toStr(r.email) : undefined,
    totalVisits: toNum(r.totalVisits, 0),
    totalSpent: toNum(r.totalSpent, 0),
    totalOutstanding: toNum(r.totalOutstanding, 0),
    notes: r.notes ? toStr(r.notes) : undefined,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
  })).filter((c) => c.id && c.name);

  // 5. Payments Sheet
  const paymentsRows = getSheetRows('Payments');
  const payments = paymentsRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    customerId: toStr(r.customerId),
    customerName: toStr(r.customerName),
    type: (toStr(r.type) || 'gaming_session') as any,
    referenceId: toStr(r.referenceId),
    referenceTitle: toStr(r.referenceTitle || r.referenceId || 'Payment'),
    amount: toNum(r.amount, 0),
    method: (toStr(r.method) || 'cash') as any,
    status: (toStr(r.status) || 'completed') as any,
    timestamp: toStr(r.timestamp || new Date().toISOString()),
    recordedBy: toStr(r.recordedBy || 'Admin'),
    totalBill: r.totalBill !== undefined && r.totalBill !== '' ? toNum(r.totalBill, 0) : undefined,
    pendingAmount: r.pendingAmount !== undefined && r.pendingAmount !== '' ? toNum(r.pendingAmount, 0) : undefined,
    notes: r.notes ? toStr(r.notes) : undefined,
    splitDetails: safeJsonParse(r.splitDetails, undefined),
  })).filter((p) => p.id);

  // 6. Cafeteria Sheet (cafeteriaItems)
  const cafeteriaRows = getSheetRows('Cafeteria');
  const cafeteriaItems = cafeteriaRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    name: toStr(r.name),
    category: (toStr(r.category) || 'Snacks') as any,
    price: toNum(r.price, 0),
    stockQuantity: toNum(r.stockQuantity, 0),
    isAvailable: toBool(r.isAvailable, true),
    description: r.description ? toStr(r.description) : undefined,
    image: r.image ? toStr(r.image) : undefined,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
  })).filter((i) => i.id && i.name);

  // 7. Cafeteria_Orders Sheet
  const orderRows = getSheetRows('Cafeteria_Orders');
  const cafeteriaOrders = orderRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    customerId: toStr(r.customerId),
    customerName: toStr(r.customerName),
    customerPhone: r.customerPhone ? toStr(r.customerPhone) : undefined,
    items: safeJsonParse(r.items, []),
    subtotal: toNum(r.subtotal, 0),
    discountAmount: toNum(r.discountAmount, 0),
    totalAmount: toNum(r.totalAmount, 0),
    paidAmount: toNum(r.paidAmount, 0),
    paymentStatus: (toStr(r.paymentStatus) || 'unpaid') as any,
    paymentMethod: (toStr(r.paymentMethod) || 'cash') as any,
    notes: r.notes ? toStr(r.notes) : undefined,
    status: (toStr(r.status) || 'completed') as any,
    createdAt: toStr(r.createdAt || r.orderTime || new Date().toISOString()),
    workerId: toStr(r.workerId),
    workerName: toStr(r.workerName),
  })).filter((o) => o.id);

  // 8. Inventory Sheet (rentalItems)
  const inventoryRows = getSheetRows('Inventory');
  const rentalItems = inventoryRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    name: toStr(r.name),
    category: (toStr(r.category) || 'Controller') as any,
    totalQuantity: toNum(r.totalQuantity, 0),
    availableQuantity: toNum(r.availableQuantity, 0),
    rentedQuantity: toNum(r.rentedQuantity, 0),
    hourlyRate: toNum(r.hourlyRate, 0),
    dailyRate: toNum(r.dailyRate, 0),
    securityDeposit: toNum(r.securityDeposit, 0),
    status: (toStr(r.status) || 'available') as any,
    description: r.description ? toStr(r.description) : undefined,
    image: r.image ? toStr(r.image) : undefined,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
  })).filter((item) => item.id && item.name);

  // 9. Rentals Sheet (rentalRecords)
  const rentalsRows = getSheetRows('Rentals');
  const rentalRecords = rentalsRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    rentalItemId: toStr(r.rentalItemId),
    rentalItemName: toStr(r.rentalItemName),
    customerId: toStr(r.customerId),
    customerName: toStr(r.customerName),
    customerPhone: toStr(r.customerPhone),
    quantity: toNum(r.quantity, 1),
    periodType: (toStr(r.periodType) || 'hourly') as any,
    startTime: toStr(r.startTime),
    expectedReturnTime: toStr(r.expectedReturnTime),
    actualReturnTime: r.actualReturnTime ? toStr(r.actualReturnTime) : null,
    rentalFee: toNum(r.rentalFee, 0),
    depositAmount: toNum(r.depositAmount, 0),
    depositRefunded: toNum(r.depositRefunded, 0),
    damageDeduction: toNum(r.damageDeduction, 0),
    lateFee: toNum(r.lateFee, 0),
    totalPaid: toNum(r.totalPaid, 0),
    paidAmount: r.paidAmount !== undefined && r.paidAmount !== '' ? toNum(r.paidAmount, 0) : undefined,
    durationUnits: r.durationUnits !== undefined && r.durationUnits !== '' ? toNum(r.durationUnits, 0) : undefined,
    rateApplied: r.rateApplied !== undefined && r.rateApplied !== '' ? toNum(r.rateApplied, 0) : undefined,
    totalBill: r.totalBill !== undefined && r.totalBill !== '' ? toNum(r.totalBill, 0) : undefined,
    pendingAmount: r.pendingAmount !== undefined && r.pendingAmount !== '' ? toNum(r.pendingAmount, 0) : undefined,
    rentedAt: r.rentedAt ? toStr(r.rentedAt) : undefined,
    paymentStatus: (toStr(r.paymentStatus) || 'unpaid') as any,
    paymentMethod: (toStr(r.paymentMethod) || 'cash') as any,
    status: (toStr(r.status) || 'active') as any,
    notes: r.notes ? toStr(r.notes) : undefined,
    workerId: toStr(r.workerId),
    workerName: toStr(r.workerName),
    createdAt: toStr(r.createdAt || new Date().toISOString()),
    splitPayments: safeJsonParse(r.splitPayments, undefined),
  })).filter((rec) => rec.id);

  // 10. Users Sheet
  const usersRows = getSheetRows('Users');
  const users = usersRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    name: toStr(r.name),
    email: toStr(r.email),
    pin: toStr(r.pin),
    role: (toStr(r.role) || 'worker') as any,
    status: (toStr(r.status) || 'active') as any,
    phone: r.phone ? toStr(r.phone) : undefined,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
    lastLogin: r.lastLogin ? toStr(r.lastLogin) : undefined,
  })).filter((u) => u.id && u.email);

  // 11. Notices Sheet
  const noticesRows = getSheetRows('Notices');
  const notices = noticesRows.map((r) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    title: toStr(r.title),
    message: toStr(r.message),
    category: (toStr(r.category) || 'general') as any,
    priority: (toStr(r.priority) || 'info') as any,
    authorName: toStr(r.authorName || 'Admin'),
    authorRole: 'admin' as const,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
    isPinned: toBool(r.isPinned, false),
    acknowledgedBy: safeJsonParse(r.acknowledgedBy, []),
  })).filter((n) => n.id && n.title);

  // 12. Vouchers Sheet
  const vouchersRows = getSheetRows('Vouchers');
  const vouchers = vouchersRows.map((r: any) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    code: toStr(r.code),
    name: toStr(r.name || r.code),
    category: (toStr(r.category) || 'All') as any,
    durationMinutes: toNum(r.durationMinutes, 60),
    totalPurchasedHours: toNum(r.totalPurchasedHours, 0),
    usedHours: toNum(r.usedHours, 0),
    remainingHours: toNum(r.remainingHours, 0),
    price: toNum(r.price, 0),
    valueAmount: toNum(r.valueAmount, 0),
    expiryDate: toStr(r.expiryDate || 'never'),
    status: (toStr(r.status) || 'active') as any,
    usageLimit: toNum(r.usageLimit, 1),
    usedCount: toNum(r.usedCount, 0),
    notes: r.notes ? toStr(r.notes) : undefined,
    assignedCustomerId: r.assignedCustomerId ? toStr(r.assignedCustomerId) : undefined,
    assignedCustomerName: r.assignedCustomerName ? toStr(r.assignedCustomerName) : undefined,
    assignedCustomerPhone: r.assignedCustomerPhone ? toStr(r.assignedCustomerPhone) : undefined,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
  })).filter((v: any) => v.id && v.code);

  // 13. Voucher Usages Sheet
  const voucherUsagesRows = getSheetRows('Voucher_Usages');
  const voucherUsages = voucherUsagesRows.map((r: any) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    voucherId: toStr(r.voucherId),
    voucherCode: toStr(r.voucherCode),
    voucherName: toStr(r.voucherName || r.voucherCode),
    customerId: toStr(r.customerId),
    customerName: toStr(r.customerName),
    customerPhone: r.customerPhone ? toStr(r.customerPhone) : undefined,
    sessionId: r.sessionId ? toStr(r.sessionId) : undefined,
    consoleCode: r.consoleCode ? toStr(r.consoleCode) : undefined,
    durationUsedMinutes: toNum(r.durationUsedMinutes, 0),
    valueDiscountApplied: toNum(r.valueDiscountApplied, 0),
    usedAt: toStr(r.usedAt || new Date().toISOString()),
    recordedBy: toStr(r.recordedBy || 'Staff'),
    notes: r.notes ? toStr(r.notes) : undefined,
  })).filter((vu: any) => vu.id);

  // 14. Buy & Sell Items Sheet
  const buySellRows = getSheetRows('Buy_Sell_Items');
  const buySellItems = buySellRows.map((r: any) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    name: toStr(r.name),
    category: (toStr(r.category) || 'Accessories') as any,
    condition: (toStr(r.condition) || 'Used / Pre-owned') as any,
    serialNumber: r.serialNumber ? toStr(r.serialNumber) : undefined,
    purchasePrice: toNum(r.purchasePrice, 0),
    suggestedSellingPrice: toNum(r.suggestedSellingPrice || r.sellingPrice, 0),
    sellerCustomerId: r.sellerCustomerId ? toStr(r.sellerCustomerId) : undefined,
    sellerCustomerName: r.sellerCustomerName || r.sellerCustomer ? toStr(r.sellerCustomerName || r.sellerCustomer) : undefined,
    sellerPhone: r.sellerPhone ? toStr(r.sellerPhone) : undefined,
    purchaseDate: toStr(r.purchaseDate || r.createdAt || new Date().toISOString()),
    status: (toStr(r.status) || 'in_inventory') as any,
    notes: r.notes ? toStr(r.notes) : undefined,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
    soldAt: r.soldAt ? toStr(r.soldAt) : undefined,
    soldPrice: r.soldPrice ? toNum(r.soldPrice, 0) : undefined,
    buyerCustomerId: r.buyerCustomerId ? toStr(r.buyerCustomerId) : undefined,
    buyerCustomerName: r.buyerCustomerName ? toStr(r.buyerCustomerName) : undefined,
    buyerPhone: r.buyerPhone ? toStr(r.buyerPhone) : undefined,
    profit: r.profit ? toNum(r.profit, 0) : undefined,
    invoiceNumber: r.invoiceNumber ? toStr(r.invoiceNumber) : undefined,
    paymentMethod: (toStr(r.paymentMethod) || 'cash') as any,
  })).filter((bs: any) => bs.id && bs.name);

  // 15. Buy & Sell Transactions Sheet
  const buySellTxRows = getSheetRows('Buy_Sell_Transactions');
  const buySellTransactions = buySellTxRows.map((r: any) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    type: (toStr(r.type) || 'sale') as any,
    itemId: toStr(r.itemId),
    itemName: toStr(r.itemName),
    category: (toStr(r.category) || 'Accessories') as any,
    condition: (toStr(r.condition) || 'Used / Pre-owned') as any,
    serialNumber: r.serialNumber ? toStr(r.serialNumber) : undefined,
    customerId: toStr(r.customerId || 'cust_walkin'),
    customerName: toStr(r.customerName || 'Walk-in'),
    customerPhone: r.customerPhone ? toStr(r.customerPhone) : undefined,
    amount: toNum(r.amount, 0),
    purchaseCost: toNum(r.purchaseCost, 0),
    profit: toNum(r.profit, 0),
    paymentMethod: (toStr(r.paymentMethod) || 'cash') as any,
    paymentStatus: (toStr(r.paymentStatus) || 'completed') as any,
    notes: r.notes ? toStr(r.notes) : undefined,
    timestamp: toStr(r.timestamp || r.date || new Date().toISOString()),
    recordedBy: toStr(r.recordedBy || 'Staff'),
  })).filter((tx: any) => tx.id);

  // 16. Repairs Sheet
  const repairRows = getSheetRows('Repairs');
  const repairRecords = repairRows.map((r: any) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    repairNumber: toStr(r.repairNumber || `REP-${r.id}`),
    repairId: toStr(r.repairId || r.id),
    customerId: toStr(r.customerId || 'cust_walkin'),
    customerName: toStr(r.customerName || 'Customer'),
    customerPhone: toStr(r.customerPhone),
    itemName: toStr(r.itemName || r.deviceName),
    category: (toStr(r.category) || 'Controllers') as any,
    serialNumber: r.serialNumber ? toStr(r.serialNumber) : undefined,
    problemDescription: toStr(r.problemDescription || r.issueDescription),
    dateReceived: toStr(r.dateReceived || r.receivedDate || new Date().toISOString()),
    expectedCompletionDate: r.expectedCompletionDate ? toStr(r.expectedCompletionDate) : undefined,
    actualCompletionDate: r.actualCompletionDate || r.completedDate ? toStr(r.actualCompletionDate || r.completedDate) : undefined,
    technicianName: r.technicianName ? toStr(r.technicianName) : undefined,
    repairCost: toNum(r.repairCost, 0),
    customerCharge: toNum(r.customerCharge || r.finalCost || r.estimatedCost, 0),
    advancePayment: toNum(r.advancePayment || r.advancePaid, 0),
    paidAmount: toNum(r.paidAmount || r.advancePaid, 0),
    pendingAmount: toNum(r.pendingAmount, 0),
    paymentStatus: (toStr(r.paymentStatus) || 'pending') as any,
    paymentMethod: (toStr(r.paymentMethod) || 'cash') as any,
    status: (toStr(r.status) || 'Received') as any,
    notes: r.notes || r.technicianNotes ? toStr(r.notes || r.technicianNotes) : undefined,
    createdAt: toStr(r.createdAt || new Date().toISOString()),
    updatedAt: toStr(r.updatedAt || new Date().toISOString()),
    deliveredAt: r.deliveredAt ? toStr(r.deliveredAt) : undefined,
  })).filter((rep: any) => rep.id && rep.itemName);

  // 17. Stock Logs Sheet
  const stockLogRows = getSheetRows('Stock_Logs');
  const cafeteriaStockLogs = stockLogRows.map((r: any) => ({
    id: toStr(r.id),
    businessId: toStr(r.businessId || businessId),
    itemId: toStr(r.itemId),
    itemName: toStr(r.itemName),
    type: (toStr(r.type || r.changeType) || 'stock_in') as any,
    quantityChange: toNum(r.quantityChange || r.quantityChanged, 0),
    previousStock: toNum(r.previousStock, 0),
    newStock: toNum(r.newStock, 0),
    unitPrice: r.unitPrice ? toNum(r.unitPrice, 0) : undefined,
    supplier: r.supplier ? toStr(r.supplier) : undefined,
    notes: r.notes || r.reason ? toStr(r.notes || r.reason) : undefined,
    recordedBy: toStr(r.recordedBy || 'Staff'),
    timestamp: toStr(r.timestamp || r.date || new Date().toISOString()),
  })).filter((sl: any) => sl.id);

  const database: CafeDatabase = {
    version: toNum(s0.version, 1),
    businessId,
    ownerId: s0.ownerId || undefined,
    ownerEmail: s0.ownerEmail || undefined,
    lastModified: s0.lastModified || new Date().toISOString(),
    lastResetAt: s0.lastResetAt || undefined,
    settings,
    consoles,
    sessions,
    customers,
    payments,
    cafeteriaItems,
    cafeteriaOrders,
    cafeteriaStockLogs,
    rentalItems,
    rentalRecords,
    vouchers,
    voucherUsages,
    buySellItems,
    buySellTransactions,
    repairRecords,
    users,
    notices,
    deletedConsoleIds: s0.deletedConsoleIds ? safeJsonParse(toStr(s0.deletedConsoleIds), []) : [],
  };

  return database;
}

/**
 * Parses a binary buffer, ArrayBuffer, or Base64 string into a CafeDatabase.
 */
export function xlsxBufferToCafeDatabase(
  bufferOrBase64: ArrayBuffer | Uint8Array | Buffer | string,
  defaultBusinessId = 'NEXTGEN_CAFE_BUSINESS_ID'
): CafeDatabase {
  let wb: XLSX.WorkBook;
  if (typeof bufferOrBase64 === 'string') {
    wb = XLSX.read(bufferOrBase64, { type: 'base64' });
  } else if (bufferOrBase64 instanceof Uint8Array || Buffer.isBuffer(bufferOrBase64)) {
    wb = XLSX.read(bufferOrBase64, { type: 'buffer' });
  } else {
    wb = XLSX.read(new Uint8Array(bufferOrBase64), { type: 'array' });
  }
  return xlsxWorkbookToCafeDatabase(wb, defaultBusinessId);
}
