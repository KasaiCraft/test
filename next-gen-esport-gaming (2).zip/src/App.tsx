import React, { useState, Component, ReactNode } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CafeProvider, useCafe } from './context/CafeContext';
import { LoginPage } from './components/auth/LoginPage';
import { LandingPage } from './components/landing/LandingPage';
import { RoleSelectScreen } from './components/auth/RoleSelectScreen';
import { RoleSwitchModal } from './components/modals/RoleSwitchModal';
import { Gamepad2, Loader2, AlertTriangle, RefreshCw } from 'lucide-react';
import { ProtectedRoute, PublicRoute } from './components/auth/ProtectedRoute';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardView } from './components/dashboard/DashboardView';
import { GamingConsolesView } from './components/consoles/GamingConsolesView';
import { CustomersView } from './components/customers/CustomersView';
import { RentalsView } from './components/rentals/RentalsView';
import { CafeteriaView } from './components/cafeteria/CafeteriaView';
import { VouchersView } from './components/vouchers/VouchersView';
import { RepairsView } from './components/repairs/RepairsView';
import { BuySellView } from './components/buysell/BuySellView';
import { PaymentsView } from './components/payments/PaymentsView';
import { ReportsView } from './components/reports/ReportsView';
import { DataCenterView } from './components/datacenter/DataCenterView';
import { WorkersView } from './components/workers/WorkersView';
import { SettingsView } from './components/settings/SettingsView';

import { StartSessionModal } from './components/modals/StartSessionModal';
import { EndSessionModal } from './components/modals/EndSessionModal';
import { ExtendSessionModal } from './components/modals/ExtendSessionModal';
import { NewRentalModal } from './components/modals/NewRentalModal';
import { ReturnRentalModal } from './components/modals/ReturnRentalModal';
import { ExtendRentalModal } from './components/modals/ExtendRentalModal';
import { CustomerModal } from './components/modals/CustomerModal';
import { ConsoleModal } from './components/modals/ConsoleModal';
import { RentalItemModal } from './components/modals/RentalItemModal';
import { WorkerModal } from './components/modals/WorkerModal';
import { DirectPaymentModal } from './components/modals/DirectPaymentModal';
import { ReceiptModal } from './components/modals/ReceiptModal';
import { LoginModal } from './components/modals/LoginModal';
import { SessionAlertBanner } from './components/layout/SessionAlertBanner';
import { StaffNoticeBanner } from './components/common/StaffNoticeBanner';
import { AdminNoticeCenter } from './components/common/AdminNoticeCenter';
import { PrivacyPolicyPage } from './components/legal/PrivacyPolicyPage';
import { TermsPage } from './components/legal/TermsPage';

import {
  GamingSession,
  ConsoleDevice,
  RentalItem,
  RentalRecord,
  Customer,
  UserAccount,
  PaymentTransaction,
} from './types';

/**
 * Robust Error Boundary to catch component crashes (like null pointer splits)
 * and prevent the dreaded "Black Screen".
 */
interface EBProps { children: ReactNode }
interface EBState { hasError: boolean; error: any }

class ErrorBoundary extends React.Component<EBProps, EBState> {
  public override state: EBState = { hasError: false, error: null };

  constructor(props: EBProps) {
    super(props);
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error('[AppErrorBoundary] Caught crash:', error, errorInfo);
  }

  render() {
    const { hasError, error } = this.state;
    const { children } = this.props;

    if (hasError) {
      return (
        <div className="min-h-screen w-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 bg-rose-500/10 border border-rose-500/30 text-rose-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-rose-500/5">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h1 className="text-xl font-bold text-white mb-2">Terminal Runtime Error</h1>
          <p className="text-slate-400 text-sm max-w-md mb-8 leading-relaxed">
            The application encountered an unexpected crash while rendering. This is usually caused by a data mismatch or a temporary sync delay.
          </p>
          <div className="flex gap-3">
            <button 
              onClick={() => window.location.reload()}
              className="flex items-center gap-2 px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 rounded-xl text-sm font-bold transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              Reset Terminal
            </button>
          </div>
          {error && (
            <div className="mt-12 p-4 bg-slate-900/50 border border-slate-800 rounded-xl text-left max-w-2xl w-full overflow-hidden">
              <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-2">Debug Trace</p>
              <p className="text-[11px] font-mono text-rose-400/80 break-all leading-tight">
                {String(error.message || error)}
              </p>
            </div>
          )}
        </div>
      );
    }
    return children;
  }
}

const AppContent: React.FC = () => {
  const { user, loading, verifiedRole } = useAuth();
  const { isAdmin } = useCafe();
  const [mobileOpen, setMobileOpen] = useState(false);

  // Role Switch Modal
  const [isRoleSwitchModalOpen, setIsRoleSwitchModalOpen] = useState(false);

  // Modal States
  const [isStartSessionOpen, setIsStartSessionOpen] = useState(false);
  const [sessionConsoleId, setSessionConsoleId] = useState<string | undefined>(undefined);
  const [sessionCustomer, setSessionCustomer] = useState<Customer | undefined>(undefined);

  const [isEndSessionOpen, setIsEndSessionOpen] = useState(false);
  const [sessionToEnd, setSessionToEnd] = useState<GamingSession | null>(null);

  const [isExtendSessionOpen, setIsExtendSessionOpen] = useState(false);
  const [sessionToExtend, setSessionToExtend] = useState<GamingSession | null>(null);

  const [isNewRentalOpen, setIsNewRentalOpen] = useState(false);
  const [rentalItemId, setRentalItemId] = useState<string | undefined>(undefined);
  const [rentalCustomer, setRentalCustomer] = useState<Customer | undefined>(undefined);

  const [isReturnRentalOpen, setIsReturnRentalOpen] = useState(false);
  const [rentalToReturn, setRentalToReturn] = useState<RentalRecord | null>(null);

  const [isExtendRentalOpen, setIsExtendRentalOpen] = useState(false);
  const [rentalToExtend, setRentalToExtend] = useState<RentalRecord | null>(null);

  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);

  const [isConsoleModalOpen, setIsConsoleModalOpen] = useState(false);
  const [consoleToEdit, setConsoleToEdit] = useState<ConsoleDevice | null>(null);

  const [isRentalItemModalOpen, setIsRentalItemModalOpen] = useState(false);
  const [rentalItemToEdit, setRentalItemToEdit] = useState<RentalItem | null>(null);

  const [isWorkerModalOpen, setIsWorkerModalOpen] = useState(false);
  const [workerToEdit, setWorkerToEdit] = useState<UserAccount | null>(null);

  const [isDirectPaymentOpen, setIsDirectPaymentOpen] = useState(false);

  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [receiptTransaction, setReceiptTransaction] = useState<PaymentTransaction | null>(null);

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isNoticeCenterOpen, setIsNoticeCenterOpen] = useState(false);

  // Quick action handlers
  const handleOpenStartSession = (consoleId?: string, customer?: Customer) => {
    setSessionConsoleId(consoleId);
    setSessionCustomer(customer);
    setIsStartSessionOpen(true);
  };

  const handleOpenStopSession = (session: GamingSession) => {
    setSessionToEnd(session);
    setIsEndSessionOpen(true);
  };

  const handleOpenExtendSession = (session: GamingSession) => {
    setSessionToExtend(session);
    setIsExtendSessionOpen(true);
  };

  const handleOpenNewRental = (itemId?: string, customer?: Customer) => {
    setRentalItemId(itemId);
    setRentalCustomer(customer);
    setIsNewRentalOpen(true);
  };

  const handleOpenReturnRental = (record: RentalRecord) => {
    setRentalToReturn(record);
    setIsReturnRentalOpen(true);
  };

  const handleOpenExtendRental = (record: RentalRecord) => {
    setRentalToExtend(record);
    setIsExtendRentalOpen(true);
  };

  const handleOpenCustomerModal = (customer?: Customer) => {
    setCustomerToEdit(customer || null);
    setIsCustomerModalOpen(true);
  };

  const handleOpenConsoleModal = (console?: ConsoleDevice) => {
    setConsoleToEdit(console || null);
    setIsConsoleModalOpen(true);
  };

  const handleOpenRentalItemModal = (item?: RentalItem) => {
    setRentalItemToEdit(item || null);
    setIsRentalItemModalOpen(true);
  };

  const handleOpenWorkerModal = (worker?: UserAccount) => {
    setWorkerToEdit(worker || null);
    setIsWorkerModalOpen(true);
  };

  const handleOpenReceipt = (transaction: PaymentTransaction) => {
    setReceiptTransaction(transaction);
    setIsReceiptModalOpen(true);
  };

  // Helper when a session checkout is finished to display receipt
  const handleSessionCheckoutComplete = (completedSession: GamingSession) => {
    const receiptTx: PaymentTransaction = {
      id: `tx-${Date.now()}`,
      type: 'gaming_session',
      customerId: completedSession.customerId,
      customerName: completedSession.customerName,
      referenceId: completedSession.id,
      referenceTitle: `${completedSession.consoleCode} Gaming Session (${completedSession.durationMinutes}m)`,
      amount: completedSession.paidAmount,
      method: completedSession.paymentMethod || 'upi',
      status: 'paid',
      timestamp: new Date().toISOString(),
      recordedBy: 'Shift Staff',
    };
    handleOpenReceipt(receiptTx);
  };

  if (loading) {
    return (
      <div className="min-h-screen w-screen bg-slate-950 flex flex-col items-center justify-center p-6">
        <div className="relative mb-8">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center animate-pulse">
            <Gamepad2 className="w-8 h-8 text-cyan-400 animate-spin" />
          </div>
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-950 animate-ping" />
        </div>
        <div className="text-center">
          <h2 className="text-white text-lg font-black tracking-[0.2em] uppercase mb-1">
            Next Gen Esport
          </h2>
          <p className="text-slate-500 text-[10px] font-mono tracking-widest uppercase">
            Initializing Terminal Session...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!verifiedRole) {
    return <RoleSelectScreen />;
  }

  return (
    <ErrorBoundary>
      <div className="flex h-screen w-screen bg-slate-950 text-slate-100 font-sans overflow-hidden antialiased select-none">
        {/* Persistent Sidebar Navigation */}
        <Sidebar
          mobileOpen={mobileOpen}
          setMobileOpen={setMobileOpen}
          onOpenLoginModal={() => setIsLoginModalOpen(true)}
          onOpenRoleSwitchModal={() => setIsRoleSwitchModalOpen(true)}
        />

        {/* Main Column */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-slate-950">
          {/* Persistent Top Header with context from current route */}
          <Header
            onOpenMobileMenu={() => setMobileOpen(true)}
            onOpenStartSession={() => handleOpenStartSession()}
            onOpenNewRental={() => handleOpenNewRental()}
            onOpenNoticeCenter={() => setIsNoticeCenterOpen(true)}
            onOpenRoleSwitchModal={() => setIsRoleSwitchModalOpen(true)}
          />

          {/* Real-time Broadcast Notice Banner for Staff & Admin */}
          <StaffNoticeBanner onOpenNoticeCenter={() => setIsNoticeCenterOpen(true)} />

          {/* Scrollable View Port with Routes */}
          <main className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-8 custom-scrollbar">
            <div className="max-w-7xl mx-auto">
              <Routes>
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                <Route
                  path="/dashboard"
                  element={
                    <DashboardView
                      onOpenStartSessionModal={handleOpenStartSession}
                      onOpenStopSessionModal={handleOpenStopSession}
                      onOpenNewRentalModal={handleOpenNewRental}
                      onOpenReturnRentalModal={handleOpenReturnRental}
                      onOpenCustomerModal={handleOpenCustomerModal}
                    />
                  }
                />
                <Route
                  path="/gaming"
                  element={
                    <GamingConsolesView
                      onOpenStartSession={handleOpenStartSession}
                      onOpenStopSession={handleOpenStopSession}
                      onOpenExtendSession={handleOpenExtendSession}
                      onOpenConsoleModal={handleOpenConsoleModal}
                    />
                  }
                />
                <Route
                  path="/customers"
                  element={
                    <CustomersView
                      onOpenCustomerModal={handleOpenCustomerModal}
                      onOpenStartSessionWithCustomer={(c) => handleOpenStartSession(undefined, c)}
                      onOpenNewRentalWithCustomer={(c) => handleOpenNewRental(undefined, c)}
                      onOpenReceiptModal={handleOpenReceipt}
                    />
                  }
                />
                <Route
                  path="/rentals"
                  element={
                    <RentalsView
                      onOpenNewRental={handleOpenNewRental}
                      onOpenReturnRental={handleOpenReturnRental}
                      onOpenExtendRental={handleOpenExtendRental}
                      onOpenRentalItemModal={handleOpenRentalItemModal}
                    />
                  }
                />
                <Route
                  path="/cafeteria"
                  element={<CafeteriaView onOpenReceiptModal={handleOpenReceipt} />}
                />
                <Route
                  path="/vouchers"
                  element={<VouchersView />}
                />
                <Route
                  path="/repairs"
                  element={<RepairsView />}
                />
                <Route
                  path="/buysell"
                  element={<BuySellView />}
                />
                <Route
                  path="/payments"
                  element={
                    <PaymentsView
                      onOpenNewPaymentModal={() => setIsDirectPaymentOpen(true)}
                      onOpenReceiptModal={handleOpenReceipt}
                    />
                  }
                />
                <Route
                  path="/reports"
                  element={isAdmin ? <ReportsView /> : <Navigate to="/dashboard" replace />}
                />
                <Route
                  path="/datacenter"
                  element={isAdmin ? <DataCenterView /> : <Navigate to="/dashboard" replace />}
                />
                <Route
                  path="/workers"
                  element={isAdmin ? <WorkersView onOpenWorkerModal={handleOpenWorkerModal} /> : <Navigate to="/dashboard" replace />}
                />
                <Route
                  path="/settings"
                  element={isAdmin ? <SettingsView /> : <Navigate to="/dashboard" replace />}
                />
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </Routes>
            </div>
          </main>
        </div>

        {/* Global Interactive Modals */}
        <RoleSwitchModal
          isOpen={isRoleSwitchModalOpen}
          onClose={() => setIsRoleSwitchModalOpen(false)}
        />
        <StartSessionModal
          isOpen={isStartSessionOpen}
          onClose={() => {
            setIsStartSessionOpen(false);
            setSessionConsoleId(undefined);
            setSessionCustomer(undefined);
          }}
          preselectedConsoleId={sessionConsoleId}
          preselectedCustomer={sessionCustomer}
        />

        <EndSessionModal
          isOpen={isEndSessionOpen}
          onClose={() => {
            setIsEndSessionOpen(false);
            setSessionToEnd(null);
          }}
          session={sessionToEnd}
          onSessionCompleted={handleSessionCheckoutComplete}
        />

        <ExtendSessionModal
          isOpen={isExtendSessionOpen}
          onClose={() => {
            setIsExtendSessionOpen(false);
            setSessionToExtend(null);
          }}
          session={sessionToExtend}
        />

        <NewRentalModal
          isOpen={isNewRentalOpen}
          onClose={() => {
            setIsNewRentalOpen(false);
            setRentalItemId(undefined);
            setRentalCustomer(undefined);
          }}
          preselectedItemId={rentalItemId}
          preselectedCustomer={rentalCustomer}
        />

        <ReturnRentalModal
          isOpen={isReturnRentalOpen}
          onClose={() => {
            setIsReturnRentalOpen(false);
            setRentalToReturn(null);
          }}
          record={rentalToReturn}
        />

        <ExtendRentalModal
          isOpen={isExtendRentalOpen}
          onClose={() => {
            setIsExtendRentalOpen(false);
            setRentalToExtend(null);
          }}
          rental={rentalToExtend}
        />

        <CustomerModal
          isOpen={isCustomerModalOpen}
          onClose={() => {
            setIsCustomerModalOpen(false);
            setCustomerToEdit(null);
          }}
          customerToEdit={customerToEdit}
        />

        <ConsoleModal
          isOpen={isConsoleModalOpen}
          onClose={() => {
            setIsConsoleModalOpen(false);
            setConsoleToEdit(null);
          }}
          consoleToEdit={consoleToEdit}
        />

        <RentalItemModal
          isOpen={isRentalItemModalOpen}
          onClose={() => {
            setIsRentalItemModalOpen(false);
            setRentalItemToEdit(null);
          }}
          itemToEdit={rentalItemToEdit}
        />

        <WorkerModal
          isOpen={isWorkerModalOpen}
          onClose={() => {
            setIsWorkerModalOpen(false);
            setWorkerToEdit(null);
          }}
          workerToEdit={workerToEdit}
        />

        <DirectPaymentModal
          isOpen={isDirectPaymentOpen}
          onClose={() => setIsDirectPaymentOpen(false)}
        />

        <ReceiptModal
          isOpen={isReceiptModalOpen}
          onClose={() => {
            setIsReceiptModalOpen(false);
            setReceiptTransaction(null);
          }}
          transaction={receiptTransaction}
        />

        <LoginModal
          isOpen={isLoginModalOpen}
          onClose={() => setIsLoginModalOpen(false)}
        />

        <AdminNoticeCenter
          isOpen={isNoticeCenterOpen}
          onClose={() => setIsNoticeCenterOpen(false)}
        />

        {/* Global Session Over Alerts */}
        <SessionAlertBanner onOpenStopSession={handleOpenStopSession} />
      </div>
    </ErrorBoundary>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <CafeProvider>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/*" element={<AppContent />} />
          </Routes>
        </CafeProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
