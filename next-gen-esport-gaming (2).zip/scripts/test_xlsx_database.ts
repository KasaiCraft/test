import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';
import { INITIAL_DATABASE } from '../src/data/initialData.ts';
import {
  cafeDatabaseToXlsxWorkbook,
  cafeDatabaseToXlsxBuffer,
  xlsxBufferToCafeDatabase,
  cafeDatabaseToXlsxBase64,
} from '../src/utils/xlsxDatabase.ts';
import {
  DEFAULT_FILE_NAME,
  LEGACY_FILE_NAME,
  findOrCreateDriveFolder,
  findDriveDatabaseFile,
  readDriveDatabaseFile,
  writeDriveDatabaseFile,
  getGoogleDriveClient,
  FOLDER_NAME,
} from '../netlify/functions/lib/googleDriveClient.ts';

const BASE_URL = 'http://localhost:3000';

function makeMockToken(payload: {
  uid: string;
  email?: string;
  role: 'owner' | 'worker';
  businessId: string;
  ownerUid?: string;
}) {
  const b64 = Buffer.from(JSON.stringify(payload)).toString('base64');
  return `mock_test_token_.${b64}.mock_sig`;
}

async function runXlsxTests() {
  console.log('\n=============================================================');
  console.log('STARTING EXCEL (.xlsx) DATABASE VERIFICATION & AUDIT');
  console.log('=============================================================\n');

  let allPassed = true;
  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
    } else {
      console.error(`❌ FAIL: ${testName} - ${detail || 'Assertion failed'}`);
      allPassed = false;
    }
  }

  // 1. Workbook Generation & Sheet Verification
  console.log('--- Test 1: Workbook Structure & Sheet Generation ---');
  const wb = cafeDatabaseToXlsxWorkbook(INITIAL_DATABASE);
  const expectedSheets = [
    'Settings',
    'Devices',
    'Sessions',
    'Customers',
    'Payments',
    'Invoices',
    'Cafeteria',
    'Cafeteria_Orders',
    'Inventory',
    'Rentals',
    'Users',
    'Notices',
    'Expenses',
    'Memberships',
    'Reservations',
  ];

  for (const sheet of expectedSheets) {
    assert(wb.SheetNames.includes(sheet), `Sheet '${sheet}' exists in workbook`);
  }

  // 2. Full Round-trip Conversion Integrity
  console.log('\n--- Test 2: Full Round-Trip Serialization & Deserialization ---');
  const buf = cafeDatabaseToXlsxBuffer(INITIAL_DATABASE);
  assert(buf.byteLength > 1000, 'XLSX buffer generated with valid binary size (> 1KB)');

  const restored = xlsxBufferToCafeDatabase(buf, INITIAL_DATABASE.businessId);
  assert(restored.businessId === INITIAL_DATABASE.businessId, 'BusinessId preserved');
  assert(restored.settings.cafeName === INITIAL_DATABASE.settings.cafeName, 'Settings cafeName preserved');
  assert(restored.consoles.length === INITIAL_DATABASE.consoles.length, 'Consoles length preserved');
  if (INITIAL_DATABASE.consoles.length > 0) {
    assert(restored.consoles[0].name === INITIAL_DATABASE.consoles[0].name, 'Console 0 name preserved');
  }
  assert(restored.cafeteriaItems.length === INITIAL_DATABASE.cafeteriaItems.length, 'Cafeteria items preserved');
  assert(restored.rentalItems.length === INITIAL_DATABASE.rentalItems.length, 'Rental items preserved');

  // 3. Base64 Conversion
  console.log('\n--- Test 3: Base64 String Encoding & Parsing ---');
  const b64 = cafeDatabaseToXlsxBase64(INITIAL_DATABASE);
  assert(typeof b64 === 'string' && b64.length > 500, 'Valid base64 string produced');
  const fromB64 = xlsxBufferToCafeDatabase(b64, INITIAL_DATABASE.businessId);
  assert(fromB64.consoles.length === INITIAL_DATABASE.consoles.length, 'Decoded from base64 correctly');

  // 4. Server-Side Google Drive Client: Writing and Reading .xlsx
  console.log('\n--- Test 4: Google Drive Client Server-Side XLSX Read/Write ---');
  const mockTenant = 'xlsx_test_tenant';
  const refreshToken = `mock_refresh_token_${mockTenant}`;
  const { drive } = getGoogleDriveClient(refreshToken);
  const folderId = await findOrCreateDriveFolder(drive, refreshToken, FOLDER_NAME);

  const writeRes = await writeDriveDatabaseFile(
    drive,
    refreshToken,
    folderId,
    DEFAULT_FILE_NAME,
    null,
    INITIAL_DATABASE
  );
  assert(Boolean(writeRes.fileId), 'writeDriveDatabaseFile created .xlsx file in mock Drive');

  // Verify the file created on disk is a real Excel file
  const mockFilePath = path.resolve(process.cwd(), '.data', 'mock_drive', `${mockTenant}_${DEFAULT_FILE_NAME}`);
  assert(fs.existsSync(mockFilePath), `File exists on disk at ${mockFilePath}`);

  const diskBuf = fs.readFileSync(mockFilePath);
  const parsedFromDiskWb = XLSX.read(diskBuf, { type: 'buffer' });
  assert(parsedFromDiskWb.SheetNames.includes('Settings'), 'Disk file is a valid XLSX workbook containing Settings sheet');
  assert(parsedFromDiskWb.SheetNames.includes('Devices'), 'Disk file contains Devices sheet');

  // Test readDriveDatabaseFile with .xlsx
  const readDb = await readDriveDatabaseFile(drive, refreshToken, writeRes.fileId, DEFAULT_FILE_NAME);
  assert(readDb.consoles.length === INITIAL_DATABASE.consoles.length, 'readDriveDatabaseFile parses .xlsx correctly');
  assert(readDb.settings.cafeName === INITIAL_DATABASE.settings.cafeName, 'readDriveDatabaseFile preserves settings');

  // 5. Automatic Legacy JSON to XLSX Migration
  console.log('\n--- Test 5: Automatic Legacy JSON to XLSX Migration ---');
  const migTenant = 'migration_test_tenant';
  const migToken = `mock_refresh_token_${migTenant}`;
  const { drive: migDrive } = getGoogleDriveClient(migToken);
  const migFolderId = await findOrCreateDriveFolder(migDrive, migToken, FOLDER_NAME);

  // Seed a legacy JSON file on mock drive
  const legacyJsonPath = path.resolve(process.cwd(), '.data', 'mock_drive', `${migTenant}_${LEGACY_FILE_NAME}`);
  const legacyXlsxPath = path.resolve(process.cwd(), '.data', 'mock_drive', `${migTenant}_${DEFAULT_FILE_NAME}`);
  if (fs.existsSync(legacyXlsxPath)) fs.unlinkSync(legacyXlsxPath);
  fs.writeFileSync(legacyJsonPath, JSON.stringify(INITIAL_DATABASE, null, 2), 'utf-8');
  assert(fs.existsSync(legacyJsonPath), 'Legacy JSON seeded in mock Drive');

  // findDriveDatabaseFile should detect the legacy JSON
  const foundLegacy = await findDriveDatabaseFile(migDrive, migToken, migFolderId, DEFAULT_FILE_NAME);
  assert(Boolean(foundLegacy && foundLegacy.isLegacyJson), 'findDriveDatabaseFile detects legacy JSON file');

  // Reading legacy file converts smoothly
  const readLegacy = await readDriveDatabaseFile(migDrive, migToken, foundLegacy!.fileId, foundLegacy!.fileName);
  assert(readLegacy.consoles.length === INITIAL_DATABASE.consoles.length, 'Legacy JSON read into database object');

  // Writing XLSX cleans up legacy JSON
  const migWrite = await writeDriveDatabaseFile(
    migDrive,
    migToken,
    migFolderId,
    DEFAULT_FILE_NAME,
    null,
    readLegacy
  );
  assert(fs.existsSync(legacyXlsxPath), 'New cafe_database.xlsx created');
  assert(!fs.existsSync(legacyJsonPath), 'Legacy JSON safely cleaned up');

  // 6. Live API HTTP Testing: Owner Connect & Sync as XLSX
  console.log('\n--- Test 6: Live API Sync Over HTTP (/api/drive-database) ---');
  const liveTenant = 'biz_live_xlsx_tenant';
  const ownerToken = makeMockToken({
    uid: 'live_owner_uid',
    email: 'live_owner@example.com',
    role: 'owner',
    businessId: liveTenant,
  });

  // Connect Drive via /api/drive-auth
  const authRes = await fetch(`${BASE_URL}/api/drive-auth`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${ownerToken}`,
    },
    body: JSON.stringify({
      code: `mock_test_code_${liveTenant}`,
    }),
  });
  assert(authRes.status === 200, 'Owner connected Google Drive via /api/drive-auth');

  // Worker writes new console to the shared database
  const workerToken = makeMockToken({
    uid: 'live_worker_uid',
    email: 'live_worker@example.com',
    role: 'worker',
    businessId: liveTenant,
    ownerUid: 'live_owner_uid',
  });

  const updatedDb = {
    ...INITIAL_DATABASE,
    businessId: liveTenant,
    consoles: [
      ...INITIAL_DATABASE.consoles,
      {
        id: 'new-ps5-pro-99',
        name: 'PS5 Pro Station 99',
        type: 'PS5',
        hourlyRate: 150,
        status: 'available',
        businessId: liveTenant,
      },
    ],
  };

  const writePostRes = await fetch(`${BASE_URL}/api/drive-database`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${workerToken}`,
    },
    body: JSON.stringify({
      database: updatedDb,
      xlsxBase64: cafeDatabaseToXlsxBase64(updatedDb as any),
    }),
  });
  const writePostJson = await writePostRes.json();
  assert(writePostRes.status === 200 && writePostJson.success === true, 'Worker POST to /api/drive-database succeeded');
  assert(Boolean(writePostJson.data.xlsxBase64), 'POST response returned xlsxBase64 payload');

  // Worker reads back the shared database
  const readGetRes = await fetch(`${BASE_URL}/api/drive-database`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${workerToken}`,
    },
  });
  const readGetJson = await readGetRes.json();
  assert(readGetRes.status === 200 && readGetJson.success === true, 'Worker GET from /api/drive-database succeeded');
  assert(
    readGetJson.data.consoles.some((c: any) => c.id === 'new-ps5-pro-99'),
    'Worker successfully verified newly written console from the shared .xlsx file'
  );
  assert(Boolean(readGetJson.data.xlsxBase64), 'GET response contains xlsxBase64 data');

  // Verify the file stored in Google Drive is truly an XLSX workbook
  const liveMockPath = path.resolve(process.cwd(), '.data', 'mock_drive', `${liveTenant}_${DEFAULT_FILE_NAME}`);
  assert(fs.existsSync(liveMockPath), `Live mock Drive file is ${DEFAULT_FILE_NAME}`);
  const liveXlsxBuf = fs.readFileSync(liveMockPath);
  const liveWb = XLSX.read(liveXlsxBuf, { type: 'buffer' });
  assert(liveWb.SheetNames.includes('Devices'), 'Live Drive file contains Devices sheet');
  const devicesSheet = XLSX.utils.sheet_to_json(liveWb.Sheets['Devices']);
  assert(
    devicesSheet.some((d: any) => d.id === 'new-ps5-pro-99'),
    'Station 99 verified inside the actual Excel Devices worksheet'
  );

  console.log('\n=============================================================');
  console.log(allPassed ? '🎉 ALL EXCEL (.xlsx) TESTS PASSED SUCCESSFULLY!' : '❌ SOME TESTS FAILED');
  console.log('=============================================================\n');

  if (!allPassed) {
    process.exit(1);
  }
}

runXlsxTests().catch((err) => {
  console.error('Fatal error during XLSX tests:', err);
  process.exit(1);
});
