import { encryptToken, decryptToken } from '../netlify/functions/lib/crypto.ts';
import { getTenantVault, saveTenantVault, saveWorkerBinding } from '../netlify/functions/lib/tenantVault.ts';
import { handler as driveAuthHandler } from '../netlify/functions/drive-auth.ts';
import { handler as driveDbHandler } from '../netlify/functions/drive-database.ts';
import { handler as driveDisconnectHandler } from '../netlify/functions/drive-disconnect.ts';
import { getAdminAuth } from '../netlify/functions/lib/firebaseAdmin.ts';
import fs from 'fs';
import path from 'path';

async function runTestMatrix() {
  console.log('====================================================');
  console.log('RUNNING PHASE 3 TEST MATRIX (TESTS 1 - 15)');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`✅ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`❌ [FAIL] ${testName} - ${detail || 'Assertion failed'}`);
      failed++;
    }
  }

  // Setup test environment
  const adminAuth = getAdminAuth();

  // Create mock Firebase test tokens using createCustomToken or mocked context
  const ownerBizA = 'biz_matrix_tenant_a';
  const ownerUidA = 'owner_matrix_uid_a';
  const workerUidA = 'worker_matrix_uid_a';

  const ownerBizB = 'biz_matrix_tenant_b';
  const ownerUidB = 'owner_matrix_uid_b';
  const workerUidB = 'worker_matrix_uid_b';

  // Clean mock drive files for isolated test matrix tenants before beginning
  const mockDriveDir = path.resolve(process.cwd(), '.data', 'mock_drive');
  for (const f of [`${ownerBizA}_NextGenGaming_Cafe_Data.xlsx`, `${ownerBizB}_NextGenGaming_Cafe_Data.xlsx`]) {
    const fp = path.join(mockDriveDir, f);
    if (fs.existsSync(fp)) {
      try { fs.unlinkSync(fp); } catch {}
    }
  }

  // Mint Custom tokens and mock decoded tokens for test runner
  // Create worker binding in vault
  await saveWorkerBinding({
    workerUid: workerUidA,
    workerEmail: 'worker_a@example.com',
    workerName: 'Worker A',
    businessId: ownerBizA,
    ownerUid: ownerUidA,
    role: 'worker',
    createdAt: new Date().toISOString(),
  });

  await saveWorkerBinding({
    workerUid: workerUidB,
    workerEmail: 'worker_b@example.com',
    workerName: 'Worker B',
    businessId: ownerBizB,
    ownerUid: ownerUidB,
    role: 'worker',
    createdAt: new Date().toISOString(),
  });

  // Mock token generator for testing Netlify handlers
  function makeMockEvent(options: {
    method: string;
    path: string;
    body?: any;
    query?: Record<string, string>;
    uid?: string;
    email?: string;
    role?: 'owner' | 'worker';
    businessId?: string;
    ownerUid?: string;
    noAuth?: boolean;
  }) {
    const headers: Record<string, string> = {
      'content-type': 'application/json',
    };

    if (!options.noAuth && options.uid) {
      // Encode simulated claims in a signed test token format handled by verifyIdToken or test token mock
      const payload = {
        uid: options.uid,
        email: options.email || `${options.uid}@example.com`,
        role: options.role || 'owner',
        businessId: options.businessId || ownerBizA,
        ownerUid: options.ownerUid,
      };
      // Create base64 encoded token: header.payload.signature
      const b64Header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64');
      const b64Payload = Buffer.from(JSON.stringify(payload)).toString('base64');
      headers['authorization'] = `Bearer mock_test_token_${b64Header}.${b64Payload}.mock_sig`;
    }

    return {
      rawUrl: `http://localhost:3000${options.path}`,
      path: options.path,
      httpMethod: options.method,
      headers,
      queryStringParameters: options.query || {},
      body: options.body ? JSON.stringify(options.body) : null,
      isBase64Encoded: false,
    } as any;
  }

  // TEST 1: Owner Connect Drive Flow
  console.log('--- Test 1: Owner Connect Drive Flow ---');
  const authEvent1 = makeMockEvent({
    method: 'POST',
    path: '/api/drive-auth',
    uid: ownerUidA,
    role: 'owner',
    businessId: ownerBizA,
    body: {
      code: `mock_test_code_${ownerBizA}`,
      redirectUri: 'postmessage',
    },
  });

  const res1 = (await driveAuthHandler(authEvent1, {} as any)) as any;
  const body1 = JSON.parse(res1?.body || '{}');

  const vaultA = await getTenantVault(ownerBizA);
  assert(
    res1.statusCode === 200 &&
      body1.success === true &&
      body1.data.isConnected === true &&
      !body1.data.refreshToken &&
      !body1.data.accessToken &&
      !body1.data.client_secret,
    'Test 1: Owner Connect Drive Flow - Temporary code exchanged, no tokens returned to client'
  );

  assert(
    !!vaultA?.encryptedRefreshToken &&
      vaultA.encryptedRefreshToken.includes(':') &&
      vaultA.businessId === ownerBizA,
    'Test 1: Encrypted refresh token stored in _tenant_vault'
  );

  // TEST 2: Worker Login - Role & permissions verification
  console.log('\n--- Test 2: Worker Login ---');
  assert(
    vaultA?.encryptedRefreshToken !== null,
    'Test 2: Worker does not need Google OAuth; Owner has connected Drive for tenant'
  );

  // TEST 3: Worker Database Read
  console.log('\n--- Test 3: Worker Database Read ---');
  // First, populate initial data into tenant A's Drive
  const initWriteEvent = makeMockEvent({
    method: 'POST',
    path: '/api/drive-database',
    uid: ownerUidA,
    role: 'owner',
    businessId: ownerBizA,
    body: {
      businessId: ownerBizA,
      consoles: [{ id: 'c1', name: 'PS5 #1', status: 'available', businessId: ownerBizA }],
      sessions: [],
      customers: [],
      users: [],
      settings: { businessId: ownerBizA, cafeName: 'Tenant A Cafe' },
    },
  });
  await driveDbHandler(initWriteEvent, {} as any);

  // Now Worker A reads tenant A data
  const workerReadEvent = makeMockEvent({
    method: 'GET',
    path: '/api/drive-database',
    uid: workerUidA,
    role: 'worker',
    businessId: ownerBizA,
    ownerUid: ownerUidA,
  });
  const res3 = (await driveDbHandler(workerReadEvent, {} as any)) as any;
  const body3 = JSON.parse(res3?.body || '{}');
  assert(
    res3?.statusCode === 200 &&
      body3.success === true &&
      body3.data.businessId === ownerBizA &&
      body3.data.consoles.length === 1 &&
      body3.data.consoles[0].name === 'PS5 #1',
    'Test 3: Worker Database Read - Worker reads Owner Google Drive data via verified Firebase claims'
  );

  // TEST 4: Worker Database Write
  console.log('\n--- Test 4: Worker Database Write ---');
  const workerWriteEvent = makeMockEvent({
    method: 'POST',
    path: '/api/drive-database',
    uid: workerUidA,
    role: 'worker',
    businessId: ownerBizA,
    ownerUid: ownerUidA,
    body: {
      businessId: ownerBizA,
      consoles: [{ id: 'c1', name: 'PS5 #1', status: 'active', businessId: ownerBizA }],
      sessions: [{ id: 's1', consoleId: 'c1', status: 'active', businessId: ownerBizA }],
      customers: [],
      users: [],
      settings: { businessId: ownerBizA, cafeName: 'Tenant A Cafe' },
    },
  });
  const res4 = (await driveDbHandler(workerWriteEvent, {} as any)) as any;
  const body4 = JSON.parse(res4?.body || '{}');
  assert(
    res4?.statusCode === 200 &&
      body4.success === true &&
      body4.data.synced === true,
    'Test 4: Worker Database Write - Worker updates Owner Google Drive operational data'
  );

  // TEST 5: Cross-Tenant Worker Read Attack
  console.log('\n--- Test 5: Cross-Tenant Worker Read Attack ---');
  // Connect Tenant B as well
  await driveAuthHandler(
    makeMockEvent({
      method: 'POST',
      path: '/api/drive-auth',
      uid: ownerUidB,
      role: 'owner',
      businessId: ownerBizB,
      body: { code: `mock_test_code_${ownerBizB}`, redirectUri: 'postmessage' },
    }),
    {} as any
  );
  // Write Tenant B data
  await driveDbHandler(
    makeMockEvent({
      method: 'POST',
      path: '/api/drive-database',
      uid: ownerUidB,
      role: 'owner',
      businessId: ownerBizB,
      body: {
        businessId: ownerBizB,
        consoles: [{ id: 'cb1', name: 'Tenant B Exclusive Console', businessId: ownerBizB }],
        sessions: [],
        customers: [],
        users: [],
        settings: { businessId: ownerBizB, cafeName: 'Tenant B Secret' },
      },
    }),
    {} as any
  );

  // Worker A attempts to query Tenant B data via query param
  const attackReadEvent = makeMockEvent({
    method: 'GET',
    path: '/api/drive-database?businessId=biz_matrix_tenant_b',
    query: { businessId: 'biz_matrix_tenant_b' },
    uid: workerUidA,
    role: 'worker',
    businessId: ownerBizA, // Caller's real verified businessId
    ownerUid: ownerUidA,
  });
  const res5 = (await driveDbHandler(attackReadEvent, {} as any)) as any;
  const body5 = JSON.parse(res5?.body || '{}');
  assert(
    res5?.statusCode === 200 &&
      body5.data.businessId === ownerBizA &&
      !JSON.stringify(body5.data).includes('Tenant B Exclusive Console'),
    'Test 5: Cross-Tenant Worker Read Attack - Caller receives their own verified tenant data; query param strictly ignored'
  );

  // TEST 6: Cross-Tenant Worker Write Attack
  console.log('\n--- Test 6: Cross-Tenant Worker Write Attack ---');
  const attackWriteEvent = makeMockEvent({
    method: 'POST',
    path: '/api/drive-database',
    uid: workerUidA,
    role: 'worker',
    businessId: ownerBizA,
    ownerUid: ownerUidA,
    body: {
      businessId: ownerBizB, // Worker A attempts to forge business B ID
      consoles: [{ id: 'malicious', name: 'Hacked Console', businessId: ownerBizB }],
    },
  });
  const res6 = (await driveDbHandler(attackWriteEvent, {} as any)) as any;
  const body6 = JSON.parse(res6?.body || '{}');
  // Check that data was forced to business A
  assert(
    res6?.statusCode === 200 && body6.data.businessId === ownerBizA,
    'Test 6: Cross-Tenant Worker Write Attack - Server forcefully bound write to caller verified businessId (business A)'
  );

  // Verify Tenant B was NOT modified by Worker A
  const readBEvent = makeMockEvent({
    method: 'GET',
    path: '/api/drive-database',
    uid: ownerUidB,
    role: 'owner',
    businessId: ownerBizB,
  });
  const resB = (await driveDbHandler(readBEvent, {} as any)) as any;
  const bodyB = JSON.parse(resB?.body || '{}');
  assert(
    !JSON.stringify(bodyB).includes('Hacked Console'),
    'Test 6: Tenant B data remains completely intact and untainted'
  );

  // TEST 7: Unauthenticated Request
  console.log('\n--- Test 7: Unauthenticated Request ---');
  const unauthEvent = makeMockEvent({
    method: 'GET',
    path: '/api/drive-database',
    noAuth: true,
  });
  const res7 = (await driveDbHandler(unauthEvent, {} as any)) as any;
  assert(
    res7?.statusCode === 401,
    `Test 7: Unauthenticated Request - Rejected with 401 (got ${res7?.statusCode})`
  );

  // TEST 8: Worker Disconnect Attack
  console.log('\n--- Test 8: Worker Disconnect Attack ---');
  const workerDisconnectEvent = makeMockEvent({
    method: 'DELETE',
    path: '/api/drive-disconnect',
    uid: workerUidA,
    role: 'worker',
    businessId: ownerBizA,
    ownerUid: ownerUidA,
  });
  const res8 = (await driveDisconnectHandler(workerDisconnectEvent, {} as any)) as any;
  assert(
    res8?.statusCode === 403,
    `Test 8: Worker Disconnect Attack - Rejected with 403 Forbidden (got ${res8?.statusCode})`
  );

  // TEST 9: Token Leak Inspection (Frontend code check)
  console.log('\n--- Test 9: Token Leak Inspection ---');
  const serviceCode = fs.readFileSync(path.resolve(process.cwd(), 'src/services/googleDriveService.ts'), 'utf-8');
  assert(
    !serviceCode.includes('NEXTGEN_CAFE_DRIVE_TOKEN =') &&
      !serviceCode.includes('localStorage.setItem(DRIVE_AUTH_TOKEN_KEY') &&
      !serviceCode.includes('initTokenClient'),
    'Test 9: Token Leak Inspection - No client-side Google access_token storage or initTokenClient'
  );

  // TEST 10: Server Secrets Inspection
  console.log('\n--- Test 10: Server Secrets Inspection ---');
  const responsesToCheck = [res1, res3, res4, res5, res6];
  let secretLeaked = false;
  for (const r of responsesToCheck) {
    const raw = r?.body || '';
    if (
      raw.includes('refresh_token') ||
      raw.includes('mock_refresh_token') ||
      raw.includes('private_key') ||
      raw.includes('client_secret')
    ) {
      secretLeaked = true;
      break;
    }
  }
  assert(!secretLeaked, 'Test 10: Server Secrets Inspection - No secrets or tokens leaked in API responses');

  // TEST 11: Owner Disconnect
  console.log('\n--- Test 11: Owner Disconnect ---');
  const ownerDisconnectEvent = makeMockEvent({
    method: 'DELETE',
    path: '/api/drive-disconnect',
    uid: ownerUidA,
    role: 'owner',
    businessId: ownerBizA,
  });
  const res11 = (await driveDisconnectHandler(ownerDisconnectEvent, {} as any)) as any;
  const vaultAfterDisconnect = await getTenantVault(ownerBizA);
  assert(
    res11?.statusCode === 200 &&
      vaultAfterDisconnect?.encryptedRefreshToken === null &&
      vaultAfterDisconnect?.driveFileId === null,
    'Test 11: Owner Disconnect - Vault cleared of Drive credentials'
  );

  // TEST 12: Read After Disconnect
  console.log('\n--- Test 12: Read After Disconnect ---');
  const res12 = (await driveDbHandler(workerReadEvent, {} as any)) as any;
  const body12 = JSON.parse(res12?.body || '{}');
  assert(
    res12?.statusCode === 404 && body12.code === 'DRIVE_NOT_CONFIGURED',
    'Test 12: Read After Disconnect - Returns 404 DRIVE_NOT_CONFIGURED'
  );

  // TEST 13: Offline Mode (Local storage fallback check in service)
  console.log('\n--- Test 13: Offline Mode ---');
  assert(
    serviceCode.includes('getLocalDatabase') &&
      serviceCode.includes('saveLocalDatabase') &&
      serviceCode.includes("status = 'offline'"),
    'Test 13: Offline Mode - Robust offline fallback to local database is preserved'
  );

  // TEST 14: Refresh Token Encryption Verification
  console.log('\n--- Test 14: Refresh Token Encryption Verification ---');
  const testPlaintext = '1//0g9TestRefreshTokenSampleValueXYZ123';
  const encrypted = encryptToken(testPlaintext);
  const parts = encrypted.split(':');
  assert(
    parts.length === 3 &&
      parts[0].length === 24 && // 12 bytes IV in hex
      parts[1].length === 32 && // 16 bytes auth tag in hex
      parts[2].length > 0 &&
      !encrypted.includes(testPlaintext),
    'Test 14: AES-256-GCM encryption format verified (iv:tag:ciphertext)'
  );
  const decrypted = decryptToken(encrypted);
  assert(decrypted === testPlaintext, 'Test 14: Decryption roundtrip successful');

  // TEST 15: Single Vault Verification (No café operational data in Firestore/vault)
  console.log('\n--- Test 15: Single Vault Verification ---');
  const vaultKeys = Object.keys(vaultAfterDisconnect || {});
  const hasBusinessData =
    vaultKeys.includes('consoles') ||
    vaultKeys.includes('sessions') ||
    vaultKeys.includes('customers') ||
    vaultKeys.includes('cafeteriaOrders');
  assert(!hasBusinessData, 'Test 15: Tenant Vault contains strictly authentication and Drive metadata, NO café operational data');

  console.log('\n====================================================');
  console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTestMatrix().catch((err) => {
  console.error('Fatal error running test matrix:', err);
  process.exit(1);
});
