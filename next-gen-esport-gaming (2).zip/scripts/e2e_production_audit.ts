import fs from 'fs';
import path from 'path';
import { encryptToken, decryptToken } from '../netlify/functions/lib/crypto.ts';
import { getTenantVault, saveTenantVault, saveWorkerBinding } from '../netlify/functions/lib/tenantVault.ts';

interface TestResult {
  category: string;
  testName: string;
  passed: boolean;
  reason: string;
  fixIfFailed?: string;
}

const results: TestResult[] = [];
const BASE_URL = 'http://localhost:3000';

function record(category: string, testName: string, passed: boolean, reason: string, fixIfFailed?: string) {
  results.push({ category, testName, passed, reason, fixIfFailed });
  const icon = passed ? '✅ PASS' : '❌ FAIL';
  console.log(`${icon} [${category}] ${testName}: ${reason}`);
  if (!passed && fixIfFailed) {
    console.log(`   Fix Required: ${fixIfFailed}`);
  }
}

function makeMockToken(payload: {
  uid: string;
  email?: string;
  role: 'owner' | 'worker';
  businessId: string;
  ownerUid?: string;
}) {
  const b64 = Buffer.from(JSON.stringify(payload)).toString('base64');
  return `mock_test_token_.${b64}.mock_sig`;
}

async function runProductionAudit() {
  console.log('\n=============================================================');
  console.log('STARTING PRODUCTION-LEVEL END-TO-END VERIFICATION (PHASE 3)');
  console.log('=============================================================\n');

  // =========================================================================
  // 1. NETLIFY DEPLOYMENT & PRODUCTION BUILD SETUP
  // =========================================================================
  console.log('--- Domain 1: Netlify Deployment & Build Setup ---');
  try {
    const netlifyTomlPath = path.resolve(process.cwd(), 'netlify.toml');
    const netlifyTomlExists = fs.existsSync(netlifyTomlPath);
    const tomlContent = netlifyTomlExists ? fs.readFileSync(netlifyTomlPath, 'utf-8') : '';

    const hasPublishDist = tomlContent.includes('publish = "dist"');
    const hasFunctionsDir = tomlContent.includes('functions = "netlify/functions"');
    const hasApiRedirect = tomlContent.includes('from = "/api/*"') && tomlContent.includes('to = "/.netlify/functions/:splat"');
    const hasSpaRedirect = tomlContent.includes('from = "/*"') && tomlContent.includes('to = "/index.html"');

    record(
      'Netlify Deployment',
      'netlify.toml Configuration',
      netlifyTomlExists && hasPublishDist && hasFunctionsDir && hasApiRedirect && hasSpaRedirect,
      'Validates publish="dist", functions="netlify/functions", /api/* proxy redirect, and SPA fallback.',
      'Ensure netlify.toml defines [build] publish="dist", functions="netlify/functions", and both redirects.'
    );

    const requiredFunctions = [
      'drive-auth.ts',
      'drive-database.ts',
      'drive-disconnect.ts',
      'tenant-vault-status.ts',
      'tenant-claim.ts',
      'provision-worker.ts',
    ];
    let allFnsExist = true;
    for (const fn of requiredFunctions) {
      if (!fs.existsSync(path.resolve(process.cwd(), 'netlify', 'functions', fn))) {
        allFnsExist = false;
        break;
      }
    }
    record(
      'Netlify Deployment',
      'Netlify Functions Directory Structure',
      allFnsExist,
      'All 6 required serverless function entrypoints are present in netlify/functions.',
      'Check that netlify/functions contains all necessary endpoints.'
    );
  } catch (err: any) {
    record('Netlify Deployment', 'Build Setup Check', false, err.message, 'Fix file permissions or paths.');
  }

  // =========================================================================
  // 2. LIVE /api/* AND /.netlify/functions/* HTTP ROUTING PARITY
  // =========================================================================
  console.log('\n--- Domain 2: /api/* and /.netlify/functions/* Live HTTP Parity ---');
  try {
    // Check CORS preflight OPTIONS request
    const optionsRes = await fetch(`${BASE_URL}/api/drive-database`, {
      method: 'OPTIONS',
      headers: {
        Origin: 'http://localhost:3000',
        'Access-Control-Request-Method': 'POST',
      },
    });
    const allowOrigin = optionsRes.headers.get('access-control-allow-origin');
    const allowMethods = optionsRes.headers.get('access-control-allow-methods');
    record(
      'HTTP Endpoints',
      'CORS Preflight (OPTIONS /api/drive-database)',
      optionsRes.status === 204 || optionsRes.status === 200 && !!allowOrigin,
      `Preflight returns status ${optionsRes.status} with Access-Control-Allow-Origin: ${allowOrigin}`,
      'Check handleCorsPreflight in authMiddleware.ts'
    );

    // Check Dual Routing: /api/tenant-vault-status vs /.netlify/functions/tenant-vault-status
    const tokenDemo = makeMockToken({ uid: 'owner_demo', role: 'owner', businessId: 'biz_parity_check' });
    const resApi = await fetch(`${BASE_URL}/api/tenant-vault-status`, {
      headers: { Authorization: `Bearer ${tokenDemo}` },
    });
    const resNetlify = await fetch(`${BASE_URL}/.netlify/functions/tenant-vault-status`, {
      headers: { Authorization: `Bearer ${tokenDemo}` },
    });
    const jsonApi = await resApi.json();
    const jsonNetlify = await resNetlify.json();

    const parityMatch =
      resApi.status === 200 &&
      resNetlify.status === 200 &&
      jsonApi.success === true &&
      jsonNetlify.success === true &&
      jsonApi.data.businessId === jsonNetlify.data.businessId;

    record(
      'HTTP Endpoints',
      'Dual Routing Parity (/api/* vs /.netlify/functions/*)',
      parityMatch,
      `Both routes return identical status and payload for verified tenant (${jsonApi.data?.businessId})`,
      'Verify vite.config.ts netlifyFunctionsDevPlugin handles both /api/ and /.netlify/functions/ prefixes.'
    );
  } catch (err: any) {
    record('HTTP Endpoints', 'Live Routing Check', false, err.message);
  }

  // =========================================================================
  // 3. FIREBASE AUTH VERIFICATION
  // =========================================================================
  console.log('\n--- Domain 3: Firebase Auth Verification ---');
  try {
    // 3a: Unauthenticated request (Missing Authorization Header)
    const unauthRes = await fetch(`${BASE_URL}/api/drive-database`);
    const unauthJson = await unauthRes.json();
    record(
      'Firebase Auth',
      'Unauthenticated Request Rejection',
      unauthRes.status === 401 && unauthJson.code === 'UNAUTHORIZED',
      `Server rejected missing Authorization header with status 401 and code UNAUTHORIZED`,
      'Ensure authMiddleware.ts checks for presence of Authorization header.'
    );

    // 3b: Malformed Bearer token
    const malformedRes = await fetch(`${BASE_URL}/api/drive-database`, {
      headers: { Authorization: 'Bearer totally_invalid_token_format' },
    });
    record(
      'Firebase Auth',
      'Malformed Bearer Token Rejection',
      malformedRes.status === 401,
      `Server rejected malformed bearer token with status ${malformedRes.status}`,
      'Ensure authMiddleware.ts verifyIdToken catches and throws AuthError 401.'
    );

    // 3c: Worker role and businessId claim binding
    const workerUid = 'worker_e2e_uid';
    const ownerUid = 'owner_e2e_uid';
    const bizId = 'biz_e2e_tenant';

    await saveWorkerBinding({
      workerUid,
      workerEmail: 'worker_e2e@example.com',
      workerName: 'E2E Worker',
      businessId: bizId,
      ownerUid,
      role: 'worker',
      createdAt: new Date().toISOString(),
    });

    const workerToken = makeMockToken({
      uid: workerUid,
      role: 'worker',
      businessId: bizId,
      ownerUid,
    });
    const workerStatusRes = await fetch(`${BASE_URL}/api/tenant-vault-status`, {
      headers: { Authorization: `Bearer ${workerToken}` },
    });
    const workerStatusJson = await workerStatusRes.json();

    record(
      'Firebase Auth',
      'Worker Role & Tenant Context Resolution',
      workerStatusRes.status === 200 &&
        workerStatusJson.data.role === 'worker' &&
        workerStatusJson.data.businessId === bizId &&
        workerStatusJson.data.isWorker === true &&
        workerStatusJson.data.isOwner === false,
      `Worker verified with role='worker', businessId='${workerStatusJson.data?.businessId}'`,
      'Ensure authMiddleware.ts resolves worker binding and claims correctly.'
    );
  } catch (err: any) {
    record('Firebase Auth', 'Authentication Verification Failure', false, err.message);
  }

  // =========================================================================
  // 4. GOOGLE OAUTH CODE EXCHANGE
  // =========================================================================
  console.log('\n--- Domain 4: Google OAuth Code Exchange ---');
  try {
    const ownerBiz = 'biz_e2e_oauth_test';
    const ownerUid = 'owner_e2e_oauth_uid';
    const ownerToken = makeMockToken({
      uid: ownerUid,
      role: 'owner',
      businessId: ownerBiz,
    });

    // 4a: Missing code in body
    const badCodeRes = await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`,
      },
      body: JSON.stringify({}),
    });
    const badCodeJson = await badCodeRes.json();
    record(
      'OAuth Exchange',
      'Missing Code Validation',
      badCodeRes.status === 400 && badCodeJson.code === 'MISSING_CODE',
      `Server rejected missing code with HTTP 400 and code MISSING_CODE`,
      'Check drive-auth.ts body parsing validation.'
    );

    // 4b: Valid code exchange flow
    const goodCodeRes = await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`,
      },
      body: JSON.stringify({
        code: `mock_test_code_${ownerBiz}`,
        redirectUri: 'postmessage',
      }),
    });
    const goodCodeJson = await goodCodeRes.json();
    const rawResponseBody = JSON.stringify(goodCodeJson);

    const exchangePassed =
      goodCodeRes.status === 200 &&
      goodCodeJson.success === true &&
      goodCodeJson.data.isConnected === true &&
      goodCodeJson.data.businessId === ownerBiz;

    const noLeak =
      !rawResponseBody.includes('refresh_token') &&
      !rawResponseBody.includes('access_token') &&
      !rawResponseBody.includes('client_secret');

    record(
      'OAuth Exchange',
      'Server-Side Code Exchange & Sanitized Response',
      exchangePassed && noLeak,
      `Code exchanged successfully. Response is sanitized (zero tokens/secrets leaked in HTTP body).`,
      'Check drive-auth.ts token exchange and response payload.'
    );
  } catch (err: any) {
    record('OAuth Exchange', 'OAuth Exchange Flow Failure', false, err.message);
  }

  // =========================================================================
  // 5. FIRESTORE _tenant_vault STORAGE & METADATA ISOLATION
  // =========================================================================
  console.log('\n--- Domain 5: Firestore _tenant_vault Storage & Isolation ---');
  try {
    const testBiz = 'biz_e2e_vault_test';
    const testOwner = 'owner_vault_uid';

    // Store a test record in the vault
    const savedVault = await saveTenantVault({
      businessId: testBiz,
      ownerUid: testOwner,
      encryptedRefreshToken: encryptToken('test_refresh_token_123'),
      driveFolderId: 'folder_abc_123',
      driveFileId: 'file_xyz_789',
      businessName: 'Vault Test Cafe',
      ownerEmail: 'owner@vaulttest.com',
    });

    const retrievedVault = await getTenantVault(testBiz);

    const vaultStoredCorrectly =
      retrievedVault !== null &&
      retrievedVault.businessId === testBiz &&
      retrievedVault.ownerUid === testOwner &&
      retrievedVault.driveFolderId === 'folder_abc_123' &&
      retrievedVault.driveFileId === 'file_xyz_789';

    // Verify STRICT ISOLATION: No café operational data in tenant vault
    const keys = Object.keys(retrievedVault || {});
    const illegalKeys = ['consoles', 'sessions', 'customers', 'cafeteriaOrders', 'rentals', 'billingHistory'];
    const hasIllegalData = keys.some((k) => illegalKeys.includes(k));

    record(
      'Tenant Vault',
      'Vault Persistence & Metadata Isolation',
      vaultStoredCorrectly && !hasIllegalData,
      `_tenant_vault persists metadata cleanly and contains ZERO café business operational data.`,
      'Check tenantVault.ts schema and field filtering.'
    );
  } catch (err: any) {
    record('Tenant Vault', 'Vault Storage Failure', false, err.message);
  }

  // =========================================================================
  // 6. ENCRYPTED REFRESH TOKEN STORAGE (AES-256-GCM)
  // =========================================================================
  console.log('\n--- Domain 6: Encrypted Refresh Token Storage (AES-256-GCM) ---');
  try {
    const sampleToken = '1//0gSAMPLE_REFRESH_TOKEN_SECURE_TEST_XYZ';
    const enc1 = encryptToken(sampleToken);
    const enc2 = encryptToken(sampleToken);

    // Check format iv:tag:data
    const parts1 = enc1.split(':');
    const parts2 = enc2.split(':');
    const validFormat = parts1.length === 3 && parts1[0].length === 24 && parts1[1].length === 32;

    // Check IV uniqueness (random 12 bytes => different ciphertext every run)
    const uniqueIVs = parts1[0] !== parts2[0] && enc1 !== enc2;

    // Check roundtrip decryption
    const dec1 = decryptToken(enc1);
    const dec2 = decryptToken(enc2);
    const roundtripSuccess = dec1 === sampleToken && dec2 === sampleToken;

    // Check tampering detection (AES-GCM authentication tag verification)
    let tamperDetected = false;
    try {
      // Flip characters in ciphertext to guarantee tampering
      const tampered = `${parts1[0]}:${parts1[1]}:${parts1[2].slice(0, -2)}${parts1[2].endsWith('aa') ? 'bb' : 'aa'}`;
      decryptToken(tampered);
    } catch {
      tamperDetected = true; // Expected: decryption fails with authentication tag error
    }

    record(
      'Cryptography',
      'AES-256-GCM Authenticated Encryption & Tamper Proofing',
      validFormat && uniqueIVs && roundtripSuccess && tamperDetected,
      `Verified AES-256-GCM formatting (12B IV, 16B tag), IV randomness, successful decryption, and tamper rejection.`,
      'Check crypto.ts encryption algorithm and tag handling.'
    );
  } catch (err: any) {
    record('Cryptography', 'Cryptographic Verification Failure', false, err.message);
  }

  // =========================================================================
  // 7. OWNER DRIVE CONNECTION FLOW
  // =========================================================================
  console.log('\n--- Domain 7: Owner Drive Connection Flow ---');
  try {
    const ownerTenant = 'biz_owner_connection_test';
    const ownerUid = 'owner_conn_uid';
    const token = makeMockToken({ uid: ownerUid, role: 'owner', businessId: ownerTenant });

    // Connect Drive
    const connectRes = await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        code: `mock_test_code_${ownerTenant}`,
        redirectUri: 'postmessage',
      }),
    });
    const connectJson = await connectRes.json();

    // Check vault status via HTTP
    const statusRes = await fetch(`${BASE_URL}/api/tenant-vault-status`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const statusJson = await statusRes.json();

    const connectionSuccess =
      connectRes.status === 200 &&
      connectJson.success === true &&
      statusJson.data.isConfigured === true &&
      !!statusJson.data.driveFolderId;

    record(
      'Owner Connection',
      'Owner Connects Google Drive Flow',
      connectionSuccess,
      `Owner connected Drive; status reports isConfigured=true, driveFolderId=${statusJson.data?.driveFolderId}`,
      'Check drive-auth.ts and tenant-vault-status.ts'
    );
  } catch (err: any) {
    record('Owner Connection', 'Owner Connection Flow Failure', false, err.message);
  }

  // =========================================================================
  // 8. WORKER CROSS-DEVICE READ/WRITE VIA OWNER'S GOOGLE DRIVE
  // =========================================================================
  console.log('\n--- Domain 8: Worker Cross-Device Read/Write ---');
  try {
    const tenantBiz = 'biz_cross_device_test';
    const ownerUid = 'owner_cd_uid';
    const workerUid = 'worker_cd_uid';

    // 1. Owner connects Drive
    const ownerToken = makeMockToken({ uid: ownerUid, role: 'owner', businessId: tenantBiz });
    await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`,
      },
      body: JSON.stringify({
        code: `mock_test_code_${tenantBiz}`,
        redirectUri: 'postmessage',
      }),
    });

    // 2. Initialize database on Owner's Drive
    const initialPayload = {
      businessId: tenantBiz,
      consoles: [
        { id: 'c1', name: 'PS5 Pro #1', status: 'available', hourlyRate: 150, businessId: tenantBiz },
        { id: 'c2', name: 'Xbox Series X #1', status: 'available', hourlyRate: 120, businessId: tenantBiz },
      ],
      sessions: [],
      customers: [{ id: 'cust1', name: 'Rahul Sharma', phone: '9876543210', businessId: tenantBiz }],
      users: [],
      settings: { businessId: tenantBiz, cafeName: 'Cross-Device Cafe' },
    };
    await fetch(`${BASE_URL}/api/drive-database`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`,
      },
      body: JSON.stringify(initialPayload),
    });

    // 3. Worker on completely different device reads data via Firebase ID token
    const workerToken = makeMockToken({
      uid: workerUid,
      role: 'worker',
      businessId: tenantBiz,
      ownerUid,
    });
    const workerReadRes = await fetch(`${BASE_URL}/api/drive-database`, {
      headers: { Authorization: `Bearer ${workerToken}` },
    });
    const workerReadJson = await workerReadRes.json();

    const workerReadSuccess =
      workerReadRes.status === 200 &&
      workerReadJson.success === true &&
      workerReadJson.data.consoles.length === 2 &&
      workerReadJson.data.consoles[0].name === 'PS5 Pro #1';

    // 4. Worker starts a gaming session and updates Owner's Google Drive
    const updatedPayload = {
      ...initialPayload,
      consoles: [
        { id: 'c1', name: 'PS5 Pro #1', status: 'active', hourlyRate: 150, businessId: tenantBiz },
        { id: 'c2', name: 'Xbox Series X #1', status: 'available', hourlyRate: 120, businessId: tenantBiz },
      ],
      sessions: [
        {
          id: 'sess_worker_1',
          consoleId: 'c1',
          customerName: 'Rahul Sharma',
          status: 'active',
          startTime: new Date().toISOString(),
          businessId: tenantBiz,
        },
      ],
    };

    const workerWriteRes = await fetch(`${BASE_URL}/api/drive-database`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${workerToken}`,
      },
      body: JSON.stringify(updatedPayload),
    });
    const workerWriteJson = await workerWriteRes.json();

    const workerWriteSuccess =
      workerWriteRes.status === 200 &&
      workerWriteJson.success === true &&
      workerWriteJson.data.synced === true;

    // 5. Verify data persisted to Owner's Drive by reading again as Owner
    const verifyReadRes = await fetch(`${BASE_URL}/api/drive-database`, {
      headers: { Authorization: `Bearer ${ownerToken}` },
    });
    const verifyReadJson = await verifyReadRes.json();

    const persistedCorrectly =
      verifyReadJson.data.consoles[0].status === 'active' &&
      verifyReadJson.data.sessions.length === 1 &&
      verifyReadJson.data.sessions[0].id === 'sess_worker_1';

    record(
      'Worker Cross-Device',
      'Worker Reads & Writes to Owner Google Drive',
      workerReadSuccess && workerWriteSuccess && persistedCorrectly,
      `Worker seamlessly read and updated Owner's Google Drive data with Firebase token alone.`,
      'Check drive-database.ts GET/POST authorization and Drive proxy handling.'
    );
  } catch (err: any) {
    record('Worker Cross-Device', 'Cross-Device Flow Failure', false, err.message);
  }

  // =========================================================================
  // 9. CROSS-TENANT ISOLATION & SECURITY ATTACK PREVENTION
  // =========================================================================
  console.log('\n--- Domain 9: Cross-Tenant Isolation & Attack Prevention ---');
  try {
    const tenantA = 'biz_iso_tenant_a';
    const tenantB = 'biz_iso_tenant_b';
    const ownerTokenA = makeMockToken({ uid: 'owner_a', role: 'owner', businessId: tenantA });
    const workerTokenA = makeMockToken({ uid: 'worker_a', role: 'worker', businessId: tenantA });
    const ownerTokenB = makeMockToken({ uid: 'owner_b', role: 'owner', businessId: tenantB });

    // Clean mock drive files for isolated test tenants before beginning
    const mockDriveDir = path.resolve(process.cwd(), '.data', 'mock_drive');
    for (const f of [`${tenantA}_NextGenGaming_Cafe_Data.xlsx`, `${tenantB}_NextGenGaming_Cafe_Data.xlsx`]) {
      const fp = path.join(mockDriveDir, f);
      if (fs.existsSync(fp)) {
        try { fs.unlinkSync(fp); } catch {}
      }
    }

    // Connect Drive for both tenants
    await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ownerTokenA}` },
      body: JSON.stringify({ code: `mock_test_code_${tenantA}`, redirectUri: 'postmessage' }),
    });
    await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ownerTokenB}` },
      body: JSON.stringify({ code: `mock_test_code_${tenantB}`, redirectUri: 'postmessage' }),
    });

    // Populate distinct data
    await fetch(`${BASE_URL}/api/drive-database`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ownerTokenA}` },
      body: JSON.stringify({
        businessId: tenantA,
        consoles: [{ id: 'ca1', name: 'Tenant A Console', businessId: tenantA }],
      }),
    });
    await fetch(`${BASE_URL}/api/drive-database`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ownerTokenB}` },
      body: JSON.stringify({
        businessId: tenantB,
        consoles: [{ id: 'cb1', name: 'Tenant B Super Secret Console', businessId: tenantB }],
      }),
    });

    // Attack 1: Worker A tries to read Tenant B's data via query param
    const attackReadRes = await fetch(`${BASE_URL}/api/drive-database?businessId=${tenantB}`, {
      headers: { Authorization: `Bearer ${workerTokenA}` },
    });
    const attackReadJson = await attackReadRes.json();
    const readProtected =
      attackReadJson.data.businessId === tenantA &&
      !JSON.stringify(attackReadJson.data).includes('Tenant B Super Secret Console');

    record(
      'Cross-Tenant Security',
      'Cross-Tenant Read Attack Neutralization',
      readProtected,
      `Server ignored query param spoofing and returned caller's verified Tenant A data exclusively.`,
      'Check drive-database.ts businessId resolution in requireAuth.'
    );

    // Attack 2: Worker A tries to overwrite Tenant B's data via body payload
    const attackWriteRes = await fetch(`${BASE_URL}/api/drive-database`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${workerTokenA}` },
      body: JSON.stringify({
        businessId: tenantB, // Spoofed target
        consoles: [{ id: 'malicious', name: 'Malicious Overwrite', businessId: tenantB }],
      }),
    });
    const attackWriteJson = await attackWriteRes.json();

    // Verify Tenant B's actual data in Drive was untouched
    const tenantBVerifyRes = await fetch(`${BASE_URL}/api/drive-database`, {
      headers: { Authorization: `Bearer ${ownerTokenB}` },
    });
    const tenantBVerifyJson = await tenantBVerifyRes.json();
    const tenantBUnscathed =
      tenantBVerifyJson.data.businessId === tenantB &&
      !JSON.stringify(tenantBVerifyJson.data).includes('Malicious Overwrite');

    record(
      'Cross-Tenant Security',
      'Cross-Tenant Write Attack Neutralization',
      attackWriteJson.data.businessId === tenantA && tenantBUnscathed,
      `Server forcefully bound write to caller's verified tenant (${tenantA}); Tenant B remained intact.`,
      'Check drive-database.ts payload.businessId enforcement.'
    );
  } catch (err: any) {
    record('Cross-Tenant Security', 'Isolation Attack Check Failure', false, err.message);
  }

  // =========================================================================
  // 10. DISCONNECT & RECONNECT LIFECYCLE
  // =========================================================================
  console.log('\n--- Domain 10: Disconnect & Reconnect Lifecycle ---');
  try {
    const lifecycleBiz = 'biz_lifecycle_test';
    const ownerToken = makeMockToken({ uid: 'owner_life', role: 'owner', businessId: lifecycleBiz });
    const workerToken = makeMockToken({ uid: 'worker_life', role: 'worker', businessId: lifecycleBiz });

    // 1. Owner connects Drive
    await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({ code: `mock_test_code_${lifecycleBiz}`, redirectUri: 'postmessage' }),
    });

    // 2. Attack: Worker attempts disconnect
    const workerDisconnectRes = await fetch(`${BASE_URL}/api/drive-disconnect`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${workerToken}` },
    });
    const workerDisconnectJson = await workerDisconnectRes.json();
    record(
      'Disconnect Lifecycle',
      'Worker Disconnect Attack Rejection',
      workerDisconnectRes.status === 403 && workerDisconnectJson.code === 'FORBIDDEN_OWNER_REQUIRED',
      `Worker rejected from disconnecting Drive with HTTP 403 FORBIDDEN_OWNER_REQUIRED`,
      'Check requireOwner enforcement in drive-disconnect.ts'
    );

    // 3. Owner performs disconnect
    const ownerDisconnectRes = await fetch(`${BASE_URL}/api/drive-disconnect`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${ownerToken}` },
    });
    const ownerDisconnectJson = await ownerDisconnectRes.json();
    const vaultStatusAfterDiscRes = await fetch(`${BASE_URL}/api/tenant-vault-status`, {
      headers: { Authorization: `Bearer ${ownerToken}` },
    });
    const vaultStatusAfterDisc = await vaultStatusAfterDiscRes.json();

    const disconnectSuccess =
      ownerDisconnectRes.status === 200 &&
      ownerDisconnectJson.success === true &&
      vaultStatusAfterDisc.data?.isConfigured === false &&
      vaultStatusAfterDisc.data?.driveFolderId === null &&
      vaultStatusAfterDisc.data?.driveFileId === null;

    record(
      'Disconnect Lifecycle',
      'Owner Disconnect Clears Vault Credentials',
      disconnectSuccess,
      `Vault credentials safely wiped on owner disconnect (isConfigured=false, driveFolderId=null, driveFileId=null).`,
      'Check saveTenantVault update in drive-disconnect.ts'
    );

    // 4. Read after disconnect returns 404 DRIVE_NOT_CONFIGURED
    const readAfterDiscRes = await fetch(`${BASE_URL}/api/drive-database`, {
      headers: { Authorization: `Bearer ${ownerToken}` },
    });
    const readAfterDiscJson = await readAfterDiscRes.json();
    record(
      'Disconnect Lifecycle',
      'Read After Disconnect Behavior',
      readAfterDiscRes.status === 404 && readAfterDiscJson.code === 'DRIVE_NOT_CONFIGURED',
      `Subsequent database read returns HTTP 404 with code DRIVE_NOT_CONFIGURED`,
      'Check drive-database.ts check for vault.encryptedRefreshToken.'
    );

    // 5. Reconnect restores connection
    const reconnectRes = await fetch(`${BASE_URL}/api/drive-auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({ code: `mock_test_code_${lifecycleBiz}`, redirectUri: 'postmessage' }),
    });
    const reconnectJson = await reconnectRes.json();
    const vaultStatusAfterReconnRes = await fetch(`${BASE_URL}/api/tenant-vault-status`, {
      headers: { Authorization: `Bearer ${ownerToken}` },
    });
    const vaultStatusAfterReconn = await vaultStatusAfterReconnRes.json();

    const reconnectSuccess =
      reconnectRes.status === 200 &&
      reconnectJson.success === true &&
      vaultStatusAfterReconn.data?.isConfigured === true &&
      !!vaultStatusAfterReconn.data?.driveFolderId;

    record(
      'Disconnect Lifecycle',
      'Owner Reconnect Restoration',
      reconnectSuccess,
      `Drive successfully reconnected and new encrypted refresh token stored in vault (isConfigured=true).`,
      'Check drive-auth.ts reconnection handling.'
    );

    // Clean up test lifecycle artifacts so live production users never see test mock accounts
    await fetch(`${BASE_URL}/api/drive-disconnect`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({ action: 'disconnect' }),
    }).catch(() => {});
  } catch (err: any) {
    record('Disconnect Lifecycle', 'Lifecycle Check Failure', false, err.message);
  }

  // =========================================================================
  // 11. OFFLINE FALLBACK RESILIENCE
  // =========================================================================
  console.log('\n--- Domain 11: Offline Fallback Resilience ---');
  try {
    const serviceFilePath = path.resolve(process.cwd(), 'src', 'services', 'googleDriveService.ts');
    const serviceCode = fs.readFileSync(serviceFilePath, 'utf-8');

    const hasGetLocal = serviceCode.includes('getLocalDatabase');
    const hasSaveLocal = serviceCode.includes('saveLocalDatabase');
    const hasOfflineStatus = serviceCode.includes("status = 'offline'");
    const hasLocalOnlyStatus = serviceCode.includes("status = 'local_only'");
    const hasCatchFallback = serviceCode.includes('falling back to local storage');

    const offlineResilient =
      hasGetLocal && hasSaveLocal && hasOfflineStatus && hasLocalOnlyStatus && hasCatchFallback;

    record(
      'Offline Resilience',
      'Frontend Offline Fallback & Cache Synchronization',
      offlineResilient,
      `Frontend googleDriveService.ts maintains local database cache and gracefully degrades to offline/local_only on network errors.`,
      'Ensure googleDriveService.ts falls back to getLocalDatabase when fetch throws or server is unreachable.'
    );
  } catch (err: any) {
    record('Offline Resilience', 'Offline Check Failure', false, err.message);
  }

  // =========================================================================
  // FINAL SUMMARY REPORT
  // =========================================================================
  console.log('\n=============================================================');
  console.log('AUDIT SUMMARY');
  console.log('=============================================================');
  const total = results.length;
  const passedCount = results.filter((r) => r.passed).length;
  const failedCount = total - passedCount;

  console.log(`Total Tests Run: ${total}`);
  console.log(`Passed: ${passedCount}`);
  console.log(`Failed: ${failedCount}`);
  console.log('=============================================================\n');

  if (failedCount > 0) {
    console.log('FAILURES DETECTED:');
    results.filter((r) => !r.passed).forEach((f, idx) => {
      console.log(`${idx + 1}. [${f.category}] ${f.testName}: ${f.reason}`);
      if (f.fixIfFailed) console.log(`   Fix: ${f.fixIfFailed}`);
    });
    process.exit(1);
  } else {
    console.log('ALL AUDIT TESTS PASSED SUCCESSFULLY! NO ERRORS FOUND.');
  }
}

runProductionAudit().catch((err) => {
  console.error('Fatal audit failure:', err);
  process.exit(1);
});
