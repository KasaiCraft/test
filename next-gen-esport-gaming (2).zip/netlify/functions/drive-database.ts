import {
  handleCorsPreflight,
  requireAuth,
  successResponse,
  errorResponse,
  formatAuthErrorResponse,
} from './lib/authMiddleware.ts';
import { decryptToken, encryptToken } from './lib/crypto.ts';
import { getTenantVault, saveTenantVault } from './lib/tenantVault.ts';
import { NEXTGEN_CAFE_BUSINESS_ID, Handler, HandlerEvent } from './lib/types.ts';
import { mergeCafeDatabases } from './lib/databaseMerge.ts';
import {
  getGoogleDriveClient,
  ensureAuthenticatedDriveClient,
  findOrCreateDriveFolder,
  findDriveDatabaseFile,
  readDriveDatabaseFile,
  writeDriveDatabaseFile,
  FOLDER_NAME,
  DEFAULT_FILE_NAME,
} from './lib/googleDriveClient.ts';
import { cafeDatabaseToXlsxBase64, xlsxBufferToCafeDatabase } from './lib/xlsxDatabase.ts';

/**
 * Netlify Function: drive-database
 * Paths:
 *   GET  /.netlify/functions/drive-database or GET  /api/drive-database
 *   POST /.netlify/functions/drive-database or POST /api/drive-database
 *
 * Secure server-side proxy for Google Drive database read & write operations.
 * Stores business data exclusively in a single Excel (.xlsx) file on Google Drive:
 * - Reads & writes the shared NEXT GEN GAMING CAFE dataset from the Owner's Drive (.xlsx).
 * - Both Workers and Owner read & write the exact same .xlsx dataset.
 * - Handles concurrent edits safely via smart record-level merge (mergeCafeDatabases)
 *   so that one worker's changes do not accidentally overwrite another worker's changes.
 * - Automatically migrates any legacy JSON database file to XLSX without data loss.
 */
export const handler: Handler = async (event: HandlerEvent) => {
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  try {
    // 1. Authenticate caller and resolve authoritative context
    const context = await requireAuth(event);
    const ownerUid = context.ownerUid || context.uid;
    const businessId = context.businessId || `user_${ownerUid}`;

    // 2. Fetch tenant vault record containing the encrypted Google Drive refresh token strictly for this tenant
    const vault = await getTenantVault(businessId, ownerUid);
    if (!vault || !vault.encryptedRefreshToken) {
      return errorResponse(
        'Google Drive is not connected. Please connect Google Drive in Settings.',
        404,
        'DRIVE_NOT_CONFIGURED'
      );
    }

    // 3. Decrypt the refresh token server-side using AES-256-GCM
    let refreshToken: string;
    try {
      refreshToken = decryptToken(vault.encryptedRefreshToken);
    } catch (decryptErr: any) {
      console.error('[drive-database] Decryption error:', decryptErr.message);
      return errorResponse(
        'Failed to decrypt Drive credentials. Please ask the owner to reconnect Google Drive.',
        500,
        'DECRYPTION_ERROR'
      );
    }

    let customClientSecret: string | null = null;
    if (vault.encryptedClientSecret) {
      try {
        customClientSecret = decryptToken(vault.encryptedClientSecret);
      } catch {}
    }

    // 4. Initialize server-side Google Drive client with guaranteed fresh access token
    const { drive } = await ensureAuthenticatedDriveClient(
      refreshToken,
      async (newRefreshToken) => {
        await saveTenantVault({
          businessId,
          ownerUid,
          encryptedRefreshToken: encryptToken(newRefreshToken),
        });
      },
      false,
      vault.customClientId,
      customClientSecret
    );
    const fileName = DEFAULT_FILE_NAME; // 'cafe_database.xlsx'

    // ==========================================
    // GET: Read cafe database from Google Drive (.xlsx)
    // ==========================================
    if (event.httpMethod === 'GET') {
      let fileId = vault.driveFileId;
      let databaseData: any = null;
      let needsMigration = false;

      // Try reading directly by stored driveFileId first
      if (fileId) {
        try {
          databaseData = await readDriveDatabaseFile(drive, refreshToken, fileId, fileName, vault.customClientId, customClientSecret);
        } catch (readErr: any) {
          console.warn('[drive-database] File read by ID notice:', readErr.message);
          fileId = null; // Stored file might have been moved or removed, fallback to search
        }
      }

      // If file not found by cached ID, locate folder and search for database file (.xlsx or legacy .json)
      const folderId = vault.driveFolderId || (await findOrCreateDriveFolder(drive, refreshToken, FOLDER_NAME, vault.customClientId, customClientSecret));
      if (!databaseData) {
        const found = await findDriveDatabaseFile(drive, refreshToken, folderId, fileName, vault.customClientId, customClientSecret);

        if (found) {
          fileId = found.fileId;
          databaseData = await readDriveDatabaseFile(drive, refreshToken, fileId, found.fileName, vault.customClientId, customClientSecret);
          needsMigration = Boolean(found.isLegacyJson);

          if (!needsMigration) {
            await saveTenantVault({
              businessId,
              driveFolderId: folderId,
              driveFileId: fileId,
            });
          }
        }
      }

      if (!databaseData) {
        return errorResponse(
          'Tenant cafe database file does not exist in Google Drive yet.',
          404,
          'DRIVE_FILE_NOT_FOUND'
        );
      }

      // Safe migration: If loaded from legacy JSON, convert and save as .xlsx in Google Drive immediately
      if (needsMigration) {
        try {
          const migrationWrite = await writeDriveDatabaseFile(
            drive,
            refreshToken,
            folderId,
            DEFAULT_FILE_NAME,
            null,
            databaseData,
            vault.customClientId,
            customClientSecret
          );
          fileId = migrationWrite.fileId;
          await saveTenantVault({
            businessId,
            driveFolderId: folderId,
            driveFileId: fileId,
          });
          console.log('[drive-database] Successfully migrated legacy JSON to cafe_database.xlsx');
        } catch (migErr: any) {
          console.warn('[drive-database] Migration warning:', migErr.message);
        }
      }

      if (typeof databaseData === 'object' && databaseData !== null) {
        databaseData.businessId = businessId;
        if (databaseData.settings) {
          databaseData.settings.businessId = businessId;
        }
      }

      // Include base64 of the XLSX along with object representation for client conversion flexibility
      const xlsxBase64 = cafeDatabaseToXlsxBase64(databaseData);
      return successResponse({
        ...databaseData,
        xlsxBase64,
      });
    }

    // ==========================================
    // POST: Write cafe database to Google Drive (.xlsx)
    // ==========================================
    if (event.httpMethod === 'POST') {
      let payload: any;
      try {
        payload = event.body ? JSON.parse(event.body) : null;
      } catch {
        return errorResponse('Invalid JSON payload', 400, 'INVALID_BODY');
      }

      if (!payload || typeof payload !== 'object') {
        return errorResponse('Database payload must be a JSON object', 400, 'INVALID_PAYLOAD');
      }

      // Support payload containing xlsxBase64 string
      if (payload.xlsxBase64 && typeof payload.xlsxBase64 === 'string') {
        try {
          payload = xlsxBufferToCafeDatabase(payload.xlsxBase64, businessId);
        } catch (e: any) {
          console.warn('Could not parse incoming xlsxBase64 payload:', e);
        }
      } else if (payload.database && typeof payload.database === 'object') {
        payload = payload.database;
      }

      // STRICT CROSS-TENANT DEFENSE:
      // Force authoritative businessId from verified caller context onto payload and all records
      payload.businessId = businessId;
      if (payload.settings && typeof payload.settings === 'object') {
        payload.settings.businessId = businessId;
      }

      const collections = [
        'consoles',
        'sessions',
        'customers',
        'users',
        'rentalItems',
        'rentalRecords',
        'cafeteriaItems',
        'cafeteriaOrders',
        'payments',
        'notices',
        'vouchers',
        'voucherUsages',
        'buySellItems',
        'buySellTransactions',
        'repairs',
        'cafeteriaStockLogs',
      ];
      for (const col of collections) {
        if (Array.isArray(payload[col])) {
          payload[col] = payload[col].map((item: any) => ({
            ...item,
            businessId,
          }));
        }
      }

      // Ensure Drive folder exists
      const folderId = vault.driveFolderId || (await findOrCreateDriveFolder(drive, refreshToken, FOLDER_NAME));
      console.log('[drive-database] (POST) Using folderId:', folderId);

      // Fetch existing file from Google Drive to perform safe merge against concurrent edits
      let existingDb: any = null;
      let targetFileId = vault.driveFileId;

      if (targetFileId) {
        try {
          existingDb = await readDriveDatabaseFile(drive, refreshToken, targetFileId, fileName);
        } catch (e) {
          targetFileId = null;
        }
      }

      if (!existingDb) {
        const found = await findDriveDatabaseFile(drive, refreshToken, folderId, fileName);
        if (found) {
          targetFileId = found.fileId;
          try {
            existingDb = await readDriveDatabaseFile(drive, refreshToken, targetFileId, found.fileName);
          } catch (e) {
            // New write will recreate
          }
        }
      }

      if (existingDb && typeof existingDb === 'object') {
        existingDb.businessId = businessId;
        for (const col of collections) {
          if (Array.isArray(existingDb[col])) {
            existingDb[col] = existingDb[col]
              .filter((item: any) => !item.businessId || item.businessId === businessId)
              .map((item: any) => ({ ...item, businessId }));
          }
        }
      }

      // Perform smart record-level merge so concurrent edits by Worker 1 and Worker 2 are safe
      const mergedPayload = existingDb ? mergeCafeDatabases(existingDb, payload) : payload;

      mergedPayload.businessId = businessId;
      mergedPayload.lastModified = new Date().toISOString();
      if (mergedPayload.settings) {
        mergedPayload.settings.businessId = businessId;
      }

      for (const col of collections) {
        if (Array.isArray(mergedPayload[col])) {
          mergedPayload[col] = mergedPayload[col].map((item: any) => ({
            ...item,
            businessId,
          }));
        }
      }

      // Write / Update file in Google Drive as cafe_database.xlsx
      const writeResult = await writeDriveDatabaseFile(
        drive,
        refreshToken,
        folderId,
        DEFAULT_FILE_NAME,
        targetFileId,
        mergedPayload,
        vault.customClientId,
        customClientSecret
      );

      // If file was newly created or changed ID, update tenant vault record
      if (writeResult.fileId !== vault.driveFileId || folderId !== vault.driveFolderId) {
        await saveTenantVault({
          businessId,
          driveFolderId: folderId,
          driveFileId: writeResult.fileId,
        });
      }

      const xlsxBase64 = cafeDatabaseToXlsxBase64(mergedPayload);

      return successResponse({
        synced: true,
        businessId,
        fileId: writeResult.fileId,
        lastSyncedAt: writeResult.modifiedTime,
        database: mergedPayload,
        xlsxBase64,
      });
    }

    return errorResponse('Method Not Allowed', 405, 'METHOD_NOT_ALLOWED');
  } catch (err: any) {
    console.error('[drive-database] Error:', err?.message || String(err));
    if (err.stack) console.error(err.stack);
    return formatAuthErrorResponse(err);
  }
};
