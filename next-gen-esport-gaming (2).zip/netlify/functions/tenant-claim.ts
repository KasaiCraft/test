import { getAdminAuth, hasAdminCredentials } from './lib/firebaseAdmin.ts';
import {
  handleCorsPreflight,
  successResponse,
  formatAuthErrorResponse,
  getVerifiedUser,
  AuthError,
} from './lib/authMiddleware.ts';
import { NEXTGEN_CAFE_BUSINESS_ID, Handler, HandlerEvent } from './lib/types.ts';
import {
  getTenantVault,
  saveTenantVault,
  getWorkerBinding,
  getWorkerBindingByEmail,
} from './lib/tenantVault.ts';

/**
 * Netlify serverless function: tenant-claim
 * Resolves or establishes authoritative server-side custom claims for NEXT GEN GAMING CAFE.
 *
 * Single Business Architecture:
 * - Exactly 1 Owner/Admin account.
 * - Maximum 5 Worker accounts.
 * - Shared dataset under NEXTGEN_CAFE_BUSINESS_ID ('nextgen_gaming_cafe').
 *
 * Owner Claims:
 *   { businessId: "nextgen_gaming_cafe", role: "owner" }
 * Worker Claims:
 *   { businessId: "nextgen_gaming_cafe", role: "worker", ownerUid: "<ownerUid>" }
 */
export const handler: Handler = async (event: HandlerEvent) => {
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  if (event.httpMethod !== 'GET' && event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { Allow: 'GET, POST, OPTIONS' },
      body: JSON.stringify({ success: false, error: 'Method Not Allowed' }),
    };
  }

  try {
    const adminAuth = getAdminAuth();
    // 1. Authenticate caller strictly using cryptographic Firebase ID token verification
    const verifiedUser = await getVerifiedUser(event);

    const uid = verifiedUser.uid;
    const email = verifiedUser.email.toLowerCase();

    // 2. Check if user is a registered worker (by UID or email in _worker_bindings)
    let workerBinding = await getWorkerBinding(uid);
    if (!workerBinding && email) {
      workerBinding = await getWorkerBindingByEmail(email);
    }

    if (workerBinding) {
      const workerClaims = {
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        role: 'worker',
        ownerUid: workerBinding.ownerUid,
      };

      if (hasAdminCredentials()) {
        try {
          const adminAuth = getAdminAuth();
          await adminAuth.setCustomUserClaims(uid, workerClaims);
        } catch (claimsErr) {
          console.warn('[tenant-claim] Could not set worker custom claims:', claimsErr);
        }
      }

      return successResponse({
        uid,
        email,
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        role: 'worker',
        ownerUid: workerBinding.ownerUid,
        businessName: 'NEXT GEN GAMING CAFE',
        requiresTokenRefresh: true,
      });
    }

    // 3. User is establishing Owner role for their isolated workspace
    const userBizId = `user_${uid}`;

    await saveTenantVault({
      businessId: userBizId,
      ownerUid: uid,
      ownerEmail: email,
      businessName: 'NEXT GEN GAMING CAFE',
    });

    // Assign owner custom claims via Firebase Admin SDK
    const ownerClaims = {
      businessId: userBizId,
      role: 'owner',
      ownerUid: uid,
    };
    if (hasAdminCredentials()) {
      try {
        const adminAuth = getAdminAuth();
        await adminAuth.setCustomUserClaims(uid, ownerClaims);
      } catch (claimsErr) {
        console.warn('Could not set owner custom claims via admin auth:', claimsErr);
      }
    }

    return successResponse({
      uid,
      email,
      businessId: userBizId,
      role: 'owner',
      ownerUid: uid,
      businessName: 'NEXT GEN GAMING CAFE',
      requiresTokenRefresh: true,
    });
  } catch (err: any) {
    console.error('Error in tenant-claim handler:', err);
    return formatAuthErrorResponse(err);
  }
};

