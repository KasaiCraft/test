import { handleCorsPreflight, successResponse, errorResponse } from './lib/authMiddleware.ts';
import { getTenantVault, saveTenantVault } from './lib/tenantVault.ts';
import { NEXTGEN_CAFE_BUSINESS_ID, Handler, HandlerEvent } from './lib/types.ts';
import { getAdminAuth, hasAdminCredentials } from './lib/firebaseAdmin.ts';

/**
 * Netlify Function: system-status
 * Path: /api/system-status or /.netlify/functions/system-status
 *
 * Authoritatively reports whether NEXT GEN GAMING CAFE has an active Owner account configured.
 * Dynamically queries Firebase Authentication when admin credentials are available.
 * Zero dependency on Firestore.
 */
export const handler: Handler = async (event: HandlerEvent) => {
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  try {
    // Helper to verify if an owner exists in Firebase Authentication
    async function verifyAuthOwner(storedOwnerUid?: string, storedOwnerEmail?: string): Promise<{
      hasUsers: boolean;
      ownerActive: boolean;
      activeOwnerEmail?: string;
      activeOwnerUid?: string;
    }> {
      if (!hasAdminCredentials()) {
        // Without admin credentials, rely on stored vault state
        const active = Boolean(storedOwnerUid || storedOwnerEmail);
        return {
          hasUsers: active,
          ownerActive: active,
          activeOwnerEmail: storedOwnerEmail,
          activeOwnerUid: storedOwnerUid,
        };
      }

      try {
        const auth = getAdminAuth();
        const usersList = await auth.listUsers(20);
        if (usersList.users.length === 0) {
          return { hasUsers: false, ownerActive: false };
        }

        // Search for user matching stored credentials
        const matchingUser = usersList.users.find(
          (u) =>
            (storedOwnerUid && u.uid === storedOwnerUid) ||
            (storedOwnerEmail && u.email?.toLowerCase() === storedOwnerEmail.toLowerCase())
        );

        if (matchingUser) {
          return {
            hasUsers: true,
            ownerActive: true,
            activeOwnerEmail: matchingUser.email?.toLowerCase(),
            activeOwnerUid: matchingUser.uid,
          };
        }

        // If stored owner was deleted but there is another user who has 'owner' custom claims
        for (const u of usersList.users) {
          if (u.customClaims?.role === 'owner' || u.customClaims?.role === 'admin') {
            return {
              hasUsers: true,
              ownerActive: true,
              activeOwnerEmail: u.email?.toLowerCase(),
              activeOwnerUid: u.uid,
            };
          }
        }

        return { hasUsers: true, ownerActive: false };
      } catch (err) {
        console.warn('[system-status] Firebase Auth listUsers notice:', err);
        return { hasUsers: true, ownerActive: Boolean(storedOwnerUid || storedOwnerEmail) };
      }
    }

    // 1. GET or POST action=check/reset: Check if owner exists with live Firebase Auth sync
    if (event.httpMethod === 'GET' || (event.httpMethod === 'POST' && event.body && event.body.includes('sync_firebase'))) {
      let ownerEmail: string | undefined;
      let ownerUid: string | undefined;
      let businessName = 'NEXT GEN GAMING CAFE';
      let ownerExists = false;

      // Check tenant vault
      const vault = await getTenantVault(NEXTGEN_CAFE_BUSINESS_ID);
      if (vault && (vault.ownerEmail || vault.ownerUid)) {
        ownerExists = true;
        ownerEmail = vault.ownerEmail;
        ownerUid = vault.ownerUid;
        businessName = vault.businessName || businessName;
      }

      // Live verification if admin credentials exist
      const authCheck = await verifyAuthOwner(ownerUid, ownerEmail);

      if (authCheck.hasUsers && authCheck.ownerActive) {
        ownerExists = true;
        ownerEmail = authCheck.activeOwnerEmail || ownerEmail;
        ownerUid = authCheck.activeOwnerUid || ownerUid;
      } else if (!authCheck.hasUsers && hasAdminCredentials()) {
        // Absolutely no users in Firebase Authentication: Purge stale config
        ownerExists = false;
        ownerEmail = undefined;
        ownerUid = undefined;

        try {
          await saveTenantVault({
            businessId: NEXTGEN_CAFE_BUSINESS_ID,
            ownerUid: '',
            ownerEmail: '',
          });
        } catch {}
      }

      return successResponse({
        ownerExists,
        businessName,
        ownerEmail: ownerEmail || undefined,
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        firebaseHasUsers: authCheck.hasUsers,
      });
    }

    // 2. DELETE: Explicitly reset / purge owner status so user can re-register
    if (event.httpMethod === 'DELETE') {
      try {
        await saveTenantVault({
          businessId: NEXTGEN_CAFE_BUSINESS_ID,
          ownerUid: '',
          ownerEmail: '',
        });
      } catch {}

      return successResponse({
        success: true,
        message: 'Owner configuration reset successfully. Registration is now open.',
        ownerExists: false,
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
      });
    }

    // 3. POST: Register owner (strictly allowed ONLY if no owner currently exists)
    if (event.httpMethod === 'POST') {
      let body: any = {};
      try {
        body = event.body ? JSON.parse(event.body) : {};
      } catch {
        return errorResponse('Invalid JSON payload', 400);
      }

      if (body.action === 'reset_owner' || body.action === 'purge_owner') {
        try {
          await saveTenantVault({
            businessId: NEXTGEN_CAFE_BUSINESS_ID,
            ownerUid: '',
            ownerEmail: '',
          });
        } catch {}

        return successResponse({
          success: true,
          message: 'Owner configuration reset successfully.',
          ownerExists: false,
        });
      }

      const existingVault = await getTenantVault(NEXTGEN_CAFE_BUSINESS_ID);
      if (existingVault && (existingVault.ownerEmail || existingVault.ownerUid)) {
        const authCheck = await verifyAuthOwner(existingVault.ownerUid, existingVault.ownerEmail);
        if (authCheck.hasUsers && authCheck.ownerActive) {
          return errorResponse(
            'FORBIDDEN: NEXT GEN GAMING CAFE already has an active Owner account configured. New registrations are closed.',
            403,
            'OWNER_ALREADY_CONFIGURED'
          );
        }
      }

      const { ownerEmail, ownerUid, ownerName } = body;
      if (!ownerEmail || !ownerUid) {
        return errorResponse('ownerEmail and ownerUid are required to initialize the cafe owner', 400);
      }

      const cleanEmail = String(ownerEmail).trim().toLowerCase();

      // Save to tenant vault
      await saveTenantVault({
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        ownerUid,
        ownerEmail: cleanEmail,
        businessName: 'NEXT GEN GAMING CAFE',
      });

      return successResponse({
        success: true,
        message: 'Owner configuration established successfully.',
        ownerEmail: cleanEmail,
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
      });
    }

    return errorResponse('Method Not Allowed', 405, 'METHOD_NOT_ALLOWED');
  } catch (err: any) {
    console.error('[system-status] Error:', err);
    return errorResponse(err.message || 'Internal Server Error', 500);
  }
};
