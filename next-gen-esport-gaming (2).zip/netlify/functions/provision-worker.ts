import { getAdminAuth, hasAdminCredentials } from './lib/firebaseAdmin.ts';
import {
  handleCorsPreflight,
  successResponse,
  errorResponse,
  formatAuthErrorResponse,
  requireOwner,
  AuthError,
} from './lib/authMiddleware.ts';
import { NEXTGEN_CAFE_BUSINESS_ID, MAX_WORKERS_ALLOWED, Handler, HandlerEvent } from './lib/types.ts';
import {
  saveWorkerBinding,
  getWorkerBinding,
  deleteWorkerBinding,
  getWorkersByBusiness,
  getWorkerBindingByEmail,
} from './lib/tenantVault.ts';

/**
 * Netlify serverless function: provision-worker
 *
 * Enforces Owner-only access (role === "owner").
 * Authoritatively assigns the authenticated owner's businessId to the worker.
 * Sets Firebase custom claims:
 *   { businessId: ownerBusinessId, role: "worker", ownerUid: ownerUid }
 * Prevents cross-business tampering and blocks workers from provisioning staff.
 */
export const handler: Handler = async (event: HandlerEvent) => {
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  try {
    // 1. Strictly enforce that the caller is an authenticated owner with verified claims
    const ownerContext = await requireOwner(event);
    const ownerBusinessId = ownerContext.businessId;
    const adminAuth = getAdminAuth();

    // 2. Route by HTTP Method / Action
    if (event.httpMethod === 'GET') {
      // List all workers bound to this owner's businessId
      const workers = await getWorkersByBusiness(ownerBusinessId);
      return successResponse(workers);
    }

    if (event.httpMethod === 'POST') {
      let body: any = {};
      try {
        body = JSON.parse(event.body || '{}');
      } catch {
        return errorResponse('Invalid JSON request body', 400, 'BAD_REQUEST');
      }

      const { action = 'provision', workerUid, workerEmail, workerName, temporaryPassword } = body;

      // Handle unbind action if sent via POST
      if (action === 'unbind') {
        return await handleUnbindWorker(ownerContext, workerUid || body.uid, adminAuth);
      }

      // Provision worker:
      let targetWorkerUid = workerUid;
      const cleanEmail = (workerEmail || '').trim().toLowerCase();

      if (!targetWorkerUid && !cleanEmail) {
        return errorResponse(
          'Missing workerUid or workerEmail for provisioning',
          400,
          'MISSING_WORKER_IDENTITY'
        );
      }

      // If workerUid is not provided, locate or create Firebase Auth user
      if (!targetWorkerUid) {
        try {
          const existingUser = await adminAuth.getUserByEmail(cleanEmail);
          targetWorkerUid = existingUser.uid;
          // If a new password was provided by Admin, update it for the existing worker
          if (temporaryPassword) {
            await adminAuth.updateUser(targetWorkerUid, {
              password: temporaryPassword,
              displayName: workerName || existingUser.displayName,
            });
          }
        } catch (getErr: any) {
          if (getErr?.code === 'auth/user-not-found' && temporaryPassword) {
            const newUser = await adminAuth.createUser({
              email: cleanEmail,
              password: temporaryPassword,
              displayName: workerName || cleanEmail.split('@')[0],
            });
            targetWorkerUid = newUser.uid;
          } else {
            return errorResponse(
              `Worker user could not be found or created in Firebase Auth: ${getErr?.message}`,
              400,
              'WORKER_AUTH_ERROR'
            );
          }
        }
      } else {
        // Verify target workerUid actually exists in Firebase Auth
        try {
          await adminAuth.getUser(targetWorkerUid);
          if (temporaryPassword) {
            await adminAuth.updateUser(targetWorkerUid, {
              password: temporaryPassword,
              displayName: workerName,
            });
          }
        } catch (verifyUserErr: any) {
          return errorResponse(
            `Target worker UID not found in Firebase Auth: ${verifyUserErr?.message}`,
            404,
            'WORKER_NOT_FOUND'
          );
        }
      }

      // Verify worker count limit: maximum 5 workers allowed for NEXT GEN GAMING CAFE
      const currentWorkers = await getWorkersByBusiness(NEXTGEN_CAFE_BUSINESS_ID);
      const isAlreadyWorker = currentWorkers.some(
        (w) => w.workerUid === targetWorkerUid || (cleanEmail && w.workerEmail.toLowerCase() === cleanEmail)
      );

      if (!isAlreadyWorker && currentWorkers.length >= MAX_WORKERS_ALLOWED) {
        return errorResponse(
          `Maximum ${MAX_WORKERS_ALLOWED} Worker accounts allowed for NEXT GEN GAMING CAFE. You currently have ${currentWorkers.length} active workers.`,
          400,
          'MAX_WORKERS_EXCEEDED'
        );
      }

      // 3. Authoritatively assign the Owner's businessId and role "worker"
      const workerClaims = {
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        role: 'worker',
        ownerUid: ownerContext.uid,
      };

      if (hasAdminCredentials()) {
        try {
          await adminAuth.setCustomUserClaims(targetWorkerUid, workerClaims);
        } catch (claimsErr) {
          console.warn('[provision-worker] Could not set custom claims via admin auth:', claimsErr);
        }
      }

      // 4. Save server-authoritative worker binding in secure vault store
      await saveWorkerBinding({
        workerUid: targetWorkerUid,
        workerEmail: cleanEmail,
        workerName: workerName || 'Staff Member',
        businessId: NEXTGEN_CAFE_BUSINESS_ID,
        ownerUid: ownerContext.uid,
        role: 'worker',
        createdAt: new Date().toISOString(),
      });

      return successResponse({
        workerUid: targetWorkerUid,
        workerEmail: cleanEmail,
        workerName: workerName || 'Staff Member',
        businessId: ownerBusinessId,
        role: 'worker',
        ownerUid: ownerContext.uid,
        message: `Worker provisioned successfully under businessId ${ownerBusinessId}`,
      });
    }

    if (event.httpMethod === 'DELETE') {
      const workerUid =
        event.queryStringParameters?.workerUid ||
        event.queryStringParameters?.uid;

      if (!workerUid) {
        return errorResponse('Missing workerUid parameter', 400, 'MISSING_WORKER_UID');
      }

      return await handleUnbindWorker(ownerContext, workerUid, adminAuth);
    }

    return {
      statusCode: 405,
      headers: { Allow: 'GET, POST, DELETE, OPTIONS' },
      body: JSON.stringify({ success: false, error: 'Method Not Allowed' }),
    };
  } catch (err: any) {
    console.error('Error in provision-worker handler:', err);
    return formatAuthErrorResponse(err);
  }
};

async function handleUnbindWorker(
  ownerContext: { businessId: string; uid: string },
  workerUid: string,
  adminAuth: any
) {
  if (!workerUid) {
    return errorResponse('Missing workerUid', 400, 'MISSING_WORKER_UID');
  }

  // Cross-business check: ensure the target worker belongs to THIS owner's business
  const existingBinding = await getWorkerBinding(workerUid);
  if (existingBinding) {
    if (existingBinding.businessId !== ownerContext.businessId) {
      throw new AuthError(
        'Cross-business access attempt denied. Worker belongs to another business.',
        403,
        'CROSS_BUSINESS_ACCESS_DENIED'
      );
    }
  }

  // Clear custom claims on the worker
  if (hasAdminCredentials()) {
    try {
      await adminAuth.setCustomUserClaims(workerUid, null);
    } catch (claimErr) {
      console.warn(`Could not reset claims for worker ${workerUid}:`, claimErr);
    }
  }

  // Delete from _worker_bindings
  await deleteWorkerBinding(workerUid);

  return successResponse({
    unassigned: true,
    workerUid,
    businessId: ownerContext.businessId,
  });
}
