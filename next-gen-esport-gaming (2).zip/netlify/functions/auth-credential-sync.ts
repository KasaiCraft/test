import { Handler, HandlerEvent } from './lib/types.ts';
import { handleCorsPreflight, successResponse, errorResponse } from './lib/authMiddleware.ts';
import { getAdminAuth, hasAdminCredentials } from './lib/firebaseAdmin.ts';

/**
 * Netlify Function: auth-credential-sync
 * Path: /api/auth-credential-sync or /.netlify/functions/auth-credential-sync
 *
 * Ensures that legitimate Firebase users (such as owners whose password provider
 * was unlinked by Google OAuth or staff provisioned via owner dashboard) have their
 * email+password credentials in Firebase Authentication synchronized so that subsequent
 * logins never fail with "Invalid email or password".
 */
export const handler: Handler = async (event: HandlerEvent) => {
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  if (event.httpMethod !== 'POST') {
    return errorResponse('Method Not Allowed', 405, 'METHOD_NOT_ALLOWED');
  }

  if (!hasAdminCredentials()) {
    return errorResponse('Admin credentials unavailable on server', 503, 'NO_ADMIN_CREDENTIALS');
  }

  try {
    let body: any = {};
    try {
      body = JSON.parse(event.body || '{}');
    } catch {
      return errorResponse('Invalid JSON payload', 400, 'INVALID_BODY');
    }

    const { email, password } = body;
    if (!email || !password) {
      return errorResponse('Email and password are required', 400, 'MISSING_FIELDS');
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password);

    if (cleanPassword.length < 6) {
      return errorResponse('Password must be at least 6 characters long', 400, 'INVALID_PASSWORD_LENGTH');
    }

    const adminAuth = getAdminAuth();
    let userRecord;
    try {
      userRecord = await adminAuth.getUserByEmail(cleanEmail);
    } catch (getErr: any) {
      if (getErr?.code === 'auth/user-not-found') {
        return errorResponse('User account does not exist in Firebase Authentication', 404, 'USER_NOT_FOUND');
      }
      throw getErr;
    }

    if (userRecord.disabled) {
      return errorResponse('User account is disabled in Firebase Authentication', 403, 'ACCOUNT_DISABLED');
    }

    // Update the password in Firebase Authentication
    await adminAuth.updateUser(userRecord.uid, {
      password: cleanPassword,
    });

    console.log(`[auth-credential-sync] Successfully synchronized password for ${cleanEmail} (uid: ${userRecord.uid})`);

    return successResponse({
      synced: true,
      uid: userRecord.uid,
      email: cleanEmail,
    });
  } catch (err: any) {
    console.error('[auth-credential-sync] Error:', err);
    return errorResponse(err?.message || 'Failed to synchronize credentials', 500, 'SYNC_ERROR');
  }
};
