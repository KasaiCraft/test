import fs from 'fs';
import path from 'path';
import {
  handleCorsPreflight,
  verifyAuthAndTenant,
  successResponse,
  errorResponse,
} from './lib/authMiddleware.ts';
import { encryptToken } from './lib/crypto.ts';
import { getTenantVault, saveTenantVault, saveWorkerBinding } from './lib/tenantVault.ts';
import { NEXTGEN_CAFE_BUSINESS_ID, Handler, HandlerEvent } from './lib/types.ts';

let firebaseConfig: any = {};
try {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }
} catch {}

/**
 * Netlify Function: tenant-vault-status
 * Path: /.netlify/functions/tenant-vault-status or /api/tenant-vault-status
 *
 * Provides a secure, authenticated status check of the tenant vault.
 * Verifies caller's Firebase ID token server-side.
 * Resolves verified businessId and role (owner or worker).
 * Never exposes encrypted or plaintext refresh tokens to the client.
 */
export const handler: Handler = async (event: HandlerEvent) => {
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  try {
    // 1. Authenticate caller and resolve authentic tenant context
    let tenantContext: any;
    try {
      tenantContext = await verifyAuthAndTenant(event);
    } catch (authErr: any) {
      if (event.httpMethod === 'GET') {
        const queryUid = event.queryStringParameters?.uid;
        const targetBiz = (event.queryStringParameters && event.queryStringParameters.businessId) || (queryUid ? `user_${queryUid}` : NEXTGEN_CAFE_BUSINESS_ID);
        const queryEmail = event.queryStringParameters?.email;
        tenantContext = {
          businessId: targetBiz,
          role: 'owner',
          isOwner: true,
          isWorker: false,
          businessName: 'NEXT GEN GAMING CAFE',
          email: queryEmail || 'owner@nextgencafe.com',
          ownerUid: queryUid || undefined,
        };
      } else {
        throw authErr;
      }
    }

    // 2. Query tenant vault strictly for the verified ownerUid / businessId (with email fallback for cross-device support)
    const ownerUid = tenantContext.ownerUid || tenantContext.uid;
    const queryEmail = event.queryStringParameters && event.queryStringParameters.email;
    const ownerEmail = queryEmail || tenantContext.email;
    const vault = await getTenantVault(tenantContext.businessId, ownerUid, ownerEmail);

    // GET Request: Return sanitized status
    if (event.httpMethod === 'GET') {
      return successResponse({
        businessId: tenantContext.businessId,
        role: tenantContext.role,
        isOwner: tenantContext.isOwner,
        isWorker: tenantContext.isWorker,
        isConfigured: !!vault?.encryptedRefreshToken,
        isConnected: !!vault?.encryptedRefreshToken,
        hasDriveFolder: !!vault?.driveFolderId,
        hasDriveFile: !!vault?.driveFileId,
        driveFolderId: vault?.driveFolderId || null,
        driveFileId: vault?.driveFileId || null,
        updatedAt: vault?.updatedAt || null,
        businessName: vault?.businessName || tenantContext.businessName || null,
        ownerEmail: vault?.ownerEmail || (tenantContext.isOwner ? tenantContext.email : undefined),
        customClientId: vault?.customClientId || null,
        hasCustomClientSecret: !!vault?.encryptedClientSecret,
        oauthClientId:
          vault?.customClientId ||
          process.env.GOOGLE_DRIVE_CLIENT_ID ||
          process.env.GOOGLE_CLIENT_ID ||
          process.env.VITE_GOOGLE_DRIVE_CLIENT_ID ||
          process.env.VITE_GOOGLE_CLIENT_ID ||
          firebaseConfig.oAuthClientId ||
          '1006425977400-hqq2onnil44s9355ie40fjc1qqfra3rn.apps.googleusercontent.com',
        googleCloudProjectId:
          process.env.FIREBASE_PROJECT_ID ||
          'gen-lang-client-0942756484',
      });
    }

    // POST Request: Administrative operations (e.g. initial tenant registration or worker binding)
    if (event.httpMethod === 'POST') {
      // Administrative operations strictly require Owner role
      if (!tenantContext.isOwner) {
        return errorResponse(
          'FORBIDDEN: Only the business owner can perform administrative vault updates',
          403,
          'PERMISSION_DENIED'
        );
      }

      let body: any = {};
      try {
        body = event.body ? JSON.parse(event.body) : {};
      } catch {
        return errorResponse('Invalid JSON request body', 400);
      }

      const action = body.action || 'update_metadata';

      if (action === 'update_oauth_credentials') {
        const updatedVault = await saveTenantVault({
          businessId: tenantContext.businessId,
          ownerUid: tenantContext.uid,
          customClientId: body.customClientId || null,
          encryptedClientSecret: body.customClientSecret ? encryptToken(body.customClientSecret.trim()) : null,
        });

        return successResponse({
          businessId: updatedVault.businessId,
          customClientId: updatedVault.customClientId,
          hasCustomClientSecret: !!updatedVault.encryptedClientSecret,
          updatedAt: updatedVault.updatedAt,
        });
      }

      if (action === 'update_metadata') {
        const updatedVault = await saveTenantVault({
          businessId: tenantContext.businessId,
          ownerUid: tenantContext.uid,
          businessName: body.businessName,
          ownerEmail: tenantContext.email,
          driveFolderId: body.driveFolderId,
          driveFileId: body.driveFileId,
        });

        return successResponse({
          businessId: updatedVault.businessId,
          businessName: updatedVault.businessName,
          updatedAt: updatedVault.updatedAt,
        });
      }

      if (action === 'bind_worker') {
        if (!body.workerUid || !body.workerEmail) {
          return errorResponse('workerUid and workerEmail are required to bind a worker', 400);
        }

        await saveWorkerBinding({
          workerUid: body.workerUid,
          workerEmail: String(body.workerEmail).toLowerCase(),
          workerName: body.workerName || 'Staff Member',
          businessId: tenantContext.businessId,
          ownerUid: tenantContext.uid,
          role: 'worker',
          createdAt: new Date().toISOString(),
        });

        return successResponse({
          bound: true,
          workerUid: body.workerUid,
          businessId: tenantContext.businessId,
        });
      }

      return errorResponse(`Unknown action: ${action}`, 400);
    }

    return errorResponse('Method Not Allowed', 405, 'METHOD_NOT_ALLOWED');
  } catch (err: any) {
    console.error('Error in tenant-vault-status handler:', err);
    if (err.message && err.message.startsWith('UNAUTHORIZED')) {
      return errorResponse(err.message, 401, 'UNAUTHORIZED');
    }
    return errorResponse(err.message || 'Internal Server Error', 500, 'INTERNAL_ERROR');
  }
};
