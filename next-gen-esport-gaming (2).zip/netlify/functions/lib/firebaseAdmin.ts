import fs from 'fs';
import path from 'path';
import {
  initializeApp,
  getApps,
  cert,
  applicationDefault,
  type App,
  type ServiceAccount,
} from 'firebase-admin/app';
import { getAuth, type Auth } from 'firebase-admin/auth';

/**
 * Checks if Firebase Admin credentials are provided in the environment.
 */
export function hasAdminCredentials(): boolean {
  return Boolean(
    process.env.FIREBASE_SERVICE_ACCOUNT_KEY ||
      (process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY) ||
      (process.env.GOOGLE_APPLICATION_CREDENTIALS && fs.existsSync(process.env.GOOGLE_APPLICATION_CREDENTIALS))
  );
}

let firebaseConfig: any = {};
try {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }
} catch {
  // fallback to env vars
}

let adminApp: App | null = null;

/**
 * Parses and formats the private key to ensure proper line break formatting
 * and valid PEM encapsulation (BEGIN/END PRIVATE KEY).
 */
export function formatPrivateKey(key: string): string {
  if (!key) return '';

  let formatted = key.replace(/\\n/g, '\n').replace(/\r/g, '').trim();

  // Strip leading and trailing quotes if present (e.g. from environment variable declarations)
  if (
    (formatted.startsWith('"') && formatted.endsWith('"')) ||
    (formatted.startsWith("'") && formatted.endsWith("'"))
  ) {
    formatted = formatted.slice(1, -1).trim();
    formatted = formatted.replace(/\\n/g, '\n').trim();
  }

  // If PEM boundaries are missing, wrap the base64 key in standard PKCS#8 PEM format
  if (!formatted.includes('-----BEGIN')) {
    formatted = `-----BEGIN PRIVATE KEY-----\n${formatted}\n-----END PRIVATE KEY-----\n`;
  }

  return formatted;
}

/**
 * Normalizes raw service account JSON dictionary into a typed ServiceAccount object.
 */
function normalizeServiceAccount(parsed: any, fallbackProjectId: string): ServiceAccount {
  return {
    projectId: parsed.project_id || parsed.projectId || fallbackProjectId,
    clientEmail: parsed.client_email || parsed.clientEmail || '',
    privateKey: formatPrivateKey(parsed.private_key || parsed.privateKey || ''),
  };
}

/**
 * Safely parses the FIREBASE_SERVICE_ACCOUNT_KEY variable.
 * Handles raw JSON strings, file paths, base64-encoded JSON, and direct private key strings.
 */
function parseServiceAccountString(raw: string, fallbackProjectId: string): ServiceAccount | null {
  if (!raw || !raw.trim()) return null;

  let cleaned = raw.trim();

  // Strip wrapping double or single quotes
  if (
    (cleaned.startsWith('"') && cleaned.endsWith('"')) ||
    (cleaned.startsWith("'") && cleaned.endsWith("'"))
  ) {
    cleaned = cleaned.slice(1, -1).trim();
  }

  // 1. If it points to an existing file on disk
  try {
    if (fs.existsSync(cleaned) && fs.statSync(cleaned).isFile()) {
      const fileContent = fs.readFileSync(cleaned, 'utf-8').trim();
      if (fileContent.startsWith('{')) {
        const parsed = JSON.parse(fileContent);
        return normalizeServiceAccount(parsed, fallbackProjectId);
      }
    }
  } catch {
    // Not a readable file path
  }

  // 2. Direct JSON format
  if (cleaned.startsWith('{')) {
    try {
      const parsed = JSON.parse(cleaned);
      return normalizeServiceAccount(parsed, fallbackProjectId);
    } catch {
      // Not valid JSON
      return null;
    }
  }

  // 3. Base64-encoded JSON format (verify decoded text begins with '{' before parsing)
  try {
    const decoded = Buffer.from(cleaned, 'base64').toString('utf8').trim();
    if (decoded.startsWith('{') && decoded.endsWith('}')) {
      const parsed = JSON.parse(decoded);
      return normalizeServiceAccount(parsed, fallbackProjectId);
    }
  } catch {
    // Not base64-encoded JSON
  }

  // 4. Raw Private Key pasted into FIREBASE_SERVICE_ACCOUNT_KEY
  const looksLikePrivateKey =
    cleaned.includes('-----BEGIN') ||
    cleaned.startsWith('MII') ||
    cleaned.startsWith('\\nMII') ||
    cleaned.startsWith('\nMII');

  if (looksLikePrivateKey) {
    const clientEmail =
      process.env.FIREBASE_CLIENT_EMAIL ||
      firebaseConfig.clientEmail;
    if (clientEmail) {
      return {
        projectId: process.env.FIREBASE_PROJECT_ID || firebaseConfig.projectId || fallbackProjectId,
        clientEmail,
        privateKey: formatPrivateKey(cleaned),
      };
    }
  }

  return null;
}

/**
 * Initializes or returns the singleton Firebase Admin App instance
 */
export function getFirebaseAdmin(): App {
  if (adminApp) {
    return adminApp;
  }

  const existingApps = getApps();
  if (existingApps.length > 0 && existingApps[0]) {
    adminApp = existingApps[0];
    return adminApp;
  }

  const projectId =
    process.env.FIREBASE_PROJECT_ID ||
    firebaseConfig.projectId ||
    'gen-lang-client-0942756484';

  // Strategy 1: Full Service Account JSON or Private Key in environment variable
  const rawServiceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
  if (rawServiceAccount) {
    try {
      const parsed = parseServiceAccountString(rawServiceAccount, projectId);
      if (parsed && parsed.clientEmail && parsed.privateKey) {
        adminApp = initializeApp({
          credential: cert(parsed),
          projectId: parsed.projectId || projectId,
        });
        return adminApp;
      }
    } catch (err: any) {
      console.warn('[firebaseAdmin] Could not initialize via FIREBASE_SERVICE_ACCOUNT_KEY:', err?.message || String(err));
    }
  }

  // Strategy 2: Individual Service Account environment variables
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const rawPrivateKey = process.env.FIREBASE_PRIVATE_KEY;
  if (clientEmail && rawPrivateKey) {
    try {
      const privateKey = formatPrivateKey(rawPrivateKey);
      adminApp = initializeApp({
        credential: cert({
          projectId,
          clientEmail,
          privateKey,
        }),
        projectId,
      });
      return adminApp;
    } catch (certErr: any) {
      console.warn('Failed to initialize Firebase Admin with FIREBASE_PRIVATE_KEY, falling back to ADC:', certErr?.message || String(certErr));
    }
  }

  // Strategy 3: Application Default Credentials (ADC) - only if explicit valid credentials file is present
  if (
    process.env.GOOGLE_APPLICATION_CREDENTIALS &&
    fs.existsSync(process.env.GOOGLE_APPLICATION_CREDENTIALS)
  ) {
    try {
      adminApp = initializeApp({
        credential: applicationDefault(),
        projectId,
      });
      return adminApp;
    } catch (adcErr: any) {
      console.warn('Failed to initialize Firebase Admin with ADC:', adcErr?.message || String(adcErr));
    }
  }

  // Strategy 4: Project-only initialization (prevents "Could not load default credentials" error)
  adminApp = initializeApp({
    projectId,
  });
  return adminApp;
}

/**
 * Returns Firebase Admin Auth service
 */
export function getAdminAuth(): Auth {
  const app = getFirebaseAdmin();
  return getAuth(app);
}

