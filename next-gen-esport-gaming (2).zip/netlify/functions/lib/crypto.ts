import crypto from 'node:crypto';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12; // 96-bit IV recommended for AES-GCM
const AUTH_TAG_LENGTH = 16; // 128-bit auth tag

/**
 * Resolves or derives a 32-byte (256-bit) encryption key from environment variable
 */
export function getEncryptionKey(overrideKey?: string): Buffer {
  const rawKey =
    overrideKey ||
    process.env.TOKEN_ENCRYPTION_KEY ||
    `nextgen-cafe-default-encryption-salt-${process.env.FIREBASE_PROJECT_ID || 'gen-lang-client-0942756484'}`;

  // If 64 hex characters (32 bytes in hex)
  if (/^[0-9a-fA-F]{64}$/.test(rawKey)) {
    return Buffer.from(rawKey, 'hex');
  }

  // If already 32 bytes ASCII/UTF-8
  if (Buffer.byteLength(rawKey, 'utf8') === 32) {
    return Buffer.from(rawKey, 'utf8');
  }

  // Otherwise, derive a consistent 256-bit key using SHA-256 digest
  return crypto.createHash('sha256').update(rawKey, 'utf8').digest();
}

/**
 * Encrypts a plaintext string (e.g. Google OAuth refresh token) using AES-256-GCM.
 * Output format: ivHex:authTagHex:encryptedHex
 */
export function encryptToken(plainText: string, customKey?: string): string {
  if (!plainText) {
    throw new Error('Cannot encrypt empty string');
  }

  const key = getEncryptionKey(customKey);
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH,
  });

  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag();

  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
}

export function getEncryptionKeyCandidates(customKey?: string): Buffer[] {
  const keys: Buffer[] = [];
  const candidateStrings = [
    customKey,
    process.env.TOKEN_ENCRYPTION_KEY,
    `nextgen-cafe-default-encryption-salt-${process.env.FIREBASE_PROJECT_ID || 'gen-lang-client-0942756484'}`,
    'nextgen-cafe-default-encryption-salt-gen-lang-client-0942756484',
    `nextgen-cafe-default-encryption-salt-${process.env.GOOGLE_CLOUD_PROJECT || 'gen-lang-client-0942756484'}`,
    'nextgen-cafe-default-encryption-salt-ai-studio-nextgenesportgam-00194049-1072-48bf-ad25-7990791f8523',
    'nextgen-cafe-default-encryption-salt-00194049-1072-48bf-ad25-7990791f8523',
    'nextgen-gaming-cafe-vault-secret-key-32bytes',
  ].filter(Boolean) as string[];

  for (const raw of candidateStrings) {
    let buf: Buffer;
    if (/^[0-9a-fA-F]{64}$/.test(raw)) {
      buf = Buffer.from(raw, 'hex');
    } else if (Buffer.byteLength(raw, 'utf8') === 32) {
      buf = Buffer.from(raw, 'utf8');
    } else {
      buf = crypto.createHash('sha256').update(raw, 'utf8').digest();
    }
    if (!keys.some((k) => k.equals(buf))) {
      keys.push(buf);
    }
  }
  return keys;
}

/**
 * Decrypts an AES-256-GCM encrypted string.
 * Validates integrity via the authentication tag.
 * Tries known key candidates if environment salts differ between processes.
 */
export function decryptToken(encryptedPayload: string, customKey?: string): string {
  if (!encryptedPayload) {
    throw new Error('Cannot decrypt empty string');
  }

  // Handle plain mock test tokens without IV/tag
  if (!encryptedPayload.includes(':') && (encryptedPayload.startsWith('mock_') || encryptedPayload.startsWith('ya29.'))) {
    return encryptedPayload;
  }

  const parts = encryptedPayload.split(':');
  if (parts.length !== 3) {
    throw new Error('Invalid encrypted payload format. Expected iv:authTag:ciphertext');
  }

  const [ivHex, authTagHex, cipherTextHex] = parts;
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  const candidateKeys = getEncryptionKeyCandidates(customKey);

  let lastError: any = null;
  for (const key of candidateKeys) {
    try {
      const decipher = crypto.createDecipheriv(ALGORITHM, key, iv, {
        authTagLength: AUTH_TAG_LENGTH,
      });
      decipher.setAuthTag(authTag);
      let decrypted = decipher.update(cipherTextHex, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      return decrypted;
    } catch (err: any) {
      lastError = err;
    }
  }

  throw lastError || new Error('Failed to decrypt token with available encryption keys');
}
