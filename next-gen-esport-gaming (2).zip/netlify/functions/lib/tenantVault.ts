import fs from 'fs';
import path from 'path';
import { getFirestore, type Firestore } from 'firebase-admin/firestore';
import { getFirebaseAdmin, getAdminAuth, hasAdminCredentials } from './firebaseAdmin.ts';
import { TenantVaultRecord, WorkerBindingRecord, NEXTGEN_CAFE_BUSINESS_ID } from './types.ts';

let firebaseAppletConfig: any = {};
try {
  const cfgPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(cfgPath)) {
    firebaseAppletConfig = JSON.parse(fs.readFileSync(cfgPath, 'utf-8'));
  }
} catch {
  // fallback
}

// Preferred persistent directories in container and serverless environments
const PRIMARY_DATA_DIR = path.resolve(process.cwd(), '.data');
const PRIMARY_DATA_FILE = path.join(PRIMARY_DATA_DIR, 'tenant_vault.json');

const FALLBACK_DATA_DIR = path.resolve('/tmp', '.data');
const FALLBACK_DATA_FILE = path.join(FALLBACK_DATA_DIR, 'tenant_vault.json');

interface LocalVaultStore {
  vaults: Record<string, TenantVaultRecord>;
  workerBindings: Record<string, WorkerBindingRecord>;
}

// In-memory active cache
let memoryStore: LocalVaultStore | null = null;
let firestoreInstance: Firestore | null = null;
let hydrationPromise: Promise<void> | null = null;
let isHydrated = false;

function getVaultFirestore(): Firestore | null {
  if (firestoreInstance) return firestoreInstance;
  try {
    const adminApp = getFirebaseAdmin();
    const databaseId =
      process.env.FIRESTORE_DATABASE_ID ||
      (firebaseAppletConfig as any)?.firestoreDatabaseId;
    if (databaseId) {
      firestoreInstance = getFirestore(adminApp, databaseId);
    } else {
      firestoreInstance = getFirestore(adminApp);
    }
    return firestoreInstance;
  } catch (err: any) {
    console.warn('[tenantVault] Firestore initialization warning:', err?.message || err);
    return null;
  }
}

/**
 * Hydrates the vault from Firestore collection `_tenant_vault`, document `store`.
 * Runs once per process. Firestore is authoritative.
 * Migrates local cache to Firestore if Firestore doc does not exist yet.
 */
export async function ensureVaultHydrated(): Promise<void> {
  if (isHydrated) return;
  if (hydrationPromise) return hydrationPromise;

  hydrationPromise = (async () => {
    try {
      if (!hasAdminCredentials()) {
        console.warn(
          '[tenantVault] WARNING: FIREBASE_SERVICE_ACCOUNT_KEY or admin credentials not configured in environment. Remote Firestore vault persistence is disabled; running in local disk cache mode.'
        );
        loadStore();
        isHydrated = true;
        return;
      }

      const db = getVaultFirestore();
      if (!db) {
        loadStore();
        isHydrated = true;
        return;
      }

      console.log('[tenantVault] Hydrating vault from Firestore collection _tenant_vault/store...');
      const docRef = db.collection('_tenant_vault').doc('store');
      const snap = await docRef.get();

      if (snap.exists) {
        const docData = snap.data();
        if (docData && typeof docData.data === 'string') {
          try {
            const parsed = JSON.parse(docData.data);
            if (parsed && typeof parsed === 'object') {
              memoryStore = {
                vaults: parsed.vaults || {},
                workerBindings: parsed.workerBindings || {},
              };
              persistStore();
              console.log('[tenantVault] Vault restored from Firestore (_tenant_vault/store).');
              isHydrated = true;
              return;
            }
          } catch (jsonErr) {
            console.error('[tenantVault] Corrupt JSON in Firestore _tenant_vault/store:', jsonErr);
          }
        }
      }

      // If document does not exist in Firestore, check local disk store and migrate up
      const local = loadStore();
      const hasLocalRecords =
        (local.vaults && Object.keys(local.vaults).length > 0) ||
        (local.workerBindings && Object.keys(local.workerBindings).length > 0);

      if (hasLocalRecords) {
        console.log('[tenantVault] Initializing Firestore _tenant_vault/store with existing local vault data...');
        await docRef.set({
          data: JSON.stringify(local),
          updatedAt: new Date().toISOString(),
        });
        console.log('[tenantVault] Migrated local vault store to Firestore (_tenant_vault/store).');
      } else {
        console.log('[tenantVault] No existing vault in Firestore or disk. Initialized empty store.');
      }
      isHydrated = true;
    } catch (err: any) {
      console.error('[tenantVault] LOUD ERROR: Failed to hydrate vault from Firestore:', err?.message || err);
      // Fallback to local disk store so app continues running without crashing
      loadStore();
      isHydrated = true;
    } finally {
      hydrationPromise = null;
    }
  })();

  return hydrationPromise;
}

/**
 * Persists memoryStore remotely to Firestore `_tenant_vault/store`.
 */
async function persistRemote(): Promise<void> {
  if (!hasAdminCredentials()) return;
  try {
    const db = getVaultFirestore();
    if (!db) return;
    const storeData = memoryStore || { vaults: {}, workerBindings: {} };
    await db.collection('_tenant_vault').doc('store').set({
      data: JSON.stringify(storeData),
      updatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('[tenantVault] LOUD ERROR: Failed to persist vault to Firestore:', err?.message || err);
  }
}

/**
 * Returns true if running in a production or Netlify environment.
 */
export function isProductionEnvironment(): boolean {
  return (
    process.env.NODE_ENV === 'production' ||
    process.env.NETLIFY === 'true' ||
    process.env.CONTEXT === 'production' ||
    process.env.DEPLOY_ENV === 'production'
  );
}

/**
 * Determines a writeable file path for persisting the secure vault on disk.
 */
function getTargetDataFile(): { dir: string; file: string } {
  try {
    if (!fs.existsSync(PRIMARY_DATA_DIR)) {
      fs.mkdirSync(PRIMARY_DATA_DIR, { recursive: true });
    }
    // Test write permission on primary path
    const testFile = path.join(PRIMARY_DATA_DIR, '.write_test');
    fs.writeFileSync(testFile, 'ok', 'utf-8');
    fs.unlinkSync(testFile);
    return { dir: PRIMARY_DATA_DIR, file: PRIMARY_DATA_FILE };
  } catch {
    // Read-only filesystem (e.g. AWS Lambda / Netlify root), use /tmp
    try {
      if (!fs.existsSync(FALLBACK_DATA_DIR)) {
        fs.mkdirSync(FALLBACK_DATA_DIR, { recursive: true });
      }
      return { dir: FALLBACK_DATA_DIR, file: FALLBACK_DATA_FILE };
    } catch {
      return { dir: '/tmp', file: path.join('/tmp', 'tenant_vault.json') };
    }
  }
}

/**
 * Loads vault store from disk into memoryStore. Always checks disk for latest updates.
 */
function loadStore(): LocalVaultStore {
  // Check primary and fallback locations
  const locations = [PRIMARY_DATA_FILE, FALLBACK_DATA_FILE, path.join('/tmp', 'tenant_vault.json')];
  for (const filePath of locations) {
    try {
      if (fs.existsSync(filePath)) {
        const raw = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          memoryStore = {
            vaults: parsed.vaults || {},
            workerBindings: parsed.workerBindings || {},
          };
          return memoryStore;
        }
      }
    } catch (readErr) {
      console.warn(`[tenantVault] Notice reading from ${filePath}:`, readErr);
    }
  }

  if (!memoryStore) {
    memoryStore = { vaults: {}, workerBindings: {} };
  }
  return memoryStore;
}

/**
 * Persists memoryStore to disk.
 */
function persistStore(): void {
  try {
    const { file, dir } = getTargetDataFile();
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const dataToWrite = memoryStore || { vaults: {}, workerBindings: {} };
    fs.writeFileSync(file, JSON.stringify(dataToWrite, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[tenantVault] Could not persist vault store to disk:', err);
  }
}

function isTestRecord(v: Partial<TenantVaultRecord> | null | undefined): boolean {
  if (!v) return false;
  const email = (v.ownerEmail || '').toLowerCase();
  const biz = (v.businessId || '').toLowerCase();
  const uid = (v.ownerUid || '').toLowerCase();
  return (
    email.endsWith('@example.com') ||
    email.includes('lifecycle_test') ||
    email.includes('test_') ||
    biz.startsWith('biz_matrix_') ||
    biz.startsWith('biz_e2e_') ||
    biz.startsWith('biz_iso_') ||
    biz.startsWith('biz_lifecycle_') ||
    biz.includes('test') ||
    uid.startsWith('owner_matrix_') ||
    uid.startsWith('owner_e2e_') ||
    uid.startsWith('owner_life') ||
    uid.startsWith('owner_a') ||
    uid.startsWith('owner_b')
  );
}

/**
 * Retrieves the secure tenant vault document for a specific businessId, ownerUid, or ownerEmail synchronously.
 * Never exposes raw tokens to client.
 */
export function getTenantVaultSync(
  businessId: string,
  ownerUid?: string,
  ownerEmail?: string
): TenantVaultRecord | null {
  const store = loadStore();
  const isCallerTest = isTestRecord({ businessId, ownerUid, ownerEmail });

  // 1. If ownerUid is explicitly provided, look up this user's vault
  if (ownerUid) {
    if (store.vaults[`user_${ownerUid}`] && store.vaults[`user_${ownerUid}`].encryptedRefreshToken) {
      return store.vaults[`user_${ownerUid}`];
    }
    if (store.vaults[ownerUid] && store.vaults[ownerUid].encryptedRefreshToken) {
      return store.vaults[ownerUid];
    }
    if (businessId && store.vaults[businessId] && store.vaults[businessId].ownerUid === ownerUid && store.vaults[businessId].encryptedRefreshToken) {
      return store.vaults[businessId];
    }
    // Search by matching ownerUid attribute
    const matchByUid = Object.values(store.vaults).find(
      (v) => v && v.ownerUid === ownerUid && Boolean(v.encryptedRefreshToken)
    );
    if (matchByUid) {
      return matchByUid;
    }
  }

  // 2. Lookup by ownerEmail if provided (supports cross-device / different Chrome profiles)
  if (ownerEmail) {
    const cleanEmail = ownerEmail.trim().toLowerCase();
    const matchByEmail = Object.values(store.vaults).find(
      (v) => v && v.ownerEmail && v.ownerEmail.trim().toLowerCase() === cleanEmail && Boolean(v.encryptedRefreshToken)
    );
    if (matchByEmail) {
      return matchByEmail;
    }
  }

  // 3. Direct key lookup by businessId
  if (businessId && store.vaults[businessId] && store.vaults[businessId].encryptedRefreshToken) {
    return store.vaults[businessId];
  }

  // 4. Fallback search by businessId
  if (businessId) {
    const matchByBiz = Object.values(store.vaults).find(
      (v) => v && v.businessId === businessId && Boolean(v.encryptedRefreshToken)
    );
    if (matchByBiz) {
      return matchByBiz;
    }
  }

  // 5. If caller is a test runner, do not fall back to production vault
  if (isCallerTest) {
    if (ownerUid && store.vaults[`user_${ownerUid}`]) return store.vaults[`user_${ownerUid}`];
    if (businessId && store.vaults[businessId]) return store.vaults[businessId];
    return null;
  }

  // 6. Shared Single-Cafe Resolution for real users:
  // "ye sirf single user / single cafe kai liye hai aur jo bhi google drive connect hogi woh sabko dikhe gi chahe koi bhi email login kare"
  if (store.vaults[NEXTGEN_CAFE_BUSINESS_ID] && store.vaults[NEXTGEN_CAFE_BUSINESS_ID].encryptedRefreshToken && !isTestRecord(store.vaults[NEXTGEN_CAFE_BUSINESS_ID])) {
    return store.vaults[NEXTGEN_CAFE_BUSINESS_ID];
  }

  const realConnectedVault = Object.values(store.vaults).find(
    (v) => v && Boolean(v.encryptedRefreshToken) && !isTestRecord(v)
  );
  if (realConnectedVault) {
    return realConnectedVault;
  }

  // Fallback to existing unconfigured vault if available
  if (ownerUid && store.vaults[`user_${ownerUid}`]) {
    return store.vaults[`user_${ownerUid}`];
  }
  if (businessId && store.vaults[businessId]) {
    return store.vaults[businessId];
  }
  if (store.vaults[NEXTGEN_CAFE_BUSINESS_ID] && !isTestRecord(store.vaults[NEXTGEN_CAFE_BUSINESS_ID])) {
    return store.vaults[NEXTGEN_CAFE_BUSINESS_ID];
  }

  return null;
}

/**
 * Retrieves the secure tenant vault document for a specific businessId and/or ownerUid.
 * Never exposes raw tokens to client.
 */
export async function getTenantVault(
  businessId: string,
  ownerUid?: string,
  ownerEmail?: string
): Promise<TenantVaultRecord | null> {
  await ensureVaultHydrated();
  return getTenantVaultSync(businessId, ownerUid, ownerEmail);
}

/**
 * Creates or updates the secure tenant vault record.
 */
export async function saveTenantVault(
  record: {
    businessId: string;
    ownerUid?: string;
    encryptedRefreshToken?: string | null;
    driveFolderId?: string | null;
    driveFileId?: string | null;
    businessName?: string;
    ownerEmail?: string;
    customClientId?: string | null;
    encryptedClientSecret?: string | null;
  }
): Promise<TenantVaultRecord> {
  await ensureVaultHydrated();
  const store = loadStore();
  const isTest = isTestRecord(record);
  const primaryKey = record.businessId || (record.ownerUid ? `user_${record.ownerUid}` : NEXTGEN_CAFE_BUSINESS_ID);
  const existing =
    store.vaults[primaryKey] ||
    (record.ownerUid ? store.vaults[`user_${record.ownerUid}`] : null) ||
    (!isTest ? store.vaults[NEXTGEN_CAFE_BUSINESS_ID] : null) ||
    (record.ownerUid ? Object.values(store.vaults).find((v) => v && v.ownerUid === record.ownerUid) : null) ||
    (record.ownerEmail ? Object.values(store.vaults).find((v) => v && v.ownerEmail && v.ownerEmail.toLowerCase() === record.ownerEmail!.toLowerCase()) : null);

  const updatedRecord: TenantVaultRecord = {
    businessId: primaryKey,
    ownerUid: record.ownerUid !== undefined ? record.ownerUid : (existing?.ownerUid || ''),
    encryptedRefreshToken: (() => {
      if (record.encryptedRefreshToken === null) {
        return null;
      }
      if (record.encryptedRefreshToken) {
        return record.encryptedRefreshToken;
      }
      return existing?.encryptedRefreshToken ?? null;
    })(),
    driveFolderId:
      record.driveFolderId !== undefined
        ? record.driveFolderId
        : (existing?.driveFolderId ?? null),
    driveFileId:
      record.driveFileId !== undefined
        ? record.driveFileId
        : (existing?.driveFileId ?? null),
    updatedAt: new Date().toISOString(),
    businessName: record.businessName || existing?.businessName || 'NEXT GEN GAMING CAFE',
    ownerEmail: record.ownerEmail !== undefined ? record.ownerEmail : (existing?.ownerEmail || ''),
    customClientId:
      record.customClientId !== undefined
        ? record.customClientId
        : (existing?.customClientId ?? null),
    encryptedClientSecret:
      record.encryptedClientSecret !== undefined
        ? record.encryptedClientSecret
        : (existing?.encryptedClientSecret ?? null),
  };

  store.vaults[primaryKey] = updatedRecord;

  // Only sync to shared cafe vault if this is NOT an automated isolated test record
  if (!isTest) {
    store.vaults[NEXTGEN_CAFE_BUSINESS_ID] = {
      ...updatedRecord,
      businessId: NEXTGEN_CAFE_BUSINESS_ID,
    };
  }

  // If explicit disconnect (null token), synchronize disconnect across real vault records
  if (record.encryptedRefreshToken === null) {
    if (!isTest) {
      if (store.vaults[NEXTGEN_CAFE_BUSINESS_ID]) {
        store.vaults[NEXTGEN_CAFE_BUSINESS_ID].encryptedRefreshToken = null;
        store.vaults[NEXTGEN_CAFE_BUSINESS_ID].driveFolderId = null;
        store.vaults[NEXTGEN_CAFE_BUSINESS_ID].driveFileId = null;
      }
      for (const key of Object.keys(store.vaults)) {
        if (store.vaults[key] && !isTestRecord(store.vaults[key])) {
          store.vaults[key].encryptedRefreshToken = null;
          store.vaults[key].driveFolderId = null;
          store.vaults[key].driveFileId = null;
        }
      }
    }
  }

  // Also index by user_${ownerUid} for consistent UID lookup
  if (updatedRecord.ownerUid) {
    store.vaults[`user_${updatedRecord.ownerUid}`] = updatedRecord;
  }
  // Also preserve under previous businessId alias if different
  if (existing?.businessId && existing.businessId !== primaryKey) {
    store.vaults[existing.businessId] = updatedRecord;
  }

  persistStore();
  await persistRemote();

  return updatedRecord;
}

/**
 * Deletes or clears a tenant vault.
 */
export async function deleteTenantVault(businessId: string, ownerUid?: string): Promise<void> {
  await ensureVaultHydrated();
  const store = loadStore();
  const isTest = isTestRecord({ businessId, ownerUid });
  if (businessId) delete store.vaults[businessId];
  if (ownerUid) {
    delete store.vaults[ownerUid];
    delete store.vaults[`user_${ownerUid}`];
  }
  if (!isTest) {
    if (store.vaults[NEXTGEN_CAFE_BUSINESS_ID]) {
      delete store.vaults[NEXTGEN_CAFE_BUSINESS_ID];
    }
    for (const k of Object.keys(store.vaults)) {
      if (store.vaults[k] && !isTestRecord(store.vaults[k])) {
        store.vaults[k].encryptedRefreshToken = null;
        store.vaults[k].driveFolderId = null;
        store.vaults[k].driveFileId = null;
      }
    }
  }
  persistStore();
  await persistRemote();
}

/**
 * Retrieves the server-authoritative worker binding record by workerUid.
 */
export async function getWorkerBinding(
  workerUid: string
): Promise<WorkerBindingRecord | null> {
  if (!workerUid) return null;
  await ensureVaultHydrated();
  const store = loadStore();

  if (store.workerBindings[workerUid]) {
    return store.workerBindings[workerUid];
  }

  // Check Firebase Auth custom claims if admin credentials are available
  if (hasAdminCredentials()) {
    try {
      const auth = getAdminAuth();
      const userRecord = await auth.getUser(workerUid);
      const claims = userRecord.customClaims;
      if (claims?.businessId && claims?.role === 'worker') {
        const binding: WorkerBindingRecord = {
          workerUid,
          workerEmail: (userRecord.email || '').toLowerCase(),
          workerName: userRecord.displayName || 'Staff Member',
          businessId: String(claims.businessId),
          ownerUid: claims.ownerUid ? String(claims.ownerUid) : '',
          role: 'worker',
          createdAt: userRecord.metadata.creationTime || new Date().toISOString(),
        };
        store.workerBindings[workerUid] = binding;
        persistStore();
        await persistRemote();
        return binding;
      }
    } catch {
      // User not found or auth error
    }
  }

  return null;
}

/**
 * Retrieves a worker binding record by email address.
 */
export async function getWorkerBindingByEmail(
  email: string
): Promise<WorkerBindingRecord | null> {
  if (!email) return null;
  await ensureVaultHydrated();
  const cleanEmail = email.toLowerCase().trim();
  const store = loadStore();

  for (const binding of Object.values(store.workerBindings)) {
    if (binding.workerEmail.toLowerCase() === cleanEmail) {
      return binding;
    }
  }

  // Check Firebase Auth if admin credentials are available
  if (hasAdminCredentials()) {
    try {
      const auth = getAdminAuth();
      const userRecord = await auth.getUserByEmail(cleanEmail);
      const claims = userRecord.customClaims;
      if (claims?.businessId && claims?.role === 'worker') {
        const binding: WorkerBindingRecord = {
          workerUid: userRecord.uid,
          workerEmail: cleanEmail,
          workerName: userRecord.displayName || 'Staff Member',
          businessId: String(claims.businessId),
          ownerUid: claims.ownerUid ? String(claims.ownerUid) : '',
          role: 'worker',
          createdAt: userRecord.metadata.creationTime || new Date().toISOString(),
        };
        store.workerBindings[userRecord.uid] = binding;
        persistStore();
        await persistRemote();
        return binding;
      }
    } catch {
      // User not found
    }
  }

  return null;
}

/**
 * Retrieves all workers bound to a specific businessId.
 */
export async function getWorkersByBusiness(
  businessId: string
): Promise<WorkerBindingRecord[]> {
  if (!businessId) return [];
  await ensureVaultHydrated();
  const store = loadStore();
  return Object.values(store.workerBindings).filter(
    (b) => b.businessId === businessId || businessId === NEXTGEN_CAFE_BUSINESS_ID
  );
}

/**
 * Binds a worker account to a businessId authoritatively on the server.
 */
export async function saveWorkerBinding(
  binding: WorkerBindingRecord
): Promise<void> {
  await ensureVaultHydrated();
  const store = loadStore();
  store.workerBindings[binding.workerUid] = binding;
  persistStore();
  await persistRemote();
}

/**
 * Removes a worker binding.
 */
export async function deleteWorkerBinding(workerUid: string): Promise<void> {
  await ensureVaultHydrated();
  const store = loadStore();
  delete store.workerBindings[workerUid];
  persistStore();
  await persistRemote();
}
