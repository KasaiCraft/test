export const NEXTGEN_CAFE_BUSINESS_ID = 'nextgen_gaming_cafe';
export const MAX_WORKERS_ALLOWED = 5;

export type UserRole = 'admin' | 'owner' | 'worker';

export interface TenantVaultRecord {
  businessId: string;
  ownerUid: string;
  encryptedRefreshToken: string | null;
  driveFolderId: string | null;
  driveFileId: string | null;
  updatedAt: string;
  businessName?: string;
  ownerEmail?: string;
  customClientId?: string | null;
  encryptedClientSecret?: string | null;
}

export interface WorkerBindingRecord {
  workerUid: string;
  workerEmail: string;
  workerName: string;
  businessId: string;
  ownerUid: string;
  role: 'worker';
  createdAt: string;
}

export interface VerifiedTenantContext {
  uid: string;
  email: string;
  role: UserRole;
  businessId: string;
  isOwner: boolean;
  isWorker: boolean;
  businessName?: string;
  ownerUid?: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  code?: string;
}

export interface HandlerEvent {
  rawUrl?: string;
  path?: string;
  httpMethod: string;
  headers: Record<string, string | undefined>;
  queryStringParameters?: Record<string, string | undefined> | null;
  body: string | null;
  isBase64Encoded?: boolean;
}

export interface HandlerResponse {
  statusCode: number;
  headers?: Record<string, string | number | boolean>;
  body?: string;
  isBase64Encoded?: boolean;
}

export type Handler = (event: HandlerEvent, context?: any) => Promise<HandlerResponse>;

