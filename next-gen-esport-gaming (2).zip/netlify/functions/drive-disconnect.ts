import {
  handleCorsPreflight,
  requireOwner,
  successResponse,
  errorResponse,
  formatAuthErrorResponse,
} from './lib/authMiddleware.ts';
import { decryptToken } from './lib/crypto.ts';
import { getTenantVault, saveTenantVault } from './lib/tenantVault.ts';
import { revokeGoogleToken } from './lib/googleDriveClient.ts';
import { NEXTGEN_CAFE_BUSINESS_ID, Handler, HandlerEvent } from './lib/types.ts';

/**
 * Netlify Function: drive-disconnect
 * Paths:
 *   DELETE /.netlify/functions/drive-disconnect or DELETE /api/drive-disconnect
 *   POST   /.netlify/functions/drive-disconnect or POST   /api/drive-disconnect
 *
 * Disconnects the Owner's Google Drive integration for the verified business.
 * Strictly restricted to users with role === 'owner'.
 * Workers receive 403 FORBIDDEN_OWNER_REQUIRED.
 */
export const handler: Handler = async (event: HandlerEvent) => {
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  if (event.httpMethod !== 'DELETE' && event.httpMethod !== 'POST') {
    return errorResponse('Method Not Allowed', 405, 'METHOD_NOT_ALLOWED');
  }

  try {
    // 1. Authenticate caller and enforce role === 'owner'
    const ownerContext = await requireOwner(event);
    const ownerUid = ownerContext.ownerUid || ownerContext.uid;
    const businessId = ownerContext.businessId || `user_${ownerUid}`;

    // 2. Load tenant vault record strictly for this owner
    const vault = await getTenantVault(businessId, ownerUid);

    // 3. Revoke Google authorization where appropriate
    if (vault?.encryptedRefreshToken) {
      try {
        const refreshToken = decryptToken(vault.encryptedRefreshToken);
        await revokeGoogleToken(refreshToken);
      } catch (revokeErr) {
        console.warn('[drive-disconnect] Revocation warning (proceeding with local disconnection):', revokeErr);
      }
    }

    // 4. Clear Drive credentials and metadata in the user's isolated tenant vault
    await saveTenantVault({
      businessId,
      ownerUid,
      encryptedRefreshToken: null,
      driveFolderId: null,
      driveFileId: null,
    });

    return successResponse({
      isConnected: false,
      businessId,
      disconnectedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('[drive-disconnect] Error:', err);
    return formatAuthErrorResponse(err);
  }
};
