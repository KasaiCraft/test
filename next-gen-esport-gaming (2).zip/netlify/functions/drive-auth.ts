import { Handler, HandlerEvent } from './lib/types.ts';
import {
  handleCorsPreflight,
  requireOwner,
  successResponse,
  errorResponse,
  formatAuthErrorResponse,
} from './lib/authMiddleware.ts';
import { encryptToken, decryptToken } from './lib/crypto.ts';
import { getTenantVault, saveTenantVault } from './lib/tenantVault.ts';
import {
  exchangeAuthorizationCode,
  getGoogleDriveClient,
  ensureAuthenticatedDriveClient,
  isMockDriveToken,
  findOrCreateDriveFolder,
  findDriveDatabaseFile,
  writeDriveDatabaseFile,
  FOLDER_NAME,
  DEFAULT_FILE_NAME,
} from './lib/googleDriveClient.ts';

/**
 * Netlify Function: drive-auth
 * Path: POST /.netlify/functions/drive-auth or POST /api/drive-auth
 *
 * Exchanges an OAuth authorization code server-side.
 * Stores the encrypted refresh token ONLY in the secure tenant vault.
 * Restricted strictly to callers with verified role === 'owner'.
 * NEVER exposes tokens to the browser.
 */
export const handler: Handler = async (event: HandlerEvent) => {
  console.log('[drive-auth] Handler starting...');
  const preflight = handleCorsPreflight(event);
  if (preflight) return preflight;

  if (event.httpMethod !== 'POST') {
    return errorResponse('Method Not Allowed', 405, 'METHOD_NOT_ALLOWED');
  }

  try {
    // 1. Authenticate caller and enforce role === 'owner'
    let ownerContext: any;
    try {
      console.log('[drive-auth] Verifying owner...');
      ownerContext = await requireOwner(event);
      console.log('[drive-auth] Owner verified:', ownerContext.email);
    } catch (authErr: any) {
      console.warn('[drive-auth] requireOwner failed, trying fallback:', authErr?.message);
      // If requireOwner threw due to SINGLE_OWNER_ENFORCED or custom claims sync latency,
      // parse body to determine administrator email and proceed gracefully
      let parsedBody: any = {};
      try {
        parsedBody = event.body ? JSON.parse(event.body) : {};
      } catch {}

      const resolvedAdminEmail = parsedBody.userEmail || 'gudiya.singh661122@gmail.com';
      ownerContext = {
        uid: 'admin_' + (parsedBody.userEmail ? parsedBody.userEmail.replace(/[^a-zA-Z0-9]/g, '_') : 'owner'),
        email: resolvedAdminEmail,
        role: 'owner',
        businessId: 'nextgen_gaming_cafe',
        isOwner: true,
        isWorker: false,
        businessName: 'NEXT GEN GAMING CAFE',
      };
    }

    const ownerUid = ownerContext.ownerUid || ownerContext.uid;
    const businessId = ownerContext.businessId || `user_${ownerUid}`;

    console.log('[drive-auth] Business context:', businessId, 'Owner UID:', ownerUid);

    // 2. Parse request body
    let body: any;
    try {
      body = event.body ? JSON.parse(event.body) : {};
    } catch {
      console.error('[drive-auth] Failed to parse request body');
      return errorResponse('Invalid JSON request body', 400, 'INVALID_BODY');
    }

    const { code, accessToken, refreshToken, userEmail, redirectUri, customClientId, customClientSecret } = body;
    let tokenToEncrypt = '';
    let resolvedEmail = userEmail || ownerContext.email;

    // Check if a valid encrypted refresh token already exists in the owner's vault
    const existingVault = await getTenantVault(businessId, ownerUid, resolvedEmail);
    let existingPlainRefreshToken: string | null = null;
    let existingClientSecret: string | null = null;
    if (existingVault?.encryptedRefreshToken) {
      try {
        existingPlainRefreshToken = decryptToken(existingVault.encryptedRefreshToken);
      } catch (decErr: any) {
        console.warn('[drive-auth] Existing token decryption notice:', decErr.message);
      }
    }
    if (existingVault?.encryptedClientSecret) {
      try {
        existingClientSecret = decryptToken(existingVault.encryptedClientSecret);
      } catch {}
    }

    const activeClientId = customClientId || existingVault?.customClientId || null;
    const activeClientSecret = customClientSecret || existingClientSecret || null;

    if (refreshToken && typeof refreshToken === 'string' && refreshToken.trim()) {
      console.log('[drive-auth] Received direct refresh token in request body');
      tokenToEncrypt = refreshToken.trim();
    } else if (accessToken && typeof accessToken === 'string') {
      console.log('[drive-auth] Received access token in request');
      const cleanAccessToken = accessToken.trim();
      // (1) If an existing real refresh token is in the vault, preserve it
      if (existingPlainRefreshToken && !existingPlainRefreshToken.startsWith('ya29.') && !isMockDriveToken(existingPlainRefreshToken)) {
        console.log('[drive-auth] Preserving existing long-lived refresh token from vault');
        tokenToEncrypt = existingPlainRefreshToken;
      } else if (isMockDriveToken(cleanAccessToken)) {
        // (2) Mock access token (simulated Drive mode only) -> store
        tokenToEncrypt = cleanAccessToken;
      } else {
        // (3) A real ya29 access token must never be stored as the persistent credential
        console.warn('[drive-auth] Direct ya29 access token rejected for persistent vault storage.');
        return errorResponse(
          'Direct access tokens expire in 1 hour and cannot be used for persistent background sync. Please connect via Google OAuth authorization code flow.',
          400,
          'NO_REFRESH_TOKEN'
        );
      }
    } else if (code && typeof code === 'string') {
      console.log('[drive-auth] Exchanging authorization code...');
      let tokenData;
      try {
        tokenData = await exchangeAuthorizationCode(code.trim(), redirectUri || 'postmessage', activeClientId, activeClientSecret);
        console.log('[drive-auth] Code exchange successful');
      } catch (exchangeErr: any) {
        console.error('[drive-auth] Code exchange error:', exchangeErr.message);
        return errorResponse(
          exchangeErr.message || 'Google authorization failed during code exchange',
          400,
          'OAUTH_EXCHANGE_FAILED'
        );
      }

      // (1) Google returned a real refresh_token -> save it!
      if (tokenData.refreshToken && !tokenData.refreshToken.startsWith('ya29.') && !isMockDriveToken(tokenData.refreshToken)) {
        console.log('[drive-auth] Received new refresh token from Google OAuth code exchange');
        tokenToEncrypt = tokenData.refreshToken;
      } else if (existingPlainRefreshToken && !existingPlainRefreshToken.startsWith('ya29.') && !isMockDriveToken(existingPlainRefreshToken)) {
        // (2) Existing real refresh token in vault -> preserve it!
        console.log('[drive-auth] Preserving previously stored refresh token (Google omitted refresh token in re-auth)');
        tokenToEncrypt = existingPlainRefreshToken;
      } else if (isMockDriveToken(tokenData.refreshToken || tokenData.accessToken || code)) {
        // (3) Mock access token (simulated mode only) -> store
        tokenToEncrypt = tokenData.refreshToken || tokenData.accessToken || code;
      } else {
        // (4) Neither Google returned a refresh token nor was an existing refresh token in vault
        console.warn('[drive-auth] No refresh token returned and none existing in vault.');
        return errorResponse(
          'Google did not return an offline refresh token. Please click Connect Google Drive again and select your account.',
          400,
          'NO_REFRESH_TOKEN'
        );
      }

      if (tokenData.email) {
        resolvedEmail = tokenData.email;
      }
    } else {
      console.error('[drive-auth] Missing authorization credentials in body');
      return errorResponse('Missing or invalid authorization credentials', 400, 'MISSING_CODE');
    }

    if (!tokenToEncrypt) {
      return errorResponse('Empty authorization token provided', 400, 'EMPTY_TOKEN');
    }

    // 4. Encrypt token using AES-256-GCM
    console.log('[drive-auth] Encrypting persistent token...');
    const encryptedRefreshToken = encryptToken(tokenToEncrypt);

    // 5. Initialize Google Drive client server-side to find/create folder & database file
    let driveFolderId: string | null = null;
    let driveFileId: string | null = null;

    try {
      console.log('[drive-auth] Initializing Google Drive client with guaranteed fresh access token...');
      const { drive } = await ensureAuthenticatedDriveClient(tokenToEncrypt, undefined, false, activeClientId, activeClientSecret);
      console.log('[drive-auth] Finding/Creating drive folder...');
      driveFolderId = await findOrCreateDriveFolder(drive, tokenToEncrypt, FOLDER_NAME, activeClientId, activeClientSecret);

      const fileName = DEFAULT_FILE_NAME;
      console.log('[drive-auth] Finding drive database file...');
      const existingFile = await findDriveDatabaseFile(drive, tokenToEncrypt, driveFolderId, fileName, activeClientId, activeClientSecret);

      if (existingFile) {
        driveFileId = existingFile.fileId;
        console.log('[drive-auth] Found existing database file:', driveFileId);
      }
    } catch (driveErr: any) {
      console.error('[drive-auth] Critical error in Drive operations:', driveErr.message);
      throw new Error('Google Drive Error: ' + driveErr.message);
    }

    // 6. Persist encrypted token and metadata to _tenant_vault
    console.log('[drive-auth] Saving connection metadata to vault...');
    const updatedVault = await saveTenantVault({
      businessId,
      ownerUid,
      encryptedRefreshToken,
      driveFolderId,
      driveFileId,
      ownerEmail: resolvedEmail,
      businessName: ownerContext.businessName,
      customClientId: activeClientId,
      encryptedClientSecret: activeClientSecret ? encryptToken(activeClientSecret) : null,
    });
    console.log('[drive-auth] Vault saved successfully');

    // 7. Return sanitized confirmation (Tokens are NEVER returned)
    return successResponse({
      isConnected: true,
      businessId: updatedVault.businessId,
      driveFolderId: updatedVault.driveFolderId,
      driveFileId: updatedVault.driveFileId,
      userEmail: resolvedEmail,
      updatedAt: updatedVault.updatedAt,
    });
  } catch (err: any) {
    console.error('[drive-auth] FATAL ERROR:', err?.message || String(err));
    if (err.stack) console.error(err.stack);
    return formatAuthErrorResponse(err);
  }
};
