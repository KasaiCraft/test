import fs from 'fs';
import path from 'path';
import type { Request, Response } from 'express';
import { getTenantVault, getTenantVaultSync, saveTenantVault } from '../netlify/functions/lib/tenantVault.ts';
import { decryptToken, encryptToken } from '../netlify/functions/lib/crypto.ts';
import {
  getGoogleDriveClient,
  ensureAuthenticatedDriveClient,
  findOrCreateDriveFolder,
  findDriveDatabaseFile,
  readDriveDatabaseFile,
  writeDriveDatabaseFile,
  FOLDER_NAME,
  DEFAULT_FILE_NAME,
} from '../netlify/functions/lib/googleDriveClient.ts';
import {
  cafeDatabaseToXlsxBuffer,
  xlsxBufferToCafeDatabase,
} from '../netlify/functions/lib/xlsxDatabase.ts';

export const NEXTGEN_CAFE_BUSINESS_ID = 'nextgen_gaming_cafe';
export const FIXED_ADMIN_CODE = '756569';

export const COLLECTIONS = [
  'consoles',
  'sessions',
  'customers',
  'rentalItems',
  'rentalRecords',
  'cafeteriaItems',
  'cafeteriaOrders',
  'cafeteriaStockLogs',
  'vouchers',
  'voucherUsages',
  'buySellItems',
  'buySellTransactions',
  'repairRecords',
  'payments',
  'notices',
  'users',
] as const;

export type CollectionName = typeof COLLECTIONS[number];

export interface MutationOptions {
  action?: 'save' | 'delete' | 'reset' | 'import';
  deleteInfo?: {
    collection: CollectionName | string;
    id: string;
  };
  forceOverwrite?: boolean;
}

export function createDefaultDatabase(
  businessId = NEXTGEN_CAFE_BUSINESS_ID,
  ownerId = 'single_owner_id',
  ownerEmail = 'owner@nextgencafe.com'
) {
  const now = new Date().toISOString();
  return {
    version: 1,
    businessId,
    ownerId,
    ownerEmail,
    lastModified: now,
    settings: {
      businessId,
      ownerId,
      ownerEmail,
      cafeName: 'Next Gen Gaming Cafe',
      tagline: 'Gaming Cafe Management System',
      phone: '',
      email: ownerEmail,
      address: '',
      currencySymbol: '₹',
      taxRatePercent: 0,
      minGamingTimeMinutes: 15,
      roundingIncrementMinutes: 5,
      autoSyncGoogleDrive: true,
      googleDriveSyncIntervalMinutes: 2,
      lastSyncedAt: now,
      adminAccessCode: FIXED_ADMIN_CODE,
      staffAccessCode: '',
      googleDriveFolder: FOLDER_NAME,
      googleDriveFile: DEFAULT_FILE_NAME,
    },
    users: [
      {
        id: ownerId,
        name: 'Admin Owner',
        email: ownerEmail,
        role: 'admin',
        businessId,
        ownerId,
        pin: FIXED_ADMIN_CODE,
        accessCode: FIXED_ADMIN_CODE,
        createdAt: now,
        status: 'active',
      },
    ],
    consoles: [],
    sessions: [],
    customers: [],
    rentalItems: [],
    rentalRecords: [],
    cafeteriaItems: [],
    cafeteriaOrders: [],
    cafeteriaStockLogs: [],
    vouchers: [],
    voucherUsages: [],
    buySellItems: [],
    buySellTransactions: [],
    repairRecords: [],
    payments: [],
    notices: [],
  };
}

interface TenantSession {
  businessId: string;
  ownerUid: string;
  inMemoryDb: any | null;
  revision: number;
  sseClients: Set<Response>;
  writeQueue: Promise<any>;
  isDriveConnected: boolean;
  recentlyDeletedIds: Set<string>;
  driveFolderId: string | null;
  driveFileId: string | null;
  driveOwnerEmail: string | null;
  isInitializingDrive: boolean;
}

class CafeDatabaseManager {
  private tenants: Map<string, TenantSession> = new Map();

  constructor() {
    this.startHeartbeat();
  }

  private getOrCreateTenant(businessId = NEXTGEN_CAFE_BUSINESS_ID, ownerUid?: string): TenantSession {
    const effectiveBiz = businessId || (ownerUid ? `user_${ownerUid}` : NEXTGEN_CAFE_BUSINESS_ID);
    let session = this.tenants.get(effectiveBiz);
    if (!session) {
      const resolvedOwnerUid = ownerUid || (effectiveBiz.startsWith('user_') ? effectiveBiz.replace(/^user_/, '') : '');
      const vault = getTenantVaultSync(effectiveBiz, resolvedOwnerUid);
      const isConnected = Boolean(vault && vault.encryptedRefreshToken);
      session = {
        businessId: effectiveBiz,
        ownerUid: resolvedOwnerUid,
        inMemoryDb: null,
        revision: 1,
        sseClients: new Set<Response>(),
        writeQueue: Promise.resolve(),
        isDriveConnected: isConnected,
        recentlyDeletedIds: new Set<string>(),
        driveFolderId: vault?.driveFolderId || null,
        driveFileId: vault?.driveFileId || null,
        driveOwnerEmail: vault?.ownerEmail || null,
        isInitializingDrive: false,
      };
      this.tenants.set(effectiveBiz, session);
    } else {
      if (ownerUid && !session.ownerUid) {
        session.ownerUid = ownerUid;
      }
      // Re-verify against vault if session status does not match persistent vault
      const vault = getTenantVaultSync(session.businessId, session.ownerUid);
      if (vault && vault.encryptedRefreshToken) {
        session.isDriveConnected = true;
        if (!session.driveFolderId) session.driveFolderId = vault.driveFolderId || null;
        if (!session.driveFileId) session.driveFileId = vault.driveFileId || null;
        if (!session.driveOwnerEmail) session.driveOwnerEmail = vault.ownerEmail || null;
      }
    }
    return session;
  }

  private startHeartbeat() {
    const timer = setInterval(() => {
      for (const tenant of this.tenants.values()) {
        for (const client of tenant.sseClients) {
          try {
            client.write(': ping\n\n');
          } catch {
            tenant.sseClients.delete(client);
          }
        }
      }
    }, 15000);
    if (timer && typeof timer.unref === 'function') {
      timer.unref();
    }
  }

  /**
   * Synchronizes state directly from Google Drive for a specific tenant/owner.
   * Google Drive is the SINGLE AUTHORITATIVE SOURCE OF TRUTH.
   */
  public async syncFromGoogleDrive(
    businessId = NEXTGEN_CAFE_BUSINESS_ID,
    ownerUid?: string
  ): Promise<{ isConnected: boolean; data: any }> {
    const session = this.getOrCreateTenant(businessId, ownerUid);

    if (session.isInitializingDrive) {
      return { isConnected: session.isDriveConnected, data: session.inMemoryDb };
    }

    session.isInitializingDrive = true;
    try {
      const vault = await getTenantVault(session.businessId, session.ownerUid, session.driveOwnerEmail || undefined);
      if (!vault || !vault.encryptedRefreshToken) {
        session.isDriveConnected = false;
        session.inMemoryDb = null;
        session.driveFolderId = null;
        session.driveFileId = null;
        session.driveOwnerEmail = null;
        return { isConnected: false, data: null };
      }

      session.driveOwnerEmail = vault.ownerEmail || null;
      let refreshToken: string;
      try {
        refreshToken = decryptToken(vault.encryptedRefreshToken);
      } catch (e: any) {
        console.warn(`[dbManager] [Diagnostic] Token decryption notice for tenant ${session.businessId}:`, e.message);
        // Do NOT disconnect Drive on transient decryption issues. Keep isDriveConnected intact.
        return { isConnected: session.isDriveConnected, data: session.inMemoryDb };
      }

      let customClientSecret: string | null = null;
      if (vault.encryptedClientSecret) {
        try {
          customClientSecret = decryptToken(vault.encryptedClientSecret);
        } catch {}
      }

      // Automatically refresh Google access token via stored refresh token before Drive calls
      const { drive } = await ensureAuthenticatedDriveClient(
        refreshToken,
        async (newRefreshToken) => {
          console.log(`[dbManager] Updating rotated refresh token for tenant ${session.businessId}`);
          await saveTenantVault({
            businessId: session.businessId,
            ownerUid: session.ownerUid,
            encryptedRefreshToken: encryptToken(newRefreshToken),
          });
        },
        false,
        vault.customClientId,
        customClientSecret
      );
      const folderId = vault.driveFolderId || (await findOrCreateDriveFolder(drive, refreshToken, FOLDER_NAME, vault.customClientId, customClientSecret));
      session.driveFolderId = folderId;

      const found = await findDriveDatabaseFile(drive, refreshToken, folderId, DEFAULT_FILE_NAME, vault.customClientId, customClientSecret);

      if (found) {
        session.driveFileId = found.fileId;
        const remoteData = await readDriveDatabaseFile(drive, refreshToken, found.fileId, found.fileName, vault.customClientId, customClientSecret);
        if (remoteData) {
          const normalized = this.normalizeDatabase(remoteData, session.businessId);
          session.inMemoryDb = normalized;
          session.isDriveConnected = true;
          session.revision++;

          // If legacy file was found, migrate to NextGenGaming_Cafe_Data.xlsx
          if (found.isLegacyJson || found.fileName !== DEFAULT_FILE_NAME) {
            try {
              const writeRes = await writeDriveDatabaseFile(
                drive,
                refreshToken,
                folderId,
                DEFAULT_FILE_NAME,
                null,
                normalized,
                vault.customClientId,
                customClientSecret
              );
              session.driveFileId = writeRes.fileId;
              await saveTenantVault({
                businessId: session.businessId,
                ownerUid: session.ownerUid,
                driveFolderId: folderId,
                driveFileId: writeRes.fileId,
              });
            } catch (migErr: any) {
              console.warn('[dbManager] Migration write warning:', migErr.message);
            }
          }

          this.broadcastUpdate(session, normalized);
          return { isConnected: true, data: normalized };
        }
      }

      // If file doesn't exist yet on Drive, initialize default template and persist to Google Drive
      const freshDb = createDefaultDatabase(session.businessId, session.ownerUid, session.driveOwnerEmail || undefined);
      const createRes = await writeDriveDatabaseFile(
        drive,
        refreshToken,
        folderId,
        DEFAULT_FILE_NAME,
        null,
        freshDb,
        vault.customClientId,
        customClientSecret
      );
      session.driveFileId = createRes.fileId;
      session.inMemoryDb = freshDb;
      session.isDriveConnected = true;
      session.revision++;

      await saveTenantVault({
        businessId: session.businessId,
        ownerUid: session.ownerUid,
        driveFolderId: folderId,
        driveFileId: createRes.fileId,
      });

      this.broadcastUpdate(session, freshDb);
      return { isConnected: true, data: freshDb };
    } catch (err: any) {
      console.warn(`[dbManager] Drive synchronization notice for tenant ${session.businessId}:`, (err as any)?.message || err);
      // Strictly preserve active connection state - NEVER auto-disconnect unexpectedly!
      session.isDriveConnected = true;
      if (!session.inMemoryDb) {
        session.inMemoryDb = createDefaultDatabase(session.businessId, session.ownerUid, session.driveOwnerEmail || undefined);
      }
      return { isConnected: true, data: session.inMemoryDb };
    } finally {
      session.isInitializingDrive = false;
    }
  }

  public async onDriveConnected(
    businessId = NEXTGEN_CAFE_BUSINESS_ID,
    ownerUid?: string,
    folderId?: string,
    fileId?: string | null
  ) {
    try {
      const session = this.getOrCreateTenant(businessId, ownerUid);
      session.isDriveConnected = true;
      if (folderId) session.driveFolderId = folderId;
      if (fileId) session.driveFileId = fileId;
      
      // Also update all active sessions
      for (const [key, s] of this.tenants.entries()) {
        s.isDriveConnected = true;
        if (folderId) s.driveFolderId = folderId;
        if (fileId) s.driveFileId = fileId;
      }

      await this.syncFromGoogleDrive(session.businessId, session.ownerUid);
    } catch (e: any) {
      console.warn('[dbManager] onDriveConnected error:', e.message);
    }
  }

  public onDriveDisconnected(businessId = NEXTGEN_CAFE_BUSINESS_ID, ownerUid?: string) {
    for (const [key, session] of this.tenants.entries()) {
      session.isDriveConnected = false;
      session.driveFolderId = null;
      session.driveFileId = null;
      session.driveOwnerEmail = null;
      session.inMemoryDb = null;
      session.revision++;
      this.broadcastDisconnect(session);
    }
  }

  private normalizeDatabase(raw: any, businessId = NEXTGEN_CAFE_BUSINESS_ID): any {
    const base = createDefaultDatabase(businessId);
    const result = {
      ...base,
      ...raw,
      businessId,
      settings: {
        ...base.settings,
        ...(raw.settings || {}),
        businessId,
        adminAccessCode: FIXED_ADMIN_CODE,
        googleDriveFolder: FOLDER_NAME,
        googleDriveFile: DEFAULT_FILE_NAME,
      },
    };

    // Ensure all collections exist as arrays
    for (const col of COLLECTIONS) {
      result[col] = Array.isArray(raw[col]) ? raw[col] : [];
    }

    // Ensure admin user exists and has fixed admin code
    let hasAdmin = false;
    result.users = result.users.map((u: any) => {
      if (u && u.role === 'admin') {
        hasAdmin = true;
        return {
          ...u,
          pin: FIXED_ADMIN_CODE,
          accessCode: FIXED_ADMIN_CODE,
        };
      }
      return u;
    });

    if (!hasAdmin) {
      result.users.unshift(base.users[0]);
    }

    result.deletedConsoleIds = Array.isArray(raw.deletedConsoleIds)
      ? raw.deletedConsoleIds
      : (Array.isArray(raw.settings?.deletedConsoleIds) ? raw.settings.deletedConsoleIds : []);

    result.deletedRepairIds = Array.isArray(raw.deletedRepairIds) ? raw.deletedRepairIds : [];
    result.deletedVoucherIds = Array.isArray(raw.deletedVoucherIds) ? raw.deletedVoucherIds : [];
    result.deletedUserIds = Array.isArray(raw.deletedUserIds) ? raw.deletedUserIds : [];

    return result;
  }

  private enqueueWrite<T>(session: TenantSession, task: () => Promise<T>): Promise<T> {
    return new Promise((resolve, reject) => {
      session.writeQueue = session.writeQueue.then(async () => {
        try {
          const result = await task();
          resolve(result);
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  /**
   * Retrieves the current database state for a specific tenant.
   * If Google Drive is not connected, returns isDriveConnected: false.
   */
  public getDatabase(
    businessId = NEXTGEN_CAFE_BUSINESS_ID,
    ownerUid?: string
  ): {
    success: boolean;
    isDriveConnected: boolean;
    data: any;
    revision: number;
    lastModified: string;
    folderName: string;
    fileName: string;
    driveFolderId: string | null;
    driveFileId: string | null;
    ownerEmail: string | null;
    error?: string;
  } {
    const session = this.getOrCreateTenant(businessId, ownerUid);

    // Authoritative check against persistent tenant vault
    const vault = getTenantVaultSync(session.businessId, session.ownerUid, session.driveOwnerEmail || undefined);
    if (vault && vault.encryptedRefreshToken) {
      session.isDriveConnected = true;
      if (!session.driveFolderId && vault.driveFolderId) session.driveFolderId = vault.driveFolderId;
      if (!session.driveFileId && vault.driveFileId) session.driveFileId = vault.driveFileId;
      if (!session.driveOwnerEmail && vault.ownerEmail) session.driveOwnerEmail = vault.ownerEmail;
    }

    if (!session.isDriveConnected) {
      return {
        success: false,
        isDriveConnected: false,
        data: null,
        revision: session.revision,
        lastModified: new Date().toISOString(),
        folderName: FOLDER_NAME,
        fileName: DEFAULT_FILE_NAME,
        driveFolderId: null,
        driveFileId: null,
        ownerEmail: session.driveOwnerEmail,
        error: 'Google Drive is not connected. Business transactions require Google Drive as the permanent storage.',
      };
    }

    return {
      success: true,
      isDriveConnected: true,
      data: session.inMemoryDb ? JSON.parse(JSON.stringify(session.inMemoryDb)) : null,
      revision: session.revision,
      lastModified: session.inMemoryDb?.lastModified || new Date().toISOString(),
      folderName: FOLDER_NAME,
      fileName: DEFAULT_FILE_NAME,
      driveFolderId: session.driveFolderId,
      driveFileId: session.driveFileId,
      ownerEmail: session.driveOwnerEmail,
    };
  }

  /**
   * Authoritative mutation strictly scoped to a single tenant:
   */
  public async applyMutation(
    businessId = NEXTGEN_CAFE_BUSINESS_ID,
    incomingPayload: any,
    options: MutationOptions = {},
    ownerUid?: string
  ): Promise<{ data: any; revision: number; lastModified: string; isDriveConnected: boolean }> {
    const session = this.getOrCreateTenant(businessId, ownerUid);

    return this.enqueueWrite(session, async () => {
      // 1. Verify Drive connection before accepting any write
      const vault = await getTenantVault(session.businessId, session.ownerUid, session.driveOwnerEmail || undefined);
      if (!vault || !vault.encryptedRefreshToken) {
        session.isDriveConnected = false;
        throw new Error(
          'Google Drive is not connected. Saving business data is strictly blocked to prevent unpersisted local data loss. Please connect Google Drive as Admin.'
        );
      }

      const refreshToken = decryptToken(vault.encryptedRefreshToken);
      let customClientSecret: string | null = null;
      if (vault.encryptedClientSecret) {
        try {
          customClientSecret = decryptToken(vault.encryptedClientSecret);
        } catch {}
      }

      let drive: any = null;
      let folderId = vault.driveFolderId;
      try {
        const clientObj = await ensureAuthenticatedDriveClient(
          refreshToken,
          async (newRefreshToken) => {
            await saveTenantVault({
              businessId: session.businessId,
              ownerUid: session.ownerUid,
              encryptedRefreshToken: encryptToken(newRefreshToken),
            });
          },
          false,
          vault.customClientId,
          customClientSecret
        );
        drive = clientObj.drive;
        folderId = vault.driveFolderId || (await findOrCreateDriveFolder(drive, refreshToken, FOLDER_NAME, vault.customClientId, customClientSecret));
        session.driveFolderId = folderId;
      } catch (authErr: any) {
        console.warn('[dbManager] Drive client init notice during mutation (continuing with cached session):', authErr.message);
      }

      // 2. Read latest remote database to guarantee concurrency protection & prevent stale overwrites
      let current: any = null;
      let targetFileId = vault.driveFileId || session.driveFileId;

      if (drive && targetFileId) {
        try {
          current = await readDriveDatabaseFile(drive, refreshToken, targetFileId, DEFAULT_FILE_NAME, vault.customClientId, customClientSecret);
        } catch (e: any) {
          console.warn('[dbManager] Notice reading target file, searching by name:', e.message);
          targetFileId = null;
        }
      }

      if (drive && !current && folderId) {
        try {
          const found = await findDriveDatabaseFile(drive, refreshToken, folderId, DEFAULT_FILE_NAME, vault.customClientId, customClientSecret);
          if (found) {
            targetFileId = found.fileId;
            current = await readDriveDatabaseFile(drive, refreshToken, found.fileId, found.fileName, vault.customClientId, customClientSecret);
          }
        } catch (e: any) {
          console.warn('[dbManager] Search by name notice:', e.message);
        }
      }

      if (!current) {
        current = session.inMemoryDb || createDefaultDatabase(session.businessId, session.ownerUid, session.driveOwnerEmail || undefined);
      }

      current = this.normalizeDatabase(current, session.businessId);

      const incoming = incomingPayload?.database || incomingPayload || {};
      const { action = 'save', deleteInfo, forceOverwrite = false } = options;

      // 3. Apply changes (Reset / Import / Delete / Deep Merge)
      if (forceOverwrite || action === 'reset' || action === 'import') {
        current = this.normalizeDatabase(incoming, session.businessId);
      } else if (action === 'delete' && deleteInfo && deleteInfo.collection && deleteInfo.id) {
        const col = deleteInfo.collection as CollectionName;
        if (Array.isArray(current[col])) {
          current[col] = current[col].filter((item: any) => item && item.id !== deleteInfo.id);

          // Track deletion to prevent resurrection by other terminals sending stale data
          session.recentlyDeletedIds.add(deleteInfo.id);
          setTimeout(() => session.recentlyDeletedIds.delete(deleteInfo.id), 120000);

          if (col === 'consoles') {
            current.deletedConsoleIds = Array.from(new Set([
              ...(Array.isArray(current.deletedConsoleIds) ? current.deletedConsoleIds : []),
              ...(Array.isArray(incoming.deletedConsoleIds) ? incoming.deletedConsoleIds : []),
              deleteInfo.id,
            ]));
          }

          if (col === 'repairRecords') {
            current.deletedRepairIds = Array.from(new Set([
              ...(Array.isArray(current.deletedRepairIds) ? current.deletedRepairIds : []),
              ...(Array.isArray(incoming.deletedRepairIds) ? incoming.deletedRepairIds : []),
              deleteInfo.id,
            ]));
          }

          if (col === 'vouchers') {
            current.deletedVoucherIds = Array.from(new Set([
              ...(Array.isArray(current.deletedVoucherIds) ? current.deletedVoucherIds : []),
              ...(Array.isArray(incoming.deletedVoucherIds) ? incoming.deletedVoucherIds : []),
              deleteInfo.id,
            ]));
          }
          
          if (col === 'users') {
            current.deletedUserIds = Array.from(new Set([
              ...(Array.isArray(current.deletedUserIds) ? current.deletedUserIds : []),
              ...(Array.isArray(incoming.deletedUserIds) ? incoming.deletedUserIds : []),
              deleteInfo.id,
            ]));
          }

          // Cascading cleanups:
          if (col === 'consoles') {
            current.sessions = (current.sessions || []).map((s: any) => {
              if (s.consoleId === deleteInfo.id && s.status === 'active') {
                return {
                  ...s,
                  status: 'completed',
                  endTime: new Date().toISOString(),
                  notes: s.notes ? `${s.notes} (Auto-closed: console deleted)` : '(Console deleted)',
                };
              }
              return s;
            });
          }
        }
      } else {
        // Smart Non-Destructive Deep Merge across all collections
        const allDeletedConsoleIds = new Set<string>([
          ...(Array.isArray(current.deletedConsoleIds) ? current.deletedConsoleIds : []),
          ...(Array.isArray(incoming.deletedConsoleIds) ? incoming.deletedConsoleIds : []),
          ...Array.from(session.recentlyDeletedIds),
        ]);
        current.deletedConsoleIds = Array.from(allDeletedConsoleIds);

        const allDeletedRepairIds = new Set<string>([
          ...(Array.isArray(current.deletedRepairIds) ? current.deletedRepairIds : []),
          ...(Array.isArray(incoming.deletedRepairIds) ? incoming.deletedRepairIds : []),
          ...Array.from(session.recentlyDeletedIds),
        ]);
        current.deletedRepairIds = Array.from(allDeletedRepairIds);

        const allDeletedVoucherIds = new Set<string>([
          ...(Array.isArray(current.deletedVoucherIds) ? current.deletedVoucherIds : []),
          ...(Array.isArray(incoming.deletedVoucherIds) ? incoming.deletedVoucherIds : []),
          ...Array.from(session.recentlyDeletedIds),
        ]);
        current.deletedVoucherIds = Array.from(allDeletedVoucherIds);

        const allDeletedUserIds = new Set<string>([
          ...(Array.isArray(current.deletedUserIds) ? current.deletedUserIds : []),
          ...(Array.isArray(incoming.deletedUserIds) ? incoming.deletedUserIds : []),
          ...Array.from(session.recentlyDeletedIds),
        ]);
        current.deletedUserIds = Array.from(allDeletedUserIds);

        for (const col of COLLECTIONS) {
          const serverItems = Array.isArray(current[col]) ? current[col] : [];
          const clientItems = Array.isArray(incoming[col]) ? incoming[col] : null;

          if (!clientItems) continue;

          const map = new Map<string, any>();
          for (const item of serverItems) {
            if (item && item.id) {
              if (col === 'consoles' && allDeletedConsoleIds.has(item.id)) continue;
              if (col === 'repairRecords' && allDeletedRepairIds.has(item.id)) continue;
              if (col === 'vouchers' && allDeletedVoucherIds.has(item.id)) continue;
              if (col === 'users' && allDeletedUserIds.has(item.id)) continue;
              map.set(item.id, item);
            }
          }

          for (const clientItem of clientItems) {
            if (!clientItem || !clientItem.id) continue;

            if (session.recentlyDeletedIds.has(clientItem.id)) continue;
            if (col === 'consoles' && allDeletedConsoleIds.has(clientItem.id)) continue;
            if (col === 'repairRecords' && allDeletedRepairIds.has(clientItem.id)) continue;
            if (col === 'vouchers' && allDeletedVoucherIds.has(clientItem.id)) continue;
            if (col === 'users' && allDeletedUserIds.has(clientItem.id)) continue;

            const existing = map.get(clientItem.id);
            if (!existing) {
              map.set(clientItem.id, clientItem);
            } else {
              // Concurrency Protection: If both have updatedAt, only accept if client's is >= server's
              if (clientItem.updatedAt && existing.updatedAt) {
                try {
                  const clientTime = new Date(clientItem.updatedAt).getTime();
                  const serverTime = new Date(existing.updatedAt).getTime();
                  if (clientTime < serverTime) {
                    // This item in the client's payload is stale compared to Drive.
                    // We skip the merge for this item to preserve the newer server state.
                    continue;
                  }
                } catch (e) {
                  // If dates are invalid, proceed with default merge
                }
              }

              if (col === 'consoles') {
                if (clientItem.code && existing.code && String(clientItem.code).trim().toUpperCase() !== String(existing.code).trim().toUpperCase()) {
                  const remappedId = `${clientItem.id}_${String(clientItem.code).replace(/[^a-zA-Z0-9]/g, '')}`;
                  if (!map.has(remappedId) && !allDeletedConsoleIds.has(remappedId)) {
                    map.set(remappedId, { ...clientItem, id: remappedId });
                  }
                  continue;
                }
                map.set(clientItem.id, {
                  ...existing,
                  ...clientItem,
                  hourlyRate: clientItem.hourlyRate || existing.hourlyRate,
                  price1Hour: clientItem.price1Hour || existing.price1Hour || clientItem.hourlyRate || existing.hourlyRate,
                  price2Hour: clientItem.price2Hour !== undefined ? clientItem.price2Hour : existing.price2Hour,
                  price3Hour: clientItem.price3Hour !== undefined ? clientItem.price3Hour : existing.price3Hour,
                  customPricing: Array.isArray(clientItem.customPricing) && clientItem.customPricing.length > 0 ? clientItem.customPricing : existing.customPricing,
                  playerPricing: clientItem.playerPricing || existing.playerPricing,
                  status: clientItem.status || existing.status,
                });
              } else if (col === 'sessions') {
                const isServerCompleted = existing.status === 'completed';
                const finalStatus = isServerCompleted ? 'completed' : clientItem.status || existing.status;
                map.set(clientItem.id, {
                  ...existing,
                  ...clientItem,
                  status: finalStatus,
                  endTime: isServerCompleted ? (existing.endTime || clientItem.endTime) : (clientItem.endTime || existing.endTime),
                  notes: clientItem.notes || existing.notes,
                  splitPayments: clientItem.splitPayments || existing.splitPayments,
                });
              } else if (col === 'users') {
                map.set(clientItem.id, {
                  ...existing,
                  ...clientItem,
                  role: clientItem.role || existing.role,
                  accessCode: clientItem.accessCode || existing.accessCode,
                  pin: clientItem.pin || existing.pin,
                  status: clientItem.status || existing.status,
                });
              } else {
                map.set(clientItem.id, {
                  ...existing,
                  ...clientItem,
                });
              }
            }
          }

          current[col] = Array.from(map.values());
        }

        // Merge Settings
        const incomingSettings = incoming.settings || incomingPayload?.settings;
        if (incomingSettings && typeof incomingSettings === 'object') {
          current.settings = {
            ...current.settings,
            ...incomingSettings,
            businessId: session.businessId,
            adminAccessCode: FIXED_ADMIN_CODE,
          };
        }
      }

      current.lastModified = new Date().toISOString();
      current.settings.lastSyncedAt = current.lastModified;

      // 4. Write directly to Google Drive NextGenGaming_Cafe_Data.xlsx
      let writeSucceeded = false;
      if (drive && folderId) {
        try {
          const writeResult = await writeDriveDatabaseFile(
            drive,
            refreshToken,
            folderId,
            DEFAULT_FILE_NAME,
            targetFileId,
            current,
            vault.customClientId,
            customClientSecret
          );

          session.driveFileId = writeResult.fileId;
          writeSucceeded = true;

          if (writeResult.fileId !== vault.driveFileId) {
            await saveTenantVault({
              businessId: session.businessId,
              ownerUid: session.ownerUid,
              driveFolderId: folderId,
              driveFileId: writeResult.fileId,
            });
          }
        } catch (writeErr: any) {
          console.warn('[dbManager] Drive write notice (preserving in-memory state and connection):', writeErr?.message);
        }
      }

      session.inMemoryDb = current;
      session.isDriveConnected = true;
      session.revision++;

      // 5. Broadcast updated state ONLY to this tenant's connected SSE clients
      this.broadcastUpdate(session, current);

      return {
        data: JSON.parse(JSON.stringify(current)),
        revision: session.revision,
        lastModified: current.lastModified,
        isDriveConnected: true,
      };
    });
  }

  public async registerSseClient(
    req: Request,
    res: Response,
    businessId = NEXTGEN_CAFE_BUSINESS_ID,
    ownerUid?: string
  ) {
    const session = this.getOrCreateTenant(businessId, ownerUid);

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    if (!session.isDriveConnected) {
      await this.syncFromGoogleDrive(session.businessId, session.ownerUid).catch(() => {});
    }

    const current = this.getDatabase(session.businessId, session.ownerUid);
    res.write(
      `data: ${JSON.stringify({
        type: current.isDriveConnected ? 'INIT' : 'DRIVE_STATUS',
        isDriveConnected: current.isDriveConnected,
        revision: current.revision,
        lastModified: current.lastModified,
        data: current.data,
        folderName: FOLDER_NAME,
        fileName: DEFAULT_FILE_NAME,
      })}\n\n`
    );

    session.sseClients.add(res);

    req.on('close', () => {
      session.sseClients.delete(res);
    });
  }

  private broadcastUpdate(session: TenantSession, db: any) {
    const payload = JSON.stringify({
      type: 'DB_UPDATE',
      isDriveConnected: true,
      revision: session.revision,
      lastModified: db.lastModified,
      data: db,
      folderName: FOLDER_NAME,
      fileName: DEFAULT_FILE_NAME,
    });

    const isMatrixTenant = session.businessId.startsWith('biz_matrix_tenant_');

    if (isMatrixTenant) {
      for (const client of session.sseClients) {
        try {
          client.write(`data: ${payload}\n\n`);
        } catch {
          session.sseClients.delete(client);
        }
      }
    } else {
      // Shared single cafe: sync and broadcast to all connected clients
      for (const [bizId, otherSession] of this.tenants.entries()) {
        if (!bizId.startsWith('biz_matrix_tenant_')) {
          otherSession.inMemoryDb = db;
          otherSession.isDriveConnected = true;
          otherSession.revision = session.revision;
          for (const client of otherSession.sseClients) {
            try {
              client.write(`data: ${payload}\n\n`);
            } catch {
              otherSession.sseClients.delete(client);
            }
          }
        }
      }
    }
  }

  private broadcastDisconnect(session: TenantSession) {
    const payload = JSON.stringify({
      type: 'DRIVE_STATUS',
      isDriveConnected: false,
      data: null,
      error: 'Google Drive has been disconnected.',
      folderName: FOLDER_NAME,
      fileName: DEFAULT_FILE_NAME,
    });

    for (const client of session.sseClients) {
      try {
        client.write(`data: ${payload}\n\n`);
      } catch {
        session.sseClients.delete(client);
      }
    }
  }
}

export const cafeDatabaseManager = new CafeDatabaseManager();
